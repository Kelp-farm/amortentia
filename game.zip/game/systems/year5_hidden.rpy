init -8 python:
    def y5_raid_messenger(state=None):
        state=store.vn if state is None else state
        status=state.get("world",{}).get("dobby_status")
        if status=="bound": return "bound_dobby"
        if status in ("free_harry","free_carina"): return "free_dobby"
        return "victoria"

    def y5_source_resolve(sid):
        """Source events, never fabricated player choices. Called once by finish."""
        w=store.vn["world"]
        if sid=="Y5-C2-S11": set_story_flag("y5_carina_conversation")
        if sid=="Y5-C2-S14": set_story_flag("y5_quibbler_banned")
        if sid=="Y5-C2-S17": set_story_flag("y5_gaunt_ring_known")
        if sid=="Y5-C3-S12":
            set_story_flag("y5_pitch_struck")
            set_story_flag("y5_intrusion_recognized")
        if sid=="Y5-C3-S13": set_story_flag("y5_quidditch_banned")
        if sid=="Y5-C3-S14": set_world("da_strength",min(100,w["da_strength"]+15))
        if sid=="Y5-C3-S15": set_story_flag("y5_lucius_visits_questioned")
        if sid=="Y5-C3-S16": set_story_flag("y5_lucius_department_known")
        if sid=="Y5-C4-S11":
            set_story_flag("y5_carina_squad")
            set_story_flag("y5_squad_harm")
            set_world("hogwarts_control","contested")
        if sid=="Y5-C4-S13" and store.vn["relationships"]["carina"]["affection"]>=9 and y5_past_carina():
            set_world("y5_carina_da","silent")
            set_story_flag("y5_carina_da_silence")
        if sid=="Y5-C4-S15": set_story_flag("y5_occlumency_practiced")
        if sid=="Y5-C4-S16": set_story_flag("y5_prophecy_explained")
        if sid=="Y5-C4-S17": set_story_flag("y5_school_quibbler")
        if sid=="Y5-C5-S11":
            set_story_flag("y5_carina_raid_warning")
            set_story_flag("y5_da_betrayed")
            set_world("y5_carina_da","exposed")
            set_story_flag("y5_dumbledore_summoned")
        if sid=="Y5-C5-S12":
            set_story_flag("y5_carina_stunned")
            set_story_flag("y5_carina_warning_heard")
        if sid=="Y5-C5-S13":
            set_story_flag("y5_order_requested")
            set_world("y5_companions","alone")
            set_world("y5_phase","ministry")
        if sid=="Y5-C5-S14": set_story_flag("y5_carina_obstruction_understood")
        if sid=="Y5-C5-S15": set_world("y5_prophecy","destroyed")
        if sid=="Y5-C5-S16":
            set_story_flag("y5_order_contacted")
            if w["sirius_status"]!="dead":
                set_world("sirius_status","dead")
                set_story_flag("y5_sirius_died")
                set_story_flag("y5_thestral_witness")
        if sid=="Y5-C5-S17":
            set_world("ministry_truth","confirmed")
            set_world("death_eaters_exposed",True)
            set_story_flag("y5_voldemort_public")
            if w["lucius_status"]!="dead": set_world("lucius_status","arrested")
            set_world("y5_ending","bereaved")
            set_world("y5_phase","aftermath")
            set_world("hogwarts_control","dumbledore")

    def y5_obsolete_save(state):
        return bool(state.get("year5_entry")) and state["year5_entry"].get("revision")!=3

    def y5_chart_source(origin):
        if origin!="hidden": return False
        w=store.vn.get("world",{})
        # When browsing Hidden from a different/unstarted campaign, display its
        # source-worldline lane. A real Hidden/non-dating campaign keeps its lane.
        return not (w.get("story_origin")=="hidden" and w.get("y4_worldline")=="canon_adjacent")
