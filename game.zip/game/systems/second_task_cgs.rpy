# The hostage is selected by the existing story, never by the illustration.
init 2 python:
    for _heroine, _name in (("carina", "카리나"), ("hermione", "헤르미온느"),
                            ("ginny", "지니"), ("luna", "루나")):
        _asset = _heroine + "_lake_recovery"
        _key = "Y4:" + _asset
        EVENT_CG_ENTRIES[_key] = dict(year=4, asset=_asset,
            title="담요 속의 " + _name, scene="Y4-C5-S04")
        M21_CGS[_key] = EVENT_CG_ENTRIES[_key]

    def y4_lake_recovery_asset():
        hostage = store.vn["world"]["y4_hostage"]
        if hostage in ("carina", "hermione", "ginny", "luna"):
            return hostage + "_lake_recovery"
        return None

label y4_show_lake_recovery:
    if y4_lake_recovery_asset() and not renpy.get_screen("y4_event_cg"):
        show screen y4_event_cg(y4_lake_recovery_asset())
        $ m21_unlock_cg("Y4:" + y4_lake_recovery_asset())
        with Dissolve(0.2)
    return
