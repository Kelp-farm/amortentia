# M6 follow-up: public and private Y3 commitment both enter Hidden. Historical choices are immutable.
init -30 python:
    def m71_restore_commitment_fields(state):
        """Recover missing derived fields from actual recorded consent, not a secrecy bit.

        Do not invent choices/flags or overwrite a contradictory explicit field.
        A secrecy flag alone is ambiguous and remains incompatible with a frozen
        Hidden entry; m6_route_incompatible presents the existing safe restart UI.
        """
        h={r["choice_id"]:r["option_id"] for r in state.get("choices",[])}
        w=state.setdefault("world",{});f=state.get("flags",{})
        visibility=h.get("Y3_DATING_VISIBILITY")
        if (h.get("Y3_COMMITMENT")=="confess" and visibility in ("private","public")
                and f.get("y3_ring_confession") and f.get("y3_quarrel_resolved")):
            w.setdefault("y3_carina_dating",True)
            w.setdefault("y3_carina_visibility",visibility)
            w.setdefault("carina_secret_dating",visibility=="private")

    def carina_hidden_candidate(state=None):
        state=store.vn if state is None else state
        history={r["choice_id"]:r["option_id"] for r in state.get("choices",[])}
        return bool(history.get("Y1_MALKIN_GUIDE")=="accept"
            and history.get("Y2_DIARY_EXPOSURE")=="hide"
            and history.get("Y2_CARINA_DECISION")=="pressure"
            and state.get("world",{}).get("carina_cooperation")=="pressured"
            and state.get("flags",{}).get("y2_carina_knows_horcrux"))

    def carina_hidden_committed(state=None):
        state=store.vn if state is None else state
        history={r["choice_id"]:r["option_id"] for r in state.get("choices",[])}
        w=state.get("world",{});f=state.get("flags",{})
        return bool(carina_hidden_candidate(state)
            and history.get("Y3_COMMITMENT")=="confess"
            and history.get("Y3_DATING_VISIBILITY") in ("private","public")
            and f.get("y3_ring_confession") and f.get("y3_quarrel_resolved")
            and w.get("y3_carina_dating") and w.get("y3_carina_visibility")==history.get("Y3_DATING_VISIBILITY"))

    def ginny_timeline_obsolete(state):
        # Never silently move a previously played confession to another year.
        history=state.get("romance",{}).get("ginny",{}).get("history",())
        return (any(e.get("id") in ("y4_ball_confession","y6_mutual_confession","y6_ginny_cup_kiss") for e in history)
            or any(c.get("choice_id")=="Y6_GINNY_KISS" for c in state.get("choices",())))

    def m6_route_incompatible(state):
        if ginny_timeline_obsolete(state): return True
        # Never rewrite an already-played AU's Moody, deaths or partner history.
        # Check the same recoverable historical fields as after_load, without
        # mutating a saved checkpoint or invalidating its stored fingerprint.
        state = dict(state, world=dict(state.get("world", {})))
        m71_restore_commitment_fields(state)
        hidden=carina_hidden_committed(state)
        if not state.get("year4_entry"):
            return bool(state.get("flags",{}).get("m32_handoff_ready")
                and (state.get("world",{}).get("y4_worldline")=="fanfic") != hidden)
        if (state["year4_entry"].get("worldline")=="fanfic") != hidden: return True
        if not hidden and state.get("romance",{}).get("carina",{}).get("status") in ("dating","separated"):
            return not state.get("flags",{}).get("carina_postwar_reconciled")
        return hidden and not m732_altered(state) and any(r.get("status") in ("dating","separated")
            for h,r in state.get("romance",{}).items() if h!="carina")
