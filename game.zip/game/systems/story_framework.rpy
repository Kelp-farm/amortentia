init -14 python:
    def m42_origin(state=None):
        state = store.vn if state is None else state
        value=state.get("world",{}).get("story_origin")
        if value in ("main","hidden","legacy"): return value
        for choice in state.get("choices",[]):
            if choice["choice_id"]=="Y1_MALKIN_GUIDE":
                return "main" if choice["option_id"]=="decline" else "hidden"
        # No invented shop decision. Old in-progress saves retain the old script.
        if state.get("schema_version",0)<7 and (state.get("choices") or state.get("current_chapter")):
            return "legacy"
        return "pending"

    def m42_main(state=None):
        return m732_altered(state) or m42_origin(state)=="main"

    def m42_hidden(state=None):
        return not m732_altered(state) and m42_origin(state) in ("hidden","legacy")

    def m42_choice_text(cid, option, state=None):
        if m732_altered(state):
            if cid=="Y7_MINISTRY_PLAN" and option["id"]!="rescue": return "엄브릿지와 경비부터 막고 심문받는 사람들을 데리고 나온다."
            if cid=="Y7_RON_ARGUMENT" and option["id"]=="remove": return "가족들 소식을 먼저 확인하자. 내가 모르는 것도 숨기지 않을게."
        if m42_main(state) and cid=="Y3_OUTING" and option["id"]=="carina":
            return "혼자 마을을 둘러본다."
        return option["text"]

    def m42_choice_allowed(cid, state=None):
        state=store.vn if state is None else state
        if cid.startswith("M42_"): return m42_main(state)
        if not m42_main(state): return True
        hidden={"REVIEW_Y3_SIRIUS_REVEAL","Y1_C1_NOTICE","Y1_C4_SNAPE_DEBT","Y2_CARINA_DECISION","Y3_TRAIN_KISS","Y3_POTIONS_VOLUNTEER","Y3_BUCKBEAK_APPEAL",
            "Y3_MEAL_HELP","Y3_BRUSH_HELP","Y3_INVITATION","Y3_CARINA_OUTING","Y3_SECRET",
            "Y3_WINTER_WORDS","Y3_PROMISE_REPLY","Y3_PROMISE_CHANGE","Y3_RING","Y3_RECONCILE",
            "Y3_RON_WARNING","Y3_RESCUE","Y3_PETER","Y3_RECOVERY_FIRST","Y3_RECOVERY",
            "Y3_COMMITMENT","Y3_DATING_VISIBILITY","Y3_CARINA_FAREWELL","Y4_FERRET_WAIT"}
        return cid not in hidden

    def m42_main_finish(sid):
        # Main scene facts never invoke hidden ring / foreknowledge side effects.
        facts={
            "Y3-C1-S05": [("world","buckbeak_status","under_review")],
            "Y3-C3-S06": [("flag","m42_hufflepuff_match",True)],
            "Y3-C4-S09": [("world","buckbeak_status","condemned")],
            "Y3-C5-S02": [("flag","y3_harry_knows_sirius",True),("flag","y3_trio_knows_peter",True)],
            "Y3-C5-S03": [("world","pettigrew_status","escaped"),("flag","y3_snape_brought_group",True)],
            "Y3-C5-S04": [("world","y3_rescue_companion","hermione")],
            "Y3-C6-S02": [("world","buckbeak_status","free")],
            "Y3-C6-S04": [("world","sirius_status","alive"),("world","sirius_legal","fugitive"),
                ("flag","y3_time_turner_returned",True),("world","y3_time_turner_holder","hermione")],
        }
        apply_effects(facts.get(sid,[]))
        if sid=="Y3-C2-S10": set_story_flag("y3_first_hogsmeade_completed")
        if sid=="Y3-C2-S05" and chose("M42_CARINA_SNOW","talk"):
            relationship_event("carina","m42_snow_conversation","memory","겨울 외출에서 잠시 나란히 앉아 이야기를 나눴다.",False)
        if sid=="Y3-C6-S07" and chose("M42_CARINA_FAREWELL","friendly"):
            relationship_event("carina","m42_summer_farewell","memory","열차 복도에서 방학 인사를 나누었다.",False)
        if sid=="Y3-C6-S07": y3_export_handoff()
        set_story_flag("finished_"+sid)
        m41_record_outcomes(sid)
        m33_complete(sid)

    def m42_participants(sid):
        if m42_main() and sid in M42_MAIN_SCENES:
            return ["hermione","carina","ron","ginny","lupin","sirius","peter","snape","hagrid","cedric"]
        return Y3_SCENES[sid]["participants"]
