# Discovery contains IDs only. Playthrough state lives exclusively in native saves.
default persistent.m21_seen = set()
default persistent.m21_completed = set()
default persistent.m21_outcomes = set()
default persistent.m21_cgs = set()
default persistent.m21_endings = set()
default persistent.m21_annual_variants = set()
default persistent.m21_hints = False
default persistent.m21_pending_replay = None
default m21_last_node = None
default m21_capture_done = None
default m21_capture_error = None
default m21_replay_source = None
default m21_choice_guard = None
default m21_session_format = 0
default m21_skip_next_checkpoint = False

init -4 python:
    import hashlib as m21_hashlib
    import json as m21_json
    import time as m21_time

    def m21_save_persistent():
        renpy.save_persistent()
        # A completed, bounded save can exceed the script watchdog on a large
        # replay library (measured 6–9s on Windows). Exclude that I/O time;
        # retain the normal 10s budget for subsequent script execution.
        renpy.not_infinite_loop(10)

    def m21_union(old, new, current):
        return canonical_data(set(old or ()) | set(new or ()) | set(current or ()))

    def m21_add(field, key, flush=True):
        if m33_active(): return False
        values = set(getattr(persistent, field, None) or ())
        if key not in values:
            values.add(key)
            setattr(persistent, field, values)
            if flush: m21_save_persistent()
            return True
        return False

    def m21_seen_node(nid):
        return nid in (persistent.m21_seen or set())

    def m21_visit(nid):
        if nid not in (persistent.m21_seen or set()): m41_stop_skip()
        if nid in M21_NODES and M21_NODES[nid]["type"]=="scene": store.m41_presented_scene=nid
        if m33_active(): return
        if nid not in M21_NODES:
            return
        # Commit this transition once. Each flush serializes the full replay
        # history, which is large by Years 6–7 even for one new discovery.
        dirty=m21_add("m42_seen",("main" if m42_main() else "hidden")+":"+nid,False)
        if M21_NODES[nid]["type"] == "scene": dirty=bool(m33_scene_started(nid)) or dirty
        store.m21_session_format = 1
        previous = store.m21_last_node
        # Review starts/new campaigns must not complete an unrelated previous scene.
        if previous in M21_NODES and previous != nid and m21_seen_node(previous):
            if M21_NODES[previous]["chapter"] == store.vn["current_chapter"]:
                dirty=m21_add("m21_completed", previous,False) or dirty
        dirty=m21_add("m21_seen", nid,False) or dirty
        store.m21_last_node = nid
        if dirty: m21_save_persistent()

    def m21_before_choice(cid):
        m41_stop_skip()
        cid = canonical_name(cid)
        store.m21_capture_done = None
        store.m21_capture_error = None
        store.m21_choice_guard = None if store.m21_skip_next_checkpoint else cid
        store.m21_skip_next_checkpoint = False
        store.m21_session_format = 1
        if cid in M21_NODES:
            m21_visit(cid)

    def m21_after_choice(cid, oid):
        cid, oid = canonical_name(cid), canonical_name(oid)
        m33_choice(cid,oid)
        if cid in M21_NODES:
            dirty=m21_add("m21_completed", cid,False)
            dirty=m21_add("m21_outcomes", cid + ":" + oid,False) or dirty
            if dirty: m21_save_persistent()
        store.m21_choice_guard = None

    def m21_finish_chapter():
        m33_complete()
        if store.m21_last_node in M21_NODES:
            m21_add("m21_completed", store.m21_last_node)
        store.m21_last_node = None

    def m21_cg_path(key):
        meta = M21_CGS[key]
        return {1:Y1_CGS,2:Y2_CGS,3:Y3_CGS,4:Y4_CGS,5:Y5_CGS,6:Y6_CGS,7:Y7_CGS}[meta["year"]][meta["asset"]]

    def m21_unlock_cg(key):
        if key not in (persistent.m21_cgs or set()): m41_stop_skip()
        if key in M21_CGS and renpy.loadable(m21_cg_path(key)):
            m21_add("m21_cgs", key)

    def m21_annual(year):
        m21_finish_chapter()
        m21_add("m21_endings", "annual_y%d" % year)
        if year == 6:
            m21_add("m21_annual_variants","Y6:"+store.vn["world"]["y6_next_campaign"])
        if year == 5:
            m21_add("m21_annual_variants","Y5:%s:%s:%s" % (store.vn["world"]["y5_ending"],store.vn["world"]["sirius_status"],store.vn["world"]["ministry_truth"]))
        if year == 4:
            m21_add("m21_annual_variants","Y4:%s:%s:%s" % (store.vn["world"]["y4_worldline"],store.vn["world"]["y4_cedric"],store.vn["world"]["y4_partner"]))
        if year == 3:
            variant = "Y3:%s:%s" % (store.vn["world"]["y3_rescue_companion"],store.vn["world"]["pettigrew_status"])
            m21_add("m21_annual_variants",variant)
            if store.vn["flags"].get("m32_handoff_ready"):
                m21_add("m21_annual_variants","M32:%s:%s:%s" % (store.vn["world"]["y3_carina_bond"],store.vn["world"]["y3_rescue_companion"],store.vn["world"]["y3_carina_visibility"]))
        if year == 2:
            variant = "%s:%s" % (store.vn["world"]["dobby_status"], store.vn["world"]["carina_cooperation"])
            m21_add("m21_annual_variants", variant)

    def m21_fingerprint(state):
        return m21_hashlib.sha256(m21_json.dumps(state, ensure_ascii=True, sort_keys=True).encode("utf-8")).hexdigest()

    def m21_slots(cid):
        names = [cid]
        names += [old for old, new in LEGACY_CARINA_IDS.items() if new == cid and old != cid]
        return ["m21cp_%s_%d" % (name, index) for name in names for index in range(2)]

    def m21_checkpoint_info(slot, cid):
        try:
            if not renpy.can_load(slot):
                return None
            data = canonical_data(renpy.slot_json(slot) or {})
            if data.get("m21_format") != M21_CHECKPOINT_FORMAT or data.get("m21_compat") != M21_CHECKPOINT_COMPAT or data.get("m21_choice") != cid:
                return None
            if cid.startswith("Y3_") and CHOICES[cid]["chapter_id"] in ("Y3-C2", "Y3-C3") and data.get("m31g_timeline") != 2:
                return None
            if cid.startswith("Y3_") and CHOICES[cid]["chapter_id"] in ("Y3-C4","Y3-C5","Y3-C6") and data.get("m32_finale") != 1:
                return None
            if cid.startswith("Y3_") and CHOICES[cid]["chapter_id"] in ("Y3-C3","Y3-C4","Y3-C5","Y3-C6") and data.get("m4d_winter") != 1:
                return None
            return data
        except Exception:
            return None

    def m21_checkpoints(cid):
        entries = [(slot, m21_checkpoint_info(slot, cid)) for slot in m21_slots(cid)]
        return sorted([(s, d) for s, d in entries if d], key=lambda row: row[1].get("m21_time", 0), reverse=True)

    def m21_capture(cid):
        cid = canonical_name(cid)
        if m33_active(): return
        if store.m21_capture_done == cid:
            return
        store.m21_capture_done = cid
        if cid not in M21_NODES or M21_NODES[cid]["type"] != "choice":
            return
        if store.m21_choice_guard != cid:
            store.m21_capture_error = "이전 저장에서 이어온 선택입니다. 다음 선택부터 체크포인트를 남깁니다."
            return
        try:
            if any(c["choice_id"] == cid for c in store.vn["choices"]):
                raise ValueError("선택 전 기록이 아닙니다.")
            fingerprint = m21_fingerprint(store.vn)
            entries = [(slot,data) for slot,data in m21_checkpoints(cid) if mpr_save_is_trusted(slot)]
            if any(data["m21_state"] == fingerprint for slot, data in entries):
                return
            available = [slot for slot in m21_slots(cid) if slot not in [s for s, d in entries]]
            slot = available[0] if available else entries[-1][0]
            meta = dict(m21_format=M21_CHECKPOINT_FORMAT, m21_compat=M21_CHECKPOINT_COMPAT,
                m31g_timeline=2, m32_finale=1, m4d_winter=1,
                m21_choice=cid, m21_state=fingerprint, m21_time=m21_time.time(),
                m21_date=m21_time.strftime("%m/%d %H:%M"),
                m21_origin=("검수 시작" if store.vn.get("flags", {}).get("y1_review_preset") or store.vn.get("flags", {}).get("y2_review_preset") else "본편 진행"),
                m21_history=len(store.vn["choices"]))
            renpy.take_screenshot()
            # Executed by the timer INSIDE call screen important_choice: native save
            # resumes that unresolved interaction with its entire Ren'Py call stack.
            renpy.save(slot, extra_info="선택 직전 · " + M21_NODES[cid]["title"], extra_json=meta)
        except Exception as exc:
            store.m21_capture_error = "체크포인트를 저장하지 못했습니다. 수동 저장을 이용해 주세요."
            renpy.log("M2.1 checkpoint capture: %r" % exc)
        renpy.restart_interaction()

    def m21_replay(slot, cid, option=None):
        if m33_active(): return
        meta = m21_checkpoint_info(slot, cid)
        try:
            if not meta or slot not in m21_slots(cid):
                raise ValueError("기록이 없거나 현재 버전과 호환되지 않습니다.")
            saved = renpy.get_save_data(slot)
            state = saved.get("vn")
            if state is None or m21_fingerprint(state) != meta["m21_state"]:
                raise ValueError("체크포인트의 상태를 확인할 수 없습니다.")
            if m6_route_incompatible(state):
                raise ValueError("개정 전 세계선의 저장입니다. 3학년 완료 전부터 다시 시작해 주세요.")
            if y5_obsolete_save(state):
                raise ValueError("등장인물과 경고 전달자가 바뀐 이전 5–7학년 저장입니다. 4학년 완료 저장에서 이어 주세요.")
            if canonical_name(saved.get("m21_choice_guard")) != cid or any(canonical_name(c["choice_id"]) == cid for c in state["choices"]):
                raise ValueError("선택 직전의 기록이 아닙니다.")
        except Exception as exc:
            renpy.notify(str(exc))
            return
        if option is not None and slot not in [s for s,m in m42_branch_checkpoints(cid,option)]:
            renpy.notify("이 분기를 적용할 수 있는 저장이 없습니다.")
            return
        persistent.m21_pending_replay = dict(choice=cid, option=option, date=meta["m21_date"], origin=meta["m21_origin"], fingerprint=meta["m21_state"])
        renpy.load(slot)

    def m21_after_load():
        pending = persistent.m21_pending_replay
        store.m42_direct_choice = dict(choice=pending["choice"],option=pending["option"]) if pending and pending.get("option") else None
        # Loading a manual/legacy save is not a new arrival at a choice.
        # In particular, new store defaults must never turn old saves into
        # purported historical automatic checkpoints.
        store.m21_choice_guard = pending["choice"] if pending else None
        store.m21_skip_next_checkpoint = (not pending and store.m21_session_format == 0)
        store.m21_session_format = 1
        if pending:
            store.m21_replay_source = pending
            persistent.m21_pending_replay = None
            m21_save_persistent()
            renpy.retain_after_load()
        # A legacy manual save proves its logged choices, not unseen CGs or scenes.
        # Review presets contain fabricated earlier choices and cannot prove those.
        if not store.vn.get("flags", {}).get("y1_review_preset") and not store.vn.get("flags", {}).get("y2_review_preset"):
            for row in store.vn.get("choices", []):
                cid = row["choice_id"]
                if cid in M21_NODES:
                    m21_add("m21_seen", cid)
                    m21_add("m21_completed", cid)
                    m21_add("m21_outcomes", cid + ":" + row["option_id"])
        store.m21_capture_done = None

        renpy.retain_after_load()

    def m21_progress(year):
        nodes = [nid for nid, node in M21_NODES.items() if node["year"] == year and node["implemented"]]
        return (sum(m21_seen_node(nid) for nid in nodes), len(nodes))

    def m21_outcome_progress(year):
        outcomes = {cid + ":" + option["id"] for cid, node in M21_NODES.items() if node["year"] == year and node["type"] == "choice" and node["implemented"] for option in CHOICES[cid]["options"]}
        return (len(outcomes & set(persistent.m21_outcomes or ())), len(outcomes))

    def m21_status(nid):
        if not m21_seen_node(nid):
            return "미발견"
        if M21_NODES[nid]["type"] == "choice":
            return "다시 선택 가능" if m21_checkpoints(nid) else "발견 · 저장 기록 없음"
        return "완료" if nid in persistent.m21_completed else "발견"

init python:
    for field in ("m21_seen", "m21_completed", "m21_outcomes", "m21_cgs", "m21_endings", "m21_annual_variants"):
        renpy.register_persistent(field, m21_union)
