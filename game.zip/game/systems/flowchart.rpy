default m42_direct_choice = None
default persistent.m42_seen = set()

init 1 python:
    M41_VARIANT_SCENES.update(M42_MAIN_SCENES)

    def m42_seen(nid,origin):
        sid=M21_NODES[nid]["scene"]
        if sid not in M42_MAIN_SCENES: return m21_seen_node(nid)
        if origin+":"+nid in (persistent.m42_seen or set()): return True
        if origin=="hidden": return m21_seen_node(nid) and "main:"+nid not in (persistent.m42_seen or set())
        return False
    def m42_chart_origin():
        return "hidden" if m42_hidden() else "main"

    def m42_chart_nodes(year,chapter,origin):
        state=state_copy(store.vn);state["world"]["story_origin"]=origin
        return [nid for nid in M21_CHAPTER_NODES.get("Y%d-C%d"%(year,chapter),[]) if
            not (year==7 and ((M21_NODES[nid]["scene"] in Y7_SOURCE_SCENES) != (origin=="hidden"))) and
            not (year==6 and ((M21_NODES[nid]["scene"] in Y6_SOURCE_SCENES) != (origin=="hidden"))) and
            not (year==5 and ((M21_NODES[nid]["scene"] in Y5_SOURCE_SCENES) != y5_chart_source(origin))) and
            not (origin=="main" and M21_NODES[nid]["scene"] in M42_HIDDEN_SCENES) and
            not (year==4 and origin=="hidden" and Y4_SCENES[M21_NODES[nid]["scene"]]["condition"]=="canon_adjacent") and
            (M21_NODES[nid]["type"]!="choice" or m42_choice_allowed(nid,state))]

    def m42_graph(year,chapter,origin):
        """A bounded chapter slice of one year's graph; coordinates in logical pixels."""
        if year==7 and origin=="main" and chapter in (10,11,12):
            return y7_branch_graph(chapter)
        boxes=[];edges=[];y=14;center=354;previous=None;previous_id=None;tails={}
        ministry=(year==5 and chapter==5 and "Y5_DEPART" in m42_chart_nodes(year,chapter,origin))
        def line(x1,y1,x2,y2,cid=None,oid=None):
            edges.append(dict(x=min(x1,x2),y=min(y1,y2),w=max(2,abs(x2-x1)),h=max(2,abs(y2-y1)),cid=cid,oid=oid))
        for nid in m42_chart_nodes(year,chapter,origin):
            node=M21_NODES[nid];height=82
            disconnected=ministry and (nid in ("Y5-C5-S08","Y5-C5-S09","Y5-C5-S10") or previous_id=="Y5_DEPART")
            if previous is not None and not disconnected: line(center,previous,center,y)
            boxes.append(dict(nid=nid,oid=None,x=center-164,y=y,w=328,h=height))
            previous=y+height;y=previous+28
            if node["type"]=="choice":
                opts=CHOICES[nid]["options"];w=min(210,int(690/len(opts))-12)
                roww=len(opts)*(w+12)-12;left=center-roww/2
                for i,opt in enumerate(opts):
                    x=int(left+i*(w+12));cx=x+w/2
                    line(center,previous,center,previous+12,nid,opt["id"])
                    line(center,previous+12,cx,previous+12,nid,opt["id"])
                    line(cx,previous+12,cx,y,nid,opt["id"])
                    boxes.append(dict(nid=nid,oid=opt["id"],x=x,y=y,w=w,h=112))
                    if not (ministry and nid=="Y5_DEPART"):
                        line(cx,y+112,cx,y+128,nid,opt["id"])
                        line(cx,y+128,center,y+128,nid,opt["id"])
                previous=y+128;y=previous+30
            tails[nid]=previous;previous_id=nid
        if ministry:
            def box(nid,oid=None): return next(b for b in boxes if b["nid"]==nid and b["oid"]==oid)
            def route(x,source_y,target,lane,cid=None,oid=None):
                target_y=box(target)["y"]-8
                line(x,source_y,x,source_y+6,cid,oid)
                line(x,source_y+6,lane,source_y+6,cid,oid)
                line(lane,source_y+6,lane,target_y,cid,oid)
                line(lane,target_y,center,target_y,cid,oid)
                line(center,target_y,center,target_y+8,cid,oid)
            for oid in ("wait","team","alone"):
                b=box("Y5_DEPART",oid)
                route(b["x"]+b["w"]/2,b["y"]+b["h"],"Y5-C5-S08" if oid=="wait" else "Y5-C5-S04",12 if oid=="wait" else 700,"Y5_DEPART",oid)
            route(center,tails["Y5_LUCIUS"],"Y5-C5-S09",24)
            line(center,tails["Y5-C5-S08"],center,box("Y5-C5-S09")["y"])
            b=box("Y5_BATTLE","pursue")
            route(b["x"]+b["w"]/2,b["y"]+b["h"],"Y5-C5-S10",714,"Y5_BATTLE","pursue")
        return dict(boxes=boxes,edges=edges,height=y+12,width=724)

    def m42_guidance_nodes(target):
        if not target or M41_TARGETS[target]["kind"]=="future": return {}
        # M41's proof names the exact same requirements used for recommendations.
        result=m41_evaluate(target,store.vn)
        return {r["cid"]:r["oid"] for r in result["rows"] if r.get("cid") and r["status"]!="satisfied"}

    def m42_guidance_years(target):
        return sorted({M41_CHOICE_ORDER[cid][0] for cid in m42_guidance_nodes(target)})

    def m42_guide_destination(target):
        ids=m42_guidance_nodes(target)
        if not ids: return (1,1,None)
        cid=min(ids,key=lambda c:M41_CHOICE_ORDER[c]);node=M21_NODES.get(cid) or M21_NODES[M41_CHOICE_SCENE[cid]]
        return node["year"],int(node["chapter"].split("-C")[1]),cid if cid in M21_NODES else node["id"]

    def m42_graph_y(graph,nid,zoomed=False):
        box=next((b for b in graph["boxes"] if b["nid"]==nid and b["oid"] is None),None)
        return int(max(0,box["y"]-24)*(1.55 if zoomed else 1)) if box else 0

    def m42_node_status(nid,origin):
        status=m21_status(nid)
        node=M21_NODES[nid]
        if origin==m42_chart_origin() and m21_seen_node(nid) and node["type"]=="scene":
            if node["chapter"]==store.vn.get("current_chapter") and node.get("optional"):
                available=(y3_scene_available(nid) if node["year"]==3 else y4_scene_available(nid) if node["year"]==4 else y5_scene_available(nid) if node["year"]==5 else y6_scene_available(nid) if node["year"]==6 else y7_scene_available(nid) if node["year"]==7 else True)
                if not available: return status+" · 현재 진행에서는 잠김"
        return status

    def m42_option_in_state(cid,oid,state):
        if not m42_choice_allowed(cid,state): return False
        old=store.vn
        try:
            store.vn=state
            if cid.startswith("Y3_") or cid=="REVIEW_Y3_SIRIUS_REVEAL": return y3_option_available(cid,oid)
            if cid.startswith("Y7_"): return y7_option_available(cid,oid)
            if cid.startswith("Y6_"): return y6_option_available(cid,oid)
            if cid.startswith("Y5_"): return y5_option_available(cid,oid)
            if cid.startswith("Y4_"): return y4_option_available(cid,oid)
            return oid in [o["id"] for o in CHOICES[cid]["options"]]
        finally: store.vn=old

    def m42_branch_checkpoints(cid,oid):
        if cid+":"+oid not in (persistent.m21_outcomes or set()) or m33_active(): return []
        rows=[]
        for slot,meta in m21_checkpoints(cid):
            try:
                saved=renpy.get_save_data(slot);raw=saved.get("vn")
                if raw is None or m21_fingerprint(raw)!=meta["m21_state"]: continue
                if canonical_name(saved.get("m21_choice_guard"))!=cid or choice_record(cid,raw): continue
                state=migrate_state(raw)
                if m6_route_incompatible(state): continue
                if y5_obsolete_save(state): continue
                if state.get("current_chapter")!=CHOICES[cid]["chapter_id"]: continue
                if m42_option_in_state(cid,oid,state): rows.append((slot,meta))
            except Exception: continue
        return rows

    def m42_switch_branch(slot,cid,oid):
        if slot not in [s for s,m in m42_branch_checkpoints(cid,oid)]:
            renpy.notify("이 이력에서는 선택을 적용할 수 없습니다.")
            return
        m21_replay(slot,cid,oid)

    def m42_direct_ready(cid):
        request=getattr(store,"m42_direct_choice",None)
        return bool(request and request["choice"]==cid and not choice_record(cid)
            and cid+":"+request["option"] in (persistent.m21_outcomes or set())
            and m42_option_in_state(cid,request["option"],store.vn))

    def m42_take_direct():
        store.m42_direct_choice=None

    def m42_thumbnail(nid,origin):
        sid=M21_NODES[nid]["scene"]
        if origin=="main" and sid in M42_MAIN_SCENES and sid!="Y3-C6-S02": return None
        return next((m21_cg_path(k) for k,v in M21_CGS.items() if v["scene"]==sid
            and not v.get("legacy") and k in persistent.m21_cgs),None)

init python:
    renpy.register_persistent("m42_seen",m21_union)
