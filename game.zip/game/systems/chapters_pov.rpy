init -30 python:
    def begin_chapter(chapter_id):
        require_key(CHAPTERS, chapter_id)
        if store.vn["current_chapter"] is not None:
            raise ValueError("Complete the active chapter first")
        if chapter_id in store.vn["chapters"]:
            raise ValueError("Chapter already visited; use a new ID")
        candidate = state_copy(store.vn)
        metadata = state_copy(CHAPTERS[chapter_id])
        metadata.update({"id": chapter_id, "route": candidate["current_route"],
                         "choice_ids": [], "completed": False, "summary": "",
                         "povs": [metadata["pov"]]})
        candidate["chapters"][chapter_id] = metadata
        candidate["current_chapter"] = chapter_id
        candidate["current_pov"] = metadata["pov"]
        store.vn = candidate

    def complete_chapter(summary):
        chapter_id = store.vn["current_chapter"]
        if chapter_id is None or store.vn["pov_stack"]:
            raise ValueError("No active chapter, or a POV interlude is still open")
        candidate = state_copy(store.vn)
        candidate["chapters"][chapter_id]["completed"] = True
        candidate["chapters"][chapter_id]["summary"] = summary
        candidate["chapters"][chapter_id]["route"] = candidate["current_route"]
        candidate["current_chapter"] = None
        store.vn = candidate
        return chapter_id

    def set_pov(pov):
        require_key(POV_NAMES, pov)
        candidate = state_copy(store.vn)
        candidate["current_pov"] = pov
        chapter_id = candidate["current_chapter"]
        if chapter_id and pov not in candidate["chapters"][chapter_id]["povs"]:
            candidate["chapters"][chapter_id]["povs"].append(pov)
        store.vn = candidate

    def push_pov(pov):
        require_key(POV_NAMES, pov)
        candidate = state_copy(store.vn)
        candidate["pov_stack"].append(candidate["current_pov"])
        store.vn = candidate
        set_pov(pov)

    def pop_pov():
        if not store.vn["pov_stack"]:
            raise ValueError("No POV to return to")
        candidate = state_copy(store.vn)
        previous = candidate["pov_stack"].pop()
        store.vn = candidate
        set_pov(previous)

label vn_chapter(chapter_id):
    $ begin_chapter(chapter_id)
    call screen chapter_title(chapter_id)
    return

label vn_pov(pov, title=None):
    $ push_pov(pov)
    if title:
        call screen pov_interlude(title)
    return

label vn_return_pov(title=None):
    $ pop_pov()
    if title:
        call screen pov_interlude(title)
    return

label vn_end_chapter(summary):
    $ m21_finish_chapter()
    $ completed_chapter_id = complete_chapter(summary)
    call screen chapter_statistics(completed_chapter_id)
    return
