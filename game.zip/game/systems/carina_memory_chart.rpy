init 4 python:
    M732_BRANCH_DESTINATIONS={
        "Y4_MEMORY_CONSENT":{"stop":"Y4-C8-S08","proceed":"Y4-C8-S09"},
        "Y7_MEMORY_OFFER":{"tell":"Y7-C9-S21","defer":"Y7-C9-S06"},
        "Y7_MEMORY_RESTORE":{"restore":"Y7-C9-S22","decline":"Y7-C9-S06"},
        "Y7_MEMORY_CURRENT":{"stay":"Y7-C9-S22","end":"Y7-C9-S24"},
        "Y7_MEMORY_LISTEN":{"listen":"Y7_MEMORY_PRESENT","explain":"Y7_MEMORY_PRESENT"},
        "Y7_MEMORY_PRESENT":{"present":"Y7-C9-S22","past":"Y7-C9-S22"},
        "Y7_MEMORY_FUTURE":{"friends":"Y7-C9-S06","again":"Y7-C9-S06"}}
    for _cid,_dest in M732_BRANCH_DESTINATIONS.items():
        M21_NODES[_cid]["branch_destinations"]=dict(_dest)

    def m732_graph(year):
        boxes=[];edges=[];links=[]
        # Compact chart captions; the selection panel retains the full dialogue.
        captions={
            "Y4_MEMORY_PLAN":{"keep":"기억을\n남긴다","prepare":"변경을\n준비한다"},
            "Y4_MEMORY_CONSENT":{"stop":"여기서\n중단한다","proceed":"합의한 변경을\n진행한다"},
            "Y7_MEMORY_OFFER":{"tell":"과거를\n이야기한다","defer":"지금은\n말하지 않는다"},
            "Y7_MEMORY_RESTORE":{"restore":"기억을\n되찾는다","decline":"복원을\n원하지 않는다"},
            "Y7_MEMORY_CURRENT":{"stay":"현재 연인과\n계속 만난다","end":"직접 만나\n교제를 끝낸다"},
            "Y7_MEMORY_LISTEN":{"listen":"카리나의\n시간을 듣는다","explain":"해리의\n시간을 말한다"},
            "Y7_MEMORY_PRESENT":{"present":"새 약속을\n함께 정한다","past":"예전 길을\n다시 걷는다"},
            "Y7_MEMORY_FUTURE":{"friends":"친구로\n남는다","again":"재회를\n제안한다"}}
        def box(nid,x,y,w=328,h=82,oid=None):
            b=dict(nid=nid,oid=oid,x=x,y=y,w=w,h=h);boxes.append(b);return b
        def line(x1,y1,x2,y2,cid=None,oid=None):
            edges.append(dict(x=min(x1,x2),y=min(y1,y2),w=max(2,abs(x2-x1)),h=max(2,abs(y2-y1)),cid=cid,oid=oid))
        def edge(a,b,cid=None,oid=None,lane=None):
            ax=a["x"]+a["w"]/2;ay=a["y"]+a["h"];bx=b["x"]+b["w"]/2;by=b["y"]
            if lane is None:
                mid=by-14
                line(ax,ay,ax,mid,cid,oid);line(ax,mid,bx,mid,cid,oid);line(bx,mid,bx,by,cid,oid)
            else:
                line(ax,ay,ax,ay+10,cid,oid);line(ax,ay+10,lane,ay+10,cid,oid)
                line(lane,ay+10,lane,by-14,cid,oid);line(lane,by-14,bx,by-14,cid,oid);line(bx,by-14,bx,by,cid,oid)
            links.append((a["nid"],b["nid"],cid,oid))
        def options(cid,x,y,w=328):
            root=box(cid,x,y,w);opts=[]
            for i,opt in enumerate(CHOICES[cid]["options"]):
                b=box(cid,x+i*(w/2+4),y+110,w/2-4,112,opt["id"])
                b["title"]=captions[cid][opt["id"]]
                edge(root,b,cid,opt["id"]);opts.append(b)
            return root,opts
        if year==4:
            prefix=[box("Y4-C8-S%02d"%n,198,14+i*110) for i,n in enumerate((1,2,4,10))]
            for a,b in zip(prefix,prefix[1:]): edge(a,b)
            plan,po=options("Y4_MEMORY_PLAN",198,454);edge(prefix[-1],plan)
            common=[box("Y4-C8-S%02d"%n,198,735+i*110) for i,n in enumerate((5,6,7))]
            for b in po:edge(b,common[0],"Y4_MEMORY_PLAN",b["oid"])
            for a,b in zip(common,common[1:]):edge(a,b)
            farewell=box("Y4-C8-S11",380,1100)
            consent,co=options("Y4_MEMORY_CONSENT",380,1210)
            old=box("Y4-C8-S08",16,1510);train=box("Y4-C8-S09",198,1720)
            edge(common[-1],old,"Y4_MEMORY_PLAN","keep",6)
            edge(common[-1],farewell,"Y4_MEMORY_PLAN","prepare",720)
            edge(farewell,consent)
            edge(co[0],old,"Y4_MEMORY_CONSENT","stop",350)
            edge(co[1],train,"Y4_MEMORY_CONSENT","proceed",720)
            edge(old,train)
            return dict(boxes=boxes,edges=edges,links=links,width=724,height=1830)
        prefix=[box("Y7-C9-S%02d"%n,198,14+i*110) for i,n in enumerate((1,2,3,4,20))]
        for a,b in zip(prefix,prefix[1:]):edge(a,b)
        offer,oo=options("Y7_MEMORY_OFFER",198,564);edge(prefix[-1],offer)
        restore=box("Y7-C9-S21",380,850);decision,ro=options("Y7_MEMORY_RESTORE",380,960)
        current=box("Y7-C9-S23",380,1240)
        current["title"]="현재 연인이 있으면 · 먼저 해야 할 이야기"
        commitment,co=options("Y7_MEMORY_CURRENT",380,1350)
        rapport=box("Y7-C9-S24",380,1640)
        listen,lo=options("Y7_MEMORY_LISTEN",380,1750)
        present,po=options("Y7_MEMORY_PRESENT",380,2010)
        adjustment=box("Y7-C9-S22",380,2300);future,fo=options("Y7_MEMORY_FUTURE",380,2410)
        career=box("Y7-C9-S06",198,2740)
        edge(oo[0],restore,"Y7_MEMORY_OFFER","tell")
        edge(oo[1],career,"Y7_MEMORY_OFFER","defer",6)
        edge(restore,decision);edge(ro[0],current,"Y7_MEMORY_RESTORE","restore")
        edge(current,commitment)
        edge(co[0],adjustment,"Y7_MEMORY_CURRENT","stay",350)
        edge(co[1],rapport,"Y7_MEMORY_CURRENT","end")
        # Without a current partner the conditional scene/choice is skipped.
        edge(ro[0],rapport,"Y7_MEMORY_RESTORE","restore",720)
        edge(rapport,listen)
        for b in lo: edge(b,present,"Y7_MEMORY_LISTEN",b["oid"])
        for b in po: edge(b,adjustment,"Y7_MEMORY_PRESENT",b["oid"])
        edge(ro[1],career,"Y7_MEMORY_RESTORE","decline",18)
        edge(adjustment,future)
        # Staying with a partner reaches the closure dialogue, not a new proposal.
        edge(adjustment,career,"Y7_MEMORY_CURRENT","stay",350)
        for b in fo:edge(b,career,"Y7_MEMORY_FUTURE",b["oid"])
        return dict(boxes=boxes,edges=edges,links=links,width=724,height=2850)

    _m732_previous_graph=m42_graph
    def m42_graph(year,chapter,origin):
        if year==4 and chapter==8 and origin=="hidden": return m732_graph(4)
        if year==7 and chapter==9 and origin=="main" and m732_altered(): return m732_graph(7)
        return _m732_previous_graph(year,chapter,origin)
