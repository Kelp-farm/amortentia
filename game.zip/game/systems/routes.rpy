init -10 python:
    def evaluate_routes(state=None):
        state = state or store.vn
        results = {}
        for heroine in HEROINE_IDS:
            rule = ROUTE_RULES[heroine]
            relationship = state["relationships"][heroine]
            reasons = []
            for metric, minimum in rule["minimums"].items():
                if relationship[metric] < minimum:
                    reasons.append("%s below demo requirement" % metric)
            for key in rule["keys"]:
                if not relationship["route_key"].get(key, False):
                    reasons.append("Missing key: %s" % key)
            for key, minimum in rule["special_min"].items():
                if state["special"][key] < minimum:
                    reasons.append("Route condition: %s" % key)
            for key, allowed in rule["world_allowed"].items():
                if state["world"][key] not in allowed:
                    reasons.append("World condition: %s" % key)
            for choice_id, option_id in rule["choices"]:
                if not chose(choice_id, option_id, state):
                    reasons.append("Required decision: %s" % choice_id)
            if state["route_intent"] != heroine:
                reasons.append("No explicit player interest in this route")
            if (heroine == "carina" and state["world"].get("carina_early_romance_blocked")
                and not (state["flags"].get("voldemort_final_defeat") and state["flags"].get("carina_postwar_reconciled"))):
                reasons.append("Reconciliation is closed until after the war")
            results[heroine] = {"eligible": not reasons, "reasons": reasons}
        results["no_romance"] = {"eligible": True, "reasons": []}
        return results

    def lock_route(route):
        require_key(ROUTE_NAMES, route)
        if store.vn["current_route"] is not None:
            if store.vn["current_route"] == route:
                return
            raise ValueError("A route is already locked; roll back before changing it")
        if not evaluate_routes()[route]["eligible"]:
            raise ValueError("Route is not eligible")
        candidate = state_copy(store.vn)
        candidate["current_route"] = route
        store.vn = candidate

label vn_route_demo:
    call screen route_evaluation
    $ lock_route(_return)
    return
