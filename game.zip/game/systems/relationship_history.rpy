# Additive save data. Dating, memories, route commitment and cooperation are independent.
init -29 python:
    def apply_relationship_event(state, heroine, event_id, action, detail, agreed=False):
        require_key(state["romance"], heroine)
        if not isinstance(event_id, str) or not event_id or not isinstance(detail, str):
            raise ValueError("Relationship events need a stable id and text")
        if type(agreed) is not bool:
            raise ValueError("Agreement must be explicit")
        if action in ("start","reconcile") and cho_active(state):
            raise ValueError("An active Cho relationship must end before another commitment")
        if heroine!="carina" and action in ("start","reconcile") and carina_hidden_campaign(state):
            raise ValueError("The committed Carina story does not allow a replacement romance")
        if (heroine == "carina" and action in ("start","reconcile")
            and state["world"].get("carina_early_romance_blocked")
            and not (state["flags"].get("voldemort_final_defeat") and state["flags"].get("carina_postwar_reconciled"))):
            raise ValueError("Carina reconciliation is closed until the postwar Year 7 event")
        bucket = state["romance"][heroine]
        path = ["romance", heroine]
        before = state_copy(bucket)
        for entry in bucket["history"]:
            if entry["id"] == event_id:
                if (entry["action"], entry["detail"], entry["agreed"]) != (action, detail, agreed):
                    raise ValueError("Relationship event already recorded differently")
                return {"kind": "relationship_event", "path": path, "before": before, "after": state_copy(bucket)}
        if action in ("start","reconcile"):
            if any(h!=heroine for h in romance_commitments(state)):
                raise ValueError("End the current relationship explicitly before another commitment")
            if romance_unresolved(heroine,state):
                raise ValueError("The earlier romantic conflict with this person remains unresolved")
        allowed = {
            "start": ("none",), "publish": ("dating",), "privatize": ("dating",),
            "separate": ("dating",), "breakup": ("dating", "separated"),
            "reconcile": ("separated", "ended"),
        }
        if action != "memory":
            if action not in allowed or bucket["status"] not in allowed[action]:
                raise ValueError("Invalid relationship transition")
            if action in ("start", "publish", "reconcile") and not agreed:
                raise ValueError("This transition needs the heroine's agreement in the scene")
            if action == "start":
                year = CHAPTERS.get(state["current_chapter"], {}).get("year", 0)
                if year < 2:
                    raise ValueError("Year 1 records companionship, not a dating commitment")
            if action in ("start", "reconcile"):
                bucket["status"], bucket["visibility"] = "dating", "private"
            elif action == "publish":
                bucket["visibility"] = "public"
            elif action == "privatize":
                bucket["visibility"] = "private"
            else:
                bucket["status"] = "separated" if action == "separate" else "ended"
                bucket["visibility"] = "private"
        else:
            bucket["memories"][event_id] = detail
        bucket["history"].append({"id": event_id, "action": action, "detail": detail,
            "agreed": agreed, "chapter": state["current_chapter"],
            "before_status": before["status"], "after_status": bucket["status"],
            "before_visibility": before["visibility"], "after_visibility": bucket["visibility"]})
        return {"kind": "relationship_event", "path": path, "before": before, "after": state_copy(bucket)}

    def relationship_event(heroine, event_id, action, detail, agreed=False):
        apply_effects([("relationship_event", heroine, event_id, action, detail, agreed)])

    def remembers(heroine, event_id):
        return event_id in store.vn["romance"][heroine]["memories"]

    def y1_personal_available(heroine):
        rel = store.vn["relationships"][heroine]
        if heroine == "hermione":
            return rel["affection"] >= 2 and (chose("Y1_C2_FRIENDSHIP", "invite") or chose("Y1_C3_REPAIR", "listen"))
        return False

    def y1_correspondence_available():
        return bool(store.vn["flags"].get("y1_mirror_carina"))
