init -30 python:
    def war_preparedness(state=None):
        """M0 balance placeholder, 0..100. Not a moral/ending quality score."""
        world = (state or store.vn)["world"]
        value = (world["da_strength"] + world["order_strength"]) // 2
        value += {"unaware": 0, "denial": 0, "wavering": 5, "confirmed": 10}[world["ministry_truth"]]
        value += 5 if world["death_eaters_exposed"] else 0
        value += {"intact": 10, "suspected": 3, "blown": 0}[world["snape_cover"]]
        # Survival never automatically awards points. Consequences are contextual.
        return max(0, min(100, value))
