init -1 python:
    M43_SCENE_MUSIC.update({sid:meta["music"] for sid,meta in Y5_SCENES.items()})
    M43_ENTRY_SFX.update({"Y5-C1-S02":"wind","Y5-C2-S01":"train","Y5-C4-S06":"footsteps"})
    M42_HIDDEN_SCENES.update(Y5_SOURCE_SCENES)
    M33_QA_BUILDERS[5]=lambda sid,recipe:y5_prepare_review(sid,recipe["profile"],recipe.get("local"))
    for _p,_title in Y5_REVIEW_PRESETS.items():
        _key=("main5_" if _p not in ("hidden","public") else "hidden5_")+_p
        M33_QA_PRESETS[_key]=dict(title=_title,profile=_p,prior={},local={})
    for _nid,_node in M21_NODES.items():
        if _node["year"]!=5: continue
        _ps=y5_presets_for_scene(_node["scene"])
        _node["replay"]["presets"]=[("main5_" if p not in ("hidden","public") else "hidden5_")+p for p in _ps]
    for _asset,_title,_sid in (("carina_door","벽난로를 막은 사람","Y5-C5-S12"),("luna_after","함께 찾아야 할 것","Y5-C6-S07")):
        M21_CGS["Y5:"+_asset]=dict(year=5,asset=_asset,title=_title,scene=_sid)

init 2 python:
    # Shared early scenes require no history-selection wall. Later variants do.
    for _sid,_meta in Y5_SCENES.items():
        _all=M21_NODES[_sid]["replay"]["presets"]
        M33_SCENE_VARIANTS[_sid]=["main5_main"] if _sid in ("Y5-C1-S02","Y5-C4-S07") else _all
