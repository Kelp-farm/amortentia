init -1 python:
    # A heard name, a score and an actual exchange are different evidence.
    # Only completed conversations or choices already made count here; being in
    # a later chapter, a portrait or the participant list does not count.
    RELATIONSHIP_CONVERSATIONS = {
        "hermione": ("Y1-C1-S06", "Y1-C3-S04", "Y1-C4-S01", "Y1-C4-S10", "Y1-C4-S12",
            "Y2-C1-S03", "Y2-C3-S03", "Y2-C4-S01", "Y2-C6-S01",
            "Y3-C4-S01", "Y3-C6-S05", "Y4-C3-S03", "Y4-C3-S08", "Y4-C4-S03",
            "Y4-C8-S05", "Y5-C3-S03", "Y5-C6-S04", "Y7-C1-S02"),
        "ginny": ("Y2-C1-S02", "Y2-C2-S03", "Y2-C3-S05", "Y2-C5-S04", "Y2-C6-S02",
            "Y3-C2-S06", "Y3-C4-S02", "Y4-C3-S04", "Y4-C3-S09", "Y4-C4-S04",
            "Y4-C8-S06", "Y5-C3-S04", "Y5-C3-S10", "Y5-C6-S05", "Y7-C1-S03"),
        "luna": ("Y2-C1-S05", "Y2-C2-S03", "Y2-C3-S05", "Y2-C6-S03",
            "Y3-C2-S07", "Y3-C4-S03", "Y4-C3-S05", "Y4-C3-S10", "Y4-C4-S05",
            "Y4-C8-S07", "Y5-C2-S03", "Y5-C3-S05", "Y5-C6-S07", "Y7-C5-S03"),
    }
    RELATIONSHIP_CONVERSATION_SKIPS = {
        "Y2-C2-S03": ("Y2_LUNA_WATCH", "later", "luna"),
        "Y3-C2-S07": ("Y3_LUNA_OUTING", "leave", "luna"),
        "Y3-C4-S03": ("Y3_LUNA_SPRING", "leave", "luna"),
    }

    def relationship_conversations(heroine, state):
        """Read existing story evidence without awarding points or memories."""
        scenes = set(RELATIONSHIP_CONVERSATIONS.get(heroine, ()))
        flags = state["flags"]
        seen = {sid for sid in scenes if flags.get("finished_" + sid)}
        # A choice is proof of reaching its conversation before scene completion.
        # Count the scene once even if it contains multiple choices or memories.
        for entry in state["choices"]:
            cid = entry["choice_id"]
            node = M21_NODES.get(cid, {})
            sid = node.get("scene")
            if sid not in scenes:
                continue
            options = CHOICES.get(cid, {}).get("options", ())
            option = next((o for o in options if o["id"] == entry["option_id"]), None)
            if option and any(e[0] in ("relationship", "relationship_event") and e[1] == heroine
                    for e in option.get("effects", ())):
                seen.add(sid)
        for sid, (cid, oid, member) in RELATIONSHIP_CONVERSATION_SKIPS.items():
            if member == heroine and chose(cid, oid, state):
                seen.discard(sid)
        return seen

    def affection_change_text(delta):
        """Player feedback has direction, never a score or a romance claim."""
        return "가까워졌습니다." if delta > 0 else "거리감이 생겼습니다." if delta < 0 else ""

    def m42_relationship(heroine, state=None):
        """Observable context wins over affinity. This never infers mutual love."""
        state=store.vn if state is None else state
        bond=state["romance"][heroine]; flags=state["flags"]; world=state["world"]
        score=state["relationships"][heroine]["affection"]
        history=bond.get("history",[])
        memory=history[-1]["detail"] if history else None
        if heroine=="carina" and m732_altered(state) and not m732_memory(state).get("renewed"):
            label,description=("기억을 되찾은 사이","지금의 관계는 새로 정한다.") if m732_memory(state).get("status")=="restored" else ("기억을 간직한 한 사람","해리는 지난 교제를 기억한다. 카리나는 그 기억을 떠올리지 못한다.")
            if m732_memory(state).get("reunion_answer")=="rejected":
                label,description="재회를 거절한 사이","지난 기억을 되찾았지만, 다시 사귀지는 않기로 했다."
        elif bond["status"] == "ended":
            label,description="헤어진 사이","교제는 끝났지만, 함께 지낸 기억은 남아 있다."
        elif bond["status"] == "separated":
            label,description="떨어져 있는 사이","함께 지낸 기억은 남아 있지만, 지금은 교제를 이어가지 않고 있다."
            if heroine == "carina" and flags.get("y4_hidden_letter_read"):
                description="지금은 떨어져 지내지만, 편지로 전해 온 마음과 함께한 약속은 남아 있다."
        elif bond["status"]=="dating":
            label="연인 사이" if bond["visibility"]=="public" else "비밀 연애 중"
            description="서로의 마음을 말로 확인하고 함께하기로 했다."
        elif romance_unresolved(heroine,state):
            label,description="서먹해진 친구","다른 사람과 사귀면서 데이트를 요구했다가 거절당했다. 그 뒤의 대화가 남아 있다."
        elif heroine=="carina" and world.get("carina_early_romance_blocked"):
            label,description="서먹해진 사이","크게 다툰 뒤 아직 화해하지 못했다."
        elif heroine=="carina" and (world.get("y3_carina_bond")=="reconciled" or flags.get("y3_quarrel_resolved")):
            label,description="다시 이야기하는 사이","다툼을 풀고 다시 이야기를 나누기 시작했다."
        elif heroine=="carina" and flags.get("y3_quarrel") and not flags.get("y3_quarrel_resolved"):
            label,description="서먹해진 사이","나누지 못한 말이 남아 있다. 아직 화해하지 않았다."
        elif heroine=="carina" and world.get("carina_cooperation")=="pressured":
            label,description="불편한 협력 관계","일기장과 가족 문제를 압박해 협력을 얻었다."
        elif (heroine=="carina" and state.get("current_chapter")=="Y1-C1"
                and not flags.get("y1_train_offered_hand_refused") and not flags.get("finished_Y1-C1-S07")):
            label,description="처음 만난 사이","다이애건 앨리에서 인사를 나눴다. 아직 서로 알아 가는 중이다."
        elif heroine=="hermione" and flags.get("m42_hermione_friction"):
            label,description="말이 엇갈린 친구","스캐버스 문제로 다퉜다. 아직 그때의 말을 풀지 못했다."
        elif heroine=="carina":
            personal=flags.get("m42_carina_conversation") or bool(history)
            label="말을 나누는 라이벌" if personal else "라이벌"
            description="기숙사와 경기에서는 겨루지만, 둘이서 이야기를 나눈 적도 있다." if personal else "만나면 서로를 견제한다."
        else:
            conversations = relationship_conversations(heroine, state)
            years = {sid.split("-")[0] for sid in conversations}
            if not conversations:
                if heroine == "ginny" and (flags.get("name_known_ginny") or flags.get("finished_Y1-C1-S05")):
                    label,description="이름만 아는 사이","론의 동생이라는 것만 안다. 아직 직접 이야기를 나누지 않았다."
                elif flags.get("name_known_" + heroine):
                    label,description="처음 만난 사이","이름을 소개받았다. 아직 서로를 알아 가기 전이다."
                else:
                    label,description="아직 만나지 않은 사이","아직 서로 인사를 나누지 않았다."
            elif score < 0:
                label,description="조금 어색한 사이","최근 대화가 매끄럽지는 않았다."
            elif len(conversations) >= 5 and len(years) >= 2 and score >= 5:
                label,description="소중한 친구","여러 학년에 걸쳐 함께한 경험이 쌓였다. 서로를 찾아가 이야기를 나누는 사이가 되었다."
            elif ((len(conversations) >= 3 and score >= 2) or
                    (heroine == "hermione" and flags.get("finished_Y1-C3-S04"))):
                label,description="친구 사이","여러 번 이야기를 나누고 시간을 함께 보내며 가까워졌다."
            elif len(conversations) >= 2:
                label,description="알아 가는 사이","몇 번 이야기를 나눴다. 서로에 대해 조금씩 알아 가고 있다."
            else:
                label,description="말을 나눈 사이","직접 인사를 나누고 이야기를 했다. 아직 함께한 시간은 많지 않다."
        return dict(label=label,description=description,memory=memory)

    def m42_node_title(nid, origin=None):
        origin=origin or m42_origin()
        node=M21_NODES[nid]
        if nid=="Y1_MALKIN_GUIDE": return "거리 안내를 받아들일까"
        if origin=="main" and node["scene"] in M42_MAIN_SCENES:
            return M42_MAIN_SCENES[node["scene"]]+(" · 선택" if node["type"]=="choice" else "")
        return node["title"]
