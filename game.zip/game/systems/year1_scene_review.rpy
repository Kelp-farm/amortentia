# Review entry registry: story remains authoritative.
init -16 python:
    Y1_REVIEW_SCENES = {
        'Y1-C1-S02': {'chapter': 1, 'offset': 0, 'label': 'y1_c1_s02', 'title': '다이애건 앨리', 'choices': [], 'flags': []},
        'Y1-C1-S03': {'chapter': 1, 'offset': 1, 'label': 'y1_c1_s03', 'title': '양장점과 카리나의 거리 안내', 'choices': [('Y1_C1_RIVAL', 'boundary'), ('Y1_C1_NOTICE', 'curious')], 'flags': []},
        'Y1-C1-S05': {'chapter': 1, 'offset': 2, 'label': 'y1_c1_s05', 'title': '승강장의 위즐리 가족', 'choices': [], 'flags': []},
        'Y1-C1-S06': {'chapter': 1, 'offset': 3, 'label': 'y1_c1_s06', 'title': '열차에서 만난 친구들', 'choices': [], 'flags': ['y1_train_offered_hand_refused']},
        'Y1-C1-S07': {'chapter': 1, 'offset': 4, 'label': 'y1_c1_s07', 'title': '기숙사 배정', 'choices': [('Y1_C1_TABLE', 'seat')], 'flags': []},
        'Y1-C2-S01': {'chapter': 2, 'offset': 0, 'label': 'y1_c2_s01', 'title': '첫 실습', 'choices': [('Y1_C2_FRIENDSHIP', 'invite')], 'flags': []},
        'Y1-C2-S02': {'chapter': 2, 'offset': 1, 'label': 'y1_c2_s02', 'title': '마법약 수업', 'choices': [], 'flags': []},
        'Y1-C2-S03': {'chapter': 2, 'offset': 2, 'label': 'y1_c2_s03', 'title': '안뜰의 신경전', 'choices': [], 'flags': []},
        'Y1-C2-S04': {'chapter': 2, 'offset': 3, 'label': 'y1_c2_s04', 'title': '비행 수업', 'choices': [], 'flags': []},
        'Y1-C2-S06': {'chapter': 2, 'offset': 4, 'label': 'y1_c2_s06', 'title': '한밤의 결투', 'choices': [('Y1_C2_DUEL', 'own_words')], 'flags': ['y1_knows_fluffy', 'y1_midnight_trap']},
        'Y1-C2-S07': {'chapter': 2, 'offset': 5, 'label': 'y1_c2_s07', 'title': '결투 다음 날', 'choices': [('Y1_C2_RULE', 'report')], 'flags': ['y1_corridor_reported']},
        'Y1-C3-S01': {'chapter': 3, 'offset': 0, 'label': 'y1_c3_s01', 'title': '핼러윈의 말다툼', 'choices': [], 'flags': []},
        'Y1-C3-S02': {'chapter': 3, 'offset': 1, 'label': 'y1_c3_s02', 'title': '헤르미온느를 찾으러', 'choices': [('Y1_C3_TROLL', 'signal')], 'flags': []},
        'Y1-C3-S03': {'chapter': 3, 'offset': 2, 'label': 'y1_c3_s03', 'title': '트롤과의 대면', 'choices': [], 'flags': ['y1_troll_help_early', 'y1_trio_rescued']},
        'Y1-C3-S04': {'chapter': 3, 'offset': 3, 'label': 'y1_c3_s04', 'title': '세 친구의 화해', 'choices': [('Y1_C3_REPAIR', 'listen')], 'flags': ['y1_friendship_callback_invite', 'y1_trio_friends']},
        'Y1-C3-S05': {'chapter': 3, 'offset': 4, 'label': 'y1_c3_s05', 'title': '첫 퀴디치 경기 이후', 'choices': [], 'flags': ['y1_quidditch_won', 'y1_suspects_snape', 'y1_knows_fluffy', 'y1_knows_flamel_name']},
        'Y1-C3-S10': {'chapter': 3, 'offset': 5, 'label': 'y1_c3_s10', 'title': '소망의 거울', 'choices': [('Y1_C3_MIRROR', 'quiet'), ('Y1_C3_MIRROR_REPLY', 'tell')], 'flags': ['y1_saw_mirror', 'y1_mirror_carina', 'y1_mirror_parents_shared', 'y1_knows_mirror_desire']},
        'Y1-C4-S01': {'chapter': 4, 'offset': 0, 'label': 'y1_c4_s01', 'title': '헤르미온느와 독서', 'choices': [('Y1_C4_STUDY', 'stay'), ('Y1_C4_BOOK', 'company')], 'flags': ['y1_knows_stone']},
        'Y1-C4-S02': {'chapter': 4, 'offset': 1, 'label': 'y1_c4_s02', 'title': '용을 들킨 밤', 'choices': [('Y1_C4_DRAGON', 'home')], 'flags': []},
        'Y1-C4-S03': {'chapter': 4, 'offset': 2, 'label': 'y1_c4_s03', 'title': '늦은 봄의 징계', 'choices': [], 'flags': ['y1_dragon_departed', 'y1_detention_assigned']},
        'Y1-C4-S04': {'chapter': 4, 'offset': 3, 'label': 'y1_c4_s04', 'title': '카리나와 금지된 숲', 'choices': [('Y1_C4_FOREST', 'pull')], 'flags': ['y1_forest_threat']},
        'Y1-C4-S05': {'chapter': 4, 'offset': 4, 'label': 'y1_c4_s05', 'title': '다음 날 아침의 시선', 'choices': [], 'flags': ['y1_breakfast_glance']},
        'Y1-C4-S06': {'chapter': 4, 'offset': 5, 'label': 'y1_c4_s06', 'title': '돌을 지키러 갈 준비', 'choices': [('Y1_C4_PLAN', 'message')], 'flags': ['y1_authority_callback_report']},
        'Y1-C4-S07': {'chapter': 4, 'offset': 6, 'label': 'y1_c4_s07', 'title': '금지된 복도로', 'choices': [], 'flags': []},
        'Y1-C4-S08': {'chapter': 4, 'offset': 7, 'label': 'y1_c4_s08', 'title': '식물방과 열쇠방', 'choices': [], 'flags': []},
        'Y1-C4-S09': {'chapter': 4, 'offset': 8, 'label': 'y1_c4_s09', 'title': '론의 체스', 'choices': [('Y1_C4_CHESS', 'trust')], 'flags': ['y1_ron_chess_sacrifice']},
        'Y1-C4-S10': {'chapter': 4, 'offset': 9, 'label': 'y1_c4_s10', 'title': '헤르미온느와 잠시 작별', 'choices': [], 'flags': []},
        'Y1-C4-S12': {'chapter': 4, 'offset': 10, 'label': 'y1_c4_s12', 'title': '병문안 · 포옹', 'choices': [], 'flags': ['y1_stone_denied', 'y1_rescue_message_callback', 'y1_hermione_reunion_hug', 'y1_received_album']},
        'Y1-C4-S14': {'chapter': 4, 'offset': 11, 'label': 'y1_c4_s14', 'title': '열차 · 작별', 'choices': [], 'flags': []},
    }

    def y1_prepare_scene_review(scene_id, overrides=None):
        store.m41_presented_scene = None
        require_key(Y1_REVIEW_SCENES, scene_id)
        entry = Y1_REVIEW_SCENES[scene_id]
        y1_prepare_review(entry["chapter"], overrides)
        begin_chapter("Y1-C%d" % entry["chapter"])
        for sid, previous in Y1_REVIEW_SCENES.items():
            if previous["chapter"] != entry["chapter"] or previous["offset"] >= entry["offset"]:
                continue
            for choice, option in previous["choices"]:
                if not m42_choice_allowed(choice): continue
                record_choice(choice, (overrides or {}).get(choice,option))
            for flag in previous["flags"]:
                set_story_flag(flag)
            if sid == "Y1-C4-S03" and m42_hidden():
                set_story_flag("y1_carina_slur_quarrel")
            if sid == "Y1-C4-S12":
                set_world("stone_status", "destroyed")
                set_world("quirrell_status", "dead")
        store.vn["review_entry_scene"] = scene_id
        store.y1_review_chapter = entry["chapter"]
        store.y1_review_scene_offset = entry["offset"]

default y1_review_scene_offset = 0

label review_y1_c1_s02:
    $ y1_prepare_scene_review("Y1-C1-S02")
    jump y1_review_continue

label review_y1_c1_s03:
    $ y1_prepare_scene_review("Y1-C1-S03")
    jump y1_review_continue

label review_y1_c1_s05:
    $ y1_prepare_scene_review("Y1-C1-S05")
    jump y1_review_continue

label review_y1_c1_s06:
    $ y1_prepare_scene_review("Y1-C1-S06")
    jump y1_review_continue

label review_y1_c1_s07:
    $ y1_prepare_scene_review("Y1-C1-S07")
    jump y1_review_continue

label review_y1_c2_s01:
    $ y1_prepare_scene_review("Y1-C2-S01")
    jump y1_review_continue

label review_y1_c2_s02:
    $ y1_prepare_scene_review("Y1-C2-S02")
    jump y1_review_continue

label review_y1_c2_s03:
    $ y1_prepare_scene_review("Y1-C2-S03")
    jump y1_review_continue

label review_y1_c2_s04:
    $ y1_prepare_scene_review("Y1-C2-S04")
    jump y1_review_continue

label review_y1_c2_s06:
    $ y1_prepare_scene_review("Y1-C2-S06")
    jump y1_review_continue

label review_y1_c2_s07:
    $ y1_prepare_scene_review("Y1-C2-S07")
    jump y1_review_continue

label review_y1_c2_s08:
    # Retired review link resumes at the next active scene.
    $ y1_prepare_scene_review("Y1-C3-S01")
    jump y1_review_continue

label review_y1_c3_s01:
    $ y1_prepare_scene_review("Y1-C3-S01")
    jump y1_review_continue

label review_y1_c3_s02:
    $ y1_prepare_scene_review("Y1-C3-S02")
    jump y1_review_continue

label review_y1_c3_s03:
    $ y1_prepare_scene_review("Y1-C3-S03")
    jump y1_review_continue

label review_y1_c3_s04:
    $ y1_prepare_scene_review("Y1-C3-S04")
    jump y1_review_continue

label review_y1_c3_s05:
    $ y1_prepare_scene_review("Y1-C3-S05")
    jump y1_review_continue

label review_y1_c3_s10:
    $ y1_prepare_scene_review("Y1-C3-S10")
    jump y1_review_continue

label review_y1_c4_s01:
    $ y1_prepare_scene_review("Y1-C4-S01")
    jump y1_review_continue

label review_y1_c4_s02:
    $ y1_prepare_scene_review("Y1-C4-S02")
    jump y1_review_continue

label review_y1_c4_s03:
    $ y1_prepare_scene_review("Y1-C4-S03")
    jump y1_review_continue

label review_y1_c4_s04:
    $ y1_prepare_scene_review("Y1-C4-S04")
    jump y1_review_continue

label review_y1_c4_s05:
    $ y1_prepare_scene_review("Y1-C4-S05")
    jump y1_review_continue

label review_y1_c4_s06:
    $ y1_prepare_scene_review("Y1-C4-S06")
    jump y1_review_continue

label review_y1_c4_s07:
    $ y1_prepare_scene_review("Y1-C4-S07")
    jump y1_review_continue

label review_y1_c4_s08:
    $ y1_prepare_scene_review("Y1-C4-S08")
    jump y1_review_continue

label review_y1_c4_s09:
    $ y1_prepare_scene_review("Y1-C4-S09")
    jump y1_review_continue

label review_y1_c4_s10:
    $ y1_prepare_scene_review("Y1-C4-S10")
    jump y1_review_continue

label review_y1_c4_s12:
    $ y1_prepare_scene_review("Y1-C4-S12")
    jump y1_review_continue

label review_y1_c4_s14:
    $ y1_prepare_scene_review("Y1-C4-S14")
    jump y1_review_continue
