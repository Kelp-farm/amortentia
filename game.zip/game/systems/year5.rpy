init -9 python:
    Y5_REVIEW_PRESETS={
        "main":"본편 · 동료들과 마법부", "hidden":"숨겨진 이야기 · 비밀 교제 후 이별",
        "public":"숨겨진 이야기 · 공개 교제 후 이별", "estranged":"본편 · 3학년 화해 실패",
        "hermione":"본편 · 헤르미온느와 교제", "ginny":"본편 · 지니와 가까워지는 경로",
        "luna":"본편 · 루나와의 우정", "no_romance":"본편 · 연애 없이",
        "bereaved":"본편 · 세드릭과 시리우스를 잃은 이력", "averted":"확인 후 학교에 남음",
        "concealed":"동료 구조 우선 · 귀환 미공개", "captured":"단독 돌파 · 감금 결말"}
    def y5_flag(key): return store.vn["flags"].get(key,False)
    def y5_fanfic(): return carina_hidden_campaign()
    def y5_dating(h): return store.vn["romance"][h]["status"]=="dating"
    def y5_departed(): return store.vn["world"]["y5_companions"]!="none"
    def y5_captured(): return store.vn["world"]["y5_ending"]=="captured"
    def y5_past_carina(): return not m732_altered() and store.vn["world"]["y4_carina_separation"]=="war_pressure"
    def y5_team(): return store.vn["world"]["y5_companions"]=="da"
    def y5_can_kiss_ginny():
        v=store.vn
        if not romance_can_pursue("ginny"): return False
        if cho_active(): return False
        if y5_fanfic() or carina_hidden_campaign() or v.get("route_intent")=="no_romance": return False
        if any(r["status"] in ("dating","separated") for r in v["romance"].values()): return False
        shared=y5_flag("y5_ginny_practice") or chose("Y5_GINNY_PRACTICE","watch")
        return bool(y5_flag("y5_quidditch_cup_won") and shared
            and v["romance"]["ginny"]["status"]=="none" and v["relationships"]["ginny"]["affection"]>=4)
    def y5_scene_available(sid):
        if (sid in Y5_SOURCE_SCENES) != y5_fanfic(): return False
        c=Y5_SCENES[sid]["condition"]
        if c.startswith("cho_"): return not y5_captured() and cho_scene_available(c)
        if c=="always": return not y5_captured()
        if c=="fanfic": return y5_fanfic()
        if c=="departed": return y5_departed() and not y5_captured()
        if c=="escaped": return y5_departed() and not y5_captured()
        if c=="stayed": return chose("Y5_DEPART","wait")
        if c=="survived": return not y5_captured()
        if c=="captured": return y5_captured()
        raise ValueError("Unknown Y5 condition: "+c)
    def y5_option_available(cid,oid):
        if cid.startswith("Y5_H_"): return y5_fanfic()
        if y5_fanfic(): return False
        if cid in ("Y5_HERMIONE_CHO","Y5_GINNY_CHO","Y5_HERMIONE_CLEAR","Y5_GINNY_CLEAR"):
            return m751_option_available(cid,oid)
        if cid.startswith("Y5_CHO_"): return cho_option_available(cid,oid)
        if cid=="Y5_GINNY_KISS": return oid=="cheer" or (oid=="kiss" and y5_can_kiss_ginny())
        if cid in ("Y5_PAPER_HARM","Y5_OFFICE"): return y5_fanfic()
        if cid=="Y5_DEPART":
            if oid=="wait": return y5_flag("y5_order_contacted")
            if oid=="team": return not y5_fanfic() or y5_flag("y5_carina_warning_heard")
            return True
        if cid in ("Y5_PROPHECY","Y5_BATTLE"): return y5_departed() and not y5_captured()
        if cid in ("Y5_EXPOSE","Y5_LUCIUS"): return y5_departed() and not y5_captured()
        return True
    def y5_choice_needed(cid):
        if cid=="Y5_GINNY_KISS": return y5_can_kiss_ginny()
        return any(y5_option_available(cid,o["id"]) for o in CHOICES[cid]["options"])

    def y5_begin():
        if store.vn["current_chapter"] or not store.vn["chapters"].get("Y4-C8",{}).get("completed"):
            raise ValueError("Complete Year 4 before Year 5")
        if not y5_flag("y4_complete") or "year5_handoff" not in store.vn: raise ValueError("Missing Year 4 handoff")
        if any(k.startswith("Y5-") for k in store.vn["chapters"]): raise ValueError("Year 5 already started")
        store.vn=migrate_state(store.vn)
        h=store.vn["year5_handoff"]
        if h["worldline"]!=store.vn["world"]["y4_worldline"]: raise ValueError("Worldline changed since Year 4")
        store.vn["year5_entry"]=state_copy(h)
        store.vn["year5_entry"]["story_origin"]=m42_origin()
        store.vn["year5_entry"]["revision"]=3
        set_world("y5_phase","school")
        set_world("hogwarts_control","dumbledore")
        set_story_flag("y5_campaign")
        for n in range(1,5):
            setattr(store,"y%d_active_scene"%n,None)
            setattr(store,"y%d_portrait"%n,None)
        store.m21_last_node=None

    def y5_resolve(sid):
        # The same function drives actual play and QA reconstruction, once per scene.
        if y5_flag("y5_resolved_"+sid): return
        if not y5_scene_available(sid): raise ValueError("Unavailable Year 5 outcome: "+sid)
        w=store.vn["world"]
        cho_resolve(sid)
        m751_resolve(sid)
        if sid in Y5_SOURCE_SCENES: y5_source_resolve(sid)
        if sid=="Y5-C2-S07" and y5_fanfic(): set_story_flag("y5_quibbler_banned")
        if sid=="Y5-C3-S01":
            set_world("da_strength",min(100,w["da_strength"]+(15 if chose("Y5_DA_RULE","agree") else 5)))
        if sid=="Y5-C3-S07": set_story_flag("y5_quidditch_banned")
        if sid=="Y5-C3-S09": set_world("y5_arthur","recovering")
        if sid=="Y5-C4-S03":
            set_story_flag("y5_carina_squad")
            set_story_flag("y5_squad_harm")
            set_world("hogwarts_control","contested")
        if sid=="Y5-C4-S04":
            knows=(store.vn["relationships"]["carina"]["affection"]>=9
                and (y5_flag("y5_carina_conversation") or y5_past_carina()))
            if knows: set_world("y5_carina_da","silent")
        if sid=="Y5-C4-S05":
            set_world("da_strength",min(100,w["da_strength"]+(15 if chose("Y5_DA_FRACTURE","vote") else 5)))
        if sid=="Y5-C4-S06":
            if not y5_fanfic():
                set_story_flag("y5_da_betrayed")
                set_world("y5_carina_da","exposed")
                set_story_flag("y5_dumbledore_departed")
        if sid=="Y5-C4-S09": set_story_flag("y5_quidditch_cup_won")
        if sid=="Y5-C4-S10" and chose("Y5_GINNY_KISS","kiss"):
            if not y5_can_kiss_ginny(): raise ValueError("Ginny cup kiss prerequisites were lost")
            relationship_event("ginny","y5_ginny_cup_kiss","start","5학년 퀴디치 우승 파티에서 입을 맞추고 서로 사귀기로 했다.",True)
            relationship_event("ginny","y5_ginny_public_cup","publish","친구들 앞에서 입을 맞추고 교제를 숨기지 않기로 했다.",True)
        if sid=="Y5-C5-S02" and y5_fanfic():
            set_story_flag("y5_da_betrayed")
            set_world("y5_carina_da","exposed")
        if sid=="Y5-C5-S03":
            mode="none" if chose("Y5_DEPART","wait") else "da" if chose("Y5_DEPART","team") else "alone"
            set_world("y5_companions",mode)
            set_world("y5_phase","school" if mode=="none" else "ministry")
        if sid=="Y5-C5-S05":
            set_world("y5_prophecy","destroyed" if chose("Y5_PROPHECY","break") else "stolen")
        if sid=="Y5-C5-S06":
            trapped=(not y5_flag("y5_order_contacted") and not y5_team()
                and chose("Y5_PROPHECY","trade") and chose("Y5_BATTLE","pursue"))
            if trapped:
                set_world("y5_ending","captured");set_world("y5_phase","captured")
            elif w["sirius_status"]!="dead":
                saved=y5_flag("y5_order_contacted") and chose("Y5_BATTLE","cover")
                set_world("sirius_status","wounded" if saved else "dead")
                set_story_flag("y5_sirius_died",not saved)
                set_story_flag("y5_thestral_witness",not saved)
        if sid=="Y5-C5-S07":
            exposed=chose("Y5_EXPOSE","alarm")
            set_world("ministry_truth","confirmed" if exposed else "wavering")
            set_world("death_eaters_exposed",True)
            if w["lucius_status"]!="dead": set_world("lucius_status","arrested" if chose("Y5_LUCIUS","secure") else "free")
            set_story_flag("y5_voldemort_public",exposed)
            set_world("y5_ending","bereaved" if w["sirius_status"]=="dead" else "survivors")
        if sid=="Y5-C5-S08":
            set_world("y5_ending","averted")
            # No Harry in the trap: the Order interrupts the operation but cannot
            # manufacture a public sighting of Voldemort or Lucius' conviction.
            set_world("y5_prophecy","untouched")
            set_story_flag("y5_voldemort_public",False)
        if sid=="Y5-C5-S09":
            set_world("y5_phase","aftermath")
            set_world("hogwarts_control","dumbledore")
        if sid in ("Y5-C6-S08","Y5-C6-S13"):
            if cho_active(): raise ValueError("Finish the actual Cho breakup before leaving Year 5")
            set_world("y5_phase","complete")
            set_story_flag("y5_complete")
            store.vn["year6_handoff"]=dict(story_origin=m42_origin(),
                worldline=w["y4_worldline"],moody=w["y4_moody"],resurrection=w["y4_resurrection"],
                harry_knowledge=w["y4_harry_knowledge"],cedric=w["y4_cedric"],
                sirius=w["sirius_status"],sirius_legal=w["sirius_legal"],lucius=w["lucius_status"],
                peter=w["pettigrew_status"],dobby=w["dobby_status"],
                ministry_truth=w["ministry_truth"],death_eaters_exposed=w["death_eaters_exposed"],
                voldemort_public=y5_flag("y5_voldemort_public"),prophecy=w["y5_prophecy"],
                carina_early_blocked=w["carina_early_romance_blocked"],
                carina_conflict=w["y5_carina_conflict"],carina_squad=y5_flag("y5_carina_squad"),
                carina_da=w["y5_carina_da"],carina_prior_visibility=w["y4_carina_prior_visibility"],
                romance=state_copy(store.vn["romance"]),relationships=state_copy(store.vn["relationships"]),
                friendship_stability=store.vn["special"]["friendship_stability"],
                cooperation={k:v for k,v in store.vn["flags"].items() if k.startswith("y5_")},
                da_strength=w["da_strength"],ending=w["y5_ending"])
        set_story_flag("y5_resolved_"+sid)

    def y5_finish_scene(sid):
        if store.vn["current_chapter"]!=Y5_SCENES[sid]["chapter"]: raise ValueError("Year 5 chapter mismatch")
        if y5_flag("finished_"+sid): return
        y5_resolve(sid)
        set_story_flag("finished_"+sid)
        m41_record_outcomes(sid)
        m33_complete(sid)

    def y5_enter_scene(sid):
        if store.vn["current_chapter"]!=Y5_SCENES[sid]["chapter"] or not y5_scene_available(sid):
            raise ValueError("Unavailable Year 5 scene")
        if store.vn["year5_entry"]["worldline"]!=store.vn["world"]["y4_worldline"]:
            raise ValueError("Frozen worldline was changed")
        store.y5_active_scene=sid;store.y5_portrait=None;store.y5_expressions={};store.y5_offscreen=[]
        set_story_flag("seen_"+sid)

    def y5_recipe(p):
        prior={"Y1_MALKIN_GUIDE":"decline"}
        profile={"hermione":"hermione_dating","ginny":"ginny","luna":"luna",
            "no_romance":"no_romance","bereaved":"cedric_dead","cho":"cedric_dead","cho_guarded":"cedric_dead"}.get(p,"standard")
        local={"Y5_VERIFY":"contact","Y5_DEPART":"team","Y5_BATTLE":"cover"}
        local["Y5_GINNY_KISS"]="kiss" if p=="ginny" else "cheer"
        local.update(Y5_CHO_INTEREST="friends",Y5_CHO_KISS="friends")
        if p in ("cho","cho_guarded"):
            local.update(Y5_CHO_INTEREST="pursue",Y5_CHO_KISS="kiss",Y5_CHO_AUTUMN="listen",
                Y5_CHO_DATE="explain",Y5_CHO_RECONNECT="apologize",Y5_CHO_BREAKUP="respect")
        if p=="cho_guarded":
            local.update(Y5_CHO_AUTUMN="honest",Y5_CHO_DATE="awkward",Y5_CHO_RECONNECT="try",Y5_CHO_BREAKUP="hurt")
        if p in ("hidden","public","estranged"):
            prior={}
            profile={"public":"dating_public","estranged":"estranged"}.get(p,"dating_private")
        if p in ("hidden","public","bereaved"):
            local.update(Y5_VERIFY="rush",Y5_DEPART="alone" if p!="bereaved" else "team",Y5_OFFICE="duel",Y5_BATTLE="pursue")
        if p=="averted": local["Y5_DEPART"]="wait"
        if p=="concealed": local.update(Y5_EXPOSE="wounded",Y5_LUCIUS="rescue")
        if p=="captured": local.update(Y5_VERIFY="rush",Y5_DEPART="alone",Y5_OFFICE="duel",Y5_PROPHECY="trade",Y5_BATTLE="pursue")
        return profile,prior,local

    def y5_presets_for_scene(sid):
        if sid in Y5_SOURCE_SCENES: return ["hidden","public"]
        if sid in Y5_CHO_ROMANTIC_SCENES: return ["cho","cho_guarded"]
        cond=Y5_SCENES[sid]["condition"]
        ps=[p for p in Y5_REVIEW_PRESETS if p not in ("hidden","public")]
        if cond=="stayed": return ["averted"]
        if cond=="captured": return ["captured"]
        if cond in ("departed","escaped"): ps=[p for p in ps if p!="averted"]
        if cond in ("escaped","survived") or Y5_SCENES[sid]["number"]==6: ps=[p for p in ps if p!="captured"]
        return ps

    def y5_prepare_review(sid,preset="main",overrides=None):
        require_key(Y5_SCENES,sid)
        if preset not in y5_presets_for_scene(sid):
            raise ValueError("Review profile does not belong to this scene's worldline")
        profile,prior,defaults=y5_recipe(preset)
        if overrides: defaults.update(overrides)
        y4_prepare_review("Y4-C8-S09",profile,prior)
        for cid in Y4_SCENES["Y4-C8-S09"]["choices"]:
            if y4_choice_needed(cid): record_choice(cid,next(o["id"] for o in CHOICES[cid]["options"] if y4_option_available(cid,o["id"])))
        y4_finish_scene("Y4-C8-S09")
        complete_chapter("4학년 장면 이전의 임시 검수 이력")
        y5_begin()
        for previous,meta in Y5_SCENES.items():
            if store.vn["current_chapter"]!=meta["chapter"]:
                if store.vn["current_chapter"]: complete_chapter("5학년 장면 이전의 임시 검수 이력")
                begin_chapter(meta["chapter"])
            if previous==sid: break
            if not y5_scene_available(previous): continue
            for cid in meta["choices"]:
                if not y5_choice_needed(cid): continue
                oid=defaults.get(cid,CHOICES[cid]["options"][0]["id"])
                if not y5_option_available(cid,oid): oid=next(o["id"] for o in CHOICES[cid]["options"] if y5_option_available(cid,o["id"]))
                record_choice(cid,oid)
            y5_finish_scene(previous)
        store.y5_review_chapter=Y5_SCENES[sid]["number"]
        store.y5_review_offset=Y5_SCENES[sid]["offset"]
        store.vn["review_entry_scene"]=sid;store.m21_last_node=None

default y5_active_scene = None
default y5_portrait = None
default y5_expressions = {}
default y5_offscreen = []
default y5_review_chapter = 1
default y5_review_offset = 0

label y5_scene(scene_id):
    $ vc_reset_stage()
    $ y5_enter_scene(scene_id)
    $ m21_visit(scene_id)
    hide screen y1_stage
    hide screen y2_stage
    hide screen y3_stage
    hide screen y4_stage
    hide screen y4_event_cg
    scene expression Solid("#182733")
    show screen y5_stage(scene_id)
    $ m43_scene_audio(scene_id)
    with Dissolve(0.25)
    return
