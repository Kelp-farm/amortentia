# Replay uses Ren'Py's store/context isolation, never a manual restore of vn.
default persistent.m33_scenes = {}
default m33_qa = False
default m33_pending = None
default m33_request = None
default m33_expected = {}
default m33_forced = {}

init -2 python:
    M33_COMPAT = "m33-affection-1"
    M33_LIMIT = 3
    M33_QA_PRESETS = {
        "standard": dict(title="기본 이력", profile="hermione", prior={}, local={}),
        "carina": dict(title="카리나와의 교류", profile="carina", prior={}, local={}),
        "ginny": dict(title="지니와의 외출", profile="ginny", prior={}, local={}),
        "luna": dict(title="루나와의 외출", profile="luna", prior={}, local={}),
        "Y3_CARINA_RING_RECONCILED": dict(title="반지 착용", profile="carina", prior={"Y3_RING":"wear"}, local={"Y3_RING":"wear"}),
        "Y3_CARINA_RING_ESTRANGED": dict(title="반지 미착용 · 갈등 지속", profile="carina", prior={"Y3_RING":"keep","Y3_RESCUE":"hermione"}, local={"Y3_RING":"keep"}),
        "ring_keep": dict(title="반지 보관 · 화해", profile="carina", prior={"Y3_RING":"keep","Y3_RESCUE":"hermione"}, local={"Y3_RING":"keep"}),
        "Y3_SIRIUS_RESCUE_HERMIONE": dict(title="화해 유지 · 헤르미온느 동행", profile="carina", prior={"Y3_RESCUE":"hermione"}, local={"Y3_RESCUE":"hermione"}),
        "Y3_SIRIUS_RESCUE_CARINA": dict(title="카리나 동행 · 페티그루 생포", profile="carina", prior={"Y3_RESCUE":"carina","Y3_PETER":"secure"}, local={"Y3_RESCUE":"carina","Y3_PETER":"secure"}),
        "peter_escape": dict(title="카리나 동행 · 페티그루 도주", profile="carina", prior={"Y3_PETER":"friends"}, local={"Y3_PETER":"friends"}),
        "dating_public": dict(title="경기 뒤 고백 · 공개 연애", profile="carina", prior={"Y3_COMMITMENT":"confess","Y3_DATING_VISIBILITY":"public"}, local={"Y3_COMMITMENT":"confess","Y3_DATING_VISIBILITY":"public"}),
        "dating_private": dict(title="경기 뒤 고백 · 비밀 연애", profile="carina", prior={"Y3_COMMITMENT":"confess","Y3_DATING_VISIBILITY":"private"}, local={"Y3_COMMITMENT":"confess","Y3_DATING_VISIBILITY":"private"}),
        "dating_decline": dict(title="경기 뒤 교제하지 않음", profile="carina", prior={"Y3_COMMITMENT":"friends"}, local={"Y3_COMMITMENT":"friends"}),
        "y2_hidden": dict(title="일기장 숨김 · 협력하지 않음", profile="hermione", diary="hide", cooperation="leave", prior={}, local={}),
        "y2_pressure": dict(title="일기장 공개 · 비공개 협력", profile="carina", diary="expose", cooperation="pressure", prior={}, local={}),
        "y2_hidden_pressure": dict(title="일기장 숨김 · 비공개 협력", profile="carina", diary="hide", cooperation="pressure", prior={}, local={}),
    }
    for _preset,_title in Y4_REVIEW_PRESETS.items():
        M33_QA_PRESETS["m4_"+_preset]=dict(title=_title,profile=_preset,prior={},local={})
    for _nid, _node in M21_NODES.items():
        _sid = _node["scene"]
        _presets = ["standard"]
        if _node["year"] == 2:
            _presets += ["y2_hidden","y2_pressure","y2_hidden_pressure"]
        elif _node["year"] == 3:
            _presets += ["carina","ginny","luna"]
            if _node["chapter"] in ("Y3-C4","Y3-C5","Y3-C6"):
                _presets += ["Y3_CARINA_RING_RECONCILED","Y3_CARINA_RING_ESTRANGED","ring_keep",
                    "Y3_SIRIUS_RESCUE_HERMIONE","Y3_SIRIUS_RESCUE_CARINA","peter_escape","dating_public","dating_private","dating_decline"]
        if _node["year"] == 4:
            _presets=["m4_"+p for p in y4_presets_for_scene(_sid)]
        _node["replay"] = dict(scene=_sid, label=M21_NODES[_sid]["label"],
            implemented=_node["implemented"], presets=_presets, discovery=_sid)

    def m33_active():
        return bool(getattr(store,"_in_replay",None))

    def m33_qa_enabled():
        return bool(m33_developer_available() and getattr(store,"m33_qa",False))

    def m33_developer_available():
        return bool(config.developer or getattr(store,"M33_QA_BUILD",False))

    def m33_all_presets(sid):
        presets=M21_NODES[sid]["replay"]["presets"]
        if sid in ("Y3-C6-S03","Y3-C6-S08","Y3-C6-S09"):
            return [p for p in presets if p not in ("Y3_CARINA_RING_ESTRANGED","ring_keep","Y3_SIRIUS_RESCUE_HERMIONE")]
        if sid=="Y3-C6-S02":
            return [p for p in presets if p!="Y3_SIRIUS_RESCUE_CARINA"]
        return presets

    def m33_presets(sid):
        return globals().get("M33_SCENE_VARIANTS",{}).get(sid,m33_all_presets(sid))

    def m33_scenes(nid):
        node = M21_NODES.get(nid,{})
        return [node["replay"]["scene"]] if "replay" in node else []

    def m33_implemented(sid):
        node = M21_NODES.get(sid,{})
        label = node.get("replay",{}).get("label")
        return bool(node.get("type")=="scene" and node.get("implemented") and label
            and renpy.has_label(label))

    def m33_record_compatible(record,sid):
        if m6_route_incompatible(record.get("state",{})): return False
        if sid.startswith(("Y5-","Y6-","Y7-")) and y5_obsolete_save(record.get("state",{})):
            return False
        if sid=="Y2-C6-S06" and not record.get("state",{}).get("flags",{}).get("m71_harry_letter"):
            return False
        if sid in ("Y3-C6-S09","Y4-C1-S01","Y4-C1-S02","Y4-C1-S03","Y4-C2-S03","Y4-C4-S07") and not record.get("state",{}).get("flags",{}).get("m4e_scene_version"):
            return False
        if sid == "Y3-C3-S01" and m42_origin(record.get("state",{}))!="main" and "Y3_RECOVERY_FIRST" not in record.get("choices",{}):
            return False
        if sid in ("Y3-C6-S10","Y3-C6-S11") and not record.get("state",{}).get("flags",{}).get("m4d_winter_broom_v1"):
            return False
        return (record.get("compat")==M33_COMPAT and record.get("scene")==sid and record.get("complete")
            and all(cid in CHOICES and any(o["id"]==oid for o in CHOICES[cid]["options"])
                for cid,oid in record.get("choices",{}).items()))

    def m33_records(sid):
        return [r for r in (getattr(persistent,"m33_scenes",{}) or {}).get(sid,[])
            if m33_record_compatible(r,sid)]

    def m33_can_view(sid, qa=False, index=0):
        if not m33_implemented(sid): return False
        if qa: return m33_qa_enabled()
        return m21_seen_node(sid) and 0 <= index < len(m33_records(sid))

    def m33_scene_started(sid):
        if m33_active(): return
        m33_complete()
        if not m33_implemented(sid): return
        store.m33_pending = dict(scene=sid,compat=M33_COMPAT,complete=False,
            state=state_copy(store.vn),choices={})

    def m33_choice(cid,oid):
        if m33_active() or not getattr(store,"m33_pending",None): return
        pending=dict(store.m33_pending)
        pending["choices"]=dict(pending["choices"])
        pending["choices"][cid]=oid
        store.m33_pending=pending

    def m33_complete(sid=None):
        if m33_active(): return
        pending=getattr(store,"m33_pending",None)
        if not pending or (sid is not None and pending["scene"]!=sid): return
        entry=dict(pending)
        entry["complete"]=True
        entry["key"]=m21_fingerprint(dict(state=entry["state"],choices=entry["choices"]))
        entry["time"]=m21_time.time()
        # Existing entries are immutable. Copy just the index/list being changed;
        # copying every historical state per scene is expensive on the web target.
        entries=dict(getattr(persistent,"m33_scenes",{}) or {})
        rows=[r for r in entries.get(entry["scene"],[]) if r.get("key")!=entry["key"]]
        entries[entry["scene"]]=(rows+[entry])[-M33_LIMIT:]
        persistent.m33_scenes=entries
        store.m33_pending=None
        m21_save_persistent()

    def m33_merge(old,new,current):
        merged={}
        for source in (old,new,current):
            for sid,rows in canonical_replay_records(source).items():
                found={r.get("key"):r for r in merged.get(sid,[])}
                found.update({r.get("key"):r for r in rows})
                merged[sid]=sorted(found.values(),key=lambda r:r.get("time",0))[-M33_LIMIT:]
        return merged

    def m33_action(sid,qa=False,preset="standard",index=0):
        allowed=m33_can_view(sid,qa,index)
        request=dict(scene=sid,qa=bool(qa),preset=preset)
        if allowed and not qa: request["record"]=state_copy(m33_records(sid)[index])
        return Replay("m33_scene_replay",scope={"m33_request":request},locked=not allowed)

    def m33_prepare():
        request=store.m33_request
        sid=request["scene"]
        if not m33_active() or not m33_implemented(sid):
            raise ValueError("Scene viewing requires an implemented scene and Replay context")
        store.m33_expected={}
        store.m33_forced={}
        if request["qa"]:
            if not m33_developer_available(): raise ValueError("QA scene viewing is developer-only")
            preset=request["preset"]
            if preset not in m33_all_presets(sid): raise ValueError("Unknown QA scenario")
            recipe=M33_QA_PRESETS[preset]
            year=M21_NODES[sid]["year"]
            builder=M33_QA_BUILDERS.get(year)
            if builder is None: return False
            builder(sid,recipe)
            if year==7 and not y7_scene_available(sid): return False
            if year==6 and not y6_scene_available(sid): return False
            if year==5 and not y5_scene_available(sid):
                return False
            if year==4 and not y4_scene_available(sid):
                return False
            if year==3 and not y3_scene_available(sid):
                return False
            store.m33_forced=state_copy(recipe["local"])
        else:
            record=request.get("record",{})
            if not m33_record_compatible(record,sid):
                raise ValueError("A completed scene viewing record is required")
            store.vn=migrate_state(record["state"])
            store.m33_expected=state_copy(record["choices"])
        return True

    def m33_option_available(cid,oid):
        if not m42_choice_allowed(cid): return False
        if cid.startswith("Y7_") and not y7_option_available(cid,oid): return False
        if cid.startswith("Y6_") and not y6_option_available(cid,oid): return False
        if cid.startswith("Y5_") and not y5_option_available(cid,oid): return False
        if cid.startswith("Y4_") and not y4_option_available(cid,oid): return False
        if not m33_active(): return not (cid.startswith("Y3_") or cid=="REVIEW_Y3_SIRIUS_REVEAL") or y3_option_available(cid,oid)
        if not store.m33_request["qa"] and store.m33_expected.get(cid)!=oid: return False
        return not (cid.startswith("Y3_") or cid=="REVIEW_Y3_SIRIUS_REVEAL") or y3_option_available(cid,oid)

    # Future years add their state builder here; the node/detail/replay UI is shared.
    M33_QA_BUILDERS = {
        1:lambda sid,recipe:y1_prepare_scene_review(sid),
        2:lambda sid,recipe:y2_prepare_review(sid,recipe.get("diary","expose"),recipe.get("cooperation","leave")),
        3:lambda sid,recipe:y3_prepare_review(sid,recipe["profile"],recipe["prior"]),
        4:lambda sid,recipe:y4_prepare_review(sid,recipe["profile"],recipe["prior"]),
    }

init python:
    config.no_replay_seen = True
    renpy.register_persistent("m33_scenes",m33_merge)

label m33_scene_replay:
    $ _autosave = False
    $ _game_menu_screen = None
    $ m33_ready = m33_prepare()
    if not m33_ready:
        call screen m33_unavailable
        $ renpy.end_replay()
    # Keep rollback inside this replay; initialization is not a reading position.
    $ renpy.block_rollback()
    show screen m33_replay_bar
    call expression M21_NODES[m33_request["scene"]]["replay"]["label"] from m33_call_scene
    $ renpy.end_replay()
    return
