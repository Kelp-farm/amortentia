init -10 python:
    Y4_REVIEW_PRESETS = {
        "standard":"원작 경로 · 헤르미온느와 친구로 참석",
        "dating_private":"팬픽 경로 · 카리나와 비밀 연애",
        "private_trust":"팬픽 경로 · 비밀 연애, 공개 조건 충족",
        "dating_public":"팬픽 경로 · 카리나와 공개 연애",
        "reconciled":"원작 경로 · 카리나와 화해, 아직 미교제",
        "estranged":"원작 경로 · 카리나와 화해 실패",
        "ginny":"원작 경로 · 지니와 참석",
        "luna":"원작 경로 · 루나와 우정 동행",
        "hermione_dating":"원작 경로 · 무도회에서 헤르미온느에게 고백",
        "ginny_dating":"원작 경로 · 지니와 우정 동행 (이전 검수 키)",
        "no_romance":"원작 경로 · 연애 없이 친구들과",
        "cedric_dead":"원작 경로 · 세드릭을 구하지 못함",
        "canon_peter_escape":"원작 경로 · 페티그루 도주",
        "fanfic_hermione":"팬픽 경로 · 헤르미온느와 친구로 참석",
        "fanfic_peter_escape":"팬픽 경로 · 페티그루 도주"}

    def y4_presets_for_scene(sid):
        condition=Y4_SCENES[sid]["condition"]
        found=[]
        for p in Y4_REVIEW_PRESETS:
            fanfic=p in ("dating_private","dating_public","private_trust","fanfic_hermione","fanfic_peter_escape")
            invite=("carina" if p in ("dating_private","private_trust","dating_public","reconciled","reconciled_dating","estranged","canon_peter_escape","fanfic_peter_escape") else
                "ginny" if p in ("ginny","ginny_dating") else "luna" if p=="luna" else "none" if p=="no_romance" else "hermione")
            partner="none" if p=="estranged" else invite
            if condition in ("memory_offer","memory_consent") and p not in ("dating_private","private_trust","fanfic_peter_escape"): continue
            if condition=="carina_dating" and not fanfic: continue
            if condition=="hidden_cloak_date" and not fanfic: continue
            if condition=="fanfic" and not fanfic: continue
            if condition=="canon_adjacent" and fanfic: continue
            if condition.startswith("invite_") and invite!=condition[7:]: continue
            if condition.startswith("partner_") and partner!=condition[8:]: continue
            if condition=="has_partner" and partner=="none": continue
            if condition=="other_partner_dating" and p!="fanfic_hermione": continue
            if condition=="carina_cover" and p not in ("dating_private","private_trust","fanfic_peter_escape"): continue
            found.append(p)
        return found

    def y4_review_preset_for(sid,preset):
        candidates=y4_presets_for_scene(sid)
        return preset if preset in candidates else candidates[0]

    def y4_flag(key):
        return store.vn["flags"].get(key,False)

    def y4_fanfic():
        return store.vn["world"]["y4_worldline"] == "fanfic"

    def y4_partner():
        return store.vn["world"]["y4_partner"]

    def y4_dating(h="carina"):
        return h in HEROINE_IDS and store.vn["romance"][h]["status"] == "dating"

    def y4_spew_badge_worn():
        # No retroactive membership or refusal is invented for older saves.
        return chose("Y4_SPEW_BADGE", "wear")

    def y4_harry_has_ring():
        ring = store.vn["world"]["carina_ring"]
        return ring in ("delivered","worn") or (ring == "returned" and y4_flag("y4_hidden_letter_read"))

    def y4_invitee():
        record=choice_record("Y4_BALL_INTENT")
        return record["option_id"] if record else "none"

    def y4_public_couple():
        return y4_dating() and store.vn["romance"]["carina"]["visibility"]=="public"

    def y4_confirm_public_partner():
        if y4_public_couple() and not choice_record("Y4_BALL_INTENT"):
            record_choice("Y4_BALL_INTENT","carina")

    def y4_can_confess(h):
        if not romance_can_pursue(h): return False
        if h=="carina" and not carina_hidden_committed(): return False
        if h!="carina" and carina_hidden_committed(): return False
        if h not in ("carina","hermione") or store.vn["route_intent"] == "no_romance": return False
        if any(y4_dating(other) for other in HEROINE_IDS): return False
        if h == "carina":
            if m42_main():
                return y3_carina_reconciled() or (store.vn["flags"].get("m42_carina_conversation",False)
                    and store.vn["flags"].get("m42_carina_farewell",False)
                    and remembers("carina","y4_invitation") and store.vn["relationships"][h]["affection"]>=4)
            return y3_carina_reconciled()
        return store.vn["romance"][h]["status"] == "none"

    def y4_ron_guess():
        # Only an openly acknowledged relationship is certain knowledge for Ron.
        public=[h for h in HEROINE_IDS if y4_dating(h) and store.vn["romance"][h]["visibility"]=="public"]
        if public: return public[0]
        plausible={"hermione": True,
            "ginny": remembers("ginny","y3_courtyard_game") or remembers("ginny","y3_courtyard_lesson") or remembers("ginny","y4_summer_flying"),
            "luna": remembers("luna","y3_corridor_listening") or remembers("luna","y3_corridor_drawing") or remembers("luna","y4_train_magazine"),
            "carina": y4_flag("y3_carina_reached_for_harry") or remembers("carina","y3_infirmary_care")}
        if store.vn["world"]["carina_early_romance_blocked"]: plausible["carina"]=False
        def score(h):
            r=store.vn["relationships"][h]
            return r["affection"]+len(store.vn["romance"][h]["memories"])*2
        return max([h for h in HEROINE_IDS if plausible[h]], key=score)

    def y4_begin():
        if store.vn["current_chapter"] or not store.vn["chapters"].get("Y3-C6",{}).get("completed"):
            raise ValueError("Year 4 requires a completed Year 3")
        if any(k.startswith("Y4-") for k in store.vn["chapters"]): raise ValueError("Year 4 already started")
        store.vn=migrate_state(store.vn)
        if not y4_flag("m32_handoff_ready"):
            raise ValueError("Finish the revised Year 3 farewell before entering Year 4")
        expected="fanfic" if carina_hidden_committed() else "canon_adjacent"
        if store.vn["world"]["y4_worldline"] != expected: raise ValueError("Inconsistent Year 3 handoff")
        set_world("story_origin","hidden" if carina_hidden_committed() else "main")
        store.vn["year4_entry"] = dict(worldline=expected,
            carina_bond=store.vn["world"]["y3_carina_bond"],
            dating=store.vn["world"]["y3_carina_dating"],
            visibility=store.vn["world"]["y3_carina_visibility"],
            peter=store.vn["world"]["pettigrew_status"],
            companion=store.vn["world"]["y3_rescue_companion"],
            early_blocked=store.vn["world"]["carina_early_romance_blocked"])
        set_story_flag("y4_campaign")
        set_story_flag("y4_worldline_frozen")
        store.y1_active_scene=store.y2_active_scene=store.y3_active_scene=None
        store.y1_portrait=store.y2_portrait=store.y3_portrait=None
        store.m21_last_node=None

    def y4_scene_available(sid):
        if sid in ("Y4-C8-S10","Y4-C8-S11"): return m732_scene_condition(sid)
        if sid=="Y4-C8-S08" and m732_altered(): return False
        if sid=="Y4-C6-S02": return y4_fanfic() and y4_flag("review_y4_moody_attacked")
        condition=Y4_SCENES[sid]["condition"]
        if condition == "always": return True
        if condition == "carina_dating": return y4_dating()
        if condition == "hidden_cloak_date": return y4_cloak_date_available()
        if condition in ("fanfic","canon_adjacent"): return store.vn["world"]["y4_worldline"]==condition
        if condition.startswith("invite_"): return y4_invitee()==condition[7:]
        if condition.startswith("partner_"): return y4_partner()==condition[8:]
        if condition=="has_partner": return y4_partner()!="none"
        if condition=="other_partner_dating": return y4_dating() and y4_invitee() not in ("carina","none")
        if condition=="carina_cover": return (y4_partner()=="carina" and y4_dating()
            and store.vn["romance"]["carina"]["visibility"]=="private")
        raise ValueError("Unknown Year 4 scene condition")

    def y4_private_date():
        return y4_dating() and store.vn["romance"]["carina"]["visibility"]=="private"

    def y4_cloak_date_available():
        return (carina_hidden_committed() and y4_fanfic() and y4_dating()
            and store.vn["world"]["y4_carina_separation"]=="none")

    def y4_option_available(cid,oid):
        if cid in ("Y4_MEMORY_PLAN","Y4_MEMORY_CONSENT"): return m732_option_available(cid,oid)
        if cid=="Y4_H_RON_RECONCILE": return y4_fanfic()
        if cid=="Y4_RON_RECONCILE": return not y4_fanfic()
        if cid=="Y4_REVIEW_JEALOUSY": return y4_fanfic()
        if cid=="Y4_CARINA_INFORMATION":
            # New Main Story flow cannot enter S04. Let an already-open old
            # menu finish without erasing the dialogue the player actually saw.
            return y4_fanfic() or getattr(store,"y4_active_scene",None)=="Y4-C2-S04"
        if cid=="Y4_CLOAK_DATE": return y4_cloak_date_available()
        if cid=="Y4_BALL_INTENT" and y4_public_couple(): return oid=="carina"
        if cid=="Y4_BALL_INTENT" and oid=="none": return not y4_dating()
        if cid in ("Y4_CUP_REUNION","Y4_AUTUMN_DATE","Y4_WINTER_DATE"): return y4_dating()
        if cid == "Y4_FERRET_WAIT": return y4_fanfic()
        if cid=="Y4_BALL_MEANING":
            h=y4_partner()
            if oid=="confess": return y4_can_confess(h)
            if oid=="affirm": return y4_dating(h)
            return h!="none" and not y4_dating(h)
        if cid=="Y4_VISIBILITY":
            h=y4_partner()
            if h=="carina" and choice_record("Y4_CARINA_PUBLICITY"): return False
            return (y4_dating(h) and store.vn["romance"][h]["visibility"]=="private"
                and (oid != "public" or h != "carina" or carina_public_ready()))
        if cid=="Y4_CARINA_PUBLICITY":
            return (y4_scene_available("Y4-C3-S12")
                and (oid!="public" or carina_public_ready()))
        if cid in ("Y4_SEPARATION_REPLY","Y4_FAREWELL_KISS"): return y4_dating()
        if cid=="Y4_CARINA_COVER": return False
        if cid=="Y4_CARINA_EGG_REPLY": return y4_fanfic()
        if cid=="Y4_PRIOR_COMMITMENT": return y4_scene_available("Y4-C3-S02")
        if cid=="Y4_FAIR_DUEL": return y4_fanfic()
        if cid in ("Y4_CUP","Y4_GRAVEYARD"): return not y4_fanfic()
        if cid.startswith("Y4_PRACTICE_") or cid.startswith("Y4_DANCE_"):
            return y4_partner()==cid.rsplit("_",1)[-1].lower()
        return True

    def y4_choice_needed(cid):
        if cid=="Y4_EGG_HELP" and y4_fanfic(): return False
        if cid=="Y4_BALL_INTENT" and y4_public_couple(): return False
        if cid=="Y4_BALL_MEANING" and y4_partner()=="ginny": return False
        if cid=="Y4_BALL_MEANING" and y4_partner()=="carina" and y4_dating(): return False
        return any(y4_option_available(cid,o["id"]) for o in CHOICES[cid]["options"])

    def y4_accept_invitation(h):
        if y4_invitee()!=h: raise ValueError("Invitation must follow the player's selection")
        if h=="carina" and store.vn["world"]["carina_early_romance_blocked"]:
            set_world("y4_partner","none")
            set_world("y4_ball_meaning","declined")
            set_story_flag("y4_carina_invitation_declined")
            return
        set_world("y4_partner",h)
        set_world("y4_ball_meaning","dating" if y4_dating(h) else "friends")
        relationship_event(h,"y4_invitation","memory","무도회에 함께 가기로 했다. 초대만으로 교제를 약속하지는 않았다.",False)

    def y4_ball_commit():
        h=y4_partner()
        if h=="none" or not choice_record("Y4_BALL_MEANING"): return
        if chose("Y4_BALL_MEANING","confess"):
            # Idempotency also allows a QA builder to call the same scene effects.
            if not any(e["id"]=="y4_ball_confession" for e in store.vn["romance"][h]["history"]):
                if not y4_can_confess(h): raise ValueError("Confession prerequisites not met")
                relationship_event(h,"y4_ball_confession","start","무도회 뒤 서로의 마음을 확인하고 사귀기로 했다.",True)
            set_world("y4_ball_meaning","confessed")
        elif chose("Y4_BALL_MEANING","affirm"):
            set_world("y4_ball_meaning","dating")
        else:
            set_world("y4_ball_meaning","friends")

    def y4_publish(choice_id="Y4_VISIBILITY"):
        h=y4_partner()
        if chose(choice_id,"public") and store.vn["romance"][h]["visibility"]!="public":
            if not y4_dating(h): raise ValueError("A dance is not a relationship")
            relationship_event(h,"y4_public_dating","publish","서로 동의하고 친구들 앞에서도 연인이라고 말하기로 했다.",True)
            set_story_flag("y4_relationship_publicly_known")

    def y4_separate():
        if store.vn["world"]["y4_carina_separation"]=="war_pressure": return
        if not y4_dating() or not choice_record("Y4_SEPARATION_REPLY"): return
        set_world("y4_carina_prior_visibility",store.vn["romance"]["carina"]["visibility"])
        relationship_event("carina","y4_forced_separation","separate",
            "볼드모트의 귀환과 가족의 압박 속에서 카리나가 이별을 고했다. 서로 좋아했던 사실과 앞선 화해는 사라지지 않았다.",False)
        set_world("y4_carina_separation","war_pressure")
        set_story_flag("y4_carina_feelings_unresolved")

    def y4_cedric_survives():
        return (y4_fanfic() or (chose("Y4_LAKE_PLAN","signal")
            and chose("Y4_MAZE_PREP","remember") and chose("Y4_CUP","signal")
            and chose("Y4_GRAVEYARD","warn")))

    def y4_hostage_name():
        return {"ron":"론","carina":"카리나","hermione":"헤르미온느","ginny":"지니","luna":"루나"}[store.vn["world"]["y4_hostage"]]

    def y4_finish_scene(sid):
        if store.vn["current_chapter"] != Y4_SCENES[sid]["chapter"]: raise ValueError("Year 4 chapter mismatch")
        if y4_flag("finished_"+sid): return
        if sid=="Y4-C5-S07":
            relationship_event("carina","y4_cloak_date","memory",
                "겨울 회랑에서 같은 망토를 쓰고 처음 만난 날을 이야기했다.",False)
            set_story_flag("y4_cloak_date_shared")
        if sid=="Y4-C1-S01" and y4_fanfic(): set_story_flag("y4_locket_recovered")
        if sid=="Y4-C8-S01" and y4_fanfic(): set_story_flag("review_hidden_cup_destroyed")
        if sid=="Y4-C3-S01": y4_confirm_public_partner()
        if sid=="Y4-C1-S04" and y4_fanfic():
            set_world("y4_moody","real_teacher")
            set_world("y4_real_moody_available",True)
        if sid in ("Y4-C1-S06","Y4-C1-S07","Y4-C5-S06"):
            key={"Y4-C1-S06":"cup_reunion","Y4-C1-S07":"autumn_date","Y4-C5-S06":"winter_date"}[sid]
            relationship_event("carina","y4_"+key,"memory",
                "사람들의 눈을 피해 투명 망토 안에서 함께 시간을 보냈다." if y4_private_date() else "숨지 않고 나란히 걸으며 함께 시간을 보냈다.",False)
            set_story_flag("y4_"+key+"_private",y4_private_date())
            if sid != "Y4-C1-S06":
                apply_effects([("relationship","carina","affection",2)], context=sid)
        if sid=="Y4-C2-S03" and y4_fanfic(): set_story_flag("y4_moody_saw_cloak",y4_private_date())
        if sid=="Y4-C2-S04" and y4_dating(): set_story_flag("y4_carina_ron_intervention")
        if sid=="Y4-C2-S08": set_story_flag("y4_trio_knows_horcrux")
        invitations={"Y4-C3-S03":"hermione","Y4-C3-S04":"ginny","Y4-C3-S05":"luna","Y4-C3-S06":"carina"}
        if sid in invitations: y4_accept_invitation(invitations[sid])
        if sid=="Y4-C3-S11" and y4_fanfic(): set_story_flag("y4_moody_trunk_mistake",y4_flag("review_y4_moody_attacked"))
        if sid=="Y4-C3-S12": y4_publish("Y4_CARINA_PUBLICITY")
        if sid=="Y4-C4-S07":
            y4_ball_commit()
            y4_publish()
        if sid=="Y4-C5-S02":
            h=y4_partner()
            # Hermione is Krum's hostage unless she attends with Harry; he chooses
            # another close friend in that case. Luna's friendship is equally real.
            set_world("y4_hostage","carina" if y4_fanfic() else h if h!="none" else "ron")
        if sid=="Y4-C6-S04": y4_separate()
        if sid=="Y4-C7-S02":
            set_world("y4_blood_taken",True)
            set_world("y4_winner","cedric")
        if sid=="Y4-C7-S04":
            alive=y4_cedric_survives()
            set_world("y4_cedric","alive" if alive else "dead")
            set_world("y4_thestral_witness",not alive)
            set_world("y4_blood_taken",True)
            set_world("y4_resurrection","graveyard")
            set_world("y4_harry_knowledge","witness")
            set_world("y4_ritual_servant","peter" if store.vn["world"]["pettigrew_status"]=="escaped" else "avery")
            set_world("y4_winner","shared")
        if sid=="Y4-C8-S02":
            set_world("y4_harry_knowledge","suspicion")
            set_story_flag("y4_hidden_letter_read")
            if store.vn["world"]["y4_carina_separation"]=="war_pressure":
                set_world("carina_ring","returned")
        if sid=="Y4-C8-S03":
            set_world("y4_moody","impostor_exposed")
            set_world("y4_real_moody_available",True)
            set_world("y4_crouch_jr","kissed")
        if sid=="Y4-C8-S04":
            if y4_fanfic():
                set_world("y4_resurrection","covert")
                set_world("y4_harry_knowledge","informed")
                set_world("y4_ritual_servant","karkaroff")
                set_world("y4_crouch_jr","at_large")
            set_world("y4_ministry_knowledge","warned" if y4_fanfic() else "testimony")
            set_world("y4_ministry_response","denial")
            set_world("ministry_truth","denial")
        if sid=="Y4-C8-S09":
            set_story_flag("y4_complete")
            store.vn["year5_handoff"] = dict(
                worldline=store.vn["world"]["y4_worldline"],moody=store.vn["world"]["y4_moody"],
                real_moody_available=store.vn["world"]["y4_real_moody_available"],
                cedric=store.vn["world"]["y4_cedric"],harry_knowledge=store.vn["world"]["y4_harry_knowledge"],
                ministry_knowledge=store.vn["world"]["y4_ministry_knowledge"],ministry_response="denial",
                ball_partner=y4_partner(),ball_meaning=store.vn["world"]["y4_ball_meaning"],
                carina_separation=store.vn["world"]["y4_carina_separation"],
                carina_prior_visibility=store.vn["world"]["y4_carina_prior_visibility"],
                thestral_witness=store.vn["world"]["y4_thestral_witness"],
                romance=state_copy(store.vn["romance"]),relationships=state_copy(store.vn["relationships"]),
                resurrection=store.vn["world"]["y4_resurrection"],ritual_servant=store.vn["world"]["y4_ritual_servant"],
                crouch_jr=store.vn["world"]["y4_crouch_jr"],peter=store.vn["world"]["pettigrew_status"],
                sirius=store.vn["world"]["sirius_status"],sirius_legal=store.vn["world"]["sirius_legal"],
                dobby=store.vn["world"]["dobby_status"],
                carina_early_blocked=store.vn["world"]["carina_early_romance_blocked"])
        m732_finish(sid)
        set_story_flag("finished_"+sid)
        m41_record_outcomes(sid)
        m33_complete(sid)

    def y4_enter_scene(sid):
        set_story_flag("m4e_scene_version")
        if store.vn["current_chapter"] != Y4_SCENES[sid]["chapter"] or not y4_scene_available(sid):
            raise ValueError("Unavailable Year 4 scene")
        if store.vn["year4_entry"]["worldline"] != store.vn["world"]["y4_worldline"]:
            raise ValueError("Year 4 worldline changed after entry")
        store.y4_active_scene=sid
        store.y4_portrait=None
        store.y4_offscreen=[]
        store.y4_expressions={}
        store.y4_bg_override=None
        store.y4_location_override=None
        set_story_flag("seen_"+sid)

    def y4_prepare_review(sid, preset="standard", overrides=None):
        require_key(Y4_SCENES,sid)
        defaults={"Y4_BALL_INTENT":"hermione","Y4_BALL_MEANING":"friend",
            "Y4_LAKE_PLAN":"signal","Y4_MAZE_PREP":"remember","Y4_CUP":"signal","Y4_GRAVEYARD":"warn"}
        prior={}
        profile="hermione"
        if preset in ("carina","dating_private","private_trust","dating_public","reconciled","reconciled_dating","estranged","fanfic_hermione","fanfic_peter_escape","canon_peter_escape"):
            profile="carina"
            defaults["Y4_BALL_INTENT"]="hermione" if preset=="fanfic_hermione" else "carina"
            prior["Y3_DATING_VISIBILITY"]="public" if preset=="dating_public" else "private"
            if preset in ("reconciled","reconciled_dating"):
                prior["Y3_COMMITMENT"]="friends"
                if preset=="reconciled_dating": defaults["Y4_BALL_MEANING"]="confess"
            elif preset=="canon_peter_escape": prior.update(Y3_COMMITMENT="friends",Y3_PETER="friends")
            elif preset=="estranged": prior.update(Y3_RING="keep",Y3_RESCUE="hermione")
            elif preset=="fanfic_peter_escape": prior["Y3_PETER"]="friends"
            else: defaults["Y4_BALL_MEANING"]="affirm" if preset!="fanfic_hermione" else "friend"
        elif preset in ("ginny","luna"):
            profile=preset
            defaults["Y4_BALL_INTENT"]=preset
        elif preset in ("hermione_dating","ginny_dating"):
            profile=preset.split("_")[0]
            defaults.update(Y4_BALL_INTENT=profile,Y4_BALL_MEANING="friend" if profile=="ginny" else "confess")
        elif preset=="no_romance": defaults["Y4_BALL_INTENT"]="none"
        elif preset=="cedric_dead": defaults.update(Y4_CUP="together",Y4_GRAVEYARD="cup")
        if sid=="Y4-C8-S11": defaults["Y4_MEMORY_PLAN"]="prepare"
        if sid=="Y4-C6-S02": defaults["Y4_REVIEW_MOODY"]="attack"
        if overrides:
            defaults.update(overrides)
            # Older QA recipes explicitly selected publicity at the end of the
            # ball. Replay that same requested decision at its new entry point.
            # This does not migrate saves or infer publicity from a cover story.
            if "Y4_VISIBILITY" in overrides and "Y4_CARINA_PUBLICITY" not in overrides:
                defaults["Y4_CARINA_PUBLICITY"] = overrides["Y4_VISIBILITY"]
            if "Y4_EGG_HELP" in overrides and "Y4_CARINA_EGG_REPLY" not in overrides:
                defaults["Y4_CARINA_EGG_REPLY"] = {"share":"explain", "cedric":"thank"}[overrides["Y4_EGG_HELP"]]
        if preset in ("dating_public","private_trust") or (preset == "reconciled" and defaults.get("Y4_VISIBILITY")=="public"):
            prior["m4e_public_history"] = True
        if overrides: prior.update({k:v for k,v in overrides.items() if k.startswith("M42_") or k in ("Y1_MALKIN_GUIDE","Y2_DIARY_EXPOSURE","Y2_CARINA_DECISION","Y3_OUTING","Y3_SECRET","Y3_COOP_RING","REVIEW_Y3_SIRIUS_REVEAL")})
        y3_prepare_review("Y3-C6-S07",profile,prior)
        for cid in Y3_SCENES["Y3-C6-S07"]["choices"]:
            if y3_review_choice_needed(cid):
                options=[o for o in CHOICES[cid]["options"] if y3_option_available(cid,o["id"])]
                if options: record_choice(cid,options[0]["id"])
        y3_finish_scene("Y3-C6-S07")
        complete_chapter("3학년 검수용 완료 이력")
        if preset=="no_romance": store.vn["route_intent"]="no_romance"
        y4_begin()
        for previous,meta in Y4_SCENES.items():
            if store.vn["current_chapter"]!=meta["chapter"]:
                if store.vn["current_chapter"]: complete_chapter("4학년 장면 이전의 임시 검수 이력")
                begin_chapter(meta["chapter"])
            if previous==sid: break
            if not y4_scene_available(previous): continue
            for cid in meta["choices"]:
                # A new confession must commit before the separate visibility menu.
                if cid=="Y4_VISIBILITY": y4_ball_commit()
                if not y4_choice_needed(cid): continue
                oid=defaults.get(cid,CHOICES[cid]["options"][0]["id"])
                if not y4_option_available(cid,oid):
                    oid=next(o["id"] for o in CHOICES[cid]["options"] if y4_option_available(cid,o["id"]))
                record_choice(cid,oid)
            y4_finish_scene(previous)
        store.y4_review_chapter=Y4_SCENES[sid]["number"]
        store.y4_review_offset=Y4_SCENES[sid]["offset"]
        store.vn["review_entry_scene"]=sid
        store.m21_last_node=None

default y4_active_scene = None
default y4_portrait = None
default y4_offscreen = []
default y4_expressions = {}
default y4_bg_override = None
default y4_location_override = None
default y4_preview_preset = "standard"
default y4_review_chapter = 1
default y4_review_offset = 0

label y4_scene(scene_id):
    $ vc_reset_stage()
    $ y4_enter_scene(scene_id)
    $ m21_visit(scene_id)
    hide screen y1_stage
    hide screen y2_stage
    hide screen y1_event_cg
    hide screen y2_event_cg
    hide screen y4_event_cg
    hide screen y3_stage
    hide screen y3_event_cg
    scene expression Solid("#182733")
    show screen y4_stage(scene_id)
    $ m43_scene_audio(scene_id)
    with Dissolve(0.25)
    return

label y4_cg(asset_id):
    show screen y4_event_cg(asset_id)
    with Dissolve(0.3)
    $ m21_unlock_cg("Y4:"+asset_id)
    return

label y4_cg_end:
    hide screen y4_event_cg
    with Dissolve(0.25)
    return
