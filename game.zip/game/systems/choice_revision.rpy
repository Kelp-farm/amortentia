# Change a reached answer by replaying an authentic earlier state, never by
# editing a completed choice or grafting flags into later worldlines.
default mpr_auto_answers = {}

init -1 python:
    def mpr_scene_for_choice(cid):
        sid=M41_CHOICE_SCENE.get(cid)
        if sid: return sid
        node=M21_NODES.get(cid)
        if node: return node["scene"]
        for year in range(1,8):
            scenes=Y1_REVIEW_SCENES if year==1 else globals()["Y%d_SCENES"%year]
            for sid,meta in scenes.items():
                if cid in [c[0] if isinstance(c,tuple) else c for c in meta.get("choices",[])]: return sid
        return None

    def mpr_pairs(state):
        return [(r["choice_id"],r["option_id"]) for r in state.get("choices",[])]

    def mpr_prefix(state,cid):
        pairs=mpr_pairs(state)
        return pairs[:next(i for i,p in enumerate(pairs) if p[0]==cid)] if any(p[0]==cid for p in pairs) else None

    def mpr_save_is_trusted(slot):
        # Inspect the signature before deserializing. A candidate-list refresh
        # must never open a trust prompt for a stale/imported checkpoint.
        tokens=getattr(renpy,"savetoken",None)
        if tokens and not getattr(renpy,"emscripten",False) and tokens.token_dir is not None and tokens.signing_keys:
            raw,signatures=renpy.loadsave.location.load(slot)
            if not tokens.verify_data(raw,signatures): return False
        return True

    def mpr_trusted_save_data(slot):
        if not mpr_save_is_trusted(slot): return None
        return renpy.get_save_data(slot)

    def mpr_checkpoints(cid,oid,state):
        prefix=mpr_prefix(state,cid)
        if prefix is None or m33_active(): return []
        rows=[]
        for slot,meta in m21_checkpoints(cid):
            try:
                saved=mpr_trusted_save_data(slot)
                if saved is None: continue
                raw=saved.get("vn")
                if raw is None or m21_fingerprint(raw)!=meta["m21_state"]: continue
                if canonical_name(saved.get("m21_choice_guard"))!=cid or choice_record(cid,raw): continue
                if mpr_pairs(raw)!=prefix: continue
                restored=migrate_state(raw)
                if m6_route_incompatible(restored) or y5_obsolete_save(restored): continue
                if restored.get("current_chapter")!=CHOICES[cid]["chapter_id"]: continue
                if m42_option_in_state(cid,oid,restored): rows.append((slot,meta))
            except Exception: continue
        return rows

    def mpr_entries(cid,oid,state):
        if cid not in CHOICES or not any(o["id"]==oid for o in CHOICES[cid]["options"]): return []
        sid=mpr_scene_for_choice(cid);prefix=mpr_prefix(state,cid)
        if not sid or prefix is None or m33_active(): return []
        rows=[]
        for record in msc_records(sid):
            before=mpr_pairs(record["state"])
            if len(before)>len(prefix) or prefix[:len(before)]!=before: continue
            # Choices between the authentic scene entry and the edited answer
            # are replayed in their original order. Nothing after it is seeded.
            local=state["choices"][len(before):len(prefix)]
            if any(mpr_scene_for_choice(r["choice_id"])!=sid for r in local): continue
            answers={r["choice_id"]:r["option_id"] for r in local};answers[cid]=oid
            rows.append(dict(record=record,answers=answers))
        return rows

    def mpr_can_change(cid,oid,state):
        if cid not in CHOICES or not any(o["id"]==oid for o in CHOICES[cid]["options"]): return False
        if mpr_checkpoints(cid,oid,state): return True
        # Later choices in the scene can depend on earlier local events; their
        # actual availability is rechecked at the unresolved choice interaction.
        return bool(m42_option_in_state(cid,oid,state) and mpr_entries(cid,oid,state))

    def mpr_backup():
        if not getattr(store,"main_menu",False):
            renpy.take_screenshot();renpy.save("scene-continue-backup",extra_info="선택 변경 전 진행")
        m21_save_persistent()

    def mpr_switch(cid,oid,state):
        if m33_active(): return
        checkpoints=mpr_checkpoints(cid,oid,state)
        entries=[] if checkpoints else mpr_entries(cid,oid,state)
        if not checkpoints and not entries:
            renpy.notify("이 선택을 되돌릴 수 있는 진행 기록이 없습니다.");return
        try: mpr_backup()
        except Exception:
            renpy.notify("현재 진행을 보관하지 못해 변경을 취소했습니다.");return
        if checkpoints:
            slot,meta=checkpoints[0]
            persistent.m21_pending_replay=dict(choice=cid,option=None,date=meta["m21_date"],origin=meta["m21_origin"],fingerprint=meta["m21_state"],mpr_option=oid)
            renpy.load(slot)
        else:
            entry=entries[0]
            renpy.session["mpr_entry"]=dict(fingerprint=m21_fingerprint(entry["record"]["state"]),answers=entry["answers"])
            msc_launch(entry["record"]["scene"],entry["record"]["resume_key"],False)

    def mpr_after_load():
        request=getattr(persistent,"m21_pending_replay",None)
        if request and request.get("mpr_option") and m21_fingerprint(store.vn)==request["fingerprint"] and not choice_record(request["choice"]):
            store.mpr_auto_answers={request["choice"]:request["mpr_option"]}
            renpy.retain_after_load()

    def mpr_auto_option(cid):
        return getattr(store,"mpr_auto_answers",{}).get(cid)

    def mpr_auto_ready(cid):
        oid=mpr_auto_option(cid)
        if oid is None or m33_active(): return False
        return not choice_record(cid) and m42_option_in_state(cid,oid,store.vn)

    def mpr_validate_auto(cid):
        if mpr_auto_option(cid) is not None and not mpr_auto_ready(cid):
            store.mpr_auto_answers={}
            renpy.notify("현재 조건에서는 그 응답을 고를 수 없습니다. 직접 선택해 주세요.")

    def mpr_take_auto(cid):
        answers=dict(store.mpr_auto_answers);answers.pop(cid,None);store.mpr_auto_answers=answers

    def mpr_apply_response(cid,answer):
        # A fast original click can have saved inside its Return action. Recheck
        # the requested response here as well as in the choice-screen timer.
        if mpr_auto_ready(cid):
            answer=mpr_auto_option(cid);mpr_take_auto(cid)
        return answer

    def mpr_record_launch(sid,index):
        records=m33_records(sid)
        if m33_active() or not 0<=index<len(records): return
        record=records[index];key=msc_record_key(record)
        if not any(r["resume_key"]==key for r in msc_records(sid)): return
        renpy.session["mpr_entry"]=dict(fingerprint=m21_fingerprint(record["state"]),answers=state_copy(record["choices"]))
        msc_launch(sid,key,not getattr(store,"main_menu",False))

    def mpr_review_launch(sid,preset,origin):
        draft=mrv_preview(sid,preset,origin)
        if not draft["available"]:
            renpy.notify(draft["note"]);return
        meta=Y1_REVIEW_SCENES[sid] if sid.startswith("Y1-") else globals()["Y%s_SCENES"%sid[1]][sid]
        local={c[0] if isinstance(c,tuple) else c for c in meta["choices"]}
        draft["answers"]={cid:oid for cid,oid in M33_QA_PRESETS[preset].get("local",{}).items() if cid in local}
        mrv_launch(draft,not getattr(store,"main_menu",False))

    def mpr_choice_rows(state):
        return [r for r in reversed(state.get("choices",[])) if r["choice_id"] in CHOICES and mpr_scene_for_choice(r["choice_id"])]

    def mpr_current_scene():
        for year in range(7,0,-1):
            sid=getattr(store,"y%d_active_scene"%year,None)
            if store.vn.get("flags",{}).get("y%d_campaign"%year) and m33_implemented(sid): return sid
        return None

    def mpr_preview_title(sid,preset):
        if sid=="Y2-C6-S04":
            return {"main":"본편 · 양장점 안내 거절","standard":"안내 수락 · 일기장 노출","y2_hidden":"안내 수락 · 일기장 은폐"}.get(preset,M33_QA_PRESETS[preset]["title"])
        return M33_QA_PRESETS[preset]["title"]

    def mpr_condition_rows(state,full=False):
        history={r["choice_id"]:r["option_id"] for r in state.get("choices",[])}
        position=m41_position(state);rows=[]
        def need(cid,oid,title):
            actual=history.get(cid)
            status="충족됨" if actual==oid else "충족 실패" if actual is not None or position>M41_CHOICE_ORDER.get(cid,(99,99,99)) else "충족되지 않음"
            rows.append(dict(cid=cid,oid=oid,title=title,status=status))
        need("Y1_MALKIN_GUIDE","accept","1학년 · 양장점에서 카리나의 안내 수락")
        need("Y2_DIARY_EXPOSURE","hide","2학년 · 루시우스에게 일기장 은폐")
        need("Y2_CARINA_DECISION","pressure","2학년 · 카리나에게 협력을 요구")
        if full:
            for cid,oid,title in (("Y3_POTIONS_VOLUNTEER","help","3학년 · 마법약 수업에서 도움 자청"),("Y3_MEAL_HELP","cut","3학년 · 식사 돕기"),("Y3_BRUSH_HELP","offer","3학년 · 다음 수발 제안"),("Y3_OUTING","carina","3학년 · 겨울 외출에서 카리나 만나기"),(y3_ring_choice_id(state),"wear","3학년 · 선물받은 반지 착용"),("Y3_RESCUE","carina","3학년 · 타임 터너 동행자로 카리나 선택"),("Y3_COMMITMENT","confess","3학년 · 경기 뒤 고백하고 교제")):
                need(cid,oid,title)
            f=state.get("flags",{});w=state.get("world",{})
            for flag,anchor,title in (("y3_carina_informed","Y3-C3-S03","시리우스의 결백을 카리나와 공유"),("y3_quarrel_resolved","Y3-C6-S04","반지 확인 후 관계 회복"),("y3_shared_patronus","Y3-C6-S04","같은 패트로누스로 마음 확인"),("y3_ring_confession","Y3-C6-S09","공개·비밀 중 하나로 실제 교제 합의")):
                done=bool(f.get(flag));passed=bool(f.get("finished_"+anchor)) or position>(M41_SCENE_ORDER[anchor][0],M41_SCENE_ORDER[anchor][1],99)
                rows.append(dict(cid=None,oid=None,title=title,status="충족됨" if done else "충족 실패" if passed else "충족되지 않음"))
        return rows

    def mpr_scene_reason(sid,state):
        if sid=="Y2-C6-S04" and m42_main(state):
            return "양장점 안내를 거절한 본편 이력입니다. 이 장면의 협박·협력 대화는 안내를 수락한 이력에서 열립니다."
        if sid=="Y2-C6-S06" and state.get("world",{}).get("carina_cooperation")!="pressured":
            return "앞선 교실에서 협력을 얻지 않아 카리나의 편지가 발생하지 않습니다."
        if carina_hidden_committed(state) and m732_altered(state):
            return "초기 히든 조건을 충족했고, 기억 변경 선택으로 현재는 본편 전개를 진행합니다."
        return ""

init 3 python:
    # Previously the reduced QA catalogue offered only the Main recipe here.
    M33_SCENE_VARIANTS["Y2-C6-S04"]=["main","y2_hidden","standard"]
    M33_SCENE_VARIANTS["Y2-C6-S06"]=["y2_pressure","y2_hidden_pressure"]
    if hasattr(config,"after_load_callbacks"): config.after_load_callbacks.append(mpr_after_load)
    _mpr_msc_prepare=msc_prepare
    def msc_prepare(record):
        year=_mpr_msc_prepare(record)
        request=renpy.session.pop("mpr_entry",None)
        store.mpr_auto_answers=state_copy(request["answers"]) if request and request["fingerprint"]==m21_fingerprint(store.vn) else {}
        return year
    _mpr_scene_started=m33_scene_started
    def m33_scene_started(sid):
        result=_mpr_scene_started(sid)
        pending=getattr(store,"m33_pending",None)
        if not m33_active() and pending and pending.get("scene")==sid and pending.get("continue_compat")!=MSC_COMPAT:
            result=bool(msc_capture_start(pending)) or result
        return result
