# A scene entry is a real historical state, independent of native save slots.
default msc_source = None

init -1 python:
    MSC_COMPAT = "scene-entry-1"
    MSC_BACKUP_SLOT = "scene-continue-backup"

    def msc_record_key(record):
        return "entry:" + m21_fingerprint(record["state"])

    def msc_capture_start(pending):
        pending["continue_compat"] = MSC_COMPAT
        pending["start_key"] = msc_record_key(pending)
        pending["time"] = m21_time.time()
        entry = dict(pending, key=pending["start_key"])
        entries = dict(getattr(persistent, "m33_scenes", {}) or {})
        rows = entries.get(entry["scene"], [])
        if any(msc_record_key(r) == entry["key"] for r in rows if isinstance(r.get("state"), dict)):
            return False
        entries[entry["scene"]] = (list(rows) + [entry])[-M33_LIMIT:]
        persistent.m33_scenes = entries
        return True

    def msc_entry_valid(record, sid):
        if not isinstance(record, dict) or not m33_implemented(sid): return False
        if record.get("scene") != sid or record.get("compat") != M33_COMPAT: return False
        if not record.get("complete") and record.get("continue_compat") != MSC_COMPAT: return False
        state = record.get("state", {})
        if not isinstance(state, dict): return False
        if not isinstance(state.get("choices"), list) or not isinstance(state.get("world"), dict): return False
        node = M21_NODES[sid]
        if state.get("current_chapter") != node["chapter"] or state.get("current_pov") != "harry": return False
        chapter = state.get("chapters", {}).get(node["chapter"], {})
        if not chapter or chapter.get("completed"): return False
        if m6_route_incompatible(state): return False
        if node["year"] >= 5 and y5_obsolete_save(state): return False
        if node["year"] == 3 and y3_needs_timeline_restart(state): return False
        return True

    def msc_records(sid):
        if m33_active() or not m21_seen_node(sid): return []
        candidates = list((getattr(persistent, "m33_scenes", {}) or {}).get(sid, []))
        pending = getattr(store, "m33_pending", None)
        if pending and pending.get("scene") == sid:
            # A loaded pre-feature save still has an authentic active entry.
            candidates.append(dict(pending, continue_compat=MSC_COMPAT, time=pending.get("time",m21_time.time())))
        by_state = {}
        for record in candidates:
            if not msc_entry_valid(record, sid): continue
            key = msc_record_key(record)
            if key not in by_state or record.get("time", 0) > by_state[key].get("time", 0):
                by_state[key] = dict(record, resume_key=key)
        return sorted(by_state.values(), key=lambda r:r.get("time", 0), reverse=True)

    def msc_can_continue(sid):
        return bool(msc_records(sid))

    def msc_history_title(record):
        state = record["state"]
        origin = "본편" if m42_main(state) else "카리나의 다른 이야기" if m42_hidden(state) else "입학 전"
        stamp = m21_time.strftime("%Y-%m-%d %H:%M", m21_time.localtime(record.get("time", 0)))
        return "%s · %s · 앞선 선택 %d개" % (stamp, origin, len(state["choices"]))

    def msc_launch(sid, key, backup_current=True):
        record = next((r for r in msc_records(sid) if r["resume_key"] == key), None)
        if record is None:
            renpy.notify("이어갈 수 있는 장면 이력을 찾지 못했습니다.")
            return False
        try:
            if backup_current:
                renpy.take_screenshot()
                renpy.save(MSC_BACKUP_SLOT, extra_info="장면 전환 전 진행")
            m21_save_persistent()
        except Exception:
            renpy.notify("현재 진행을 보관하지 못했습니다. 저장 공간을 확인해 주세요.")
            return False
        renpy.session["msc_request"] = state_copy(record)
        # Fresh store/context prevents later-scene UI or return stacks leaking back.
        renpy.full_restart(transition=None, label="msc_scene_start")

    def msc_prepare(record):
        sid = record.get("scene") if isinstance(record, dict) else None
        if not msc_entry_valid(record, sid): raise ValueError("Incompatible scene continuation entry")
        store.vn = migrate_state(record["state"])
        year = M21_NODES[sid]["year"]
        entry = Y1_REVIEW_SCENES[sid] if year == 1 else globals()["Y%d_SCENES" % year][sid]
        setattr(store, "y%d_review_chapter" % year, entry["chapter"] if year == 1 else entry["number"])
        setattr(store, "y%d_review_scene_offset" % year if year == 1 else "y%d_review_offset" % year, entry["offset"])
        store.m33_pending = None
        store.m33_expected = {}
        store.m33_forced = {}
        store.m21_last_node = None
        store.m41_presented_scene = None
        store.msc_source = dict(scene=sid, history=record.get("resume_key", msc_record_key(record)))
        return year

label msc_scene_start:
    $ msc_request = renpy.session.pop("msc_request", None)
    if msc_request is None:
        $ renpy.notify("장면을 다시 선택해 주세요.")
        return
    $ msc_year = msc_prepare(msc_request)
    $ msc_request = None
    $ renpy.block_rollback()
    stop music fadeout 0.2
    if msc_year == 1:
        jump y1_review_continue
    jump expression "y%d_continue" % msc_year
