init -30 python:
    def mock_choice_statistics(choice_id):
        percentages = MOCK_STATISTICS.get(choice_id)
        return {"source": "M0 mock data - not real players", "is_mock": True,
                "percentages": state_copy(percentages) if percentages else {}}

    # The only provider binding. No sockets, identifiers, or submission in M0.
    choice_statistics_provider = mock_choice_statistics

    def get_choice_statistics(choice_id):
        try:
            result = choice_statistics_provider(choice_id)
            percentages = result.get("percentages", {})
            options = {o["id"] for o in CHOICES[choice_id]["options"]}
            if not percentages:
                raise ValueError("No aggregate sample")
            if set(percentages) != options:
                raise ValueError("Mismatched aggregate option IDs")
            if any(type(v) not in (int, float) or not 0 <= v <= 100
                   for v in percentages.values()):
                raise ValueError("Invalid percentage")
            if abs(sum(percentages.values()) - 100.0) > 0.1:
                raise ValueError("Percentages must total 100")
            if type(result.get("is_mock")) is not bool or not isinstance(result.get("source"), str):
                raise ValueError("Provider must identify its source")
            return state_copy(result)
        except Exception:
            # Provider failure must never block reading or erase local choices.
            return {"source": "Statistics unavailable", "is_mock": False, "percentages": {}}

    def chapter_statistics_rows(chapter_id):
        rows = []
        for entry in store.vn["choices"]:
            if entry["chapter_id"] == chapter_id and entry["statistics"]:
                aggregate = get_choice_statistics(entry["choice_id"])
                rows.append({"choice": entry, "source": aggregate["source"],
                             "percent": aggregate["percentages"].get(entry["option_id"])})
        return rows
