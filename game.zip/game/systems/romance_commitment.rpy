# M7.5.1: derive commitments and local consequences from actual saved events.
init -28 python:
    M751_CONFLICTS = {
        "hermione": ("Y5_HERMIONE_CHO", "Y5_HERMIONE_CLEAR"),
        "ginny": ("Y5_GINNY_CHO", "Y5_GINNY_CLEAR"),
    }

    def romance_commitments(state=None):
        v=store.vn if state is None else state
        partners=[h for h,r in v["romance"].items() if r["status"] in ("dating","separated")]
        if carina_hidden_campaign(v) and "carina" not in partners: partners.append("carina")
        if cho_active(v): partners.append("cho")
        return tuple(partners)

    def romance_unresolved(heroine,state=None):
        v=store.vn if state is None else state
        pair=M751_CONFLICTS.get(heroine)
        return bool(pair and chose(pair[0],"overlap",v) and not chose(pair[1],"apologize",v))

    def romance_can_pursue(heroine,state=None):
        v=store.vn if state is None else state
        return not romance_commitments(v) and not romance_unresolved(heroine,v)

    def romance_commitment_text(state=None):
        names={"hermione":"헤르미온느","ginny":"지니","luna":"루나","carina":"카리나","cho":"초"}
        partners=romance_commitments(state)
        if len(partners)>1: return "이전 저장의 교제 기록이 겹쳐 있습니다. 새 교제 전의 기록으로 돌아가 주세요."
        if not partners: return None
        v=store.vn if state is None else state
        if partners==("carina",) and v["romance"]["carina"]["status"]=="separated":
            return "카리나와 떨어져 지내는 중"
        return names[partners[0]]+"와 교제 중"

    def m751_postwar_bond(heroine,state=None):
        v=store.vn if state is None else state
        f=v["flags"]; score=v["relationships"][heroine]["affection"]
        if heroine=="hermione":
            return bool(score>=6 and (f.get("y5_hermione_time") or v["world"].get("y4_partner")==heroine)
                and f.get("finished_Y7-C1-S02") and f.get("finished_Y7-C2-S05"))
        if heroine=="ginny":
            return bool(score>=4 and (f.get("y5_ginny_practice") or chose("Y5_GINNY_PRACTICE","watch",v))
                and f.get("finished_Y5-C6-S05") and f.get("finished_Y7-C1-S03"))
        if heroine=="luna":
            return bool(score>=4 and f.get("y5_luna_aftermath") and f.get("finished_Y7-C5-S03"))
        return bool(f.get("y7_carina_listened") and f.get("y7_carina_apologized"))

    def m751_no_romance_variant(state=None):
        v=store.vn if state is None else state
        return "wry" if all(romance_unresolved(h,v) for h in M751_CONFLICTS) else "independent"

    def m751_option_available(cid,oid):
        if cid in ("Y5_HERMIONE_CHO","Y5_GINNY_CHO"):
            return cho_eligible() and cho_active()
        if cid in ("Y5_HERMIONE_CLEAR","Y5_GINNY_CLEAR"):
            h="hermione" if cid=="Y5_HERMIONE_CLEAR" else "ginny"
            return cho_status()=="ended" and romance_unresolved(h)
        return False

    def m751_resolve(sid):
        for h,(advance,repair) in M751_CONFLICTS.items():
            if sid==("Y5-C4-S24" if h=="hermione" else "Y5-C4-S25") and choice_record(advance):
                detail=("초와 사귀면서 데이트를 요구했다가 거절당했다." if chose(advance,"overlap")
                    else "초와 사귀고 있다는 이야기를 직접 했다.")
                apply_relationship_event(store.vn,h,"m751_cho_"+h,"memory",detail)
            if sid=="Y5-C4-S26" and chose(repair,"apologize"):
                apply_relationship_event(store.vn,h,"m751_apology_"+h,"memory",
                    "초와 헤어진 뒤, 교제 중에 했던 부적절한 요구를 직접 사과했다.")

init 5 python:
    _m751_ending_proof=y7_ending_proof
    def y7_ending_proof(proof,ending):
        _m751_ending_proof(proof,ending)
        v=proof.state
        if ending not in ("hermione","ginny","luna") or carina_hidden_campaign(v): return
        if v["romance"][ending]["status"]!="none": return
        if cho_active(v):
            proof.need("Y5_CHO_BREAKUP","respect","초와의 교제가 끝난 뒤 새로운 마음을 전한다.")
        if romance_unresolved(ending,v):
            proof.need(M751_CONFLICTS[ending][1],"apologize","교제 중 했던 부적절한 요구를 당사자에게 직접 사과한다.")
        proof.row("함께한 개인적인 시간과 이후의 교류가 충분히 쌓였다.",
            "satisfied" if m751_postwar_bond(ending,v) else "impossible" if proof.after("Y7-C9-S04") else "unsatisfied")

    for _year,_scenes in ((5,("Y5-C4-S24","Y5-C4-S25","Y5-C4-S26")),
            (7,("Y7-C9-S04","Y7-C12-S06"))):
        for _kind,_repair,_name in (("unresolved","later","초 교제 중 중복 요구 · 사과하지 않음"),
                ("repaired","apologize","초 이별 뒤 당사자에게 사과함")):
            _key="m751_%d_"%_year+_kind
            M33_QA_PRESETS[_key]=dict(title=_name,profile="cho",prior={},local={
                "Y5_HERMIONE_CHO":"overlap","Y5_GINNY_CHO":"overlap",
                "Y5_HERMIONE_CLEAR":_repair,"Y5_GINNY_CLEAR":_repair})
            for _sid in _scenes:
                M21_NODES[_sid]["replay"]["presets"].append(_key)
                M33_SCENE_VARIANTS[_sid].append(_key)
    # These three scenes require a real Cho relationship; the memory campaign
    # has a living Cedric and must not receive generic memory QA recipes.
    for _sid in Y5_CHO_ROMANTIC_SCENES:
        M21_NODES[_sid]["replay"]["presets"][:]=[k for k in M21_NODES[_sid]["replay"]["presets"] if not k.startswith("memory")]
        M33_SCENE_VARIANTS[_sid][:]=[k for k in M33_SCENE_VARIANTS[_sid] if not k.startswith("memory")]

