init -1 python:
    M43_SCENE_MUSIC.update({sid:meta["music"] for sid,meta in Y6_SCENES.items()})
    M43_ENTRY_SFX.update({"Y6-C1-S05":"train","Y6-C1-S11":"train","Y6-C6-S02":"wind","Y6-C3-S13":"wind"})
    M42_HIDDEN_SCENES.update(Y6_SOURCE_SCENES)
    M33_QA_BUILDERS[6]=lambda sid,recipe:y6_prepare_review(sid,recipe["profile"],recipe.get("local"))
    for _p,_title in Y6_REVIEW_PRESETS.items():
        _key=("hidden6_" if _p in ("hidden","public") else "main6_")+_p
        M33_QA_PRESETS[_key]=dict(title=_title,profile=_p,prior={},local={})
    for _nid,_node in M21_NODES.items():
        if _node["year"]!=6: continue
        _ps=y6_presets_for_scene(_node["scene"])
        _node["replay"]["presets"]=[("hidden6_" if p in ("hidden","public") else "main6_")+p for p in _ps]
    for _asset,_title,_sid in (("carina_tower","내려놓지 못한 지팡이","Y6-C6-S05"),
            ("last_protection","내 목소리가 아닌 주문","Y6-C4-S17"),
            ("carina_reunion","곁에 남는 사람","Y6-C5-S16"),
            ("night_visit","방학 마지막 밤의 방문","Y6-C7-S14")):
        M21_CGS["Y6:"+_asset]=dict(year=6,asset=_asset,title=_title,scene=_sid)
    Y6_CONTINUATIONS={
        "main":dict(id="Y6-MAIN-TO-Y7",from_scene="Y6-C8-S05",destination="main_horcrux_hunt",
            title="7학년으로 · 남은 호크룩스",implemented=False,final_ending=False),
        "hidden":dict(id="Y6-HIDDEN-TO-Y7",from_scene="Y6-C8-S15",destination="hidden_soul_summer",
            title="7학년을 앞둔 여름 · 남은 영혼",implemented=False,final_ending=False)}

init 2 python:
    # Only histories which affect lines or available options get a picker.
    _m6_variants={
        "Y6-C1-S01":["main","bereaved","averted"],"Y6-C1-S03":["main","hermione","ginny"],
        "Y6-C2-S02":["main"],"Y6-C2-S03":["main","concealed"],
        "Y6-C2-S04":["main","ginny"],"Y6-C3-S02":["main","hermione","ginny","no_romance"],
        "Y6-C3-S03":["main","ginny","luna","no_romance","bereaved"],
        "Y6-C4-S03":["main","concealed"],"Y6-C5-S03":["main","ginny"],"Y6-C5-S04":["main","ginny"],
        "Y6-C5-S05":["main","hermione","ginny","luna","no_romance"],
        "Y6-C8-S01":["main","bereaved"],"Y6-C8-S02":["main","hermione","ginny","luna_romance"],
        "Y6-C8-S04":["main","bereaved"],"Y6-C8-S05":["main","bereaved"]}
    for _sid in Y6_SCENES:
        _profiles=(["hidden","public"] if _sid=="Y6-C6-S11" else ["hidden"]) if _sid in Y6_SOURCE_SCENES else _m6_variants.get(_sid,["main"])
        M33_SCENE_VARIANTS[_sid]=[("hidden6_" if p in ("hidden","public") else "main6_")+p for p in _profiles]

init 3 python:
    # Replay the consequences using actual earlier choices, not fabricated injuries.
    for _sid in ("Y6-C5-S02","Y6-C5-S03","Y6-C5-S04","Y6-C5-S05","Y6-C7-S02"):
        _base_keys=list(M33_SCENE_VARIANTS[_sid])
        for _base in _base_keys:
            if _sid=="Y6-C5-S05" and _base!="main6_ginny": continue
            _duel_variants=(("disarm","무장해제 · 중상 없음"),("hesitate","주저한 뒤 중단 · 중상 없음")) if _sid in ("Y6-C5-S02","Y6-C5-S03") else (("disarm","중상 회피"),)
            for _answer,_title in _duel_variants:
                # A literal starting with __ is filename-mangled by Ren'Py.
                _suffix=_answer if _sid in ("Y6-C5-S02","Y6-C5-S03") else "safe"
                _key=_base+"__"+"duel_"+_suffix
                M33_QA_PRESETS[_key]=dict(M33_QA_PRESETS[_base],title=M33_QA_PRESETS[_base]["title"]+" · "+_title,local={"Y6_DUEL":_answer})
                M21_NODES[_sid]["replay"]["presets"].append(_key)
                M33_SCENE_VARIANTS[_sid].append(_key)
