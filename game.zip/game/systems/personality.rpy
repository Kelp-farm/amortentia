init -30 python:
    def interpret_personality(axis, normalized, evidence):
        # Interpretation hook: expand with authored, choice-grounded text later.
        if not evidence:
            return "No recorded decisions for this axis yet."
        low, high = AXIS_LABELS[axis]
        if normalized <= -0.2:
            return "Your recorded decisions leaned toward %s." % low
        if normalized >= 0.2:
            return "Your recorded decisions leaned toward %s." % high
        return "Your recorded decisions show a mixed or slight tendency."

    def personality_summary(state=None):
        state = state or store.vn
        rows = []
        for axis, endpoints in AXIS_LABELS.items():
            evidence = sum(1 for entry in state["choices"] if any(
                change["kind"] == "personality" and change["path"][-1] == axis
                and change["before"] != change["after"] for change in entry["changes"]))
            normalized = state["personality"][axis] / 100.0
            rows.append({"axis": axis, "endpoints": endpoints, "normalized": normalized,
                         "evidence": evidence,
                         "text": interpret_personality(axis, normalized, evidence)})
        return rows
