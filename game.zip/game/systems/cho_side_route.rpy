init -9 python:
    def cho_status(state=None):
        v=store.vn if state is None else state
        return v["world"].get("y5_cho_relationship","none")

    def cho_active(state=None):
        return cho_status(state) in ("dating","strained")

    def cho_eligible(state=None):
        v=store.vn if state is None else state
        return (v["world"].get("y4_cedric")=="dead" and not carina_hidden_campaign(v)
            and v.get("route_intent")!="no_romance"
            and not any(r["status"] in ("dating","separated") for r in v["romance"].values()))

    def cho_scene_available(condition):
        if condition=="cho_interested": return cho_eligible() and cho_status()=="interested"
        if condition=="cho_active": return cho_eligible() and cho_active()
        if condition=="cho_article": return cho_eligible() and cho_active() and y5_flag("y5_interview_published")
        if condition=="cho_betrayal": return cho_eligible() and cho_active() and y5_flag("y5_da_betrayed")
        return False

    def cho_option_available(cid,oid):
        if cid=="Y5_CHO_INTEREST": return cho_eligible() and cho_status()=="none"
        if cid in ("Y5_CHO_AUTUMN","Y5_CHO_KISS"): return cho_eligible() and cho_status()=="interested"
        if cid in ("Y5_CHO_DATE","Y5_CHO_RECONNECT","Y5_CHO_BREAKUP"): return cho_eligible() and cho_active()
        return False

    def cho_resolve(sid):
        if sid=="Y5-C3-S21":
            set_story_flag("y5_cho_conversation")
            if chose("Y5_CHO_INTEREST","pursue"):
                if not cho_eligible(): raise ValueError("Cho relationship prerequisites were lost")
                set_world("y5_cho_relationship","interested")
        elif sid=="Y5-C3-S22":
            if not choice_record("Y5_CHO_KISS"): return
            set_world("y5_cho_relationship","dating" if chose("Y5_CHO_KISS","kiss") else "declined")
        elif sid=="Y5-C4-S21": set_world("y5_cho_relationship","strained")
        elif sid=="Y5-C4-S22": set_world("y5_cho_relationship","dating")
        elif sid=="Y5-C4-S23": set_world("y5_cho_relationship","ended")
        elif sid=="Y5-C4-S02": set_story_flag("y5_interview_published")

    def cho_relationship_view():
        status=cho_status()
        label={"none":"말을 나눈 선배","interested":"신경 쓰이는 선배","declined":"친구로 남은 사이",
            "dating":"연인 사이","strained":"서먹해진 사이","ended":"헤어진 사이"}[status]
        description={"none":"DA에서 함께 연습하고 이야기를 나눴다.","interested":"모임이 끝나면 조금 더 함께 있고 싶다.",
            "declined":"마음을 이야기한 뒤 친구로 지내기로 했다.","dating":"서로에게 마음을 표현하고 만나고 있다.",
            "strained":"호그스미드에서 다툰 뒤, 어떻게 말을 걸지 망설이고 있다.",
            "ended":"함께했던 겨울을 기억하지만, 더는 사귀지 않는다."}[status]
        return dict(label=label,description=description)
