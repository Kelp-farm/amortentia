init -13 python:
    def y1_choice_available(cid, state=None):
        # Reached-choice prerequisites are separate from Main/Hidden membership.
        # Export and the chart must still describe branches not yet chosen.
        if cid=="Y1_C4_SLUR": return chose("Y1_C4_NEVILLE", "confront", state)
        if cid=="Y1_C4_RELEASE": return chose("Y1_C4_SLUR", "fight", state)
        return True

    def y1_heard_carina_slur(state=None):
        state = store.vn if state is None else state
        # Both responses occur after hearing the insult; violence is a separate fact.
        # The old flag preserves actual pre-choice playthroughs without inventing an answer.
        return bool(state.get("flags", {}).get("y1_carina_slur_quarrel")
            or choice_record("Y1_C4_SLUR", state))
