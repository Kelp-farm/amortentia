init -13 python:
    def y1_heard_carina_slur(state=None):
        state = store.vn if state is None else state
        # Both responses occur after hearing the insult; violence is a separate fact.
        # The old flag preserves actual pre-choice playthroughs without inventing an answer.
        return bool(state.get("flags", {}).get("y1_carina_slur_quarrel")
            or choice_record("Y1_C4_SLUR", state))
