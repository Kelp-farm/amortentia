# M7.3.2: historical commitment is immutable; only the current campaign changes.
init -29 python:
    M732_REUNION_AFFECTION = 9
    M732_OTHER_ROMANCE_PENALTY = 12

    def m732_memory(state=None):
        state=store.vn if state is None else state
        return state.get("carina_memory",{})

    def m732_altered(state=None):
        return m732_memory(state).get("status") in ("altered","restored")

    def carina_hidden_campaign(state=None):
        return carina_hidden_committed(state) and not m732_altered(state)

    def m732_lucius_informed(state=None):
        state=store.vn if state is None else state
        # Author-only continuity: Harry cannot observe this offscreen discovery.
        return bool(carina_hidden_campaign(state) and not m732_public_history(state)
            and (chose("Y4_MEMORY_PLAN","keep",state) or chose("Y4_MEMORY_CONSENT","stop",state)))

    def m732_public_history(state=None):
        state=store.vn if state is None else state
        # Recorded/public relationship, not a friend privately guessing.
        return (state.get("world",{}).get("y3_carina_visibility")=="public"
            or state.get("romance",{}).get("carina",{}).get("visibility")=="public"
            or state.get("world",{}).get("y4_carina_prior_visibility")=="public"
            or chose("Y4_VISIBILITY","public",state))

    def m732_offer(state=None):
        state=store.vn if state is None else state
        return bool(carina_hidden_committed(state) and not m732_public_history(state)
            and not m732_altered(state))

    def m732_callbacks(state):
        return {
            "train_kiss":chose("Y3_TRAIN_KISS","kiss",state),
            "pursuit_kiss":bool(state["flags"].get("finished_Y3-C5-S01") and chose("Y3_SECRET","exclude",state)),
            "cloak_date":bool(choice_record("Y4_CLOAK_DATE",state)),
            "ball_together":state["world"].get("y4_partner")=="carina",
            "patronus":state["world"].get("y3_rescue_companion")=="carina",
        }

    def m732_erase():
        v=store.vn
        if m732_altered(): return
        if not (m732_offer() and chose("Y4_MEMORY_PLAN","prepare")
                and chose("Y4_MEMORY_CONSENT","proceed")
                and v["flags"].get("m732_spell_prepared")):
            raise ValueError("Memory alteration requires preparation and current mutual consent")
        # No world/choice reset. This snapshot is evidence of the actual history.
        v["carina_memory"]={"status":"altered","restoration":"unoffered",
            "altered_on":"2030-06-29","callbacks":m732_callbacks(v),
            "archive":"consented_carina_memory_and_scope_record",
            "ring_custodian":"harry","harry_remembers":True,"renewed":False,
            "history":["mutual_scope_agreement","harry_cast_limited_modification"]}
        apply_relationship_event(v,"carina","m732_farewell","breakup",
            "서로 동의해 카리나의 연애 기억을 바꿨다. 해리는 기억을 간직한다.",True)
        # The diary cooperation, Sirius knowledge, romance history and ring remain.

    def m732_finish(sid):
        if sid=="Y7-C9-S20" and chose("Y7_MEMORY_OFFER","tell"):
            m732_disclose_romances()
        v=store.vn
        if sid=="Y4-C8-S10" and chose("Y4_MEMORY_PLAN","prepare"):
            v["flags"]["m732_spell_prepared"]=True
        if sid=="Y4-C8-S11" and chose("Y4_MEMORY_CONSENT","proceed"):
            m732_erase()
        if sid=="Y7-C9-S20":
            v["carina_memory"]["restoration"]="invited" if chose("Y7_MEMORY_OFFER","tell") else "deferred"
        if sid=="Y7-C9-S21":
            consent=chose("Y7_MEMORY_RESTORE","restore")
            v["carina_memory"]["restoration"]="completed" if consent else "declined"
            if consent:
                v["carina_memory"]["status"]="restored"
                v["carina_memory"]["history"].append("present_day_consent_and_supervised_recovery")
        if sid=="Y7-C9-S23" and chose("Y7_MEMORY_CURRENT","end"):
            partner=m732_current_other(v)
            if partner:
                apply_relationship_event(v,partner,"m732_postwar_breakup","breakup",
                    "전쟁이 끝난 뒤 직접 만나, 다른 사람에게 마음이 남아 있음을 말하고 교제를 끝냈다.",True)
        if sid=="Y7-C9-S22" and chose("Y7_MEMORY_FUTURE","again"):
            if m732_memory(v).get("reunion_answer") in ("accepted","rejected"): return
            if not m732_can_ask(v): raise ValueError("A reunion proposal requires restoration and no current commitment")
            accepted=m732_can_reunite(v)
            v["carina_memory"]["reunion_answer"]="accepted" if accepted else "rejected"
            if accepted:
                apply_relationship_event(v,"carina","m732_new_commitment","reconcile",
                    "돌아온 기억을 확인한 뒤, 지금의 서로와 다시 사귀기로 했다.",True)
                v["carina_memory"]["renewed"]=True

    def m732_current_other(state=None):
        state=store.vn if state is None else state
        return next((h for h,r in state["romance"].items() if h!="carina" and r["status"] in ("dating","separated")),None)

    def m732_other_romances(state=None):
        """Actual commitments after the Year 4 farewell; friendship and dances do not count."""
        state=store.vn if state is None else state
        if not m732_altered(state): return []
        return [h for h,r in state["romance"].items() if h!="carina" and any(
            e["action"] in ("start","reconcile") and CHAPTERS.get(e.get("chapter"),{}).get("year",0)>=5
            for e in r.get("history",[]))]

    def m732_disclose_romances():
        """Apply the cost once, when Harry actually tells Carina. Replay/rollback use their own state."""
        known=m732_memory().get("disclosed_partners",[])
        new=[h for h in m732_other_romances() if h not in known]
        if not new: return False
        if not chose("Y7_MEMORY_OFFER","tell"): return False
        previous_logs=len(store.vn.get("affection_history",[]))
        apply_effects([("relationship","carina","affection",-M732_OTHER_ROMANCE_PENALTY*len(new))],context="Y7-C9-S20")
        store.vn["carina_memory"]["disclosed_partners"]=known+new
        changed=len(store.vn["affection_history"])>previous_logs
        if changed: store.vn["affection_history"][-1]["text"]="카리나에게 이별 뒤 다른 사람과 교제했던 사실을 이야기했다."
        return changed

    def m732_can_ask(state=None):
        state=store.vn if state is None else state
        return bool(m732_memory(state).get("status")=="restored"
            and m732_memory(state).get("restoration")=="completed"
            and state.get("route_intent")!="no_romance"
            and not any(r["status"] in ("dating","separated") for r in state["romance"].values()))

    def m732_can_reunite(state=None):
        state=store.vn if state is None else state
        return m732_can_ask(state) and state["relationships"]["carina"]["affection"]>=M732_REUNION_AFFECTION

    def m732_inherited(item,state=None):
        state=store.vn if state is None else state
        return m732_altered(state) and state.get("flags",{}).get("review_hidden_"+item+"_destroyed",False)

    def m732_scene_condition(sid):
        if sid=="Y4-C8-S10": return m732_offer()
        if sid=="Y4-C8-S11": return m732_offer() and chose("Y4_MEMORY_PLAN","prepare")
        if sid=="Y7-C9-S20": return m732_altered() and y7_flag("voldemort_final_defeat")
        if sid=="Y7-C9-S21": return m732_altered() and chose("Y7_MEMORY_OFFER","tell")
        if sid=="Y7-C9-S22": return m732_altered() and m732_memory().get("status")=="restored"
        if sid=="Y7-C9-S23": return m732_scene_condition("Y7-C9-S22") and bool(m732_current_other())
        if sid=="Y7-C9-S24": return m732_can_ask()
        if sid=="Y7-C11-S20": return m732_memory().get("renewed",False) and chose("Y7_FUTURE","return")
        return False

    def m732_option_available(cid,oid):
        if cid=="Y4_MEMORY_PLAN": return m732_offer()
        if cid=="Y4_MEMORY_CONSENT": return m732_offer() and chose("Y4_MEMORY_PLAN","prepare") and store.vn["flags"].get("m732_spell_prepared",False)
        if cid=="Y7_MEMORY_OFFER": return m732_scene_condition("Y7-C9-S20")
        if cid=="Y7_MEMORY_RESTORE": return m732_scene_condition("Y7-C9-S21")
        if cid=="Y7_MEMORY_CURRENT": return m732_scene_condition("Y7-C9-S23")
        if cid in ("Y7_MEMORY_LISTEN","Y7_MEMORY_PRESENT"): return m732_scene_condition("Y7-C9-S24")
        if cid=="Y7_MEMORY_FUTURE": return m732_scene_condition("Y7-C9-S22") and (oid=="friends" or m732_can_ask())
        return False

    def m732_prepare_review(year,sid,overrides=None):
        """Replay real choices through each actual resolver; never graft AU flags onto a Main save."""
        defaults={"Y4_MEMORY_PLAN":"prepare","Y4_MEMORY_CONSENT":"proceed",
            "Y5_VERIFY":"contact","Y5_DEPART":"team","Y5_BATTLE":"cover",
            "Y5_GINNY_KISS":"cheer","Y6_FEELINGS":"friends",
            "Y7_RELATIONSHIP":"friends","Y7_FUTURE":"return",
            "Y7_MEMORY_OFFER":"tell","Y7_MEMORY_RESTORE":"restore","Y7_MEMORY_CURRENT":"stay",
            "Y7_MEMORY_LISTEN":"listen","Y7_MEMORY_PRESENT":"present","Y7_MEMORY_FUTURE":"again"}
        defaults.update(overrides or {})
        y4_prepare_review("Y4-C8-S10","dating_private",overrides)
        for current in range(4,year+1):
            if current>4: globals()["y%d_begin"%current]()
            scenes=globals()["Y%d_SCENES"%current]
            first=False
            for old,meta in scenes.items():
                if current==4:
                    if old=="Y4-C8-S10": first=True
                    if not first: continue
                if store.vn["current_chapter"]!=meta["chapter"]:
                    if store.vn["current_chapter"]: complete_chapter("기억 변경 경로 · 임시 감상 이력")
                    begin_chapter(meta["chapter"])
                if current==year and old==sid:
                    if not globals()["y%d_scene_available"%current](sid): raise ValueError("Memory QA target is not reachable")
                    setattr(store,"y%d_review_chapter"%current,meta["number"])
                    setattr(store,"y%d_review_offset"%current,meta["offset"])
                    store.vn["review_entry_scene"]=sid;store.m21_last_node=None
                    return
                if not globals()["y%d_scene_available"%current](old): continue
                for cid in meta["choices"]:
                    if not globals()["y%d_choice_needed"%current](cid): continue
                    options=[o["id"] for o in CHOICES[cid]["options"] if globals()["y%d_option_available"%current](cid,o["id"])]
                    oid=defaults.get(cid,options[0])
                    if oid not in options: oid=options[0]
                    record_choice(cid,oid)
                globals()["y%d_finish_scene"%current](old)
            if store.vn["current_chapter"]: complete_chapter("기억 변경 경로 · 이전 학년 완료")
        raise ValueError("Unknown memory-route scene")
