init 0 python:
    # Temporary QA recipes. They never write discoveries or player checkpoints.
    for _p,_profile,_title in (("main","hermione","본편 · 친구들과 함께"),
        ("main_carina","carina","본편 · 카리나와의 교류"),
        ("main_ginny","ginny","본편 · 지니와의 교류"),
        ("main_luna","luna","본편 · 루나와의 우정"),
        ("main_distant","hermione","본편 · 친구들과의 마찰")):
        _prior={"Y1_MALKIN_GUIDE":"decline","M42_CARINA_SNOW":"talk",
            "M42_CARINA_FAREWELL":"friendly"}
        if _p=="main_distant":
            _prior.update(M42_RON_ARGUMENT="withdraw",M42_SCABBERS="blame")
        M33_QA_PRESETS[_p]=dict(title=_title,profile=_profile,prior=_prior,local={})
    def m42_qa_y4(sid,recipe):
        profile={"hermione":"standard","carina":"reconciled","ginny":"ginny","luna":"luna"}.get(recipe["profile"],recipe["profile"])
        y4_prepare_review(sid,profile,recipe["prior"])
    M33_QA_BUILDERS[1]=lambda sid,recipe:y1_prepare_scene_review(sid,recipe["prior"])
    M33_QA_BUILDERS[2]=lambda sid,recipe:y2_prepare_review(sid,recipe.get("diary","expose"),recipe.get("cooperation","leave"),recipe["prior"])
    M33_QA_BUILDERS[4]=m42_qa_y4
    for _nid,_node in M21_NODES.items():
        if _node["type"]!="scene" or _node["year"]>=5: continue
        _sid=_node["scene"]
        if _sid in M42_HIDDEN_SCENES: continue
        _extra=["main"]
        if _node["year"]==3 and _sid in ("Y3-C6-S02","Y3-C6-S05"):
            _extra += ["main_distant"]
        if _node["year"]==3 and _sid=="Y3-C6-S07": _extra += ["main_carina"]
        if _node["year"]==4:
            # Only physically possible partners/worldline scenes are offered.
            _extra=["main","main_carina","main_ginny","main_luna"]
            _old=M33_SCENE_VARIANTS.get(_sid,_node["replay"]["presets"])
            # Register against the full physical recipes, not the reduced
            # generated menu (which may retain a main_* alias as representative).
            _extra=[p for p in _extra if "m4_"+{"main":"standard","main_carina":"reconciled","main_ginny":"ginny","main_luna":"luna","main_distant":"standard"}[p] in _node["replay"]["presets"]]
        _node["replay"]["presets"]=list(dict.fromkeys(_extra+_node["replay"]["presets"]))
        if _node["year"]==4:
            M33_SCENE_VARIANTS[_sid]=[p for p in _old if p in _node["replay"]["presets"]]
            continue
        # Shared scenes do not need two equivalent framework selections.
        if _sid in M42_MAIN_SCENES or _sid in ("Y1-C1-S06","Y1-C4-S03","Y1-C4-S04","Y2-C5-S03","Y2-C6-S01") or _node["year"]==4:
            M33_SCENE_VARIANTS[_sid]=_extra+M33_SCENE_VARIANTS.get(_sid,_node["replay"]["presets"])
        elif _extra:
            M33_SCENE_VARIANTS[_sid]=[_extra[0]]+([p for p in M33_SCENE_VARIANTS.get(_sid,[]) if p!="standard"] if _node["year"]==3 else [])
        M33_SCENE_VARIANTS[_sid]=list(dict.fromkeys(M33_SCENE_VARIANTS.get(_sid,[])))
    # These scenes now have a played Hidden quarrel or its actual aftermath.
    # Keep both incoming histories even when the previous generated menu was shared.
    for _sid in ("Y1-C4-S03", "Y1-C4-S04", "Y2-C2-S02", "Y2-C2-S03"):
        M33_SCENE_VARIANTS[_sid] = ["main", "standard"]
