init -1 python:
    Y7_ENDINGS={"hermione":("헤르미온느 · 함께 찾은 답","Y7-C12-S01"),
        "ginny":("지니 · 각자의 이름으로","Y7-C12-S02"),"luna":("루나 · 아직 남은 빈 곳","Y7-C12-S03"),
        "carina":("카리나 본편 · 이번에는 잡은 손","Y7-C12-S04"),
        "no_romance":("연애 없이 · 내가 설 자리","Y7-C12-S06"),
        "carina_hidden":("카리나 히든 · 빼앗기지 않은 내일","Y7-C12-S11")}
    M21_ENDINGS["annual_y7"]=dict(title="일곱 해의 끝",year=7,implemented=True,kind="annual",scene="Y7-C12-S06")
    for _key,(_title,_sid) in Y7_ENDINGS.items():
        M21_ENDINGS["route_"+_key]=dict(title=_title,year=7,implemented=True,kind="route",route=_key,scene=_sid)
        M41_TARGETS["route_"+_key]=dict(group="carina" if _key=="carina_hidden" else _key,
            title=_title,hint="지나온 선택과 현재 관계에 따라 이어지는 마지막 이야기입니다.",kind="y7_ending",ending=_key,anchor=_sid)
    M43_SCENE_MUSIC.update({sid:meta["music"] for sid,meta in Y7_SCENES.items()})
    M42_HIDDEN_SCENES.update(Y7_SOURCE_SCENES)
    M33_QA_BUILDERS[7]=lambda sid,recipe:y7_prepare_review(sid,recipe["profile"],recipe.get("local"))
    for _p,_title in Y7_REVIEW_PRESETS.items():
        _key=("hidden7_" if _p in ("hidden","public") else "main7_")+_p
        M33_QA_PRESETS[_key]=dict(title=_title,profile=_p,prior={},local={})
    for _nid,_node in M21_NODES.items():
        if _node["year"]!=7: continue
        _node["replay"]["presets"]=[("hidden7_" if p in ("hidden","public") else "main7_")+p for p in y7_presets_for_scene(_node["scene"])]

    # Alternate incoming histories reuse real choices; no fabricated state flags.
    def _y7_add_qa(sid,base_key,suffix,title,local):
        key=base_key+"__"+suffix
        M33_QA_PRESETS[key]=dict(M33_QA_PRESETS[base_key],title=title,local=local)
        M21_NODES[sid]["replay"]["presets"].append(key)
    for _sid in Y7_SCENES:
        _condition=Y7_SCENES[_sid]["condition"]
        if _condition.startswith("end_"):
            _base=M21_NODES[_sid]["replay"]["presets"][0]
            _y7_add_qa(_sid,_base,"auror","같은 상대 · 오러 진로",{"Y7_FUTURE":"auror"})
    for _sid in ("Y7-C3-S02","Y7-C3-S04","Y7-C3-S06"):
        _y7_add_qa(_sid,"main7_main","ron_left","론이 떠났다가 돌아온 이력",{"Y7_RON_ARGUMENT":"leave"})
    for _sid in ("Y7-C5-S03","Y7-C5-S04","Y7-C9-S01"):
        _y7_add_qa(_sid,"main7_main","dobby_lost","지팡이를 챙기고 도비를 잃은 이력",{"Y7_MANOR_ESCAPE":"wands"})
    for _sid in ("Y7-C7-S04","Y7-C8-S06"):
        _y7_add_qa(_sid,"main7_main","fred_lost","현관을 지키고 프레드를 잃은 이력",{"Y7_BATTLE_PREP":"defend"})
    _y7_add_qa("Y7-C12-S11","hidden7_hidden","teach","히든 · 교육 진로",{"Y7_H_FUTURE":"teach"})

    def y7_ending_proof(proof,ending):
        s=proof.state;f=proof.flags;w=proof.world
        current=next((h for h,r in s["romance"].items() if r["status"]=="dating"),None)
        if ending=="carina_hidden":
            if carina_hidden_committed(s): proof.row("3학년 교제 확정은 강제 이별 뒤에도 유지됩니다.","satisfied")
            else: proof.worldline("fanfic")
            proof.fact(f.get("y7_hidden_soul_resolution"),"Y7-C6-S13","생일 전에 남은 영혼 조각을 해결한다.")
            proof.fact(s.get("year7",{}).get("legal_resolution"),"Y7-C8-S12","조사 결과를 받고 자유롭게 미래를 정한다.")
            proof.fact(f.get("y7_hidden_shared_future"),"Y7-C11-S13","회복과 졸업 뒤 함께 살기로 합의한다.")
            return
        proof.worldline("canon_adjacent")
        if current and current!=ending:
            proof.row("이미 약속한 연인을 다른 사람으로 바꾸는 경로는 없습니다.","impossible")
            return
        proof.fact(f.get("voldemort_final_defeat"),"Y7-C8-S05","남은 호크룩스를 해결하고 전쟁을 마친다.")
        if ending=="no_romance":
            proof.need("Y7_RELATIONSHIP","friends","전후에도 친구 관계를 유지한다.")
            if proof.actual.get("Y7_CARINA_ACCOUNT")=="listen" or proof.future("Y7_CARINA_ACCOUNT"):
                proof.need("Y7_CARINA_POSTWAR","friends","카리나와 새 교제를 시작하지 않는다.")
        elif current==ending:
            proof.row("현재 연인과의 약속을 유지한다.","satisfied")
        elif s.get("route_intent")=="no_romance":
            proof.row("연애하지 않는 진행을 선택했습니다.","impossible")
        elif ending=="carina":
            proof.need("Y7_CARINA_ACCOUNT","listen","전후 카리나의 말을 직접 듣는다.")
            proof.need("Y7_RELATIONSHIP","friends","다른 사람과 교제를 시작하지 않는다.")
            proof.fact(f.get("y7_carina_apologized"),"Y7-C9-S03","카리나가 헤르미온느에게 자신의 잘못을 사과한다.")
            proof.need("Y7_CARINA_POSTWAR","date","전쟁 뒤 새로 사귀자는 뜻을 전하고 서로 동의한다.")
        else:
            if s["romance"][ending]["status"]!="none":
                proof.row("끝난 관계를 이 장면에서 자동으로 되돌리지는 않습니다.","impossible")
            proof.need("Y7_RELATIONSHIP",ending,"전쟁 뒤 마음을 전하고 함께 사귀기로 한다.")
        future=proof.actual.get("Y7_FUTURE")
        if future: proof.row("오러와 복학 모두 같은 상대와의 결말로 이어집니다.","satisfied")
        else: proof.need("Y7_FUTURE","return","원하는 미래를 고른다. 별을 보는 장면은 복학에서 이어진다.")

init 2 python:
    for _sid in Y7_SCENES:
        M33_SCENE_VARIANTS[_sid]=M21_NODES[_sid]["replay"]["presets"][:]

init -1 python:
    M21_CGS["Y7:camp_hermione"]=dict(year=7,asset="camp_hermione",title="첫 경계의 차",scene="Y7-C2-S05")
    M21_CGS["Y7:manor_carina"]=dict(year=7,asset="manor_carina",title="확실하지 않은 얼굴",scene="Y7-C4-S04")
    M21_CGS["Y7:battle_friends"]=dict(year=7,asset="battle_friends",title="각자의 자리에서",scene="Y7-C7-S04")
    M21_CGS["Y7:apology"]=dict(year=7,asset="apology",title="그날의 말에 대한 사과",scene="Y7-C9-S03")
    M21_CGS["Y7:star_hermione"]=dict(year=7,asset="star_hermione",title="설명하지 않아도 되는 별",scene="Y7-C11-S01")
    M21_CGS["Y7:star_ginny"]=dict(year=7,asset="star_ginny",title="서로의 앞을 달리는 사람",scene="Y7-C11-S02")
    M21_CGS["Y7:star_luna"]=dict(year=7,asset="star_luna",title="아직 모르기로 한 밤",scene="Y7-C11-S03")
    M21_CGS["Y7:star_carina"]=dict(year=7,asset="star_carina",title="카리나가 내민 손바닥",scene="Y7-C11-S04")
    M21_CGS["Y7:star_carina_harry"]=dict(year=7,asset="star_carina_harry",title="해리가 먼저 내민 손",scene="Y7-C11-S04")
    M21_CGS["Y7:family_hermione"]=dict(year=7,asset="family_hermione",title="아이리스의 첫 질문",scene="Y7-C12-S01")
    M21_CGS["Y7:family_ginny"]=dict(year=7,asset="family_ginny",title="네 이름으로 살아도 돼",scene="Y7-C12-S02")
    M21_CGS["Y7:family_luna"]=dict(year=7,asset="family_luna",title="빈 곳이 남은 지도",scene="Y7-C12-S03")
    M21_CGS["Y7:family_carina"]=dict(year=7,asset="family_carina",title="다시 손을 흔드는 날",scene="Y7-C12-S04")
    M21_CGS["Y7:hidden_soul"]=dict(year=7,asset="hidden_soul",title="내 안의 마지막 목소리",scene="Y7-C6-S13")
    M21_CGS["Y7:hidden_awakening"]=dict(year=7,asset="hidden_awakening",title="다시 부르는 이름",scene="Y7-C7-S11")
    M21_CGS["Y7:hidden_future"]=dict(year=7,asset="hidden_future",title="같이 정할 내일",scene="Y7-C11-S13")
    M21_CGS["Y7:family_carina_hidden"]=dict(year=7,asset="family_carina_hidden",title="리라의 첫 출발",scene="Y7-C12-S11")

init -1 python:
    def y7_branch_graph(chapter):
        """Exclusive late-year destinations; no edge passes through another heroine."""
        boxes=[];edges=[];links=[]
        def box(nid,x,y,w=220,h=148,oid=None):
            b=dict(nid=nid,oid=oid,x=x,y=y,w=w,h=h);boxes.append(b);return b
        def line(x1,y1,x2,y2,cid=None,oid=None):
            edges.append(dict(x=min(x1,x2),y=min(y1,y2),w=max(2,abs(x2-x1)),h=max(2,abs(y2-y1)),cid=cid,oid=oid))
        def edge(a,b,cid=None,oid=None):
            ax=a['x']+a['w']/2;ay=a['y']+a['h'];bx=b['x']+b['w']/2;by=b['y'];mid=by-18
            line(ax,ay,ax,mid,cid,oid);line(ax,mid,bx,mid,cid,oid);line(bx,mid,bx,by,cid,oid)
            links.append((a['nid'],b['nid'],cid,oid))
        if chapter==10:
            for x,ids,oid in ((16,[1,2,3],'auror'),(380,[4,5],'return')):
                last=None
                for i,num in enumerate(ids):
                    b=box('Y7-C10-S%02d'%num,x,40+i*200,w=328)
                    if last: edge(last,b,'Y7_FUTURE',oid)
                    else: line(x+164,0,x+164,40,'Y7_FUTURE',oid)
                    last=b
            return dict(boxes=boxes,edges=edges,links=links,width=724,height=650)
        if chapter==12:
            for i,num in enumerate((1,2,3,4,6)):
                b=box('Y7-C12-S%02d'%num,12+(i%3)*240,55+(i//3)*230)
                # Endpoints are alternatives, with independent incoming paths.
                line(b['x']+110,b['y']-30,b['x']+110,b['y'])
            return dict(boxes=boxes,edges=edges,links=links,width=724,height=470)
        stars=[]
        for i,num in enumerate((1,2,3,4,5)):
            _star='Y7-C11-S20' if num==4 and m732_altered() else 'Y7-C11-S%02d'%num
            b=box(_star,12+(i%3)*240,40+(i//3)*230)
            line(b['x']+110,b['y']-24,b['x']+110,b['y']);stars.append(b)
        if m732_altered():
            graduation=box('Y7-C11-S06',198,590,w=328,h=100)
            for _star in stars: edge(_star,graduation)
            return dict(boxes=boxes,edges=edges,links=links,width=724,height=715)
        choice=box('Y7_HANDSHAKE',12,470,w=328,h=82)
        edge(stars[3],choice)
        tails=[]
        for i,oid in enumerate(('harry','carina')):
            opt=box('Y7_HANDSHAKE',12+i*174,590,w=160,h=124,oid=oid)
            edge(choice,opt,'Y7_HANDSHAKE',oid);tails.append(opt)
        graduation=box('Y7-C11-S06',198,820,w=328,h=100)
        # Route vertical connectors outside other boxes before the common graduation.
        for i,b in enumerate(stars[:3]+[stars[4]]+tails):
            lane=4+i*3 if i<3 else 706+i*2
            x=b['x']+b['w']/2;y=b['y']+b['h']
            line(x,y,x,y+10);line(x,y+10,lane,y+10);line(lane,y+10,lane,792)
            line(lane,792,362,792);line(362,792,362,820)
            links.append((b['nid'],graduation['nid'],None,b.get('oid')))
        return dict(boxes=boxes,edges=edges,links=links,width=724,height=945)
