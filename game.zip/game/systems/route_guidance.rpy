default persistent.m41_outcomes = set()
default persistent.m41_spoilers = False
default m41_presented_scene = None

init -2 python:
    M41_STATUS = {"satisfied":"충족됨", "unsatisfied":"충족되지 않음", "pending":"충족되지 않음", "impossible":"충족 실패", "unknown":"확인 불가"}

    def m41_guide_section(target=None):
        if target is None or M41_TARGETS.get(target, {}).get("kind") == "y7_ending":
            return "endings"
        return "events"

    def m41_guide_targets(section, group=None):
        # Read the final registry after every implemented year has registered.
        # Intermediate outcomes can coexist; their count is not an ending count.
        return [tid for tid, meta in M41_TARGETS.items()
            if meta["kind"] != "future" and m41_guide_section(tid) == section
            and (group is None or meta["group"] == group)]

    def m41_guide_summary():
        return "최종 엔딩 %d개 · 중간 결과 %d개" % (
            len(m41_guide_targets("endings")), len(m41_guide_targets("events")))

    def m41_guide_label(target, level):
        if level == 2 or m41_known(target):
            return M41_TARGETS[target]["title"]
        section = m41_guide_section(target)
        ordinal = m41_guide_targets(section).index(target) + 1
        return ("미발견 엔딩 · " if section == "endings" else "미발견 중간 결과 · ") + str(ordinal)

    def m41_position(state, guard=None):
        if guard in M41_CHOICE_ORDER: return M41_CHOICE_ORDER[guard]
        flags=state.get("flags",{})
        positions=[M41_CHOICE_ORDER[c["choice_id"]] for c in state.get("choices",[]) if c["choice_id"] in M41_CHOICE_ORDER]
        positions += [(y,i,99) for sid,(y,i,_) in M41_SCENE_ORDER.items() if flags.get("finished_"+sid)]
        positions += [M41_SCENE_ORDER[sid] for sid in M41_SCENE_ORDER if flags.get("seen_"+sid)]
        return max(positions or [(0,0,0)])

    def m41_achieved(target, state):
        meta=M41_TARGETS[target]; w=state.get("world",{}); f=state.get("flags",{})
        if meta["kind"]=="future": return False
        anchor = ("Y4-C7-S04" if w.get("y4_worldline")=="canon_adjacent" else "Y4-C7-S05") if meta["kind"]=="cedric" else meta["anchor"]
        if meta["kind"]=="y5" and carina_hidden_campaign(state):
            anchor={"carina":"Y5-C5-S14","exposure":"Y5-C5-S17","sirius":"Y5-C6-S11"}.get(meta["result"],anchor)
        if not f.get("finished_"+anchor): return False
        kind=meta["kind"]
        if kind=="y7_ending": return f.get("y7_complete",False) and state.get("year7",{}).get("ending")==meta["ending"]
        if kind=="rescue": return w.get("y3_rescue_companion")=="carina" and f.get("y3_shared_patronus",False)
        if kind=="dating": return f.get("y3_ring_confession",False) and any(c["choice_id"]=="Y3_DATING_VISIBILITY" and c["option_id"]==meta["visibility"] for c in state["choices"])
        if kind=="world": return bool(f.get("y4_worldline_frozen")) and w.get("y4_worldline")==meta["worldline"]
        if kind=="ball": return w.get("y4_partner")==meta["partner"]
        if kind=="separation": return w.get("y4_carina_separation")=="war_pressure"
        if kind=="cedric": return (w.get("y4_cedric")=="alive")==meta["alive"]
        if kind=="y5":
            r=meta["result"]
            if r=="sirius": return w.get("sirius_status")!="dead" and w.get("y5_ending")!="captured"
            if r=="wait": return w.get("y5_ending")=="averted"
            return bool(f.get({"exposure":"y5_voldemort_public","hermione":"y5_hermione_time","ginny":"y5_ginny_practice","luna":"y5_luna_aftermath","carina":"y5_carina_obstruction_understood"}[r]))
        return False

    class M41Proof:
        """A bounded prerequisite witness, never a gameplay simulator.

        Only authored future choices explicitly listed here can prove a path.
        Fixed choices and frozen scene facts win over the proposed witness.
        No store, persistent data, manual saves or checkpoints are modified.
        """
        def __init__(self,state,guard=None):
            self.state=state; self.position=m41_position(state,guard); self.guard=guard
            self.flags=state.get("flags",{}); self.world=state.get("world",{})
            self.actual={c["choice_id"]:c["option_id"] for c in state.get("choices",[])}
            self.plan={}; self.rows=[]

        def row(self,text,status):
            self.rows.append(dict(text=text,status=status)); return status not in ("impossible","unknown")

        def future(self,cid):
            return cid not in self.actual and self.position <= M41_CHOICE_ORDER[cid]

        def need(self,cid,oid,text):
            start=len(self.rows)
            result=self._need(cid,oid,text)
            for row in self.rows[start:]: row.update(cid=cid,oid=oid)
            return result

        def _need(self,cid,oid,text):
            if cid in self.actual:
                return self.row(text,"satisfied" if self.actual[cid]==oid else "impossible")
            if not self.future(cid): return self.row(text,"impossible")
            if cid in self.plan and self.plan[cid]!=oid: return self.row(text,"impossible")
            self.plan[cid]=oid
            return self.row(text,"unsatisfied" if self.guard==cid else "pending")

        def after(self,sid):
            return bool(self.flags.get("finished_"+sid)) or self.position > (M41_SCENE_ORDER[sid][0],M41_SCENE_ORDER[sid][1],99)

        def fact(self,now,sid,text):
            return self.row(text,"satisfied" if now else "impossible" if self.after(sid) else "pending")

        def carina_rescue(self):
            if m42_origin(self.state)!="legacy":
                self.need("Y1_MALKIN_GUIDE","accept","양장점에서 카리나의 안내를 받아들인다. 교제 확정과는 별개다.")
                self.need("Y2_DIARY_EXPOSURE","hide","루시우스에게 일기장을 드러내지 않는다.")
                self.need("Y2_CARINA_DECISION","pressure","일기장의 비밀을 바탕으로 카리나와 협력한다.")
            if self.world.get("carina_early_romance_blocked"):
                self.row("큰 다툼 뒤 화해하지 않은 이력은 전후까지 조기 교제를 막습니다.","impossible")
            for cid,oid,words in (("Y3_POTIONS_VOLUNTEER","help","마법약 수업에서 수발을 자청한다."),("Y3_MEAL_HELP","cut","식사를 도와준다."),("Y3_BRUSH_HELP","offer","다음 수발도 제안한다.")):
                self.need(cid,oid,words)
            if not self.after("Y3-C4-S09"):
                self.fact(self.world.get("buckbeak_status")=="isolated","Y3-C1-S07","세 번의 도움으로 벅빅이 격리된다.")
            memories=self.state["romance"]["carina"].get("memories",{})
            if "y3_private_outing" in memories:
                self.row("겨울 외출에서 다음 만남을 약속했다.","satisfied")
            else:
                # This option's actual gate is promise OR either memory OR affection >=2.
                eligible=(self.world.get("y3_hogsmeade_promise")=="made" or "y1_summer_letters_agreed" in memories or "y3_infirmary_care" in memories or self.state["relationships"]["carina"]["affection"]>=2)
                if not eligible:
                    if self.future("Y3_BUCKBEAK_CARE"):
                        self.need("Y3_BUCKBEAK_CARE","help","다친 카리나 곁에 남는다.")
                    else:
                        self.need("Y3_INVITATION","meet","겨울 외출 약속을 받아들인다.")
                self.need("Y3_OUTING","carina","겨울 외출에서 카리나를 찾아간다.")
                self.need("Y3_CARINA_OUTING","again","다음에도 둘이 만나고 싶다고 말한다.")
            self.need("Y3_RING","wear","크래브에게 받은 반지를 낀다.")
            self.fact(self.flags.get("y3_crabbe_delivered"),"Y3-C4-S04","실제로 반지를 전달받는다.")
            self.fact(self.flags.get("y3_carina_informed"),"Y3-C3-S03","오두막에서 카리나에게 시리우스의 결백을 알린다.")
            if "y3_past_carina_rescuer" in self.flags:
                self.row("과거의 카리나가 구조 현장에 왔다.","satisfied" if self.flags["y3_past_carina_rescuer"] else "impossible")
            else:
                self.fact(False,"Y3-C5-S03","과거의 카리나가 구조 현장에 온다.")
            self.need("Y3_RESCUE","carina","시간 여행의 동행자로 카리나를 선택한다.")

        def dating(self,visibility=None):
            self.carina_rescue()
            if self.state.get("route_intent")=="no_romance": self.row("연애하지 않기로 정한 진행은 교제를 시작할 수 없습니다.","impossible")
            self.fact(self.flags.get("y3_shared_patronus"),"Y3-C6-S04","동행 중 같은 패트로누스로 마음을 확인한다.")
            self.need("Y3_COMMITMENT","confess","학년말 경기 뒤 고백한다.")
            if visibility:
                self.need("Y3_DATING_VISIBILITY",visibility,"공개 연애에 합의한다." if visibility=="public" else "비밀 연애에 합의한다.")
            elif "Y3_DATING_VISIBILITY" not in self.actual:
                self.need("Y3_DATING_VISIBILITY","private","공개 여부를 함께 결정한다. 공개·비밀 교제 모두 히든 세계선으로 이어진다.")
            if visibility=="public" and self.future("Y3_DATING_VISIBILITY"):
                # A sufficient, legal witness, not an optimistic score upper bound.
                # Outing is already required above. Invitation is unconditional;
                # winter words only occur on that outing. Promise reply only on broken promises.
                for cid,oid in (("Y3_BUCKBEAK_CARE","help"),("Y3_INVITATION","tease"),("Y3_WINTER_WORDS","listen")):
                    if self.future(cid) and cid not in self.plan: self.plan[cid]=oid
                promised=self.world.get("y3_hogsmeade_promise")=="broken"
                if promised and self.future("Y3_PROMISE_REPLY"): self.plan["Y3_PROMISE_REPLY"]="apologize"
                score=self.state["relationships"]["carina"]["affection"]
                for cid,oid in sorted(self.plan.items(),key=lambda p:M41_CHOICE_ORDER[p[0]]):
                    for effect in next(o["effects"] for o in CHOICES[cid]["options"] if o["id"]==oid):
                        if effect[:3]==("relationship","carina","affection"): score=bounded(score+effect[3])
                ring_worn=(self.plan.get("Y3_RING") or self.actual.get("Y3_RING"))=="wear"
                carina_companion=(self.plan.get("Y3_RESCUE") or self.actual.get("Y3_RESCUE"))=="carina"
                if not self.flags.get("y3_quarrel_resolved") and not self.after("Y3-C6-S03") and ring_worn and carina_companion:
                    score=bounded(score+2)
                if not self.flags.get("y3_shared_patronus") and not self.after("Y3-C6-S04") and carina_companion:
                    score=bounded(score+2)
                status="unknown" if self.position[0]<3 else "satisfied" if self.state["relationships"]["carina"]["affection"]>=CARINA_PUBLIC_AFFECTION else "pending" if score>=CARINA_PUBLIC_AFFECTION else "impossible"
                self.row("서로 충분히 가까워진 뒤 공개 교제를 합의한다.",status)

        def worldline(self,wanted):
            if wanted=="canon_adjacent" and m42_main(self.state):
                return self.row("본편에서는 뒤늦은 교제가 4학년 사건 세계선을 바꾸지 않습니다.","satisfied")
            if wanted=="canon_adjacent" and m42_origin(self.state)=="pending" and self.future("Y1_MALKIN_GUIDE"):
                return self.need("Y1_MALKIN_GUIDE","decline","양장점에서 안내를 사양하고 본편을 시작한다.")
            fixed=self.state.get("year4_entry",{}).get("worldline") or (self.world.get("y4_worldline") if self.flags.get("m32_handoff_ready") else None)
            if fixed:
                return self.row("4학년 입장 세계선은 양장점 안내 수락과 3학년 말 교제 합의로 고정됩니다. 공개 여부는 조건을 바꾸지 않습니다.","satisfied" if fixed==wanted else "impossible")
            if wanted=="fanfic": self.dating(self.actual.get("Y3_DATING_VISIBILITY") or "private")
            elif self.actual.get("Y3_COMMITMENT")=="confess":
                self.row("합의한 교제를 공개 여부만 바꿔 본편 세계선으로 돌릴 수 없습니다.","impossible")
            elif self.future("Y3_COMMITMENT"):
                # Only choose 'friends' if that optional scene can occur. Avoiding
                # Carina as companion is an unconditional sufficient alternative.
                if self.future("Y3_RESCUE"):
                    self.need("Y3_RESCUE","hermione","헤르미온느와 동행하면 3학년 고백 장면에 진입하지 않는다.")
                elif self.actual.get("Y3_RESCUE")=="carina":
                    self.need("Y3_COMMITMENT","friends","학년말 경기 뒤 교제를 시작하지 않는다.")
                else: self.row("3학년 고백 경로를 선택하지 않았다.","satisfied")
            else:
                self.fact(not self.flags.get("y3_ring_confession"),"Y3-C6-S09","3학년 말 교제하지 않는다.")

        def ball(self,partner):
            if partner=="none" and self.actual.get("Y4_BALL_INTENT")=="carina" and self.world.get("carina_early_romance_blocked"):
                self.row("카리나의 초대 거절 뒤 친구들과 참석한다.","satisfied")
                return
            if partner=="carina" and self.world.get("carina_early_romance_blocked"):
                self.row("큰 다툼 뒤 화해하지 않아 카리나의 초대가 거절됩니다.","impossible")
            elif partner=="carina" and self.flags.get("y3_major_quarrel") and not self.flags.get("y3_quarrel_resolved"):
                self.need("Y3_RING","wear","크래브에게 받은 반지를 착용해 관계를 회복한다.")
            self.need("Y4_BALL_INTENT",partner,"무도회 동행을 선택한다. 교제 여부와는 별개다.")
            if self.after("Y4-C3-S06"):
                self.row("실제로 합의한 동행자와 일치한다.","satisfied" if self.world.get("y4_partner")==partner else "impossible")

    def m41_evaluate(target,state,guard=None,_try_alternate=True):
        proof=M41Proof(state,guard); meta=M41_TARGETS[target]; kind=meta["kind"]
        achieved=m41_achieved(target,state)
        if kind=="future": proof.row("최종 엔딩은 아직 미구현입니다. 7학년 전후 화해와 후일 연애도 현재 계산하지 않습니다.","unknown")
        elif achieved: proof.row("이 진행에서 목표 결과를 이미 경험했습니다.","satisfied")
        elif proof.after(meta["anchor"]): proof.row("이 진행에서는 목표 장면을 이미 다른 결과로 지나갔습니다.","impossible")
        elif kind=="y7_ending": y7_ending_proof(proof,meta["ending"])
        elif kind=="rescue": proof.carina_rescue()
        elif kind=="dating": proof.dating(meta["visibility"])
        elif kind=="world": proof.worldline(meta["worldline"])
        elif kind=="ball": proof.ball(meta["partner"])
        elif kind=="y5":
            result=meta["result"]
            if carina_hidden_campaign(state):
                if result in ("carina","exposure"):
                    proof.row("이 경로에서는 사건의 흐름을 따라 확인합니다. 별도의 분기 선택은 없습니다.","pending")
                else:
                    proof.row("이 목표는 원작 사건 경로의 선택입니다. 현재 경로에는 해당 선택이 없습니다.","impossible")
            elif result=="carina":
                proof.worldline("fanfic")
            elif result in ("hermione","ginny","luna"):
                cid,oid={"hermione":("Y5_HERMIONE_TIME","stay"),"ginny":("Y5_GINNY_PRACTICE","play"),"luna":("Y5_LUNA_AFTER","help")}[result]
                proof.need(cid,oid,"그녀가 하려는 일에 함께 참여한다.")
                if proof.world.get("y5_ending")=="captured": proof.row("학년말까지 돌아와야 한다.","impossible")
            else:
                if result=="sirius" and proof.world.get("sirius_status")=="dead":
                    proof.row("이미 사망한 사람의 결과를 소급해 바꿀 수 없습니다.","impossible")
                if result in ("sirius","wait"):
                    proof.need("Y5_VERIFY","contact","환상을 행동으로 옮기기 전에 기사단에 확인한다.")
                if result=="wait" or (result=="sirius" and proof.actual.get("Y5_DEPART") in (None,"wait")):
                    proof.need("Y5_DEPART","wait","확인된 소식을 기다리며 학교에 남는다.")
                else:
                    chosen=proof.actual.get("Y5_DEPART")
                    proof.need("Y5_DEPART",chosen if chosen in ("team","alone") else "alone","마법부 현장에 도착한다.")
                    if result=="sirius":
                        proof.need("Y5_BATTLE","cover","퇴로를 확보하고 시리우스를 엄호한다.")
                if result=="exposure":
                    # Exposure remains possible after rushing. Avoid only the
                    # exact captured combination, using a legal future option.
                    if proof.world.get("y5_ending")=="captured":
                        proof.row("감금된 진행에서는 중앙 홀에 도착할 수 없습니다.","impossible")
                    elif proof.actual.get("Y5_VERIFY")!="contact" and proof.actual.get("Y5_DEPART")!="team":
                        if proof.actual.get("Y5_BATTLE")=="pursue" or proof.actual.get("Y5_PROPHECY") is None:
                            proof.need("Y5_PROPHECY","break","예언을 넘기지 않고 함정에서 벗어난다.")
                        elif proof.actual.get("Y5_PROPHECY")=="trade":
                            proof.need("Y5_BATTLE","cover","뒤쫓기보다 퇴로를 확보한다.")
                    proof.need("Y5_EXPOSE","alarm","중앙 홀 경보를 울려 공적인 증인을 부른다.")
        elif kind=="separation":
            if state["romance"]["carina"]["status"]=="dating": proof.row("현재 카리나와 교제 중이다.","satisfied")
            elif proof.future("Y4_BALL_MEANING"):
                # An early relationship is sufficient. Late Carina confession has
                # additional exclusivity gates and is deliberately unsupported.
                if not proof.flags.get("m32_handoff_ready"): proof.dating()
                else: proof.row("4학년 중 시작하는 교제는 이 목표의 현재 안내 범위 밖입니다.","unknown")
            else: proof.row("이별 장면 전에 카리나와 교제해야 합니다.","impossible")
        elif kind=="cedric":
            line=state.get("year4_entry",{}).get("worldline") or (proof.world.get("y4_worldline") if proof.flags.get("m32_handoff_ready") else None)
            if line=="fanfic": proof.row("이 세계선에서는 세드릭이 생존합니다.","satisfied" if meta["alive"] else "impossible")
            else:
                proof.worldline("canon_adjacent")
                if meta["alive"]:
                    for cid,oid,text in (("Y4_LAKE_PLAN","signal","호수 때부터 신호를 준비한다."),("Y4_MAZE_PREP","remember","미로 전 신호 약속을 기억한다."),("Y4_CUP","signal","우승컵 앞에서 신호를 보낸다."),("Y4_GRAVEYARD","warn","묘지에서 세드릭에게 경고한다.")):
                        proof.need(cid,oid,text)
                else:
                    missed=any(cid in proof.actual and proof.actual[cid]!=oid for cid,oid in (("Y4_LAKE_PLAN","signal"),("Y4_MAZE_PREP","remember"),("Y4_CUP","signal"),("Y4_GRAVEYARD","warn")))
                    if missed: proof.row("생존을 위한 신호 연결이 이미 끊겼다.","satisfied")
                    elif proof.future("Y4_GRAVEYARD"):
                        other=next(o["id"] for o in CHOICES["Y4_GRAVEYARD"]["options"] if o["id"]!="warn")
                        proof.need("Y4_GRAVEYARD",other,"묘지에서 경고하지 않는다.")
                    else: proof.row("신호와 경고를 모두 선택해 생존이 확정됐습니다.","impossible")
        # Before the Y3 handoff, survival has two sufficient routes. Never
        # reject an already chosen confession just because the canon witness failed.
        if kind=="cedric" and meta["alive"] and not achieved and _try_alternate and not state.get("year4_entry") and not proof.flags.get("m32_handoff_ready"):
            if any(r["status"] in ("impossible","unknown") for r in proof.rows):
                alternative=m41_evaluate("world_fanfic",state,guard,False)
                if alternative["reachable"]:
                    return dict(alternative,rows=alternative["rows"]+[dict(text="교제에서 이어지는 세계선에서는 세드릭이 생존합니다.",status="pending")])
        statuses={r["status"] for r in proof.rows}
        return dict(reachable=not statuses.intersection({"impossible","unknown"}),achieved=bool(achieved),rows=proof.rows,plan=proof.plan,
            status="impossible" if "impossible" in statuses else "unknown" if "unknown" in statuses else "satisfied" if achieved else "pending")

    def m41_checkpoint_rows():
        # Called only when the guide opens or the player requests a refresh.
        rows=[]; rejected=0
        for cid,node in M21_NODES.items():
            if node["type"]!="choice": continue
            for slot,meta in m21_checkpoints(cid):
                try:
                    saved=renpy.get_save_data(slot); raw=saved.get("vn")
                    if raw is None or m21_fingerprint(raw)!=meta["m21_state"]: raise ValueError("fingerprint")
                    state=canonical_data(state_copy(raw))
                    if canonical_name(saved.get("m21_choice_guard"))!=cid or any(c["choice_id"]==cid for c in state["choices"]): raise ValueError("resolved")
                    if state.get("current_chapter")!=CHOICES[cid]["chapter_id"]: raise ValueError("chapter")
                    rows.append(dict(slot=slot,cid=cid,meta=meta,state=state))
                except Exception:
                    rejected+=1
        return rows,rejected

    def m41_recommend(target,rows):
        possible=[]; uncertain=0
        for row in rows:
            result=m41_evaluate(target,row["state"],row["cid"])
            if result["reachable"] and not result["achieved"]: possible.append(dict(row,result=result))
            elif result["status"]=="unknown": uncertain+=1
        # Nearest in story order minimizes replay; latest capture breaks ties.
        possible.sort(key=lambda r:(M41_CHOICE_ORDER[r["cid"]],r["meta"].get("m21_time",0)),reverse=True)
        return dict(best=possible[0] if possible else None,uncertain=uncertain)

    def m41_record_outcomes(sid):
        if m33_active() or getattr(store,"m41_presented_scene",None)!=sid: return
        for target,meta in M41_TARGETS.items():
            anchor=("Y4-C7-S04" if store.vn["world"].get("y4_worldline")=="canon_adjacent" else "Y4-C7-S05") if meta["kind"]=="cedric" else meta["anchor"]
            # A review builder can seed a past event but cannot present it.
            # Record only THIS completed scene, never all seeded earlier facts.
            if sid==anchor and m41_achieved(target,store.vn): m21_add("m41_outcomes",target)
        store.m41_presented_scene=None

    def m41_known(target):
        if target in (persistent.m41_outcomes or set()): return True
        if M41_TARGETS[target]["kind"] == "y7_ending":
            return "route_" + M41_TARGETS[target]["ending"] in (persistent.m21_endings or set())
        # Existing actual annual outcome records prove only these exact facts.
        for value in (persistent.m21_annual_variants or set()):
            if target=="carina_rescue" and value.startswith("Y3:carina:"): return True
            if target in ("carina_private","carina_public") and value.startswith("M32:") and value.endswith(":"+("private" if target=="carina_private" else "public")): return True
            if value.startswith("Y4:"):
                _,line,cedric,partner=value.split(":")
                if target=="world_fanfic" and line=="fanfic": return True
                if target=="world_canon" and line=="canon_adjacent": return True
                if target=="cedric_alive" and cedric=="alive": return True
                if target=="cedric_dead" and cedric=="dead": return True
                if target=="ball_"+partner and partner!="none": return True
                if target=="ball_friends" and partner=="none": return True
        return False

    def m41_hint_level():
        if m33_qa_enabled() or persistent.m41_spoilers: return 2
        if any(key in (persistent.m21_endings or set()) for key,e in M21_ENDINGS.items() if e["implemented"]): return 1
        return 0

init python:
    renpy.register_persistent("m41_outcomes",m21_union)
