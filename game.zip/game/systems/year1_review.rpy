# Chapter review starts a separate story with an explicit prior-choice preset.
init -17 python:
    Y1_REVIEW_CHOICES = {
        1: (("Y1_C1_RIVAL", "boundary"), ("Y1_C1_NOTICE", "curious"), ("Y1_C1_TABLE", "seat")),
        2: (("Y1_C2_FRIENDSHIP", "invite"), ("Y1_C2_DUEL", "own_words"), ("Y1_C2_RULE", "report")),
        3: (("Y1_C3_TROLL", "signal"), ("Y1_C3_REPAIR", "listen"), ("Y1_C3_MIRROR", "quiet"), ("Y1_C3_MIRROR_REPLY", "tell")),
    }
    Y1_REVIEW_FLAGS = {
        1: ("y1_train_offered_hand_refused",),
        2: ("y1_knows_fluffy", "y1_midnight_trap", "y1_corridor_reported"),
        3: ("y1_troll_help_early", "y1_trio_rescued", "y1_friendship_callback_invite", "y1_trio_friends", "y1_quidditch_won", "y1_suspects_snape", "y1_knows_fluffy", "y1_knows_flamel_name", "y1_saw_mirror", "y1_mirror_carina", "y1_mirror_parents_shared", "y1_knows_mirror_desire"),
    }

    def y1_prepare_review(chapter, overrides=None):
        store.m41_presented_scene = None
        if type(chapter) is not int or chapter not in (1, 2, 3, 4):
            raise ValueError("Unknown Year 1 review chapter")
        store.vn = fresh_year1_state()
        store.vn["flags"]["y1_review_preset"] = True
        store.y1_active_scene = None
        y1_clear_portrait()
        # Use the real choice/effect APIs, including memories and chapter logs.
        # Only earlier chapters are seeded; future events remain unresolved.
        for previous in range(1, chapter):
            cid = "Y1-C%d" % previous
            begin_chapter(cid)
            for choice, option in Y1_REVIEW_CHOICES[previous]:
                if not m42_choice_allowed(choice): continue
                record_choice(choice, (overrides or {}).get(choice,option))
            for flag in Y1_REVIEW_FLAGS[previous]:
                set_story_flag(flag)
            complete_chapter("챕터 선택에서 설정한 검수용 이전 이야기입니다.")
            store.vn["chapters"][cid]["review_preset"] = True

default y1_review_chapter = 1

label y1_review_c1:
    $ y1_review_chapter = 1
    jump y1_review_start
label y1_review_c2:
    $ y1_review_chapter = 2
    jump y1_review_start
label y1_review_c3:
    $ y1_review_chapter = 3
    jump y1_review_start
label y1_review_c4:
    $ y1_review_chapter = 4
    jump y1_review_start

label y1_review_start:
    $ y1_prepare_review(y1_review_chapter)
    $ y1_review_scene_offset = 0

label y1_review_continue:
    hide screen y1_event_cg
    hide screen y1_stage
    if y1_review_chapter <= 1:
        call y1_c1(start_at=y1_review_scene_offset if y1_review_chapter == 1 else 0) from y1_review_run_c1
    if y1_review_chapter <= 2:
        call y1_c2(start_at=y1_review_scene_offset if y1_review_chapter == 2 else 0) from y1_review_run_c2
    if y1_review_chapter <= 3:
        call y1_chapter3(start_at=y1_review_scene_offset if y1_review_chapter == 3 else 0) from y1_review_run_c3
    call y1_chapter4(start_at=y1_review_scene_offset if y1_review_chapter == 4 else 0) from y1_review_run_c4
    jump y1_year_end
