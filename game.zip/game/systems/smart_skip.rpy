# Native skip still executes every statement. This guard adds rendered-text
# variants; it never uses a scene's discovery record as proof of read dialogue.
default persistent.m41_read_text = set()
default m41_text_key = None

init -3 python:
    # Native statement/translation IDs distinguish all authored static branches.
    # These two scenes also interpolate different people into the SAME statement.
    # A source-audit test requires future interpolated scenes to register here.
    M41_VARIANT_SCENES = {"Y4-C3-S02", "Y4-C5-S03"}

    def m41_stop_skip():
        config.skipping = None

    def m41_text_digest(scene, text):
        return m21_hashlib.sha256((str(scene) + "\0" + text).encode("utf-8")).hexdigest()

    def m41_skip_allowed():
        return bool(config.skipping) or not getattr(store,"m41_text_key",None) or store.m41_text_key in (persistent.m41_read_text or set())

    def m41_character_callback(event, interact=True, what=None, **kwargs):
        if not interact or what is None: return
        if event == "begin":
            chapter=store.vn.get("current_chapter") or ""
            sid = next((getattr(store,"y%d_active_scene" % y,None) for y in (4,3,2,1)
                if str(getattr(store,"y%d_active_scene" % y,None)).startswith(chapter) and chapter), "other")
            store.m41_text_key = m41_text_digest(sid, what) if sid in M41_VARIANT_SCENES else None
            if store.m41_text_key and store.m41_text_key not in (persistent.m41_read_text or set()):
                m41_stop_skip()
        elif event == "interact_done" and kwargs.get("last_segment",True) and not kwargs.get("exception"):
            # Scene Replay must not write discovery/read-variant records.
            if not m33_active() and store.m41_text_key:
                persistent.m41_read_text.add(store.m41_text_key)

    def m41_skip_preferences():
        # Never let an old preference enable unseen text or skip past choices.
        _preferences.skip_unseen = False
        _preferences.skip_after_choices = False

init python:
    renpy.register_persistent("m41_read_text",m21_union)
    config.all_character_callbacks.append(m41_character_callback)
    config.interact_callbacks.append(m41_skip_preferences)
    config.overlay_screens.append("m41_skip_controls")
    # A toggle is predictable on touch and keyboard. Holding Ctrl must not
    # restart skipping after an unread interaction or a new CG stopped it.
    config.keymap["skip"] = []
    config.keymap["toggle_skip"] = []
    config.fast_skipping = False

screen m41_skip_controls():
    zorder 195
    if not main_menu and renpy.get_screen("say") and not renpy.get_screen("important_choice") and not renpy.context()._menu:
        textbutton ("읽은 대사 넘기기 중 · 멈춤" if renpy.is_skipping() else "읽은 대사 넘기기 · Tab"):
            action If(bool(renpy.is_skipping()),Function(m41_stop_skip),Skip())
            sensitive m41_skip_allowed()
            selected bool(renpy.is_skipping())
            text_size 18 padding (12,10)
            xalign 1.0 ypos 66
            id "m41_skip"
        if m41_skip_allowed():
            key "K_TAB" action If(bool(renpy.is_skipping()),Function(m41_stop_skip),Skip())
        if renpy.is_skipping():
            key "K_ESCAPE" action Function(m41_stop_skip)
