# Registered with the existing discovered-gallery/replay machinery.
init 2 python:
    M733_CG_ENTRIES = {
        "Y4:memory_startled":dict(year=4,asset="memory_startled",title="낯설어진 품",scene="Y4-C8-S11"),
        "Y3:carina_reach":dict(year=3,asset="carina_reach",title="마지막으로 본 손",scene="Y3-C3-S06"),
        "Y5:ginny_victory":dict(year=5,asset="ginny_victory",title="우승 뒤의 대답",scene="Y5-C4-S10"),
        "Y5:da_practice":dict(year=5,asset="da_practice",title="함께 배우는 주문",scene="Y5-C3-S02"),
        "Y6:luna_confession":dict(year=6,asset="luna_confession",title="기다렸던 말",scene="Y6-C5-S05"),
        "Y6:hermione_confession":dict(year=6,asset="hermione_confession",title="친구라는 말 다음에",scene="Y6-C5-S05"),
        "Y6:tower_death":dict(year=6,asset="tower_death",title="탑 위의 초록빛",scene="Y6-C7-S01"),
    }
    M21_CGS.update(M733_CG_ENTRIES)
