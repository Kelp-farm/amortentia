init -40 python:
    def state_copy(value):
        # Construct all containers in Ren'Py Python, including migration copies.
        if isinstance(value, dict):
            return {k: state_copy(v) for k, v in value.items()}
        if isinstance(value, list):
            return [state_copy(v) for v in value]
        return value

    def fresh_state():
        return {
            "schema_version": SCHEMA_VERSION,
            "carina_memory": {"status":"intact","restoration":"unoffered","renewed":False},
            "relationships": {h: {"affection": 0,
                                  "route_key": {}} for h in HEROINE_IDS},
            "affection_history": [],
            "romance": {h: {"status": "none", "visibility": "private",
                            "history": [], "memories": {}} for h in HEROINE_IDS},
            "special": state_copy(SPECIAL_DEFAULTS),
            "world": state_copy(WORLD_DEFAULTS),
            "personality": {axis: 0 for axis in AXIS_LABELS},
            "flags": {}, "choices": [], "chapters": {},
            "current_chapter": None, "current_pov": "harry", "pov_stack": [],
            "current_route": None, "route_intent": None,
            "debug_modified": False, "debug_log": [],
        }

    def add_missing(target, defaults):
        for key, value in defaults.items():
            if key not in target:
                target[key] = state_copy(value)
            elif isinstance(value, dict) and isinstance(target[key], dict):
                add_missing(target[key], value)

    def migrate_state(state):
        version = state.get("schema_version", 0)
        if version > SCHEMA_VERSION:
            raise ValueError("This save needs a newer game version.")
        result = canonical_data(state)
        # Add named version-to-version transformations here BEFORE add_missing.
        m71_restore_commitment_fields(result)
        origin = m42_origin(result)
        add_missing(result, fresh_state())
        result["world"]["story_origin"] = origin
        result["schema_version"] = SCHEMA_VERSION
        return result

    def require_key(mapping, key):
        if key not in mapping:
            raise ValueError("Unknown state key: %s" % key)

    def integer(value):
        if type(value) is not int:
            raise ValueError("Expected an integer, not %r" % value)
        return value

    def bounded(value, low=-100, high=100):
        return max(low, min(high, integer(value)))

    def checked_value(key, value, defaults, enums, bounds=None):
        require_key(defaults, key)
        if key in enums:
            if value not in enums[key]:
                raise ValueError("Invalid %s: %r" % (key, value))
            return value
        if type(defaults[key]) is bool:
            if type(value) is not bool:
                raise ValueError("%s requires True or False" % key)
            return value
        low, high = (bounds or {}).get(key, (-100, 100))
        return bounded(value, low, high)

    def apply_effect(state, effect):
        # Effect tuples are deliberately small and readable; no eval or callbacks.
        kind = effect[0]
        if kind == "relationship_event":
            _, heroine, event_id, action, detail, agreed = effect
            return apply_relationship_event(state, heroine, event_id, action, detail, agreed)
        elif kind == "relationship":
            _, heroine, metric, delta = effect
            require_key(state["relationships"], heroine)
            if metric != "affection":
                raise ValueError("Unknown relationship metric: %s" % metric)
            bucket = state["relationships"][heroine]
            path = ["relationships", heroine, metric]
            key, value = metric, bounded(bucket[metric] + integer(delta))
        elif kind == "personality":
            _, key, delta = effect
            bucket = state["personality"]
            require_key(bucket, key)
            path = ["personality", key]
            value = bounded(bucket[key] + integer(delta))
        elif kind == "route_flag":
            _, heroine, key, value = effect
            require_key(state["relationships"], heroine)
            if not isinstance(key, str) or not key or type(value) is not bool:
                raise ValueError("Route flags require a name and boolean")
            bucket = state["relationships"][heroine]["route_key"]
            path = ["relationships", heroine, "route_key", key]
        elif kind in ("world", "special"):
            _, key, value = effect
            bucket = state[kind]
            if kind == "world":
                value = checked_value(key, value, WORLD_DEFAULTS, WORLD_ENUMS, WORLD_BOUNDS)
            else:
                value = checked_value(key, value, SPECIAL_DEFAULTS, SPECIAL_ENUMS)
            path = [kind, key]
        elif kind == "flag":
            _, key, value = effect
            if not isinstance(key, str) or not key or type(value) is not bool:
                raise ValueError("Story flags require a name and boolean")
            bucket, path = state["flags"], ["flags", key]
        elif kind == "route_intent":
            _, value = effect
            require_key(ROUTE_NAMES, value)
            bucket, key, path = state, "route_intent", ["route_intent"]
        else:
            raise ValueError("Unknown effect type: %s" % kind)
        before = bucket.get(key)
        bucket[key] = value
        return {"kind": kind, "path": path, "before": before, "after": value}

    def affection_log_update(candidate, previous, choice=None, context=None):
        changes = {}
        for heroine in HEROINE_IDS:
            before = previous["relationships"][heroine]["affection"]
            after = candidate["relationships"][heroine]["affection"]
            if before != after:
                changes[heroine] = {"before": before, "after": after, "delta": after-before}
        if choice is None and not changes:
            return
        chapter = candidate["current_chapter"]
        scene = context
        if scene is None:
            for year in (7,6,5,4,3,2,1):
                sid = getattr(store, "y%d_active_scene" % year, None)
                if sid and sid[:5] == chapter:
                    scene = sid
                    break
        # Only past actions are recorded. Hidden world flags never enter the UI.
        candidate.setdefault("affection_history", []).append({
            "kind": "choice" if choice else "event", "chapter": chapter,
            "scene": scene, "choice_id": choice["choice_id"] if choice else None,
            "text": choice["option_text"] if choice else "함께 보낸 시간",
            "changes": changes,
        })

    def apply_effects(effects, context=None):
        candidate = state_copy(store.vn)
        for effect in effects:
            apply_effect(candidate, effect)
        affection_log_update(candidate, store.vn, context=context)
        store.vn = candidate

    def increase_affection(heroine, amount):
        apply_effects([("relationship", heroine, "affection", amount)])

    def set_route_flag(heroine, flag, value=True):
        apply_effects([("route_flag", heroine, flag, value)])

    def change_personality(axis, amount):
        apply_effects([("personality", axis, amount)])

    def set_world(key, value):
        apply_effects([("world", key, value)])

    def change_world(key, amount):
        require_key(WORLD_BOUNDS, key)
        set_world(key, store.vn["world"][key] + integer(amount))

    def set_special(key, value):
        apply_effects([("special", key, value)])

    def change_special(key, amount):
        require_key(SPECIAL_DEFAULTS, key)
        if key in SPECIAL_ENUMS:
            raise ValueError("Use set_special for enum states")
        set_special(key, store.vn["special"][key] + integer(amount))

    def set_story_flag(key, value=True):
        apply_effects([("flag", key, value)])

default vn = fresh_state()

label after_load:
    $ canonical_after_load()
    $ vn = migrate_state(vn)
    if vn.get("current_pov") == "carina" and vn.get("current_chapter") == "Y2-C6":
        $ persistent.m21_pending_replay = None
        call screen m71_viewpoint_changed
        $ renpy.full_restart()
    if ginny_timeline_obsolete(vn):
        $ persistent.m21_pending_replay = None
        call screen ginny_timeline_changed
        $ renpy.full_restart()
    if m6_route_incompatible(vn):
        $ persistent.m21_pending_replay = None
        call screen m6_commitment_changed
        $ renpy.full_restart()
    if y5_obsolete_save(vn):
        $ persistent.m21_pending_replay = None
        call screen y5_revision_changed
        $ renpy.full_restart()
    if y3_needs_timeline_restart():
        $ persistent.m21_pending_replay = None
        call screen y3_timeline_changed
    elif vn.get("flags", {}).get("y3_campaign"):
        $ set_story_flag("y3_hogsmeade_timeline_v2")
    if vn.get("flags", {}).get("y3_campaign"):
        $ y3_sync_sirius_knowledge()
    $ m21_after_load()
    # Migration must not roll back into the old schema.
    $ renpy.block_rollback()
    if y1_retired_interlude_loaded():
        jump y1_resume_after_interlude
    return
