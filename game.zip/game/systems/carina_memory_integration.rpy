init 3 python:
    for _heroine,_name in (("hermione","헤르미온느"),("ginny","지니"),("luna","루나")):
        M33_QA_PRESETS["memory7_"+_heroine]=dict(title="기억 복원 · "+_name+"와 교제 중",profile="memory",prior={},local={"Y7_RELATIONSHIP":_heroine})
        M33_QA_PRESETS["memory7_return_"+_heroine]=dict(title="기억 복원 · "+_name+"와 이별 뒤 재회",profile="memory",prior={},local={"Y7_RELATIONSHIP":_heroine,"Y7_MEMORY_CURRENT":"end"})
    # QA uses authentic early choices, not a save from another campaign with grafted flags.
    for _year in (5,6,7):
        _old=M33_QA_BUILDERS[_year]
        def _m732_builder(sid,recipe,year=_year,original=_old):
            if recipe.get("profile")=="memory": return m732_prepare_review(year,sid,recipe.get("local"))
            return original(sid,recipe)
        M33_QA_BUILDERS[_year]=_m732_builder
        M33_QA_PRESETS["memory%d"%_year]=dict(title="기억 변경 이후 · 실제 이전 선택",profile="memory",prior={},local={})
        for _sid,_meta in globals()["Y%d_SCENES"%_year].items():
            if _sid in globals()["Y%d_SOURCE_SCENES"%_year]: continue
            if (_year==6 and _sid in ("Y6-C6-S02","Y6-C6-S03")) or (_year==7 and _sid in ("Y7-C6-S01","Y7-C9-S05","Y7-C11-S04")): continue
            if _year==7 and _meta["condition"] in ("end_hermione","end_ginny","end_luna","star_hermione","star_ginny","star_luna","star_none","end_none"): continue
            if _meta.get("condition") in ("stayed","captured","auror","carina_conversation"): continue
            _presets=M21_NODES[_sid]["replay"]["presets"]
            if _meta.get("condition")=="memory": _presets[:]=["memory%d"%_year]
            else: _presets.append("memory%d"%_year)
            M33_SCENE_VARIANTS[_sid]=_presets[:]
    for _sid in ("Y4-C8-S10","Y4-C8-S11"):
        M21_NODES[_sid]["replay"]["presets"]=["m4_dating_private"]
        M33_SCENE_VARIANTS[_sid]=["m4_dating_private"]
    for _sid,_presets in (
            ("Y7-C9-S23",["memory7_"+h for h in ("hermione","ginny","luna")]),
            ("Y7-C9-S24",["memory7"]+["memory7_return_"+h for h in ("hermione","ginny","luna")]),
            ("Y7-C9-S22",["memory7"]+["memory7_"+h for h in ("hermione","ginny","luna")]+["memory7_return_"+h for h in ("hermione","ginny","luna")])):
        M21_NODES[_sid]["replay"]["presets"]=_presets[:]
        M33_SCENE_VARIANTS[_sid]=_presets[:]
    M73_SCENE_OVERRIDES.update({"Y4-C8-S10":"reflection","Y4-C8-S11":"carina_pressure",
        "Y7-C9-S20":"reflection","Y7-C9-S21":"reflection","Y7-C9-S23":"reflection","Y7-C9-S24":"carina_reconcile","Y7-C9-S22":"carina_reconcile","Y7-C11-S20":"carina_reconcile"})
    Y7_ENDINGS["carina_restored"]=("카리나 · 다시 기억하는 내일","Y7-C12-S04")
    M21_ENDINGS["route_carina_restored"]=dict(title=Y7_ENDINGS["carina_restored"][0],year=7,implemented=True,kind="route",route="carina_restored",scene="Y7-C12-S04")
    M41_TARGETS["route_carina_restored"]=dict(group="carina",title=Y7_ENDINGS["carina_restored"][0],hint="잊었던 시간을 마주한 뒤, 지금의 관계를 함께 고릅니다.",kind="y7_ending",ending="carina_restored",anchor="Y7-C12-S04")

    _m732_original_ending_proof=y7_ending_proof
    def y7_ending_proof(proof,ending):
        if ending=="carina_hidden":
            if m732_altered(proof.state):
                proof.row("기억 변경 이후에는 본편의 전후 이야기로 이어집니다.","impossible")
                return
            return _m732_original_ending_proof(proof,ending)
        if ending=="carina_restored":
            if m732_public_history(proof.state):
                proof.row("공개한 교제 이력은 기억 변경 경로로 이어지지 않습니다.","impossible")
                return
            if carina_hidden_committed(proof.state):
                proof.row("실제 조기 협력과 3학년의 교제 약속을 지났습니다.","satisfied")
            else:
                for cid,oid,text in (("Y1_MALKIN_GUIDE","accept","양장점의 안내를 받아들인다."),
                        ("Y2_DIARY_EXPOSURE","hide","일기장 파괴를 루시우스에게 숨긴다."),
                        ("Y2_CARINA_DECISION","pressure","카리나와 비공개로 협력한다."),
                        ("Y3_COMMITMENT","confess","3학년 말 실제 고백과 교제에 합의한다."),
                        ("Y3_DATING_VISIBILITY","private","그 관계를 공개하지 않는다.")):
                    proof.need(cid,oid,text)
            proof.need("Y4_MEMORY_PLAN","prepare","비밀 교제 경로에서 기억 변경을 함께 검토한다.")
            proof.need("Y4_MEMORY_CONSENT","proceed","마지막 동의를 확인하고 기억을 변경한다.")
            proof.need("Y7_MEMORY_OFFER","tell","전쟁이 끝난 뒤 잃은 기억에 관해 이야기한다.")
            proof.need("Y7_MEMORY_RESTORE","restore","카리나의 현재 동의로 복원을 진행한다.")
            other=next((h for h,r in proof.state["romance"].items() if h!="carina" and r["status"] in ("dating","separated")),None)
            if other: proof.need("Y7_MEMORY_CURRENT","end","현재 연인과 직접 이야기해 관계를 정리한다.")
            proof.need("Y7_MEMORY_FUTURE","again","되찾은 기억과 별도로 다시 만날 뜻을 전한다.")
            answer=m732_memory(proof.state).get("reunion_answer")
            if answer=="rejected": proof.row("카리나가 재교제를 받아들인다.","impossible")
            elif answer=="accepted" or m732_memory(proof.state).get("renewed"):
                proof.row("카리나가 재교제를 받아들인다.","satisfied")
            else:
                score=proof.state["relationships"]["carina"]["affection"]
                undisclosed=set(m732_other_romances(proof.state))-set(m732_memory(proof.state).get("disclosed_partners",[]))
                score-=M732_OTHER_ROMANCE_PENALTY*len(undisclosed)
                proof.row("이별 뒤의 교제 이력을 포함해, 카리나가 다시 만날 만큼 가까운 관계를 쌓는다.",
                    "satisfied" if score>=M732_REUNION_AFFECTION else "unsatisfied")
            return
        if m732_altered(proof.state):
            # The campaign is Main, but its historical Y4 worldline is still fanfic.
            if ending=="carina":
                proof.row("이 이력의 카리나 결말은 ‘다시 기억하는 내일’입니다.","impossible")
                return
            proof.fact(proof.flags.get("voldemort_final_defeat"),"Y7-C8-S05","남은 조각을 해결하고 전쟁을 끝낸다.")
            current=next((h for h,r in proof.state["romance"].items() if r["status"]=="dating"),None)
            if current and current!=ending: proof.row("현재 연인과의 약속을 유지합니다.","impossible")
            elif ending=="no_romance":
                # Deferring disclosure or declining recovery skips MEMORY_FUTURE.
                # The shared postwar relationship choice remains the real gate.
                proof.need("Y7_RELATIONSHIP","friends","전후에도 새 교제를 시작하지 않는다.")
            elif current==ending: proof.row("현재 연인과의 약속을 유지합니다.","satisfied")
            else: proof.need("Y7_RELATIONSHIP",ending,"마음을 전하고 서로 사귀기로 한다.")
            return
        return _m732_original_ending_proof(proof,ending)

init -1 python:
    for _year,_asset,_title,_sid in ((4,"memory_farewell","한 사람에게 남길 기억","Y4-C8-S11"),(7,"memory_restoration","되찾은 시간","Y7-C9-S21"),(7,"memory_renewal","오늘부터 세는 날","Y7-C11-S20")):
        M21_CGS["Y%d:"%_year+_asset]=dict(year=_year,asset=_asset,title=_title,scene=_sid)
