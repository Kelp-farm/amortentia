init -11 python:
    def y3_needs_timeline_restart(state=None):
        state = store.vn if state is None else state
        chapter, flags = state.get("current_chapter"), state.get("flags", {})
        return ((chapter in ("Y3-C2", "Y3-C3") and not flags.get("y3_hogsmeade_timeline_v2"))
            or (chapter in ("Y3-C4", "Y3-C5", "Y3-C6") and not flags.get("m32_finale_v1"))
            or (chapter in ("Y3-C3","Y3-C4","Y3-C5","Y3-C6") and not flags.get("m4d_winter_broom_v1")))

    def y3_flag(key):
        return store.vn["flags"].get(key,False)

    def y3_firebolt_source():
        value = store.vn["world"].get("y3_firebolt","none")
        if value != "none": return value
        # Old saves already described an anonymous winter gift. Preserve that
        # ownership without inventing a new purchase or replaying a second gift.
        if not y3_flag("y3_firebolt_sequence_v1") and y3_flag("finished_Y3-C4-S06"):
            return "legacy_gift"
        return "none"

    def y3_early():
        return store.vn["world"]["carina_cooperation"] == "pressured"

    def y3_sync_sirius_knowledge():
        # Shared summer premise, including ongoing saves and isolated scene replay.
        # Knowing his innocence does not reveal Peter or inform Carina.
        if not m42_main(): set_story_flag("y3_harry_knows_sirius")

    def y3_reveal_sirius_to_carina():
        # Identity is witnessed at the winter meeting. This is distinct from
        # Harry choosing to share the investigation or later reconciliation.
        if m42_main() or not chose("Y3_OUTING","carina"):
            raise ValueError("Sirius identity reveal requires the winter hut meeting")
        set_story_flag("y3_carina_knows_sirius_identity")
        set_story_flag("y3_carina_informed")

    def y3_ring_available():
        return not m42_main() and chose("Y3_OUTING","carina")

    def y3_care_complete():
        return (chose("Y3_POTIONS_VOLUNTEER","help") and chose("Y3_MEAL_HELP","cut")
            and chose("Y3_BRUSH_HELP","offer"))

    def y3_carina_reconciled():
        return (store.vn["world"]["y3_carina_bond"] == "reconciled"
            and y3_flag("y3_quarrel_resolved")
            and not store.vn["world"]["carina_early_romance_blocked"])

    def y3_ring_functional():
        # Wearing the delivered ring is the owner's sole repair decision.
        # Carina's observed response is recorded later, not a second apology gate.
        return store.vn["world"]["carina_ring"] == "worn" and (y3_flag("y3_crabbe_delivered") or y3_flag("review_y3_direct_ring_gift"))

    def y3_pre_pursuit_kiss_available():
        # Entry uses the history already played, never a future partner/confession.
        return (not m42_main() and carina_hidden_candidate()
            and y3_flag("y3_quarrel") and y3_ring_functional()
            and y3_flag("y3_carina_informed"))

    def y3_cooperative_pre_pursuit_available():
        # The owner kept the angry kiss only on the earlier exclusion path.
        return (not m42_main() and chose("Y3_SECRET","include")
            and y3_ring_functional() and y3_flag("y3_carina_informed"))

    def y3_record_pre_pursuit_kiss():
        if not y3_pre_pursuit_kiss_available():
            raise ValueError("Pre-pursuit kiss requires the current Carina candidate history")
        if y3_flag("y3_pre_pursuit_kiss"): return
        set_story_flag("y3_pre_pursuit_kiss")
        relationship_event("carina","y3_pre_pursuit_kiss","memory",
            "성의 복도에서 카리나에게 입을 맞췄다. 그녀가 떠난 뒤 루핀 교수님이 론의 소식을 알렸다.",False)

    def y3_carina_rescue_available():
        return y3_carina_past_rescue() and y3_ring_functional()

    def y3_carina_past_rescue():
        if m42_main(): return False
        flags = store.vn["flags"]
        if "y3_past_carina_rescuer" in flags:
            return flags["y3_past_carina_rescuer"]
        return (y3_flag("y3_carina_informed") and y3_ring_functional()
            and store.vn["world"]["buckbeak_status"] == "isolated")

    def y3_finish_reconciliation():
        if y3_ring_functional():
            if y3_flag("y3_quarrel_resolved"): return
            set_world("y3_carina_bond","reconciled")
            set_story_flag("y3_quarrel_resolved")
            set_story_flag("y3_ring_pair_active")
            memory="카리나가 내가 낀 반지를 확인하고 겨울의 다툼을 풀었다." if y3_flag("y3_quarrel") else "카리나가 내가 낀 반지를 확인하고 계속 끼고 있으라고 했다."
            relationship_event("carina","y3_reconciled","memory",memory,False)
            apply_effects([("relationship","carina","affection",2)],context="Y3_RING")
        elif y3_flag("y3_major_quarrel"):
            set_world("y3_carina_bond","estranged")
            set_world("carina_early_romance_blocked",True)
            set_story_flag("y3_ring_pair_active",False)

    def y3_export_handoff():
        # M6: the shop invitation plus reconciled, explicitly secret Y3 commitment.
        romance = store.vn["romance"]["carina"]
        dating = (y3_flag("y3_ring_confession") and chose("Y3_COMMITMENT","confess")
            and romance["status"] == "dating" and y3_carina_reconciled())
        visibility = romance["visibility"] if dating else "none"
        set_world("y3_carina_dating",dating)
        set_world("carina_secret_dating",dating and visibility == "private")
        set_world("y3_carina_visibility",visibility)
        set_world("y4_worldline","fanfic" if carina_hidden_committed() else "canon_adjacent")
        set_story_flag("m32_handoff_ready")

    def y3_romance_sequence_available():
        return chose("Y3_RESCUE", "carina") and y3_flag("y3_shared_patronus") and y3_carina_reconciled()

    def y3_record_shared_patronus():
        # Actual scene event, never inferred from an old completed rescue save.
        if y3_flag("y3_shared_patronus"): return
        if not chose("Y3_RESCUE", "carina") or not y3_carina_rescue_available():
            raise ValueError("Shared Patronuses require Carina as the time-turner partner")
        relationship_event("carina", "y3_shared_patronus", "memory",
            "호숫가에서 같은 은빛 여우를 불러내고 서로를 생각했다고 말했다.", False)
        apply_effects([("relationship","carina","affection",2)],context="Y3-C6-S04")
        set_story_flag("y3_shared_patronus")

    def y3_record_ring_confession():
        if (not y3_romance_sequence_available() or not y3_flag("finished_Y3-C6-S08")
            or not chose("Y3_COMMITMENT","confess") or not choice_record("Y3_DATING_VISIBILITY")):
            raise ValueError("Dating requires reconciliation, the post-match confession and a visibility decision")
        relationship_event("carina", "y3_ring_confession", "start",
            "마지막 경기 뒤 마음을 고백하고 서로 사귀기로 했다. 공개 여부도 함께 결정했다.", True)
        if chose("Y3_DATING_VISIBILITY","public"):
            relationship_event("carina","y3_public_dating","publish","친구들 앞에서도 서로 연인이라고 소개하기로 했다.",True)
        set_story_flag("y3_ring_confession")

    # Unified scores: the demanding pre-Y4 review history reaches 9.
    # Reconciliation and all action prerequisites still apply independently.
    CARINA_PUBLIC_AFFECTION = 9

    def carina_public_ready():
        return ((y3_carina_reconciled() or (m42_main() and store.vn["flags"].get("m42_carina_conversation")
            and store.vn["flags"].get("m42_carina_farewell")))
            and store.vn["relationships"]["carina"]["affection"] >= CARINA_PUBLIC_AFFECTION)

    def carina_public_hint(cid):
        relevant = cid == "Y3_DATING_VISIBILITY" or (cid == "Y4_VISIBILITY" and y4_partner()=="carina")
        if not relevant or carina_public_ready(): return None
        score=store.vn["relationships"]["carina"]["affection"]
        if m33_developer_available():
            return "공개 연애 조건 · 호감도 %d/%d · 관계 회복/교류 조건 %s" % (score,CARINA_PUBLIC_AFFECTION,"완료" if y3_carina_reconciled() or m42_main() else "필요")
        return "지금까지 쌓은 관계와 서로의 동의가 더 필요합니다."

    def y3_option_available(cid,oid):
        if not m42_choice_allowed(cid): return False
        if cid=="REVIEW_Y3_SIRIUS_REVEAL": return chose("Y3_OUTING","carina")
        if cid=="Y3_WINTER_WORDS": return y3_review_choice_needed(cid)
        if cid == "Y3_SECRET": return y3_review_choice_needed(cid)
        if m42_main() and cid == "Y3_OUTING" and oid == "carina": return True
        if cid == "Y3_COMMITMENT":
            return (y3_romance_sequence_available() and y3_flag("finished_Y3-C6-S08")
                and (oid != "confess" or store.vn.get("route_intent") != "no_romance"))
        if cid == "Y3_DATING_VISIBILITY":
            return (y3_romance_sequence_available() and chose("Y3_COMMITMENT","confess")
                and (oid != "public" or carina_public_ready()))
        if cid == "Y3_RECONCILE":
            return False # Retired: wearing the ring is the only repair decision.
        if cid == "Y3_PETER":
            return chose("Y3_RESCUE","carina")
        if cid == "Y3_RESCUE" and oid == "carina":
            return y3_carina_rescue_available()
        if cid == "Y3_OUTING" and oid == "carina":
            return (store.vn["world"]["y3_hogsmeade_promise"] == "made"
                or remembers("carina","y1_summer_letters_agreed") or remembers("carina","y3_infirmary_care")
                or store.vn["relationships"]["carina"]["affection"] >= 2)
        if cid == "Y3_CARINA_FAREWELL" and oid == "letter":
            return (not store.vn["world"]["carina_early_romance_blocked"] and (y3_flag("y3_ring_confession")
                or y3_carina_reconciled()))
        return True

    def y3_scene_available(sid):
        if m42_main() and sid in M42_HIDDEN_SCENES: return False
        outings = {"Y3-C2-S04":"trio","Y3-C2-S05":"carina","Y3-C2-S06":"ginny","Y3-C2-S07":"luna"}
        if sid in outings:
            return chose("Y3_OUTING",outings[sid])
        if sid == "Y3-C4-S04":
            return store.vn["world"]["carina_ring"] in ("bought","withheld","delivered","worn","returned")
        if sid == "Y3-C4-S05":
            return (not chose("Y3_RESCUE","carina")
                and (y3_flag("y3_quarrel") or store.vn["world"]["carina_ring"] != "none"))
        if sid == "Y3-C6-S02":
            return store.vn["world"]["y3_rescue_companion"] == "hermione"
        if sid == "Y3-C6-S03":
            return store.vn["world"]["y3_rescue_companion"] == "carina"
        if sid in ("Y3-C6-S08", "Y3-C6-S09"):
            return y3_romance_sequence_available()
        return True

    def y3_begin():
        if not store.vn["chapters"].get("Y2-C6",{}).get("completed") or store.vn["current_chapter"]:
            raise ValueError("Year 3 requires a completed Year 2")
        if any(k.startswith("Y3-") for k in store.vn["chapters"]):
            raise ValueError("Year 3 has already started")
        store.vn = migrate_state(store.vn)
        if not carina_hidden_candidate():
            set_world("story_origin","main")
        set_story_flag("y3_campaign")
        set_story_flag("m32_finale_v1")
        set_story_flag("y3_firebolt_sequence_v1")
        set_story_flag("m4d_winter_broom_v1")
        set_story_flag("y3_hogsmeade_timeline_v2")
        set_story_flag("y3_pursuit_v2")
        set_world("sirius_legal","fugitive")
        y3_sync_sirius_knowledge()
        if y3_early():
            set_story_flag("y3_dumbledore_knows_peter")
            set_world("pettigrew_status","hiding")
        store.y1_active_scene = store.y2_active_scene = None
        store.y1_portrait = store.y2_portrait = None
        store.m21_last_node = None

    def y3_enter_scene(sid):
        set_story_flag("m4e_scene_version")
        meta = Y3_SCENES[sid]
        if store.vn["current_chapter"] != meta["chapter"]:
            raise ValueError("Year 3 scene chapter mismatch")
        y3_sync_sirius_knowledge()
        store.y3_active_scene = sid
        store.y3_portrait = None
        store.y3_offscreen = []
        store.y3_expressions = {}
        store.y3_background_override = None
        store.y3_train_shade = 0.0
        if sid in ("Y3-C1-S05","Y3-C1-S06","Y3-C1-S07"):
            set_story_flag("y3_care_sequence_v1")
        if sid == "Y3-C3-S05":
            set_story_flag("m4d_winter_broom_v1")
        if sid == "Y3-C4-S08":
            set_story_flag("m32_finale_v1")
        if sid == "Y3-C5-S01":
            set_story_flag("y3_pursuit_v2")
        if sid == "Y3-C5-S04" and "y3_past_carina_rescuer" not in store.vn["flags"]:
            set_story_flag("y3_past_carina_rescuer",y3_carina_past_rescue())
        set_story_flag("seen_"+sid)

    def y3_expression(member, expression):
        updated = dict(store.y3_expressions)
        updated[member] = expression
        store.y3_expressions = updated

    def y3_finish_scene(sid):
        if store.vn["current_chapter"] != Y3_SCENES[sid]["chapter"]:
            raise ValueError("Cannot finish a Year 3 scene outside its chapter")
        if y3_flag("finished_"+sid):
            return
        if m42_main() and sid in M42_MAIN_SCENES:
            m42_main_finish(sid)
            return
        if sid == "Y3-C1-S05":
            set_story_flag("y3_care_sequence_v1")
            set_world("buckbeak_status","under_review")
        elif sid == "Y3-C1-S07":
            set_story_flag("y3_care_sequence_v1")
            set_world("buckbeak_status","isolated" if y3_care_complete() else "condemned")
            set_story_flag("y3_bandage_removed")
        elif sid == "Y3-C2-S02":
            set_story_flag("y3_map_received")
        elif sid == "Y3-C2-S10":
            set_story_flag("y3_first_hogsmeade_completed")
        elif sid == "Y3-C2-S03":
            if store.vn["world"]["y3_hogsmeade_promise"] == "made":
                outcome = "kept" if chose("Y3_OUTING","carina") else "prevented" if y3_flag("y3_promise_cancelled") else "broken"
                set_world("y3_hogsmeade_promise",outcome)
                relationship_event("carina","y3_promise_"+outcome,"memory",{
                    "kept":"호그스미드 약속을 지켰다.","prevented":"외출을 취소하고 빅토리아를 통해 미리 전했다.","broken":"카리나와의 약속을 지키지 않고 다른 곳으로 갔다."}[outcome],False)
        elif sid == "Y3-C2-S05" and y3_ring_available():
            set_world("carina_ring","bought")
            # World-only eligibility; Harry learns of her earlier purchase at delivery.
            # Do not create a false memory of watching her shop for the rings.
        elif sid == "Y3-C3-S05":
            set_story_flag("y3_patronus_practice_seen")
        elif sid == "Y3-C3-S06":
            set_story_flag("y3_carina_reached_for_harry")
            set_story_flag("y3_autumn_slytherin_win")
        elif sid == "Y3-C3-S03":
            quarrel = chose("REVIEW_Y3_SIRIUS_REVEAL","withhold") or chose("Y3_SECRET","exclude")
            set_story_flag("y3_quarrel",quarrel)
            set_story_flag("y3_smile_withheld",not m42_main() and chose("Y3_OUTING","carina") and chose("Y3_SECRET","exclude"))
            close = y3_ring_available()
            set_story_flag("y3_prior_close",close)
            set_story_flag("y3_major_quarrel",close and quarrel)
            set_world("y3_carina_bond","hurt" if close and quarrel else "close" if close else "rivalry")
            if quarrel and store.vn["world"]["carina_ring"] == "bought":
                set_world("carina_ring","withheld")
        elif sid == "Y3-C4-S07":
            set_story_flag("y3_hufflepuff_tactics_known")
            if y3_flag("y3_quarrel"): set_story_flag("y3_handkerchief_left")
        elif sid == "Y3-C5-S01" and y3_pre_pursuit_kiss_available():
            y3_record_pre_pursuit_kiss()
        elif sid == "Y3-C4-S04":
            if y3_flag("review_y3_direct_ring_gift"):
                relationship_event("carina","review_y3_ring_gift","memory","카리나에게 직접 은빛 반지를 선물받았다.",False)
            else:
                set_story_flag("y3_crabbe_delivered")
                relationship_event("carina","y3_crabbe_intervened","memory","빅토리아 크래브에게 카리나의 반지 한 짝을 받았다.",False)
        elif sid == "Y3-C4-S05" or (sid == "Y3-C6-S03" and chose("Y3_RESCUE","carina")):
            y3_finish_reconciliation()
        elif sid == "Y3-C4-S08":
            set_story_flag("m32_finale_v1")
            set_story_flag("y3_harry_knows_sirius")
            set_story_flag("y3_dumbledore_knows_peter")
            set_story_flag("y3_investigation_time_used")
            set_world("pettigrew_status","hiding")
        elif sid == "Y3-C4-S09":
            if store.vn["world"]["buckbeak_status"] == "condemned":
                set_world("buckbeak_status","free")
                set_story_flag("y3_buckbeak_prior_time_rescue")
            set_story_flag("y3_buckbeak_safe_before_crisis")
        elif sid == "Y3-C4-S06":
            set_story_flag("y3_pursuit_v2")
            set_story_flag("y3_harry_knows_sirius")
            set_story_flag("y3_dumbledore_knows_peter")
            set_world("pettigrew_status","hiding")
        elif sid == "Y3-C6-S10":
            set_story_flag("y3_carina_firebolt_seen")
        elif sid == "Y3-C6-S11":
            source = y3_firebolt_source()
            if source == "ordered": set_world("y3_firebolt","purchased") # Archived purchase saves only.
            elif source == "none": set_world("y3_firebolt","sirius_gift")
            elif source == "legacy_gift": set_world("y3_firebolt","legacy_gift")
        elif sid == "Y3-C5-S03":
            set_story_flag("y3_trio_knows_peter")
            if "y3_past_carina_rescuer" not in store.vn["flags"]:
                set_story_flag("y3_past_carina_rescuer",y3_carina_past_rescue())
            set_story_flag("y3_snape_brought_group")
            set_story_flag("y3_past_carina_stopped_snape",y3_carina_past_rescue())
        elif sid == "Y3-C5-S04":
            set_world("y3_time_turner_holder","harry_carina" if chose("Y3_RESCUE","carina") else "hermione")
        elif sid == "Y3-C6-S04":
            if chose("Y3_RESCUE","hermione"):
                set_world("pettigrew_status","captured")
                set_story_flag("y3_hermione_secured_peter")
            set_story_flag("y3_past_carina_stopped_snape",y3_carina_past_rescue())
            set_world("sirius_status","alive")
            captured = store.vn["world"]["pettigrew_status"] == "captured"
            set_world("sirius_legal","fugitive") # Legal clearance follows testimony in S05, not a spell at the lake.
            set_world("buckbeak_status","isolated" if captured and store.vn["world"]["buckbeak_status"] == "isolated" else "free")
            set_story_flag("y3_dumbledore_knows_peter")
            set_story_flag("y3_time_turner_returned")
            set_world("y3_time_turner_holder","hermione")
        elif sid == "Y3-C6-S05" and store.vn["world"]["pettigrew_status"] == "captured":
            set_world("sirius_legal","cleared")
        elif sid == "Y3-C6-S06":
            set_world("y3_time_turner_holder","school")
        elif sid == "Y3-C6-S07":
            y3_export_handoff()
        set_story_flag("finished_"+sid)
        m41_record_outcomes(sid)
        m33_complete(sid)

    def y3_review_choice_needed(cid):
        if not m42_choice_allowed(cid): return False
        if cid == "Y3_PETER": return chose("Y3_RESCUE","carina")
        if cid == "Y3_FIREBOLT": return False # Purchase choices are retired in M4D.
        if cid == "Y3_PROMISE_CHANGE": return store.vn["world"]["y3_hogsmeade_promise"] == "made" and not chose("Y3_OUTING","carina")
        if cid == "Y3_SECRET":
            return (chose("Y3_OUTING","carina") and y3_flag("y3_carina_knows_sirius_identity"))
        if cid == "Y3_WINTER_WORDS": return chose("Y3_SECRET","exclude")
        if cid == "Y3_PROMISE_REPLY": return store.vn["world"]["y3_hogsmeade_promise"] == "broken"
        if cid == "Y3_RECONCILE": return False
        if cid == "Y3_DATING_VISIBILITY": return chose("Y3_COMMITMENT","confess")
        return True

    def y3_prepare_review(sid, preset="hermione", replay_choices=None):
        require_key(Y3_SCENES,sid)
        preset = {"Y3-C2-S04":"hermione","Y3-C2-S05":"carina","Y3-C2-S06":"ginny","Y3-C2-S07":"luna","Y3-C4-S04":"carina","Y3-C4-S05":"carina","Y3-C6-S02":"hermione","Y3-C6-S03":"carina","Y3-C6-S08":"carina","Y3-C6-S09":"carina"}.get(sid,preset)
        if preset not in ("hermione","carina","ginny","luna"):
            raise ValueError("Unknown Year 3 review preset")
        # No global discovery calls while constructing the labelled review history.
        high_public = bool((replay_choices or {}).get("Y3_DATING_VISIBILITY")=="public" or (replay_choices or {}).get("m4e_public_history"))
        prior=dict(replay_choices or {})
        if sid == "Y3-C4-S05": prior.setdefault("Y3_RESCUE","hermione")
        # Source-lane recipes retain its actual diary/cooperation prerequisites.
        # Main QA explicitly declines the Y1 invitation; overrides remain exact.
        y2_prepare_review("Y2-C6-S05",prior.get("Y2_DIARY_EXPOSURE","hide"),
            prior.get("Y2_CARINA_DECISION","pressure"),
            dict({"Y1_C1_RIVAL":"boundary","Y1_C1_NOTICE":"curious"} if high_public else {}, Y1_MALKIN_GUIDE=prior.get("Y1_MALKIN_GUIDE","accept")))
        y2_finish_scene("Y2-C6-S05")
        if preset == "carina": y2_finish_scene("Y2-C6-S06")
        complete_chapter("2학년 검수용 완료 이력")
        y3_begin()
        set_story_flag("y3_review_preset")
        defaults = {"Y3_TRAIN_KISS":"kiss" if preset=="carina" else "stand",
            "Y3_POTIONS_SEAT":"carina" if preset=="carina" else "hermione",
            "Y3_POTIONS_VOLUNTEER":"help" if preset=="carina" else "ron",
            "Y3_MEAL_HELP":"cut" if preset=="carina" else "leave",
            "Y3_BRUSH_HELP":"offer" if preset=="carina" else "leave",
            "Y3_INVITATION":"meet" if preset=="carina" else "avoid",
            "Y3_OUTING":"trio" if preset=="hermione" else preset,
            "Y3_CARINA_OUTING":"again","Y3_SECRET":"exclude","Y3_RING":"wear",
            "Y3_RECOVERY_FIRST":"carina" if preset=="carina" else "match",
            "Y3_COMMITMENT":"confess","Y3_DATING_VISIBILITY":"private",
            "Y3_RESCUE":"carina" if preset=="carina" else "hermione"}
        if high_public:
            defaults.update(Y3_INVITATION="tease",Y3_PROMISE_REPLY="apologize",Y3_WINTER_WORDS="listen")
        defaults.update(prior)
        for previous,meta in Y3_SCENES.items():
            if store.vn["current_chapter"] != meta["chapter"]:
                if store.vn["current_chapter"]: complete_chapter("장면 이전의 검수용 이야기")
                begin_chapter(meta["chapter"])
            if previous == sid: break
            if not y3_scene_available(previous): continue
            if previous == "Y3-C3-S03" and not m42_main() and chose("Y3_OUTING","carina"):
                y3_reveal_sirius_to_carina()
            for cid in meta["choices"]:
                if not y3_review_choice_needed(cid): continue
                oid = defaults.get(cid,CHOICES[cid]["options"][0]["id"])
                if not y3_option_available(cid,oid): oid = CHOICES[cid]["options"][-1]["id"]
                record_choice(cid,oid)
            if previous == "Y3-C6-S04" and chose("Y3_RESCUE", "carina"):
                y3_record_shared_patronus()
            if previous == "Y3-C6-S09" and chose("Y3_COMMITMENT","confess"):
                y3_record_ring_confession()
            y3_finish_scene(previous)
        target = Y3_SCENES[sid]
        store.y3_review_chapter,store.y3_review_offset = target["number"],target["offset"]
        store.vn["review_entry_scene"] = sid
        store.m21_last_node = None

default y3_active_scene = None
default y3_portrait = None
default y3_offscreen = []
default y3_train_shade = 0.0
default y3_expressions = {}
default y3_background_override = None
default y3_review_chapter = 1
default y3_review_offset = 0
default y3_preview_preset = "hermione"

label y3_scene(scene_id):
    $ vc_reset_stage()
    $ y3_enter_scene(scene_id)
    $ m21_visit(scene_id)
    hide screen y3_event_cg
    scene expression Solid("#182733")
    show screen y3_stage(scene_id)
    $ m43_scene_audio(scene_id)
    with Dissolve(0.25)
    return

label y3_cg(asset_id):
    $ m43_cg_audio(asset_id)
    $ m21_unlock_cg("Y3:"+asset_id)
    show screen y3_event_cg(asset_id)
    with Dissolve(0.3)
    return

label y3_cg_end:
    hide screen y3_event_cg
    with Dissolve(0.25)
    return
