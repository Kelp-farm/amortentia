# Persistent history is immutable archive data, not active rollback state.
# Keep large snapshots opaque to Ren'Py's per-interaction persistent comparison.
init -5 python:
    import json as m33_storage_json
    import zlib as m33_storage_zlib
    import hashlib as m33_storage_hash
    import builtins as m33_storage_builtins
    M33_STATE_CODEC = "json-zlib-1"
    M33_STATE_LIMIT = 16 * 1024 * 1024

    def m33_pack_record(record):
        if not isinstance(record.get("state"), m33_storage_builtins.dict): return record
        try:
            raw = m33_storage_json.dumps(record["state"], ensure_ascii=True,
                sort_keys=True, separators=(",", ":")).encode("utf8")
            # Preserve unusual legacy Python types instead of silently coercing them.
            if len(raw) > M33_STATE_LIMIT or m33_storage_json.loads(raw) != record["state"]:
                return record
        except (TypeError, ValueError): return record
        packed = dict(record)
        del packed["state"]
        packed.update(state_codec=M33_STATE_CODEC,
            state_z=m33_storage_zlib.compress(raw, 3),
            state_sha256=m33_storage_hash.sha256(raw).hexdigest())
        return packed

    def m33_unpack_record(record):
        if isinstance(record.get("state"), m33_storage_builtins.dict): return record
        if "state_codec" not in record: return record
        if record["state_codec"] != M33_STATE_CODEC:
            raise ValueError("This scene record uses an unsupported storage version")
        decoder = m33_storage_zlib.decompressobj()
        raw = decoder.decompress(record["state_z"], M33_STATE_LIMIT + 1)
        if len(raw) > M33_STATE_LIMIT or not decoder.eof or decoder.unused_data:
            raise ValueError("Invalid scene snapshot length")
        if m33_storage_hash.sha256(raw).hexdigest() != record["state_sha256"]:
            raise ValueError("Scene snapshot integrity check failed")
        state = m33_storage_json.loads(raw)
        if not isinstance(state, m33_storage_builtins.dict): raise ValueError("Invalid scene snapshot")
        result = {key:value for key,value in record.items()
            if key not in ("state_codec", "state_z", "state_sha256")}
        result["state"] = m33_rollback_state(state)
        return result

    def m33_rollback_state(value):
        # JSON creates builtin containers. Rebuild them through Ren'Py Python so
        # loaded history receives the same rollback/copy semantics as fresh state.
        if isinstance(value, m33_storage_builtins.dict):
            return {key:m33_rollback_state(item) for key,item in value.items()}
        if isinstance(value, m33_storage_builtins.list):
            return [m33_rollback_state(item) for item in value]
        return value

    def m33_read_records(rows):
        result = []
        for row in rows:
            try: result.append(m33_unpack_record(row))
            except (KeyError, TypeError, ValueError, m33_storage_zlib.error):
                pass  # Keep the original stored row; never delete a damaged archive.
        return result

    def m33_pack_library(records):
        return {sid:[m33_pack_record(row) for row in rows] for sid,rows in records.items()}
