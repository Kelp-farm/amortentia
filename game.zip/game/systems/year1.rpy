init -18 python:
    def y1_clear_portrait():
        store.y1_portrait = None

    def fresh_year1_state():
        candidate = fresh_state()
        candidate["flags"]["y1_campaign"] = True
        candidate["world"].update({"hogwarts_control": "dumbledore",
            "ministry_truth": "unaware", "stone_status": "protected",
            "quirrell_status": "active"})
        return candidate

    def y1_ui(korean, english):
        # Old M0 saves may predate the m0_demo flag.
        demo = store.vn["flags"].get("m0_demo") or any(
            key.startswith("M0-") for key in store.vn["chapters"])
        return english if demo else korean

    def y1_pov_name():
        return {"harry": "해리", "carina": "카리나"}.get(
            store.vn["current_pov"], POV_NAMES[store.vn["current_pov"]])

    def y1_confirm_message(message):
        translated = {
            "Are you sure?": "계속할까요?",
            "Are you sure you want to delete this save?": "이 저장 기록을 지울까요?",
            "Are you sure you want to overwrite your save?": "기존 저장 기록을 덮어쓸까요?",
            "Loading will lose unsaved progress.\nAre you sure you want to do this?": "저장하지 않은 진행 내용은 사라집니다.\n이 기록을 불러올까요?",
            "Are you sure you want to quit?": "게임을 종료할까요?",
            "Are you sure you want to return to the main menu?\nThis will lose unsaved progress.": "처음 화면으로 돌아갈까요?\n저장하지 않은 진행 내용은 사라집니다.",
            "Are you sure you want to continue where you left off?": "이전 진행 지점에서 계속할까요?",
            "Are you sure you want to end the replay?": "다시 보기를 마칠까요?",
            "Are you sure you want to begin skipping?": "대사 넘기기를 시작할까요?",
            "Are you sure you want to skip to the next choice?": "다음 선택지까지 넘어갈까요?",
            "Are you sure you want to skip unseen dialogue to the next choice?": "읽지 않은 대사도 다음 선택지까지 넘어갈까요?",
        }.get(message, message)
        return y1_ui(translated, message)

    def y1_retired_interlude_loaded():
        flags = store.vn["flags"]
        return (flags.get("y1_campaign") and not flags.get("y2_campaign")
            and not flags.get("y3_campaign") and not flags.get("y1_complete")
            and store.vn["current_chapter"] in (None, "Y1-C2")
            and (store.y1_active_scene == "Y1-C2-S08"
                 or store.vn["current_pov"] == "carina"))

    def y1_enter_scene(scene_id):
        require_key(Y1_SCENES, scene_id)
        metadata = Y1_SCENES[scene_id]
        if metadata["chapter"] != store.vn["current_chapter"]:
            raise ValueError("Scene is outside the active chapter: " + scene_id)
        if metadata["pov"] != store.vn["current_pov"]:
            raise ValueError("Scene POV mismatch: " + scene_id)
        store.y1_active_scene = scene_id
        y1_clear_portrait()
        set_story_flag("seen_" + scene_id)

label y1_start:
    $ vn = fresh_year1_state()
    call y1_c1 from y1_start_c1
    call y1_c2 from y1_start_c2
    call y1_chapter3 from y1_start_c3
    call y1_chapter4 from y1_start_c4

label y1_year_end:
    hide screen y1_event_cg
    hide screen y1_stage
    scene bg demo_room
    $ m21_annual(1)
    call screen y1_ending
    if _return == "year2":
        jump y2_start
    return

label y1_scene(scene_id):
    $ vc_reset_stage()
    $ y1_enter_scene(scene_id)
    $ m21_visit(scene_id)
    hide screen y1_event_cg
    scene expression Solid(Y1_SCENES[scene_id]["color"])
    show screen y1_stage(scene_id)
    $ m43_scene_audio(scene_id)
    with Dissolve(0.25)
    return

# Preserve choices when loading a save made inside the removed POV scene.
label y1_resume_after_interlude:
    $ renpy.set_return_stack([])
    $ vn["current_pov"] = "harry"
    $ vn["pov_stack"] = []
    $ y1_active_scene = None
    $ y1_clear_portrait()
    hide screen y1_stage
    hide screen pov_interlude
    hide screen chapter_statistics
    if vn["current_chapter"] == "Y1-C2":
        call y1_c2(start_at=6) from y1_retired_interlude_end
    call y1_chapter3 from y1_retired_interlude_c3
    call y1_chapter4 from y1_retired_interlude_c4
    jump y1_year_end
