# Stable collection IDs; discovery still requires an actual display outside Replay.
init 1 python:
    EVENT_CG_ENTRIES = {}
    for _year, _asset, _title, _scene in (
        (1, "carina_forest", "금지된 숲의 카리나", "Y1-C4-S04"),
        (2, "carina_sleeve", "스니치를 잡은 뒤 붙잡은 소매", "Y2-C2-S06"),
        (2, "hermione_stone", "석화된 헤르미온느의 병상", "Y2-C4-S02"),
        (2, "hermione_cat", "커튼 뒤의 고양이 귀", "Y2-C3-S03"),
        (3, "carina_meal", "입 벌려, 말포이", "Y3-C1-S06"),
        (3, "pursuit_kiss", "추적 직전의 입맞춤", "Y3-C5-S01"),
        (4, "carina_tent", "천막 속 투명 망토의 방문자", "Y4-C2-S06"),
        (4, "egg_corridor", "욕실로 가는 길의 황금 알", "Y4-C5-S01"),
        (4, "carina_ferret", "품 안의 흰족제비", "Y4-C2-S03"),
        (4, "carina_bath_after", "옷이 마를 때까지만", "Y4-C5-S01"),
        (5, "ginny_practice", "골대 아래 한 번 더", "Y5-C3-S04"),
        (5, "ginny_waiting", "그건 내가 알아", "Y5-C3-S10"),
        (5, "luna_practice", "루나와 맞춰 보는 호흡", "Y5-C3-S05"),
        (5, "carina_supervisor", "감독관의 자리", "Y5-C2-S15"),
        (6, "memory_handoff", "손에 남긴 은빛 기억", "Y6-C2-S14"),
        (7, "luna_cellar", "지하 감방에서 부르는 이름", "Y7-C4-S05"),
    ):
        EVENT_CG_ENTRIES["Y%d:" % _year + _asset] = dict(
            year=_year, asset=_asset, title=_title, scene=_scene)
    M21_CGS.update(EVENT_CG_ENTRIES)
