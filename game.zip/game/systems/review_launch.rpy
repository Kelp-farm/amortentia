# Continuous QA starts use the existing authored review recipes and year flows.
default mrv_source = None

init -1 python:
    import re as mrv_re

    def mrv_fields_in_store():
        return {key for key,value in vars(store).items()
            if mrv_re.match(r"^(vn$|y[1-7]_|m(?:21|33|41|42|732)_|vc_|pensieve_)",key)
            and isinstance(value,(dict,list,tuple,set,str,int,float,bool,type(None)))}

    def mrv_allowed(sid):
        return m33_developer_available() and not m33_active() and m33_implemented(sid)

    def mrv_presets(sid, origin):
        variants = list(m33_presets(sid))
        preferred = [p for p in variants if p.startswith("main") == (origin == "main")]
        return preferred or variants

    def mrv_preview(sid, preset, origin, overrides=None):
        if not mrv_allowed(sid) or preset not in mrv_presets(sid,origin):
            raise ValueError("Unavailable review entry")
        overrides = dict(overrides or {})
        for cid,oid in overrides.items():
            if cid not in CHOICES or not any(o["id"]==oid for o in CHOICES[cid]["options"]):
                raise ValueError("Unknown review answer")
        fields = mrv_fields_in_store()
        saved = {key:getattr(store,key) for key in fields}
        try:
            # Protect active progress, pending scene capture and all visual state.
            for key,value in saved.items(): setattr(store,key,state_copy(value))
            store.m33_pending = None
            store.m41_presented_scene = None
            recipe = state_copy(M33_QA_PRESETS[preset])
            prior = dict(recipe.get("prior",{}))
            prior.update(overrides)
            year = M21_NODES[sid]["year"]
            if year <= 2: prior["Y1_MALKIN_GUIDE"] = overrides.get("Y1_MALKIN_GUIDE","decline" if origin=="main" else "accept")
            if year == 1:
                y1_prepare_scene_review(sid,prior)
            elif year == 2:
                y2_prepare_review(sid,prior.get("Y2_DIARY_EXPOSURE",recipe.get("diary","expose")),
                    prior.get("Y2_CARINA_DECISION",recipe.get("cooperation","leave")),prior)
            else:
                recipe["prior"] = prior
                M33_QA_BUILDERS[year](sid,recipe)
            state = state_copy(store.vn)
            available = year < 3 or globals()["y%d_scene_available" % year](sid)
            recorded = {r["choice_id"]:r["option_id"] for r in state["choices"]}
            honored = all(recorded.get(cid)==oid for cid,oid in overrides.items())
            return dict(scene=sid,preset=preset,origin=origin,state=state,
                overrides=overrides,available=bool(available and honored),
                note=("" if available and honored else "이전 선택 때문에 이 장면에 도달할 수 없습니다. 앞선 전개나 선택을 바꿔 주세요."))
        finally:
            for key in mrv_fields_in_store() - fields: delattr(store,key)
            for key,value in saved.items(): setattr(store,key,value)

    def mrv_prior_choices(draft):
        year = M21_NODES[draft["scene"]]["year"]
        rows = []
        for row in draft["state"]["choices"]:
            cid = row["choice_id"]
            if not row["chapter_id"].startswith("Y%d-" % year) or CHOICES[cid].get("tier",1) < 2: continue
            # Year 2's established builder exposes these two major controls.
            if year == 2 and cid not in ("Y2_DIARY_EXPOSURE","Y2_CARINA_DECISION"): continue
            rows.append(row)
        return rows

    def mrv_choice_title(cid):
        node = M21_NODES.get(cid) or M21_NODES.get(M41_CHOICE_SCENE.get(cid))
        return node["title"] if node else CHOICES[cid]["chapter_id"]+"의 선택"

    def mrv_change(sid,preset,origin,overrides,cid=None,oid=None):
        changes = dict(overrides)
        if cid is not None: changes[cid]=oid
        try:
            draft = mrv_preview(sid,preset,origin,changes)
        except (ValueError,KeyError):
            renpy.notify("이 선택은 현재 앞선 전개와 함께 사용할 수 없습니다. 다른 전개를 골라 주세요.")
            return
        renpy.set_screen_variable("preset",preset)
        renpy.set_screen_variable("changes",changes)
        renpy.set_screen_variable("draft",draft)
        renpy.restart_interaction()

    def mrv_open(sid,origin):
        if m33_active() or not m33_implemented(sid): return
        if m33_developer_available():
            variants = mrv_presets(sid,origin)
            if len(variants)==1:
                draft = mrv_preview(sid,variants[0],origin)
                if draft["available"] and not mrv_prior_choices(draft):
                    mrv_launch(draft,not getattr(store,"main_menu",False))
                    return
            renpy.run(ShowMenu("mrv_scene_setup",sid=sid,origin=origin))
        elif m21_seen_node(sid):
            renpy.run(ShowMenu("msc_scene_continue",sid=sid))

    def mrv_node_click(nid,year,chapter,origin,target=None):
        node = M21_NODES[nid]
        now = m21_time.monotonic()
        previous = renpy.session.pop("mrv_click",None)
        known = m42_seen(nid,origin) or m33_qa_enabled()
        double = previous and previous[0]==(nid,year,chapter,origin) and 0 <= now-previous[1] <= 0.5
        if double and node["type"]=="scene" and known:
            mrv_open(nid,origin)
            return
        renpy.session["mrv_click"] = ((nid,year,chapter,origin),now)
        # Keep the viewport and tile under the pointer between both clicks.
        renpy.set_screen_variable("current_node",nid,screen="story_flow")
        renpy.restart_interaction()

    def mrv_launch(draft,backup_current=True):
        sid = draft["scene"]
        if not mrv_allowed(sid) or not draft.get("available"): return
        try:
            if backup_current:
                renpy.take_screenshot()
                renpy.save("scene-continue-backup",extra_info="연속 검수 전 진행")
            m21_save_persistent()
        except Exception:
            renpy.notify("현재 진행을 보관하지 못했습니다. 저장 공간을 확인해 주세요.")
            return
        renpy.session["mrv_entry"] = state_copy(draft)
        renpy.full_restart(transition=None,label="mrv_scene_start")

    def mrv_prepare(draft):
        sid = draft["scene"]
        if not mrv_allowed(sid) or not draft.get("available"): raise ValueError("Unavailable review start")
        store.vn = migrate_state(draft["state"])
        year = M21_NODES[sid]["year"]
        meta = Y1_REVIEW_SCENES[sid] if year==1 else globals()["Y%d_SCENES" % year][sid]
        setattr(store,"y%d_review_chapter" % year,meta["chapter"] if year==1 else meta["number"])
        setattr(store,"y1_review_scene_offset" if year==1 else "y%d_review_offset" % year,meta["offset"])
        store.m33_pending=None;store.m33_expected={};store.m33_forced={}
        store.m21_last_node=None;store.m41_presented_scene=None
        store.mrv_source=dict(scene=sid,preset=draft["preset"],overrides=draft["overrides"])
        return year

label mrv_scene_start:
    $ mrv_entry = renpy.session.pop("mrv_entry",None)
    if mrv_entry is None:
        return
    $ mrv_year = mrv_prepare(mrv_entry)
    $ mrv_entry = None
    $ renpy.block_rollback()
    stop music fadeout 0.2
    if mrv_year == 1:
        jump y1_review_continue
    jump expression "y%d_continue" % mrv_year
