init -7 python:
    Y6_BIRTHDAY="2015-07-31"
    Y6_PROTECTION_END="2032-07-31"
    Y6_REVIEW_PRESETS={"main":"본편 · 동료들과 함께", "hermione":"본편 · 헤르미온느와 교제",
        "ginny":"본편 · 지니와 교제", "luna":"본편 · 루나와 쌓은 우정",
        "luna_romance":"본편 · 루나에게 마음을 전한 이력", "carina":"본편 · 카리나와 라이벌",
        "public":"히든 · 공개 교제 확정, 강제 이별 이후", "estranged":"본편 · 3학년 화해 실패",
        "no_romance":"본편 · 연애 없이", "bereaved":"본편 · 세드릭·시리우스 사망",
        "averted":"본편 · 시리우스 생존, 마법부 부인", "concealed":"본편 · 구조 우선, 루시우스 자유",
        "hidden":"히든 · 비밀 교제 확정, 강제 이별 이후"}

    def y6_hidden(): return carina_hidden_campaign()
    def y6_flag(key): return store.vn["flags"].get(key,False)
    def y6_sectumsempra_used():
        record=choice_record("Y6_DUEL")
        if record: return record["option_id"]=="sectumsempra"
        # Existing development saves retain the injury that actually happened.
        return "carina_sectumsempra_treated" in store.vn.get("year6",{}).get("injuries",[])
    def y6_current_partner():
        return next((h for h in HEROINE_IDS if store.vn["romance"][h]["status"]=="dating"),None)
    def y6_romance_conversation(h):
        # Staging only: no event or relationship is synthesized by an observation.
        store.y6_portrait=h if h in ("hermione","ginny","luna","carina") else None
    def y6_can_confess(h):
        if y6_hidden() or y6_current_partner() or store.vn.get("route_intent")=="no_romance": return False
        if h not in ("hermione","luna"): return False
        if store.vn["romance"][h]["status"]!="none": return False
        prior={"hermione":"y5_hermione_time","luna":"y5_luna_aftermath"}[h]
        return y6_flag(prior) and store.vn["relationships"][h]["affection"]>=4
    def y6_option_available(cid,oid):
        if cid not in CHOICES or oid not in [o["id"] for o in CHOICES[cid]["options"]]: return False
        if cid.startswith("Y6_H_")!=y6_hidden(): return False
        if cid=="Y6_GINNY_KISS": return False  # Retired development choice; identity preserved for save diagnostics.
        if cid=="Y6_PRINCE": return y6_sectumsempra_used()
        if cid=="Y6_FEELINGS": return oid=="friends" or (oid!="ginny" and y6_can_confess(oid))
        if cid=="Y6_PARTY":
            current=y6_current_partner()
            return not current or oid in (current,"alone")
        return True
    def y6_choice_needed(cid):
        if cid=="Y6_GINNY_KISS": return False
        if cid=="Y6_FEELINGS" and y6_current_partner(): return False
        return any(y6_option_available(cid,o["id"]) for o in CHOICES[cid]["options"])
    def y6_scene_available(sid):
        if sid in ("Y6-C6-S02","Y6-C6-S03") and m732_inherited("locket"): return False
        return sid in Y6_SCENES and ((sid in Y6_SOURCE_SCENES)==y6_hidden())

    def y6_mark_horcrux(item,status,event):
        book=store.vn["year6"]["horcruxes"]
        require_key(book,item)
        if status not in ("suspected","known","located","destroyed"): raise ValueError("Unknown investigation status")
        entry=book[item]
        if status=="suspected": entry["suspected"]=True
        else:
            entry["known"]=True
            if status in ("located","destroyed"): entry["located"]=True
            if status=="destroyed": entry["destroyed"]=True
        if event not in entry["evidence"]: entry["evidence"].append(event)
    def y6_protection_active(on_date):
        # ISO date comparison: expires on the seventeenth birthday, not after Y7.
        q=store.vn.get("year6",{}).get("protection",{})
        return bool(q.get("known") and q.get("activated_on", "9999")<=on_date<q.get("expires_on","0000"))
    def y6_begin():
        v=store.vn
        if v["current_chapter"] or not v["chapters"].get("Y5-C6",{}).get("completed") or not y6_flag("y5_complete"):
            raise ValueError("Year 6 requires completed Year 5")
        if "year6_handoff" not in v or any(k.startswith("Y6-") for k in v["chapters"]): raise ValueError("Invalid Year 6 entry")
        if m6_route_incompatible(v): raise ValueError("Old worldline requires restart; past events are not rewritten")
        store.vn=migrate_state(v);v=store.vn
        expected="fanfic" if carina_hidden_committed() else "canon_adjacent"
        if v["year6_handoff"]["worldline"]!=expected or v["world"]["y4_worldline"]!=expected:
            raise ValueError("Year 6 handoff differs from committed worldline")
        v["year6_entry"]=state_copy(v["year6_handoff"])
        v["year6_entry"].update(revision=1,hidden=bool(y6_hidden()))
        v["year6"]={"horcruxes":{h:dict(known=False,suspected=False,located=False,destroyed=False,evidence=[])
            for h in ("diary","ring","locket","cup","diadem","nagini","harry")},
            "protection":dict(known=False,activated_on=None,expires_on=None,origin=None,prevents=[],does_not_prevent=[]),
            "knowledge":dict(harry=[],carina=[],allies=[],public=[]),"casualties":[],"injuries":[],"objectives":[],"events":[]}
        y6_mark_horcrux("diary","destroyed","Y2 chamber destruction")
        if y6_hidden():
            if y6_flag("review_hidden_locket_destroyed"):
                y6_mark_horcrux("locket","destroyed","Y4 summer Kreacher/Regulus locket")
            if y6_flag("review_hidden_cup_destroyed"):
                y6_mark_horcrux("cup","destroyed","Y4 spring Gringotts cup confirmation")
        if y6_hidden() and y6_flag("y5_gaunt_ring_known"): y6_mark_horcrux("ring","known","Y5 gaunt research")
        if m732_altered():
            for item in ("locket","cup"):
                if m732_inherited(item): y6_mark_horcrux(item,"destroyed","inherited actual Year 4 destruction")
        set_world("y6_phase","school");set_story_flag("y6_campaign")
        for n in range(1,6):
            setattr(store,"y%d_active_scene"%n,None);setattr(store,"y%d_portrait"%n,None)
        store.m21_last_node=None

    def y6_resolve(sid):
        if y6_flag("y6_resolved_"+sid): return
        if not y6_scene_available(sid): raise ValueError("Wrong Year 6 story lane")
        v=store.vn;w=v["world"];q=v["year6"]
        # Keep nested investigation/knowledge and world changes in the same object.
        # The general set_world API replaces vn atomically, invalidating q/w refs.
        def set_world(key,value): return apply_effect(v,("world",key,value))
        def set_story_flag(key,value=True): return apply_effect(v,("flag",key,value))
        def relationship_event(h,event,action,detail,agreed=False):
            return apply_effect(v,("relationship_event",h,event,action,detail,agreed))
        if sid in ("Y6-C3-S01","Y6-C1-S14"):
            y6_mark_horcrux("ring","destroyed",sid)
            for h in ("locket","cup"): y6_mark_horcrux(h,"suspected",sid)
        if sid=="Y6-C4-S05":
            for h in ("locket","cup"): y6_mark_horcrux(h,"known",sid)
            for h in ("diadem","nagini"): y6_mark_horcrux(h,"suspected",sid)
        if sid=="Y6-C4-S03": set_world("y6_cabinet","suspected")
        if sid=="Y6-C5-S01" and (not choice_record("Y6_DUEL") or chose("Y6_DUEL","sectumsempra")):
            q["injuries"].append("carina_sectumsempra_treated")
        if sid=="Y6-C5-S05" and choice_record("Y6_FEELINGS"):
            h=choice_record("Y6_FEELINGS")["option_id"]
            if h!="friends":
                if not y6_can_confess(h): raise ValueError("Confession prerequisites were lost")
                relationship_event(h,"y6_mutual_confession","start","호숫가에서 마음을 전하고 서로 사귀기로 했다.",True)
        if sid=="Y6-C6-S05": set_world("y6_cabinet","infiltration")
        if sid=="Y6-C7-S01":
            set_world("dumbledore_status","dead_tower");set_world("y6_dumbledore_killer","snape")
            set_world("y6_snape","fugitive");set_world("y6_carina","fled")
            q["casualties"].append("dumbledore");q["knowledge"]["harry"].append("snape_killed_dumbledore")
        if sid=="Y6-C7-S03":
            q["injuries"].append("neville_treated" if chose("Y6_PREPARE","guard") else "order_members_treated")
            set_world("y6_phase","aftermath");set_world("hogwarts_control","mcgonagall")
        if sid=="Y6-C7-S04" and not m732_altered():
            q["knowledge"]["harry"].extend(["cave_locket_fake","RAB_initials"])
            q["objectives"]=["find_real_locket","identify_RAB","locate_cup","identify_ravenclaw_object","confirm_nagini"]

        if sid=="Y6-C2-S15": set_world("y6_carina","sleeping")
        if sid=="Y6-C2-S16":
            q["knowledge"]["harry"].extend(["mark_watches_actions","family_hostages","carina_mission","cabinet_passage","diadem_location"])
            y6_mark_horcrux("diadem","located",sid);set_world("y6_cabinet","repaired")
        if sid=="Y6-C3-S11": q["counterattack_deadline"]="2031-10-21"
        if sid=="Y6-C3-S12":
            y6_mark_horcrux("diadem","destroyed",sid)
            # Legacy development presets can lack the new Y4 editorial flags.
            # They retain known destroyed items without inventing a second destruction.
            for h in ("locket","cup"):
                if not q["horcruxes"][h]["destroyed"]:
                    y6_mark_horcrux(h,"destroyed","Y4 previously completed investigation")
            y6_mark_horcrux("nagini","known",sid)
        if sid=="Y6-C3-S16": set_world("y6_phase","counterattack");set_world("y6_cabinet","counterattack")
        if sid=="Y6-C4-S14": y6_mark_horcrux("nagini","destroyed",sid)
        if sid=="Y6-C4-S15":
            set_world("y6_snape","dead_protecting_harry");q["casualties"].append("snape")
            q["injuries"].extend(["harry_arm_treated","lupin_recovered"])
        if sid=="Y6-C4-S16": set_world("y6_voldemort","body_defeated")
        if sid=="Y6-C4-S17":
            set_world("dumbledore_status","dying");set_world("y6_dumbledore_killer","voldemort_through_harry")
        if sid=="Y6-C5-S12":
            set_world("dumbledore_status","dead_hidden");q["casualties"].append("dumbledore")
            set_world("y6_soul","remaining_fragment");y6_mark_horcrux("harry","located",sid)
            set_world("y6_protection","active");set_world("y6_phase","aftermath");set_world("hogwarts_control","mcgonagall")
            q["protection"]=dict(known=True,activated_on="2031-10-20",expires_on=Y6_PROTECTION_END,
                origin="lily_blood_reinforced_by_dying_dumbledore_and_fawkes",
                prevents=["fragment_takes_control"],does_not_prevent=["internal_voice","shared_senses","knowledge_and_power_transfer","remaining_fragment"])
            q["knowledge"]["harry"].extend(["living_horcrux","possession_witness","birthday_deadline","lily_protection_reinforced"])
            q["knowledge"]["allies"].extend(["possession_witness","birthday_deadline"])
            q["objectives"]=["separate_remaining_soul","survive_seventeenth_birthday","contain_death_eater_remnants"]
        if sid=="Y6-C5-S13":
            set_world("y6_carina","recovering");set_story_flag("y6_carina_mark_removed")
            if w["lucius_status"]=="arrested": set_world("lucius_status","free")
            set_world("ministry_truth","confirmed")
        if sid=="Y6-C5-S15": q["knowledge"]["carina"]=list(q["knowledge"]["harry"])
        if sid=="Y6-C5-S16":
            relationship_event("carina","y6_reunion","reconcile","기억을 함께 본 뒤 서로 곁에 남아 살아갈 방법을 찾기로 했다.",True)
            set_world("y6_carina","reunited")
        if sid=="Y6-C6-S11":
            relationship_event("carina","y6_public_reunion","publish","대연회장에서 다시 교제하고 있음을 직접 밝혔다.",True)
            q["knowledge"]["public"].extend(["living_horcrux","temporary_protection","carina_relationship"])
        if sid=="Y6-C6-S14": set_story_flag("y6_internal_negotiation_failed")
        if sid=="Y6-C6-S16":
            set_world("y6_cabinet","closed");set_story_flag("y6_carina_stopped_killing")
            q["remnants"]=["crouch_jr","bellatrix","karkaroff"]
        if sid=="Y6-C7-S15": set_story_flag("y6_snape_inheritance")
        if sid=="Y6-C8-S11": set_story_flag("y6_snape_memories_read")
        if sid=="Y6-C8-S12": set_story_flag("y6_ginny_seeker")
        if sid=="Y6-C8-S14":
            set_story_flag("y6_veritaserum_given");q["knowledge"]["carina"].append("private_search_prepared")
        if sid in ("Y6-C8-S05","Y6-C8-S15"): y6_export_handoff()
        q["events"].append(sid);set_story_flag("y6_resolved_"+sid)

    def y6_export_handoff():
        v=store.vn;w=v["world"];q=v["year6"];hidden=y6_hidden()
        def set_world(key,value): return apply_effect(v,("world",key,value))
        def set_story_flag(key,value=True): return apply_effect(v,("flag",key,value))
        if w["dumbledore_status"]!=("dead_hidden" if hidden else "dead_tower"): raise ValueError("Fixed Dumbledore outcome missing")
        if hidden and (w["y6_voldemort"]!="body_defeated" or w["y6_soul"]!="remaining_fragment"): raise ValueError("Hidden conflict cannot be resolved early")
        destination="hidden_soul_summer" if hidden else "main_horcrux_hunt"
        set_world("y6_next_campaign",destination);set_world("y6_phase","complete");set_story_flag("y6_complete")
        common=dict(origin="hidden" if hidden else "main",destination=destination,start_date="2032-07-01",
            implemented=True,final_ending=False,romance=state_copy(v["romance"]),friendships=state_copy(v["relationships"]),
            friendship_stability=v["special"]["friendship_stability"],prior=state_copy(v["year6_entry"]),
            survivors={k:w[k] for k in ("sirius_status","sirius_legal","y4_cedric","lucius_status","pettigrew_status","dobby_status")},
            ministry=w["ministry_truth"],dumbledore=w["dumbledore_status"],killer=w["y6_dumbledore_killer"],snape=w["y6_snape"],
            horcruxes=state_copy(q["horcruxes"]),objectives=list(q["objectives"]),casualties=list(q["casualties"]),injuries=list(q["injuries"]),
            choices=[state_copy(c) for c in v["choices"] if c["choice_id"].startswith("Y6_")])
        if hidden:
            common.update(committed=True,y3_visibility=w["y3_carina_visibility"],y3_secret_dating=w["carina_secret_dating"],forced_separation=w["y4_carina_separation"],
                voldemort=w["y6_voldemort"],soul=w["y6_soul"],protection=state_copy(q["protection"]),
                knowledge=state_copy(q["knowledge"]),remnants=list(q.get("remnants",[])),
                privet_required_days=7,carina_search="destination_not_known_to_harry",
                snape_inheritance=y6_flag("y6_snape_inheritance"),veritaserum_given=y6_flag("y6_veritaserum_given"))
        else:
            common.update(voldemort="active",carina=w["y6_carina"],carina_future_open=y6_flag("y6_carina_future_open"),
                snape_motive="unknown_to_harry",knowledge=state_copy(q["knowledge"]),order_strength=w["order_strength"])
        v["year7_handoff"]=common

    def y6_finish_scene(sid):
        if store.vn["current_chapter"]!=Y6_SCENES[sid]["chapter"]: raise ValueError("Year 6 chapter mismatch")
        if y6_flag("finished_"+sid): return
        y6_resolve(sid);set_story_flag("finished_"+sid);m41_record_outcomes(sid);m33_complete(sid)
    def y6_enter_scene(sid):
        if store.vn["current_chapter"]!=Y6_SCENES[sid]["chapter"] or not y6_scene_available(sid): raise ValueError("Unavailable Year 6 scene")
        if store.vn["year6_entry"]["hidden"]!=y6_hidden(): raise ValueError("Committed story changed")
        store.y6_active_scene=sid;store.y6_portrait=None;store.y6_expressions={};store.y6_offscreen=[]
        store.m733_shop_tryon=None
        if sid in ("Y6-C2-S06","Y6-C3-S04","Y6-C5-S01","Y6-C6-S05","Y6-C2-S13","Y6-C2-S14","Y6-C5-S13","Y6-C5-S15","Y6-C5-S16","Y6-C8-S14"):
            store.y6_expressions["carina"]="concerned"
        if sid in ("Y6-C1-S12","Y6-C6-S15","Y6-C7-S14"):
            store.y6_expressions["carina"]="confident"
        set_story_flag("seen_"+sid)
    def y6_presets_for_scene(sid):
        return ["hidden","public"] if sid in Y6_SOURCE_SCENES else [p for p in Y6_REVIEW_PRESETS if p not in ("hidden","public")]
    def y6_prepare_review(sid,preset="main",overrides=None):
        if preset not in y6_presets_for_scene(sid): raise ValueError("QA history does not match lane")
        previous="Y5-C6-S13" if preset in ("hidden","public") else "Y5-C6-S08"
        profile="luna" if preset=="luna_romance" else "main" if preset=="carina" else preset
        y5_prepare_review(previous,profile)
        for cid in Y5_SCENES[previous]["choices"]:
            if y5_choice_needed(cid): record_choice(cid,next(o["id"] for o in CHOICES[cid]["options"] if y5_option_available(cid,o["id"])))
        y5_finish_scene(previous);complete_chapter("5학년 완료 · 임시 검수 이력")
        y6_begin()
        defaults={"Y6_FEELINGS":"luna" if preset=="luna_romance" else "friends",
            "Y6_PARTY":"luna" if preset in ("luna","luna_romance") else "ginny" if preset=="ginny" else "alone" if preset=="no_romance" else "hermione"}
        defaults.update(overrides or {})
        for old,meta in Y6_SCENES.items():
            if store.vn["current_chapter"]!=meta["chapter"]:
                if store.vn["current_chapter"]: complete_chapter("6학년 장면 이전의 임시 검수 이력")
                begin_chapter(meta["chapter"])
            if old==sid: break
            if not y6_scene_available(old): continue
            for cid in meta["choices"]:
                if not y6_choice_needed(cid): continue
                oid=defaults.get(cid,CHOICES[cid]["options"][0]["id"])
                if not y6_option_available(cid,oid): oid=next(o["id"] for o in CHOICES[cid]["options"] if y6_option_available(cid,o["id"]))
                record_choice(cid,oid)
            y6_finish_scene(old)
        store.y6_review_chapter=Y6_SCENES[sid]["number"];store.y6_review_offset=Y6_SCENES[sid]["offset"]
        store.vn["review_entry_scene"]=sid;store.m21_last_node=None

default y6_active_scene = None
default y6_portrait = None
default y6_expressions = {}
default y6_offscreen = []
default y6_review_chapter = 1
default y6_review_offset = 0

label y6_scene(scene_id):
    $ vc_reset_stage()
    $ y6_enter_scene(scene_id)
    $ m21_visit(scene_id)
    hide screen y1_stage
    hide screen y2_stage
    hide screen y3_stage
    hide screen y4_stage
    hide screen y5_stage
    hide screen y6_event_cg
    scene expression Solid("#182733")
    show screen y6_stage(scene_id)
    $ m43_scene_audio(scene_id)
    with Dissolve(0.25)
    return

label y6_cg(asset_id):
    show screen y6_event_cg(asset_id)
    with Dissolve(0.3)
    $ m21_unlock_cg("Y6:"+asset_id)
    return
