init -30 python:
    def choice_record(choice_id, state=None):
        choice_id = canonical_name(choice_id)
        for entry in (state or store.vn)["choices"]:
            if entry["choice_id"] == choice_id:
                return entry
        return None

    def chose(choice_id, option_id, state=None):
        option_id = canonical_name(option_id)
        entry = choice_record(choice_id, state)
        return entry is not None and entry["option_id"] == option_id

    def record_choice(choice_id, option_id):
        choice_id, option_id = canonical_name(choice_id), canonical_name(option_id)
        require_key(CHOICES, choice_id)
        definition = CHOICES[choice_id]
        options = {o["id"]: o for o in definition["options"]}
        require_key(options, option_id)
        old = choice_record(choice_id)
        if old:
            if old["option_id"] != option_id:
                raise ValueError("Choice already resolved; roll back before changing it")
            return False  # Idempotent: no duplicate score, history or notice.
        chapter_id = store.vn["current_chapter"]
        if chapter_id != definition["chapter_id"]:
            raise ValueError("Choice does not belong to the active chapter")
        if store.vn["chapters"][chapter_id]["completed"]:
            raise ValueError("Chapter is already completed")
        if choice_id.startswith("Y7_") and not y7_option_available(choice_id, option_id):
            raise ValueError("Unavailable Year 7 choice")
        if choice_id.startswith("Y6_") and not y6_option_available(choice_id, option_id):
            raise ValueError("Unavailable Year 6 choice")
        if choice_id.startswith("Y5_") and not y5_option_available(choice_id, option_id):
            raise ValueError("Unavailable Year 5 choice")
        if choice_id.startswith("Y4_") and not y4_option_available(choice_id, option_id):
            raise ValueError("Unavailable Year 4 choice")
        if (choice_id.startswith("Y3_") or choice_id=="REVIEW_Y3_SIRIUS_REVEAL") and not y3_option_available(choice_id, option_id):
            raise ValueError("Year 3 choice prerequisite not met")
        if not m42_choice_allowed(choice_id):
            raise ValueError("Choice belongs to a different story framework")
        option = options[option_id]
        candidate = state_copy(store.vn)
        changes = [apply_effect(candidate, effect) for effect in option.get("effects", [])]
        candidate["choices"].append({
            "choice_id": choice_id, "chapter_id": chapter_id,
            "choice_text": definition["text"], "option_id": option_id,
            "option_text": m42_choice_text(choice_id,option), "statistics": definition.get("statistics", False),
            "tags": list(definition.get("tags", [])), "pov": candidate["current_pov"],
            "tier": definition.get("tier", 1),
            "changes": changes,
        })
        candidate["chapters"][chapter_id]["choice_ids"].append(choice_id)
        affection_log_update(candidate, store.vn, choice=candidate["choices"][-1])
        store.vn = candidate  # Commit state and log together only after validation.
        return True

label vn_choose(choice_id):
    $ choice_id = canonical_name(choice_id)
    if m33_active() and choice_id in m33_forced:
        $ affection_new_choice = record_choice(choice_id,m33_forced[choice_id])
        if affection_new_choice:
            $ affection_notify_latest()
        return
    $ m21_before_choice(choice_id)
    call screen important_choice(choice_id)
    $ affection_new_choice = record_choice(choice_id, _return)
    $ m21_after_choice(choice_id, _return)
    if affection_new_choice:
        $ affection_notify_latest()
    return
