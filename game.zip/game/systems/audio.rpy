init -1 python:
    def m43_scene_track(sid, state=None):
        state=state if state is not None else store.vn
        if sid in M73_SCENE_OVERRIDES:
            return M73_SCENE_OVERRIDES[sid]
        # The same IDs can stage very different events in the two frameworks.
        origin=state.get("world",{}).get("story_origin")
        if sid=="Y1-C4-S12": return "hermione"
        if sid=="Y3-C1-S01": return "warm"
        if sid=="Y3-C6-S03": return "mystery"
        if sid=="Y3-C6-S05": return "warm"
        if sid=="Y3-C4-S08": return "mystery"
        if sid=="Y3-C4-S07": return "danger" if origin=="main" else "carina"
        if sid=="Y3-C6-S08":
            return "carina"
        if sid=="Y3-C6-S09": return "separation"
        if sid=="Y4-C6-S04":
            return "carina_pressure" if state.get("romance",{}).get("carina",{}).get("status")=="dating" else "mystery"
        return M43_SCENE_MUSIC.get(sid,"school")

    def m43_play(track, fade=1.0):
        if track is None:
            renpy.music.stop(channel="music",fadeout=fade)
            return
        if track not in M43_TRACKS: raise ValueError("Unknown music cue: "+str(track))
        path="audio/ost/"+track+".ogg"
        # One established channel retains Ren'Py save/load, rollback and Replay
        # restoration. Fades are sequential, not claimed to be dual-channel crossfades.
        # During a fade get_playing still reports the outgoing track. Compare
        # the requested loop so rapid scene changes can cancel a stale queue.
        queued=renpy.music.get_loop(channel="music")
        if queued and len(queued)==1 and queued[0].split(">")[-1]==path: return
        renpy.music.play(path,channel="music",loop=track not in M73_NON_LOOPING,fadeout=fade,
                         fadein=fade+0.35,if_changed=True)

    def m43_sfx(cue):
        if renpy.is_skipping(): return
        renpy.sound.play("audio/sfx/"+cue+".ogg",channel="sound",relative_volume=0.7)

    def m43_scene_audio(sid):
        # Fade lingering one-shot atmosphere when a new scene begins.
        renpy.sound.stop(channel="sound",fadeout=0.25)
        m43_play(m43_scene_track(sid))
        cue=M43_ENTRY_SFX.get(sid)
        if cue: m43_sfx(cue)

    def m43_cg_audio(asset):
        cue={"shared_patronus":"magic","hermione_rescue":"wind"}.get(asset)
        if cue: m43_sfx(cue)
        if asset=="shared_patronus": m73_cue("shared_patronus")
        if asset=="hermione_rescue": m43_play("reflection")

    def m43_music_title():
        path=renpy.music.get_playing(channel="music")
        if not path: return "무음"
        key=path.rsplit("/",1)[-1].split(".")[0]
        return M43_TRACKS.get(key,"이전 버전 음악")

    def m43_restore_preview(path,position):
        queued=renpy.music.get_loop(channel="music")
        if queued==[path]: return
        if path:
            path=path.split(">")[-1]
            key=path.rsplit("/",1)[-1].split(".")[0]
            looping=key not in M73_NON_LOOPING
            prefix=("<from %.3f loop 0.0>" if looping else "<from %.3f>")%(position or 0)
            renpy.music.play(prefix+path,channel="music",loop=looping,fadeout=0.35,fadein=0.5)
        else:
            renpy.music.stop(channel="music",fadeout=0.4)

    def m43_resume_legacy_music():
        current=renpy.music.get_playing(channel="music")
        if current not in ("audio/m2/quiet.wav","audio/m2/mystery.wav","audio/m4_waltz.wav"): return
        for year in (4,3,2,1):
            sid=getattr(store,"y%d_active_scene"%year,None)
            if sid and (store.vn.get("current_chapter") or "").startswith("Y%d-"%year):
                m43_play(m43_scene_track(sid));return

init python:
    config.main_menu_music = "audio/ost/title.ogg"
    config.main_menu_music_fadein = 1.0
    config.default_music_volume = 0.6
    config.default_sfx_volume = 0.65
    config.after_load_callbacks.append(m43_resume_legacy_music)
