init -7 python:
    Y7_REVIEW_PRESETS=dict(Y6_REVIEW_PRESETS)
    Y7_REVIEW_PRESETS.update(carina="본편 · 전후 카리나와 새 출발",no_romance="본편 · 연애 없이")
    def y7_hidden(): return carina_hidden_campaign()
    def y7_flag(key): return store.vn["flags"].get(key,False)
    def y7_partner():
        return next((h for h in HEROINE_IDS if store.vn["romance"][h]["status"]=="dating"),None)
    def y7_chapter_title(number):
        return (Y7_HIDDEN_TITLES if y7_hidden() else Y7_TITLES)[number-1]
    def y7_can_date(h):
        if not romance_can_pursue(h): return False
        if y7_hidden() or y7_partner() or store.vn["route_intent"]=="no_romance": return False
        if not y7_flag("voldemort_final_defeat") or h not in HEROINE_IDS: return False
        if h=="carina": return not m732_altered() and y7_flag("y7_carina_listened") and y7_flag("y7_carina_apologized")
        return y7_flag("finished_Y7-C9-S01") and store.vn["romance"][h]["status"]=="none" and m751_postwar_bond(h)
    def y7_can_confess_in_tent():
        v=store.vn
        return bool(romance_can_pursue("hermione") and not y7_hidden() and not y7_partner() and v["route_intent"]!="no_romance"
            and chose("Y7_RON_ARGUMENT","leave") and not v.get("year7",{}).get("ron_present",True)
            and v["romance"]["hermione"]["status"]=="none"
            and v["relationships"]["hermione"]["affection"]>=6
            and y7_flag("finished_Y7-C2-S05")
            and (y7_flag("y5_hermione_time") or v["world"].get("y4_partner")=="hermione"))
    def y7_option_available(cid,oid):
        if cid.startswith("Y7_MEMORY_"): return m732_option_available(cid,oid)
        if cid not in CHOICES or oid not in [o["id"] for o in CHOICES[cid]["options"]]: return False
        if cid.startswith("Y7_H_")!=y7_hidden(): return False
        if cid=="Y7_TENT_EVENING": return y7_scene_available("Y7-C3-S07")
        if cid=="Y7_HERMIONE_TENT": return y7_can_confess_in_tent()
        if cid=="Y7_RELATIONSHIP": return not y7_partner() and (oid=="friends" or y7_can_date(oid))
        if cid=="Y7_CARINA_POSTWAR": return not y7_partner() and (oid=="friends" or y7_can_date("carina"))
        if cid=="Y7_HANDSHAKE": return chose("Y7_FUTURE","return") and y7_partner()=="carina" and not y7_hidden()
        if cid=="Y7_RETURN_CLASS": return chose("Y7_FUTURE","return")
        return True
    def y7_choice_needed(cid):
        if cid=="Y7_MEMORY_FUTURE" and m732_current_other(): return False
        return any(y7_option_available(cid,o["id"]) for o in CHOICES[cid]["options"])
    def y7_scene_available(sid):
        if sid=="Y7-C3-S05" and m732_inherited("locket"): return False
        if sid=="Y7-C6-S01" and m732_inherited("cup"): return False
        if sid in ("Y7-C9-S20","Y7-C9-S21","Y7-C9-S22","Y7-C9-S23","Y7-C9-S24","Y7-C11-S20"): return m732_scene_condition(sid)
        if sid=="Y7-C11-S04" and m732_altered(): return False
        if sid not in Y7_SCENES or ((sid in Y7_SOURCE_SCENES)!=y7_hidden()): return False
        c=Y7_SCENES[sid]["condition"]
        if c=="always": return True
        if c=="ron_absent": return chose("Y7_RON_ARGUMENT","leave") and not store.vn["year7"]["ron_present"]
        if c=="carina_conversation": return not m732_altered() and not y7_partner() and y7_flag("y7_carina_listened")
        if c in ("auror","return"): return chose("Y7_FUTURE",c)
        if c.startswith("star_"): return chose("Y7_FUTURE","return") and (y7_partner() or "none")==c[5:]
        if c.startswith("end_"): return (y7_partner() or "none")==c[4:] and y7_flag("voldemort_final_defeat")
        return False
    def y7_begin():
        v=store.vn
        if v["current_chapter"] or not v["chapters"].get("Y6-C8",{}).get("completed") or not y7_flag("y6_complete"):
            raise ValueError("Year 7 requires completed Year 6")
        if "year7_handoff" not in v or any(k.startswith("Y7-") for k in v["chapters"]): raise ValueError("Invalid Year 7 entry")
        if m6_route_incompatible(v): raise ValueError("Historical worldline requires restart")
        hidden=y7_hidden()
        if v["year7_handoff"]["origin"]!=("hidden" if hidden else "main"): raise ValueError("Year 7 origin mismatch")
        v["year7_entry"]=state_copy(v["year7_handoff"])
        v["year7"]={"hidden":hidden,"horcruxes":state_copy(v["year7_handoff"]["horcruxes"]),
            "knowledge":state_copy(v["year7_handoff"]["knowledge"]),"events":[],"casualties":[],"injuries":[],
            "career":None,"ending":None,"family":None,"education":None,"dobby":v["world"]["dobby_status"],
            "ministry_rescued":0,"ron_present":True,"wand_owner":None,"soul_resolved":False,"legal_resolution":False}
        set_story_flag("y7_campaign")
        for n in range(1,7):
            setattr(store,"y%d_active_scene"%n,None);setattr(store,"y%d_portrait"%n,None)
        store.m21_last_node=None
    def y7_mark_horcrux(item,status,sid):
        book=store.vn["year7"]["horcruxes"];require_key(book,item)
        if status not in ("known","located","destroyed"): raise ValueError("Invalid discovery")
        book[item]["known"]=True
        if status in ("located","destroyed"): book[item]["located"]=True
        if status=="destroyed": book[item]["destroyed"]=True
        if sid not in book[item]["evidence"]: book[item]["evidence"].append(sid)
    def y7_resolve(sid):
        if y7_flag("y7_resolved_"+sid): return
        if not y7_scene_available(sid): raise ValueError("Wrong Year 7 lane or condition")
        v=store.vn;q=v["year7"]
        def world(k,x): return apply_effect(v,("world",k,x))
        def flag(k,x=True): v["flags"][k]=x
        def romance(h,event,detail):
            action="reconcile" if v["romance"][h]["status"] in ("ended","separated") else "start"
            apply_relationship_event(v,h,event,action,detail,True)
        if sid=="Y7-C2-S01":
            y7_mark_horcrux("locket","known",sid);q["knowledge"]["harry"].append("regulus_and_kreacher")
        if sid=="Y7-C2-S03":
            y7_mark_horcrux("locket","located",sid)
            q["ministry_rescued"]=12 if chose("Y7_MINISTRY_PLAN","rescue") else 7
        if sid=="Y7-C2-S04": q["injuries"].append("ron_splinched_treated")
        if sid=="Y7-C3-S01": q["ron_present"]=not chose("Y7_RON_ARGUMENT","leave")
        if sid=="Y7-C3-S07":
            if chose("Y7_HERMIONE_TENT","confess"):
                if not y7_can_confess_in_tent(): raise ValueError("Tent confession prerequisites were lost")
                romance("hermione","y7_tent_confession","론이 떠난 뒤 함께 지내며 마음을 전하고 서로 사귀기로 했다.")
            apply_relationship_event(v,"hermione","y7_tent_evening","memory",
                "론을 기다리던 저녁, 텐트에서 잠들지 못한 채 함께 이야기를 나눴다.",False)
        if sid=="Y7-C3-S03": q["knowledge"]["harry"].append("nagini_is_horcrux");y7_mark_horcrux("nagini","known",sid)
        if sid=="Y7-C3-S04": q["ron_present"]=True
        if sid=="Y7-C3-S05": y7_mark_horcrux("locket","destroyed",sid)
        if sid=="Y7-C4-S02": q["knowledge"]["harry"].extend(["luna_captive","three_hallows"])
        if sid=="Y7-C5-S01":
            if v["world"]["dobby_status"]=="bound": world("dobby_status","free_carina");flag("y7_carina_freed_dobby")
            if v["world"]["pettigrew_status"]=="escaped": world("pettigrew_status","captured");flag("y7_peter_recaptured")
        if sid=="Y7-C5-S02":
            q["wand_owner"]="harry";flag("y7_carina_disarmed");q["injuries"].append("hermione_torture_treated")
            if chose("Y7_MANOR_ESCAPE","shield"): q["injuries"].append("harry_arm_treated")
            else: world("dobby_status","dead");q["casualties"].append("dobby")
            q["dobby"]=v["world"]["dobby_status"]
        if sid=="Y7-C5-S04": q["knowledge"]["harry"].extend(["wand_allegiance_can_transfer_without_death","cup_in_lestrange_vault"])
        if sid=="Y7-C6-S01": y7_mark_horcrux("cup","located",sid)
        if sid=="Y7-C6-S04": y7_mark_horcrux("diadem","located",sid)
        if sid=="Y7-C7-S02": y7_mark_horcrux("cup","destroyed",sid)
        if sid=="Y7-C7-S03":
            y7_mark_horcrux("diadem","destroyed",sid);q["casualties"].append("victoria");flag("y7_carina_rescued")
        if sid=="Y7-C7-S04":
            q["casualties"].extend(["lupin","tonks"])
            if chose("Y7_BATTLE_PREP","evacuate"): q["injuries"].extend(["fred_treated","percy_treated"])
            else: q["casualties"].append("fred")
        if sid=="Y7-C7-S05": q["snape_status"]="dead_by_nagini";q["casualties"].append("snape");flag("y7_snape_death_main")
        if sid=="Y7-C7-S06":
            y7_mark_horcrux("harry","located",sid);q["knowledge"]["harry"].extend(["snape_planned_tower_death","living_horcrux"])
        if sid=="Y7-C8-S02":
            y7_mark_horcrux("harry","destroyed",sid);q["soul_resolved"]=True
            q["knowledge"]["harry"].append("lily_blood_tether_in_voldemort")
        if sid=="Y7-C8-S04": y7_mark_horcrux("nagini","destroyed",sid)
        if sid=="Y7-C8-S05":
            if not all(x["destroyed"] for x in q["horcruxes"].values()) or q["wand_owner"]!="harry": raise ValueError("Unresolved final duel prerequisites")
            flag("voldemort_final_defeat");world("ministry_truth","confirmed")
        if sid=="Y7-C9-S02": flag("y7_carina_accountability")
        if sid=="Y7-C9-S03": flag("y7_carina_apologized")
        if sid=="Y7-C9-S04" and choice_record("Y7_RELATIONSHIP"):
            h=choice_record("Y7_RELATIONSHIP")["option_id"]
            if h!="friends":
                if not y7_can_date(h): raise ValueError("Postwar confession not available")
                romance(h,"y7_postwar_confession","전쟁이 끝난 뒤 서로 마음을 전하고 사귀기로 했다.")
        if sid=="Y7-C9-S05" and chose("Y7_CARINA_POSTWAR","date"):
            if not y7_can_date("carina"): raise ValueError("Main Carina romance requires mutual postwar decision")
            flag("carina_postwar_reconciled");romance("carina","y7_postwar_carina","전후의 대화를 거쳐 카리나와 새롭게 사귀기로 했다.")
        if sid=="Y7-C9-S06": q["career"]=choice_record("Y7_FUTURE")["option_id"];q["education"]="return_planned" if q["career"]=="return" else "interrupted"
        if sid=="Y7-C10-S03": flag("y7_auror_qualified")
        if sid.startswith("Y7-C11-S0") and sid!="Y7-C11-S06": flag("y7_quiet_conclusion")
        if sid=="Y7-C11-S06": q["education"]="graduated_2034";flag("y7_graduated")
        if sid=="Y7-C1-S13": flag("y7_privet_week_completed")
        if sid=="Y7-C2-S11": q["knowledge"]["harry"].append("karkaroff_attack_and_protective_command")
        if sid=="Y7-C3-S12":
            q["knowledge"]["harry"].append("grindelwald_victim_proposal_not_a_cure")
        if sid=="Y7-C4-S11": flag("y7_murder_refused")
        if sid=="Y7-C4-S13": flag("y7_karkaroff_returned_alive")
        if sid=="Y7-C6-S12":
            if not y6_flag("y6_snape_inheritance") or v["world"]["y6_snape"]!="dead_protecting_harry":
                raise ValueError("Hidden soul protection needs the witnessed Year 6 sacrifice")
            q["knowledge"]["harry"].extend(["snape_soul_protection","dumbledore_temporary_seal_distinct"])
        if sid=="Y7-C6-S13":
            if Y7_SCENES[sid]["time"]>=Y6_PROTECTION_END: raise ValueError("Soul resolution is before the birthday")
            if not y7_flag("y7_murder_refused") or not y7_flag("y7_karkaroff_returned_alive"):
                raise ValueError("Victim proposal must have been rejected")
            y7_mark_horcrux("harry","destroyed",sid)
            if not all(h["destroyed"] for h in q["horcruxes"].values()): raise ValueError("Hidden outer fragments remain")
            q["soul_resolved"]=True;q["soul_resolution_date"]="2032-07-30"
            flag("voldemort_final_defeat");flag("y7_hidden_soul_resolution")
        if sid=="Y7-C7-S12":
            if not q["soul_resolved"]: raise ValueError("Birthday cannot resolve the fragment automatically")
            q["temporary_protection_expired"]=True;q["birthday_observed"]="2032-07-31"
        if sid=="Y7-C7-S13": q["movement_restriction"]="lifted_pending_investigation"
        if sid=="Y7-C8-S11": flag("y7_carina_testified")
        if sid=="Y7-C8-S12":
            if not q["soul_resolved"] or not y7_flag("y7_carina_testified"): raise ValueError("Investigation incomplete")
            q["legal_resolution"]=True;q["legal_finding"]="possession_not_voluntary_killing"
            q["movement_restriction"]="lifted";flag("y7_original_happy_aftermath")
        if sid=="Y7-C9-S11": flag("y7_carina_apologized")
        if sid=="Y7-C10-S12" and v["world"]["dobby_status"]=="bound":
            world("dobby_status","free_carina");q["dobby"]="free_carina";flag("y7_carina_freed_dobby")
        if sid=="Y7-C10-S13": q["career"]=choice_record("Y7_H_FUTURE")["option_id"]
        if sid=="Y7-C11-S11": q["education"]="graduated_2033";flag("y7_graduated")
        if sid=="Y7-C11-S13": q["marriage_agreed"]="2037-07-31";flag("y7_hidden_shared_future")
        if sid.startswith("Y7-C12-"): y7_finish_story(sid)
        m732_finish(sid)
        # Relationship feedback can atomically replace the state container.
        v=store.vn;q=v["year7"]
        q["events"].append(sid);v["flags"]["y7_resolved_"+sid]=True
    def y7_finish_story(sid):
        v=store.vn;q=v["year7"]
        if len(romance_commitments(v))>1 or cho_active(v):
            raise ValueError("Conflicting active commitments cannot produce a romance ending")
        if not y7_flag("voldemort_final_defeat") or not q["soul_resolved"]: raise ValueError("Ending before resolution")
        if not y7_hidden() and not (y7_flag("y7_auror_qualified") or y7_flag("y7_graduated")): raise ValueError("Future chapter incomplete")
        if y7_hidden() and not (q["legal_resolution"] and q.get("marriage_agreed") and q["education"]=="graduated_2033" and y7_partner()=="carina"):
            raise ValueError("Hidden ending needs recovery, legal aftermath and a shared future")
        partner=y7_partner()
        key=("carina_hidden" if y7_hidden() else "carina_restored" if partner=="carina" and m732_memory().get("renewed") else partner or "no_romance")
        q["ending"]=key;q["family"]=dict(partner=partner,year=2052,scene=sid) if partner else None
        if not partner: q["no_romance_variant"]=m751_no_romance_variant(v)
        v["current_route"]=partner or "no_romance";v["flags"]["y7_complete"]=True
    def y7_publish_ending():
        if m33_active() or not y7_flag("y7_complete"): return
        q=store.vn["year7"]
        m21_add("m21_endings","route_"+q["ending"])
        m21_add("m21_annual_variants","Y7:"+q["ending"]+":"+str(q["career"]))
    def y7_finish_scene(sid):
        if store.vn["current_chapter"]!=Y7_SCENES[sid]["chapter"]: raise ValueError("Year 7 chapter mismatch")
        if y7_flag("finished_"+sid): return
        y7_resolve(sid);set_story_flag("finished_"+sid);m41_record_outcomes(sid);m33_complete(sid)
    def y7_enter_scene(sid):
        if store.vn["current_chapter"]!=Y7_SCENES[sid]["chapter"] or not y7_scene_available(sid): raise ValueError("Unavailable Year 7 scene")
        if store.vn["year7"]["hidden"]!=y7_hidden(): raise ValueError("Committed story changed")
        store.y7_active_scene=sid;store.y7_portrait=None;store.y7_expressions={};store.y7_offscreen=[]
        set_story_flag("seen_"+sid)
    def y7_presets_for_scene(sid):
        if sid in Y7_SOURCE_SCENES: return ["hidden","public"]
        if sid=="Y7-C12-S06": return ["no_romance","cho"]
        c=Y7_SCENES[sid]["condition"]
        if c.startswith(("star_","end_")):
            h=c.split("_",1)[1]
            return [{"none":"no_romance","luna":"luna_romance"}.get(h,h)]
        if c=="carina_conversation": return ["carina","cho"]
        return [p for p in Y7_REVIEW_PRESETS if p not in ("hidden","public")]
    def y7_prepare_review(sid,preset="main",overrides=None):
        if preset not in y7_presets_for_scene(sid): raise ValueError("QA history does not match Year 7 lane")
        previous="Y6-C8-S15" if preset in ("hidden","public") else "Y6-C8-S05"
        y6_prepare_review(previous,preset,overrides)
        for cid in Y6_SCENES[previous]["choices"]:
            if y6_choice_needed(cid): record_choice(cid,next(o["id"] for o in CHOICES[cid]["options"] if y6_option_available(cid,o["id"])))
        y6_finish_scene(previous);complete_chapter("6학년 완료 · 임시 검수 이력");y7_begin()
        defaults={"Y7_RELATIONSHIP":"friends","Y7_CARINA_POSTWAR":"date" if preset=="carina" else "friends","Y7_FUTURE":"return"}
        if sid=="Y7-C3-S07": defaults["Y7_RON_ARGUMENT"]="leave"
        if Y7_SCENES[sid]["condition"]=="auror": defaults["Y7_FUTURE"]="auror"
        defaults.update(overrides or {})
        for old,meta in Y7_SCENES.items():
            if store.vn["current_chapter"]!=meta["chapter"]:
                if store.vn["current_chapter"]: complete_chapter("7학년 장면 이전의 임시 검수 이력")
                begin_chapter(meta["chapter"])
            if old==sid: break
            if not y7_scene_available(old): continue
            for cid in meta["choices"]:
                if not y7_choice_needed(cid): continue
                oid=defaults.get(cid,CHOICES[cid]["options"][0]["id"])
                if not y7_option_available(cid,oid): oid=next(o["id"] for o in CHOICES[cid]["options"] if y7_option_available(cid,o["id"]))
                record_choice(cid,oid)
            y7_finish_scene(old)
        store.y7_review_chapter=Y7_SCENES[sid]["number"];store.y7_review_offset=Y7_SCENES[sid]["offset"]
        store.vn["review_entry_scene"]=sid;store.m21_last_node=None

default y7_active_scene = None
default y7_portrait = None
default y7_expressions = {}
default y7_offscreen = []
default y7_review_chapter = 1
default y7_review_offset = 0

label y7_scene(scene_id):
    $ vc_reset_stage()
    $ y7_enter_scene(scene_id)
    $ m21_visit(scene_id)
    hide screen y1_stage
    hide screen y2_stage
    hide screen y3_stage
    hide screen y4_stage
    hide screen y5_stage
    hide screen y6_stage
    hide screen y1_event_cg
    hide screen y2_event_cg
    hide screen y3_event_cg
    hide screen y4_event_cg
    hide screen y5_event_cg
    hide screen y6_event_cg
    hide screen y7_event_cg
    scene expression Solid("#182733")
    show screen y7_stage(scene_id)
    $ m43_scene_audio(scene_id)
    with Dissolve(0.25)
    return

label y7_cg(asset_id):
    show screen y7_event_cg(asset_id)
    with Dissolve(0.3)
    $ m21_unlock_cg("Y7:"+asset_id)
    return
