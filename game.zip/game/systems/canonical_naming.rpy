# Canonical character naming. Legacy spelling occurs only in the explicit map.
init -60 python:
    import re as canonical_re
    LEGACY_CARINA_IDS = {
        "KARINA": "CARINA",
        "KARINA_CHARACTER_BIBLE": "CARINA_CHARACTER_BIBLE",
        "KARINA_PUBLIC_AFFECTION": "CARINA_PUBLIC_AFFECTION",
        "KARINA_REFERENCE_ANALYSIS": "CARINA_REFERENCE_ANALYSIS",
        "Karina": "Carina",
        "M0_C1_KARINA": "M0_C1_CARINA",
        "M4A_KARINA_COSTUME": "M4A_CARINA_COSTUME",
        "Y2_KARINA_APPROACH": "Y2_CARINA_APPROACH",
        "Y2_KARINA_DECISION": "Y2_CARINA_DECISION",
        "Y3_KARINA_FAREWELL": "Y3_CARINA_FAREWELL",
        "Y3_KARINA_OUTING": "Y3_CARINA_OUTING",
        "Y3_KARINA_RING_ESTRANGED": "Y3_CARINA_RING_ESTRANGED",
        "Y3_KARINA_RING_RECONCILED": "Y3_CARINA_RING_RECONCILED",
        "Y3_SIRIUS_RESCUE_KARINA": "Y3_SIRIUS_RESCUE_CARINA",
        "Y4_DANCE_KARINA": "Y4_DANCE_CARINA",
        "Y4_KARINA_COVER": "Y4_CARINA_COVER",
        "Y4_KARINA_INFORMATION": "Y4_CARINA_INFORMATION",
        "Y4_PRACTICE_KARINA": "Y4_PRACTICE_CARINA",
        "affection_value_karina": "affection_value_carina",
        "anchor_karina_y1_uniform_v001": "anchor_carina_y1_uniform_v001",
        "ball_karina": "ball_carina",
        "completion_karina_casual_y4": "completion_carina_casual_y4",
        "completion_karina_quidditch_y2": "completion_carina_quidditch_y2",
        "completion_karina_quidditch_y3": "completion_carina_quidditch_y3",
        "example_karina_pov": "example_carina_pov",
        "free_karina": "free_carina",
        "harry_karina": "harry_carina",
        "invite_karina": "invite_carina",
        "karina": "carina",
        "karina_bandaged": "carina_bandaged",
        "karina_bond": "carina_bond",
        "karina_casual_y4": "carina_casual_y4",
        "karina_concerned": "carina_concerned",
        "karina_confident": "carina_confident",
        "karina_continuity_m11": "carina_continuity_m11",
        "karina_cooperation": "carina_cooperation",
        "karina_cover": "carina_cover",
        "karina_da_relationship_y5": "carina_da_relationship_y5",
        "karina_dating": "carina_dating",
        "karina_death_eater_access": "carina_death_eater_access",
        "karina_diary": "carina_diary",
        "karina_disdain": "carina_disdain",
        "karina_early_blocked": "carina_early_blocked",
        "karina_early_romance_blocked": "carina_early_romance_blocked",
        "karina_embarrassed": "carina_embarrassed",
        "karina_family_loyalty": "carina_family_loyalty",
        "karina_fitting": "carina_fitting",
        "karina_formal": "carina_formal",
        "karina_guarded": "carina_guarded",
        "karina_ideology": "carina_ideology",
        "karina_irritated": "carina_irritated",
        "karina_neutral": "carina_neutral",
        "karina_postwar_reconciled": "carina_postwar_reconciled",
        "karina_prior_visibility": "carina_prior_visibility",
        "karina_public_hint": "carina_public_hint",
        "karina_public_ready": "carina_public_ready",
        "karina_quidditch_concept_v001": "carina_quidditch_concept_v001",
        "karina_quidditch_cutout_v002": "carina_quidditch_cutout_v002",
        "karina_quidditch_y2": "carina_quidditch_y2",
        "karina_quidditch_y3": "carina_quidditch_y3",
        "karina_reference_analysis": "carina_reference_analysis",
        "karina_rescue": "carina_rescue",
        "karina_ring": "carina_ring",
        "karina_secret_dating": "carina_secret_dating",
        "karina_separation": "carina_separation",
        "karina_smile": "carina_smile",
        "karina_thoughtful": "carina_thoughtful",
        "karina_uniform_neutral": "carina_uniform_neutral",
        "karina_v3": "carina_v3",
        "karina_y1_uniform_angry_v001": "carina_y1_uniform_angry_v001",
        "karina_y1_uniform_embarrassed_v001": "carina_y1_uniform_embarrassed_v001",
        "karina_y1_uniform_happy_v001": "carina_y1_uniform_happy_v001",
        "karina_y1_uniform_neutral_v001": "carina_y1_uniform_neutral_v001",
        "karina_y1_uniform_neutral_v002": "carina_y1_uniform_neutral_v002",
        "karina_y1_uniform_proud_v001": "carina_y1_uniform_proud_v001",
        "karina_y1_uniform_sad_v001": "carina_y1_uniform_sad_v001",
        "karina_y1_uniform_thoughtful_v001": "carina_y1_uniform_thoughtful_v001",
        "m0_karina_choice": "m0_carina_choice",
        "m0_karina_neutral": "m0_carina_neutral",
        "m14_karina_neutral": "m14_carina_neutral",
        "m14_karina_thoughtful": "m14_carina_thoughtful",
        "m14r_karina_fitting": "m14r_carina_fitting",
        "m14r_karina_guarded": "m14r_carina_guarded",
        "m14r_karina_neutral": "m14r_carina_neutral",
        "m14r_karina_thoughtful": "m14r_carina_thoughtful",
        "m14r_rejected_karina": "m14r_rejected_carina",
        "m14s_karina_fitting": "m14s_carina_fitting",
        "m14s_karina_guarded": "m14s_carina_guarded",
        "m14s_karina_neutral": "m14s_carina_neutral",
        "m14s_karina_thoughtful": "m14s_carina_thoughtful",
        "m14t_forest_karina": "m14t_forest_carina",
        "m14t_train_karina": "m14t_train_carina",
        "m14v_mirror_karina": "m14v_mirror_carina",
        "m2_karina_diary": "m2_carina_diary",
        "m31_karina_bandaged": "m31_carina_bandaged",
        "m31j_karina_quidditch_concept": "m31j_carina_quidditch_concept",
        "m33_preset_Y3_KARINA_RING_ESTRANGED": "m33_preset_Y3_CARINA_RING_ESTRANGED",
        "m3_karina_concerned": "m3_carina_concerned",
        "m3_karina_confident": "m3_carina_confident",
        "m3_karina_disdain": "m3_carina_disdain",
        "m3_karina_embarrassed": "m3_carina_embarrassed",
        "m3_karina_irritated": "m3_carina_irritated",
        "m3_karina_neutral": "m3_carina_neutral",
        "m3_karina_rescue": "m3_carina_rescue",
        "m3_karina_smile": "m3_carina_smile",
        "m3_standing_karina": "m3_standing_carina",
        "m3a_train_karina": "m3a_train_carina",
        "m4_ball_karina": "m4_ball_carina",
        "m4_formal_karina": "m4_formal_carina",
        "m4_karina_formal": "m4_carina_formal",
        "m4_practice_karina": "m4_practice_carina",
        "name_known_karina": "name_known_carina",
        "partner_karina": "partner_carina",
        "practice_karina": "practice_carina",
        "route_karina": "route_carina",
        "spr_karina_y1_uniform_angry": "spr_carina_y1_uniform_angry",
        "spr_karina_y1_uniform_embarrassed": "spr_carina_y1_uniform_embarrassed",
        "spr_karina_y1_uniform_happy": "spr_carina_y1_uniform_happy",
        "spr_karina_y1_uniform_neutral": "spr_carina_y1_uniform_neutral",
        "spr_karina_y1_uniform_proud": "spr_carina_y1_uniform_proud",
        "spr_karina_y1_uniform_sad": "spr_carina_y1_uniform_sad",
        "spr_karina_y1_uniform_thoughtful": "spr_carina_y1_uniform_thoughtful",
        "test_karina_partner_requires_earlier_rescue_and_cannot_unlock_late": "test_carina_partner_requires_earlier_rescue_and_cannot_unlock_late",
        "test_summer_sirius_knowledge_is_common_but_not_karina_cooperation": "test_summer_sirius_knowledge_is_common_but_not_carina_cooperation",
        "y1_karina_dorm_pov": "y1_carina_dorm_pov",
        "y1_karina_dorm_return": "y1_carina_dorm_return",
        "y1_mirror_karina": "y1_mirror_carina",
        "y1_mirror_karina_reply": "y1_mirror_carina_reply",
        "y1_review_karina": "y1_review_carina",
        "y2_karina_decision_choice": "y2_carina_decision_choice",
        "y2_karina_diary_cg": "y2_carina_diary_cg",
        "y2_karina_diary_cg_end": "y2_carina_diary_cg_end",
        "y2_karina_family_risk_confirmed": "y2_carina_family_risk_confirmed",
        "y2_karina_home_pov": "y2_carina_home_pov",
        "y2_karina_home_return": "y2_carina_home_return",
        "y2_karina_knows_horcrux": "y2_carina_knows_horcrux",
        "y2_karina_not_heir": "y2_carina_not_heir",
        "y2_quidditch_caught_karina": "y2_quidditch_caught_carina",
        "y3_karina_bond": "y3_carina_bond",
        "y3_karina_briefed_after_lake": "y3_carina_briefed_after_lake",
        "y3_karina_dating": "y3_carina_dating",
        "y3_karina_excluded": "y3_carina_excluded",
        "y3_karina_farewell_choice": "y3_carina_farewell_choice",
        "y3_karina_firebolt_seen": "y3_carina_firebolt_seen",
        "y3_karina_informed": "y3_carina_informed",
        "y3_karina_outing_choice": "y3_carina_outing_choice",
        "y3_karina_past_rescue": "y3_carina_past_rescue",
        "y3_karina_reached_for_harry": "y3_carina_reached_for_harry",
        "y3_karina_reconciled": "y3_carina_reconciled",
        "y3_karina_rescue_available": "y3_carina_rescue_available",
        "y3_karina_rescue_cg_end": "y3_carina_rescue_cg_end",
        "y3_karina_visibility": "y3_carina_visibility",
        "y3_outing_karina": "y3_outing_carina",
        "y3_past_karina_rescuer": "y3_past_carina_rescuer",
        "y3_past_karina_stopped_snape": "y3_past_carina_stopped_snape",
        "y4_karina_feelings_unresolved": "y4_carina_feelings_unresolved",
        "y4_karina_invitation_declined": "y4_carina_invitation_declined",
        "y4_karina_prior_visibility": "y4_carina_prior_visibility",
        "y4_karina_ron_intervention": "y4_carina_ron_intervention",
        "y4_karina_separation": "y4_carina_separation"
    }
    LEGACY_CARINA_LABELS = {
        "m0_karina_choice": "m0_carina_choice",
        "y1_karina_dorm_pov": "y1_carina_dorm_pov",
        "y1_karina_dorm_return": "y1_carina_dorm_return",
        "y1_mirror_karina_reply": "y1_mirror_carina_reply",
        "y2_karina_decision_choice": "y2_carina_decision_choice",
        "y2_karina_diary_cg": "y2_carina_diary_cg",
        "y2_karina_diary_cg_end": "y2_carina_diary_cg_end",
        "y2_karina_home_pov": "y2_carina_home_pov",
        "y2_karina_home_return": "y2_carina_home_return",
        "y3_karina_outing_choice": "y3_carina_outing_choice",
        "y3_karina_farewell_choice": "y3_carina_farewell_choice"
    }

    def canonical_name(value):
        if not isinstance(value, str):
            return value
        return canonical_re.sub(r"[A-Za-z_][A-Za-z0-9_]*",
            lambda match: LEGACY_CARINA_IDS.get(match.group(), match.group()), value)

    def canonical_data(value):
        # Copy first. Conflicting mixed spellings must never silently lose data.
        if isinstance(value, dict):
            result = {}
            for key, item in value.items():
                name, item = canonical_name(key), canonical_data(item)
                if name in result and result[name] != item:
                    raise ValueError("Conflicting legacy and canonical Carina save keys: %s" % name)
                result[name] = item
            return result
        if isinstance(value, list):
            return [canonical_data(item) for item in value]
        if isinstance(value, tuple):
            return tuple(canonical_data(item) for item in value)
        if isinstance(value, set):
            return {canonical_data(item) for item in value}
        return canonical_name(value)

    def canonical_replay_records(records):
        result = {}
        for sid,rows in (records or {}).items():
            normalized = []
            for row in rows:
                try: row = m33_unpack_record(row)
                except (KeyError, TypeError, ValueError, m33_storage_zlib.error):
                    normalized.append(row)
                    continue
                normalized.append(canonical_data(row))
            result[canonical_name(sid)] = normalized
        for rows in result.values():
            for row in rows:
                if "key" in row and "state" in row:
                    row["key"] = m21_fingerprint(dict(state=row["state"], choices=row["choices"]))
        return result

    def canonical_migrate_persistent(target):
        # No new discoveries: only rewrite IDs already present in actual records.
        for field in ("m21_seen", "m21_completed", "m21_outcomes", "m21_cgs",
                      "m21_endings", "m21_annual_variants", "m21_pending_replay", "m33_scenes"):
            previous = getattr(target, field, None)
            if previous is None:
                continue
            current = m33_pack_library(canonical_replay_records(previous)) if field == "m33_scenes" else canonical_data(previous)
            if current != previous:
                setattr(target, field, current)

    def canonical_after_load():
        # Native call/screen arguments and pending viewer state are saved too.
        fields = ("choice_id", "asset_id", "pov", "heroine", "m21_last_node", "m21_choice_guard", "m21_capture_done",
            "m21_replay_source", "m33_pending", "m33_request", "m33_expected", "m33_forced",
            "y1_portrait", "y2_portrait", "y3_portrait", "y4_portrait", "y2_offscreen", "y3_offscreen", "y4_offscreen",
            "y3_expressions", "y4_expressions", "m4e_start_preset",
            "y3_preview_preset", "y4_preview_preset", "m31n_member", "vc_test_member")
        for field in fields:
            if hasattr(store, field):
                previous = getattr(store, field)
                current = canonical_data(previous)
                if current != previous:
                    setattr(store, field, current)

init 100 python:
    if "persistent" in globals():
        canonical_migrate_persistent(persistent)
        # Ren'Py resolves old saved return addresses through its normal lookup.
        config.label_overrides.update(LEGACY_CARINA_LABELS)

# A legacy M0 manual save can still have this image tag in its saved show list.
image karina neutral = "carina neutral"
