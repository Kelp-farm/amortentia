init -13 python:
    Y2_SCENE_EFFECTS = {
        "Y2-C1-S03": [("world","diary_status","active")],
        "Y2-C2-S04": [("flag","y2_voice_shared",True)],
        "Y2-C2-S06": [("flag","y2_quidditch_snitch_caught",True),("flag","y2_quidditch_caught_carina",True),("flag","y2_quidditch_arm_injured",True)],
        "Y2-C2-S05": [("flag","y2_knows_clothes_free_elf",True)],
        "Y2-C3-S02": [("flag","y2_polyjuice_infiltration",True),("flag","y2_carina_not_heir",True)],
        "Y2-C3-S04": [("flag","y2_read_diary",True)],
        "Y2-C4-S01": [("flag","y2_diary_stolen",True)],
        "Y2-C4-S02": [("flag","y2_hermione_petrified",True)],
        "Y2-C4-S04": [("flag","y2_ginny_missing",True),("flag","y2_basilisk_identified",True)],
        "Y2-C5-S01": [("world","diary_status","destroyed"),("flag","y2_riddle_defeated",True)],
        "Y2-C5-S02": [("flag","y2_ginny_rescued",True),("flag","y2_ginny_missing",False)],
        "Y2-C5-S03": [("world","horcrux_research","identified"),("flag","y2_harry_knows_horcrux",True),("flag","y2_diary_with_harry",True),("flag","y2_diary_with_lucius",False)],
        "Y2-C6-S01": [("flag","y2_hermione_petrified",False),("flag","y2_trio_knows_horcrux",True)],
        "Y2-C6-S04": [("flag","y2_diary_with_harry",False),("flag","y2_diary_returned_dumbledore",True)],
        "Y2-C6-S06": [("flag","y2_carina_family_risk_confirmed",True),("special","carina_death_eater_access","indirect")],
    }
    def y2_begin():
        if not store.vn["chapters"].get("Y1-C4",{}).get("completed") or store.vn["current_chapter"]:
            raise ValueError("Year 2 requires a completed Year 1")
        if any(k.startswith("Y2-") for k in store.vn["chapters"]):
            raise ValueError("Year 2 has already started")
        store.vn = migrate_state(store.vn)
        set_story_flag("y2_campaign")
        store.y1_active_scene = None
        store.y1_portrait = None
        store.y2_active_scene = None
        store.y2_portrait = None

    def y2_enter_scene(sid):
        meta = Y2_SCENES[sid]
        if store.vn["current_chapter"] != meta["chapter"] or store.vn["current_pov"] != meta["pov"]:
            raise ValueError("Year 2 scene chapter/POV mismatch: " + sid)
        store.y2_active_scene = sid
        store.y2_portrait = None
        store.y2_offscreen = []
        store.y2_stage_location = None
        store.y2_stage_background = None
        if sid=="Y2-C6-S06": set_story_flag("m71_harry_letter")
        set_story_flag("seen_" + sid)

    def y2_accept_alliance():
        if m42_main(): raise ValueError("Early coercion belongs to the hidden story")
        if not chose("Y2_CARINA_DECISION","pressure") or store.vn["world"]["diary_status"] != "destroyed" or not store.vn["flags"].get("y2_diary_with_harry"):
            raise ValueError("Alliance requires the post-rescue coercion choice")
        if not remembers("carina","y2_coercion"):
            apply_effects([("relationship","carina","affection",-3)])
            relationship_event("carina","y2_coercion","memory","일기장의 정체와 가족에게 닥칠 보복을 협박 수단으로 썼다.",False)
        set_world("carina_cooperation","pressured")
        set_story_flag("y2_carina_knows_horcrux")
        relationship_event("carina","y2_forced_alliance","memory","가족에게 닥칠 보복을 두려워해 비공개 협력을 받아들였다.",False)

    def y2_finish_scene(sid):
        if store.vn["current_chapter"] != Y2_SCENES[sid]["chapter"]:
            raise ValueError("Cannot finish a scene outside its chapter")
        if store.vn["flags"].get("finished_" + sid):
            return
        if sid == "Y2-C6-S06" and store.vn["world"]["carina_cooperation"] != "pressured":
            return
        effects=Y2_SCENE_EFFECTS.get(sid, [])
        if sid == "Y2-C3-S02" and chose("REVIEW_Y2_INVESTIGATION_METHOD", "feigned_death"):
            # This scene originally contained only Polyjuice. Retain that legacy
            # history when no method choice exists; a played alternative must
            # never record an infiltration the player did not perform.
            effects=[("flag", "y2_polyjuice_infiltration", False) if e[1] == "y2_polyjuice_infiltration" else e for e in effects]
        if m42_main():
            effects=[e for e in effects if e[1] not in ("horcrux_research","y2_harry_knows_horcrux","y2_trio_knows_horcrux")]
        apply_effects(effects + [("flag","finished_"+sid,True)])
        m33_complete(sid)

    def y2_prepare_review(sid, diary="expose", cooperation="leave", prior_choices=None):
        require_key(Y2_SCENES,sid)
        if diary not in ("expose","hide") or cooperation not in ("pressure","leave"):
            raise ValueError("Unknown review preset")
        if sid == "Y2-C6-S06":
            cooperation = "pressure"
        y1_prepare_scene_review("Y1-C4-S14",prior_choices)
        complete_chapter("1학년 검수용 완료 이력; 방학 편지 약속 없음")
        y2_begin()
        set_story_flag("y2_review_preset")
        target = Y2_SCENES[sid]
        for previous, meta in Y2_SCENES.items():
            if store.vn["current_chapter"] != meta["chapter"]:
                if store.vn["current_chapter"]:
                    complete_chapter("장면 선택 이전의 검수용 이야기")
                begin_chapter(meta["chapter"])
            if previous == sid:
                break
            if previous == "Y2-C6-S06" and cooperation != "pressure":
                continue
            for cid in meta["choices"]:
                if not m42_choice_allowed(cid): continue
                if cid == "Y2_LUNA_SUMMER" and store.vn["relationships"]["luna"]["affection"] < 2:
                    continue
                oid = diary if cid == "Y2_DIARY_EXPOSURE" else cooperation if cid == "Y2_CARINA_DECISION" else CHOICES[cid]["options"][0]["id"]
                record_choice(cid,oid)
            if previous == "Y2-C6-S04" and cooperation == "pressure" and not m42_main():
                y2_accept_alliance()
            y2_finish_scene(previous)
        store.y2_review_chapter = target["number"]
        store.y2_review_offset = target["offset"]
        store.vn["review_entry_scene"] = sid

default y2_active_scene = None
default y2_portrait = None
default y2_offscreen = []
default y2_stage_location = None
default y2_stage_background = None
default y2_review_chapter = 1
default y2_review_offset = 0
default y2_preview_diary = "expose"
default y2_preview_cooperation = "leave"

label y2_scene(scene_id):
    $ vc_reset_stage()
    $ y2_enter_scene(scene_id)
    $ m21_visit(scene_id)
    hide screen y2_event_cg
    scene expression Solid("#182733")
    show screen y2_stage(scene_id)
    $ m43_scene_audio(scene_id)
    with Dissolve(0.25)
    return

label y2_cg(asset_id):
    $ m43_cg_audio(asset_id)
    $ m21_unlock_cg("Y2:" + asset_id)
    show screen y2_event_cg(asset_id)
    with Dissolve(0.3)
    return

label y2_cg_end:
    hide screen y2_event_cg
    with Dissolve(0.25)
    return
