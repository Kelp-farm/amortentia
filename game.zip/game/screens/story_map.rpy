style m21_small is text:
    size 20
style m21_button is button:
    padding (12, 8)
style m21_button_text is button_text:
    size 21

screen story_flow(year=1, chapter=1, selected=None, target=None, origin=None):
    tag menu
    modal True
    default framework = origin or m42_chart_origin()
    default zoomed = renpy.variant("small")
    default current_node = selected
    $ highlights=m42_guidance_nodes(target) if target and (m41_hint_level()==2 or m41_known(target)) else {}
    $ graph=m42_graph(year,chapter,framework) if M21_YEARS[year]["implemented"] else None
    add Solid("#101d29")
    frame:
        align (0.5,0.5) xsize 1240 ysize 690 padding (18,14)
        vbox:
            spacing 9
            hbox:
                spacing 14
                text "이야기 흐름도" style "heading"
                textbutton "엔딩 탐색 가이드" action ShowMenu("route_guide",target=target) text_size 21 id "flow_guide"
                textbutton "감상실" action ShowMenu("story_collection") text_size 21 id "flow_collection"
                textbutton ("축소" if zoomed else "지도 확대") action ToggleScreenVariable("zoomed") text_size 20 id "flow_zoom"
                textbutton "돌아가기" action Return() id "flow_back"
            hbox:
                spacing 8
                for y in range(1,8):
                    textbutton ("%d학년"%y):
                        action ShowMenu("story_flow",year=y,target=target,origin=framework)
                        selected year==y selected_background Solid("#416c70")
                        text_size 22 padding (14,7) id "flow_year_%d"%y
                if m33_developer_available():
                    textbutton ("QA "+("켜짐" if m33_qa_enabled() else "꺼짐")) action ToggleVariable("m33_qa") text_size 20 id "m33_qa_toggle"
            if m33_qa_enabled() or persistent.m41_spoilers or "Y1_MALKIN_GUIDE:accept" in persistent.m21_outcomes or m42_hidden():
                hbox:
                    spacing 12
                    textbutton "본편" action ShowMenu("story_flow",year=year,chapter=chapter,origin="main",target=target) selected framework=="main" text_size 19
                    textbutton "또 다른 이야기" action ShowMenu("story_flow",year=year,chapter=chapter,origin="hidden",target=target) selected framework=="hidden" text_size 19
                    text ("7학년은 서로 다른 사건과 결말로 이어집니다." if year==7 else "공통 장면은 두 이야기에서 함께 사용합니다.") size 18 color "#b2c3ca"
            if not graph:
                null height 50
                text "아직 펼쳐지지 않은 이야기" size 30
                text "이 학년은 제작 예정입니다. 진행률에 포함하지 않습니다." size 22
                if year == 7:
                    text Y6_CONTINUATIONS[framework]["title"] size 25 color "#b8dcda"
                    text "6학년의 사건과 관계 기록을 이어받습니다. 최종 엔딩은 아직 열리지 않았습니다." size 21
            else:
                hbox:
                    spacing 6
                    for c in M21_YEARS[year]["chapters"]:
                        textbutton ("%d장"%c):
                            action ShowMenu("story_flow",year=year,chapter=c,origin=framework,target=target)
                            selected chapter==c selected_background Solid("#416c70")
                            text_size 20 padding (10 if year==7 else 14,5) id "flow_chapter_%d"%c
                    text ("  %d학년 안의 장별 지도"%year) size 18 yalign 0.5
                if target and highlights:
                    hbox:
                        spacing 10
                        text "금색 · 목표와 관련된 선택" size 18 color "#e7c97d"
                        for gy in m42_guidance_years(target):
                            $ gids=[c for c in highlights if M41_CHOICE_ORDER[c][0]==gy]
                            $ gn=M21_NODES.get(gids[0]) or M21_NODES[M41_CHOICE_SCENE[gids[0]]]
                            textbutton ("%d학년 갈래"%gy) action ShowMenu("story_flow",year=gy,chapter=int(gn["chapter"].split("-C")[1]),selected=gn["id"],target=target,origin=framework) text_size 18
                else:
                    if year==5 and chapter==5 and y5_chart_source(framework):
                        text "이 장은 아래 순서대로 이어집니다. 출발·예언·전투의 결과를 바꾸는 선택은 없습니다." size 18 color "#a6bac5"
                    elif year==7 and framework=="main" and chapter in (10,11,12):
                        text {10:"오러와 복학은 서로 다른 진행입니다. 9장의 진로 선택으로 갈립니다.",11:"복학한 경우에만 진행합니다. 현재 연인에 맞는 밤을 보낸 뒤 졸업합니다.",12:"현재 관계에 맞는 결말 하나로 이어집니다. 다른 결말을 연이어 재생하지 않습니다."}[chapter] size 18 color "#a6bac5"
                    else:
                        text ("확인·동행·예언·전투 선택의 조합에 따라 경로가 갈립니다. 연결된 모든 장면을 거치지는 않습니다." if year==5 and chapter==5 else "아래로 진행 · 갈라진 선택은 공통 사건에서 다시 만납니다. 조건부 장면은 건너뛸 수 있습니다.") size 18 color "#a6bac5"
                hbox:
                    spacing 14
                    viewport:
                        id "flow_nodes"
                        xsize (1190 if zoomed else 744) ysize 420 mousewheel True draggable True scrollbars "vertical"
                        yinitial m42_graph_y(graph,selected,zoomed)
                        pagekeys True
                        fixed:
                            at Transform(zoom=1.55 if zoomed else 1.0)
                            xsize graph["width"] ysize graph["height"]
                            for edge in graph["edges"]:
                                $ active=edge["cid"] in highlights and highlights.get(edge["cid"])==edge["oid"]
                                add Solid("#dbb85f" if active else "#547585") xpos int(edge["x"]) ypos int(edge["y"]) xsize int(edge["w"]) ysize int(edge["h"])
                            for box in graph["boxes"]:
                                $ nid=box["nid"]
                                $ oid=box["oid"]
                                $ node=M21_NODES[nid]
                                $ known=m42_seen(nid,framework) or m33_qa_enabled()
                                $ found=known and (oid is None or m33_qa_enabled() or nid+":"+oid in persistent.m21_outcomes)
                                $ active=nid in highlights and (oid is None or highlights[nid]==oid)
                                button:
                                    xpos int(box["x"]) ypos box["y"] xsize box["w"] ysize box["h"] padding (12,8)
                                    background Solid("#645535" if active else "#355c65" if current_node==nid else "#243744" if found else "#182732")
                                    action (ShowMenu("m42_branch_select",cid=nid,oid=oid,year=year,chapter=chapter,origin=framework,target=target) if oid and found else Function(mrv_node_click,nid,year,chapter,framework,target))
                                    id ("branch_"+nid+"_"+oid if oid else "node_"+nid)
                                    if oid:
                                        $ opt=next(o for o in CHOICES[nid]["options"] if o["id"]==oid)
                                        vbox:
                                            spacing 5
                                            text (box.get("title") or m42_choice_text(nid,opt,{"world":{"story_origin":framework}}) if found or active and m41_hint_level()==2 else "???") size 18 xsize box["w"]-24 substitute False
                                            if found:
                                                text "선택 변경 →" size 15 color "#bad6d1"
                                    else:
                                        hbox:
                                            spacing 10
                                            $ thumb=m42_thumbnail(nid,framework) if known and node["type"]=="scene" and box["w"]>=300 else None
                                            if thumb:
                                                add thumb xysize (88,50) fit "cover"
                                            vbox:
                                                text (m42_node_title(nid,framework) if known else "???") size 20 xsize box["w"]-(124 if thumb else 24)
                                                text ((m42_node_status(nid,framework) if known else "미발견")+(" · 조건부" if known and node.get("optional") else "")) size 15 xsize box["w"]-(124 if thumb else 24) color "#b3cbd0"
                    if not zoomed:
                        frame:
                            xsize 440 ysize 420 padding (18,14)
                            viewport:
                                mousewheel True draggable True scrollbars "vertical"
                                vbox:
                                    spacing 12
                                    if current_node not in M21_NODES:
                                        text "장면이나 선택을 골라 주세요" size 25
                                        text "장면을 더블클릭하면 그 지점부터 이어집니다." size 21 xmaximum 385
                                        text "감상은 현재 진행을 바꾸지 않습니다." style "muted" xmaximum 385
                                        if year == 6 and chapter == 8:
                                            textbutton Y6_CONTINUATIONS[framework]["title"] action ShowMenu("story_flow",year=7,origin=framework) text_size 22 id "y6_continuation"
                                        if year>1:
                                            text "앞선 학년의 관계와 사건이 이어집니다." size 20
                                            textbutton "이전 학년 보기" action ShowMenu("story_flow",year=year-1,origin=framework,target=target) text_size 20
                                    elif not m42_seen(current_node,framework) and not m33_qa_enabled():
                                        text "???" size 28
                                        text "아직 발견하지 않은 기록입니다." size 21
                                        if current_node in highlights:
                                            text "목표와 관련된 갈래입니다. 표시 자체가 재개 가능한 저장을 뜻하지는 않습니다." size 20 xmaximum 385
                                    else:
                                        $ detail=M21_NODES[current_node]
                                        text m42_node_title(current_node,framework) size 26 xmaximum 385
                                        text m21_status(current_node) size 20 color "#b8dcda"
                                        if m33_implemented(detail["scene"]):
                                            if m33_developer_available():
                                                textbutton "이 장면부터 연속 검수" action Function(mrv_open,detail["scene"],framework) id "mrv_detail"
                                            textbutton "장면 감상 · 이어하기" action ShowMenu("m33_scene_detail",nid=current_node,origin=framework) id "m33_detail"
                                        if detail["type"]=="choice":
                                            $ checkpoints=m21_checkpoints(current_node)
                                            if checkpoints:
                                                text "선택 직전부터 다시 진행" size 22
                                                for slot,data in checkpoints:
                                                    textbutton (data["m21_date"]+" · "+data["m21_origin"]):
                                                        action Confirm("선택 직전의 진행을 불러올까요?\n저장하지 않은 현재 진행은 사라집니다.\n수동 저장과 감상 기록은 유지됩니다.",Function(m21_replay,slot,current_node))
                                                        xmaximum 385 text_size 20 id "replay_"+slot
                                            else:
                                                text "체크포인트 없음" size 23
                                                text "더 이른 수동 저장이나 새 진행에서 다시 도달해야 합니다." size 20 xmaximum 385
                                        for key,cg in M21_CGS.items():
                                            if cg["scene"]==detail["scene"] and key in persistent.m21_cgs:
                                                textbutton ("CG · "+cg["title"]) action ShowMenu("story_cg",key=key) text_size 20

screen m42_branch_select(cid,oid,year,chapter,origin,target=None):
    tag menu
    modal True
    default candidates=m42_branch_checkpoints(cid,oid)
    add Solid("#101d29")
    frame:
        align (0.5,0.5) xsize 950 padding (32,26)
        vbox:
            spacing 16
            text "이 선택으로 바꿔서 계속" style "heading"
            $ opt=next(o for o in CHOICES[cid]["options"] if o["id"]==oid)
            text m42_choice_text(cid,opt,{"world":{"story_origin":origin}}) size 27 xmaximum 880 substitute False
            text "선택 직전의 이력을 불러와 이 선택을 바로 적용합니다. 그 뒤의 사건은 다시 진행합니다. 수동 저장과 감상 기록은 유지됩니다." size 22 xmaximum 880
            if candidates:
                text "이어갈 이력" size 23
                for slot,meta in candidates:
                    textbutton (meta["m21_date"]+" · "+meta["m21_origin"]+" · 이전 선택 %d개"%meta["m21_history"]):
                        action Confirm("이 선택으로 이어갈까요?\n저장하지 않은 현재 진행은 사라집니다.",Function(m42_switch_branch,slot,cid,oid))
                        id "switch_"+slot text_size 23
            else:
                text "이 선택을 적용할 수 있는 체크포인트가 없습니다." size 24 color "#dfb8a7"
                text "이전 저장이 없거나 당시 조건이 맞지 않습니다. 감상만으로 새 진행 이력을 만들지는 않습니다." size 21 xmaximum 880
            textbutton "흐름도로 돌아가기" action ShowMenu("story_flow",year=year,chapter=chapter,selected=cid,origin=origin,target=target) id "branch_back"


screen story_collection(tab="cg"):
    tag menu
    modal True
    add Solid("#101d29")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1210
        ysize 680
        padding (22,18)
        vbox:
            spacing 14
            hbox:
                spacing 16
                text "감상실" style "heading"
                textbutton "이야기 흐름도" action ShowMenu("story_flow") style "m21_button" id "collection_flow"
                textbutton "돌아가기" action Return() style "m21_button" id "collection_back"
            hbox:
                spacing 14
                textbutton "CG" action ShowMenu("story_collection", tab="cg") selected tab == "cg" style "m21_button" id "collection_cg"
                textbutton "완료 · 엔딩" action ShowMenu("story_collection", tab="ending") selected tab == "ending" style "m21_button" id "collection_ending"
            if tab == "cg":
                $ gallery_cgs = {key: meta for key, meta in M21_CGS.items() if not meta.get("legacy") or key in persistent.m21_cgs}
                text ("감상한 CG %d / %d · 현재 일러스트는 검수 중입니다." % (len(set(persistent.m21_cgs) & set(gallery_cgs)), len(gallery_cgs))) style "muted"
                viewport:
                    ysize 500
                    mousewheel True
                    draggable True
                    scrollbars "vertical"
                    vpgrid:
                        cols 3
                        spacing 12
                        for key, meta in gallery_cgs.items():
                            $ unlocked = key in persistent.m21_cgs and renpy.loadable(m21_cg_path(key))
                            button:
                                xsize 370
                                ysize 245
                                padding (10,10)
                                action ShowMenu("story_cg", key=key)
                                sensitive unlocked
                                id "cg_" + key.replace(":", "_")
                                vbox:
                                    spacing 6
                                    if unlocked:
                                        add m21_cg_path(key) xysize (350,197)
                                    else:
                                        fixed:
                                            xysize (350,197)
                                            add Solid("#1e2c3b")
                                            text "???" align (0.5,0.5) size 30 color "#81909f"
                                    text (meta["title"] if unlocked else "미감상") size 19
            else:
                text "학년 완료와 연애 엔딩을 따로 모읍니다. 제작 예정인 엔딩은 진행률에서 제외합니다." style "muted"
                viewport:
                    ysize 500
                    mousewheel True
                    draggable True
                    scrollbars "vertical"
                    vbox:
                        spacing 14
                        text ("학년 완료 %d / 7 · 최종 결말 %d / 6" % (len(set(persistent.m21_endings) & {"annual_y%d"%n for n in range(1,8)}),len(set(persistent.m21_endings) & {"route_"+k for k in Y7_ENDINGS}))) size 26 color "#b8dcda"
                        for key, ending in sorted(((k,e) for k,e in M21_ENDINGS.items() if e["implemented"]),key=lambda pair:pair[1]["year"]):
                            frame:
                                xsize 1130
                                padding (18,12)
                                vbox:
                                    spacing 6
                                    if ending["implemented"]:
                                        text (ending["title"] if key in persistent.m21_endings else "%d학년 · 미완료" % ending["year"]) size 24
                                        text ("학년 완료 기록 · 연애 엔딩이 아닙니다." if key in persistent.m21_endings else "이 학년의 마지막까지 읽으면 기록됩니다.") style "muted"
                                        if key == "annual_y2" and key in persistent.m21_endings:
                                            for variant in sorted(v for v in persistent.m21_annual_variants if not v.startswith(("Y3:","M32:","Y4:","Y5:","Y6:"))):
                                                text (("도비 해방" if variant.startswith("free_harry:") else "도비 예속") + " · " + ("비공개 협력" if variant.endswith(":pressured") else "협력 없음")) style "m21_small"
                                        if key == "annual_y6" and key in persistent.m21_endings:
                                            for origin,entry in Y6_CONTINUATIONS.items():
                                                if "Y6:"+entry["destination"] in persistent.m21_annual_variants:
                                                    text entry["title"] style "m21_small"
                                        if key == "annual_y3" and key in persistent.m21_endings:
                                            for variant in sorted(v for v in persistent.m21_annual_variants if v.startswith("Y3:")):
                                                text (("헤르미온느와 구출" if ":hermione:" in variant else "카리나와 구출") + " · " + ("페티그루 체포" if variant.endswith(":captured") else "페티그루 도주")) style "m21_small"
                                            for variant in sorted(v for v in persistent.m21_annual_variants if v.startswith("M32:")):
                                                $ parts = variant.split(":")
                                                text ({"rivalry":"라이벌", "close":"가까운 사이", "hurt":"남아 있는 다툼", "reconciled":"화해", "estranged":"결별"}[parts[1]] + " · " + ("카리나 동행" if parts[2] == "carina" else "헤르미온느 동행") + " · " + {"none":"교제하지 않음","private":"비밀 연애","public":"공개 연애"}[parts[3]]) style "m21_small"
                                    else:
                                        text (ending["title"] + " · 연애 엔딩 제작 예정" if ending["route"] != "no_romance" else "연애 없이 · 엔딩 제작 예정") size 23
                                        text "아직 구현되지 않았습니다." style "muted"
                        use m42_ending_categories

screen m42_ending_categories():
    frame:
        xsize 1130 padding (18,12)
        vbox:
            spacing 8
            text "7학년 최종 엔딩" size 25 color "#b8dcda"
            text "본편 · 카리나, 헤르미온느, 지니, 루나, 연애 없이" size 22
            text "히든 · 카리나" size 22
            text "아래의 중간 결과는 여러 개를 함께 경험할 수 있습니다. 공개·비밀 교제와 진로 차이가 모두 별도의 최종 엔딩으로 세어지는 것은 아닙니다." style "muted"
            textbutton "최종 엔딩 가이드" action ShowMenu("route_guide") text_size 20 id "collection_final_guide"
    for category,title,targets in (
        ("alternate","중간 결과 · 학교생활과 사건",tuple(t for t in m41_guide_targets("events") if t not in ("carina_rescue","carina_private","carina_public","world_fanfic","y5_carina"))),
        ("hidden","중간 결과 · 카리나의 다른 이야기",("carina_rescue","carina_private","carina_public","world_fanfic","y5_carina"))):
        frame:
            xsize 1130 padding (18,12)
            vbox:
                spacing 8
                text title size 25 color "#b8dcda"
                text ("감상한 결과 %d / %d"%(sum(m41_known(t) for t in targets),len(targets))) size 21
                for tid in targets:
                    hbox:
                        spacing 12
                        text (M41_TARGETS[tid]["title"]+" · 감상 완료" if m41_known(tid) else "미발견 중간 결과") size 21 yalign 0.5
                        textbutton "목표 경로 확인" action ShowMenu("route_guide",target=tid) text_size 19 id "collection_target_"+tid
    frame:
        xsize 1130 padding (18,12)
        vbox:
            spacing 8
            text "중도 종료" size 25 color "#b8dcda"
            text "현재 구현된 중도 종료 엔딩은 없습니다. 인물의 생사 등 진행이 계속되는 결과는 위 항목에 따로 기록합니다." style "muted"

screen story_cg(key):
    tag menu
    modal True
    add Solid("#101d29")
    if key in M21_CGS and key in persistent.m21_cgs and renpy.loadable(m21_cg_path(key)):
        add m21_cg_path(key) xysize (1280,720) fit "contain"
    else:
        text "아직 감상하지 않은 CG입니다." align (0.5,0.5)
    textbutton "감상실로" xpos 20 ypos 20 action ShowMenu("story_collection") id "cg_back"
    key "game_menu" action ShowMenu("story_collection")
