init -5 python:
    AFFECTION_HEROINES = (
        ("carina", "카리나 말포이", "#a9cfc1"),
        ("hermione", "헤르미온느 그레인저", "#dfbb96"),
        ("ginny", "지니 위즐리", "#dca9aa"),
        ("luna", "루나 러브굿", "#b5c7e5"),
    )
    AFFECTION_INTRO_SCENES = {
        "carina": "Y1-C1-S03", "hermione": "Y1-C1-S06",
        "ginny": "Y1-C1-S05", "luna": "Y2-C1-S05",
    }

    def affection_name_known(heroine):
        # Introduction flags belong to this playthrough/replay, never persistent.
        if store.vn["flags"].get("name_known_" + heroine):
            return True
        # Old saves and review presets predate these flags. All introductions
        # are mandatory, so later scenes safely establish earlier names.
        chapter = store.vn.get("current_chapter") or ""
        intro = AFFECTION_INTRO_SCENES[heroine]
        if chapter.startswith("Y") and chapter > intro[:5]:
            return True
        if chapter == intro[:5]:
            sid = getattr(store, "y%s_active_scene" % chapter[1], None)
            if sid and sid > intro:
                return True
            if sid == intro:
                # An old save made just after the introduction can still use
                # the already-rendered real speaker name in its local history.
                name = {"carina": "카리나", "hermione": "헤르미온느",
                        "ginny": "지니", "luna": "루나"}[heroine]
                return any(entry.who == name for entry in store._history_list)
        return False

    def affection_short_name(heroine):
        if not affection_name_known(heroine): return "???"
        return dict((h,n.split()[0]) for h,n,c in AFFECTION_HEROINES)[heroine]

    def affection_history_title(entry):
        sid = entry.get("scene")
        node = M21_NODES.get(sid, {})
        chapter = CHAPTERS.get(entry["chapter"], {})
        return "%s · %s" % ("%d학년" % chapter["year"] if chapter.get("year") else "이야기",
            node.get("title") or chapter.get("title") or "관계 변화")

    def affection_notify_latest():
        history = store.vn.get("affection_history", [])
        if not history or not history[-1]["changes"]:
            renpy.hide_screen("notify")
            return
        lines = [affection_short_name(h) + " · " + affection_change_text(change["delta"])
            for h,change in history[-1]["changes"].items() if change["delta"]]
        if not lines:
            renpy.hide_screen("notify")
            return
        renpy.notify("\n".join(lines))

# Show the relationship and its history; keep mechanics explanations in the docs.
screen affection():
    tag menu
    modal True
    zorder 220
    predict False
    default panel = "values"
    add Solid("#101d29")
    frame:
        align (0.5, 0.5)
        xsize 1120
        ysize 690
        padding (32, 26)
        vbox:
            spacing 12
            hbox:
                xfill True
                text "관계" style "heading" yalign 0.5
                textbutton "지금의 관계" action SetScreenVariable("panel","values") selected panel == "values" text_size 21 id "affection_values_tab"
                textbutton "변화 기록" action SetScreenVariable("panel","history") selected panel == "history" text_size 21 id "affection_history_tab"
                if vn["flags"].get("y5_cho_conversation"):
                    textbutton "초와의 기억" action SetScreenVariable("panel","cho") selected panel == "cho" text_size 21 id "affection_cho_tab"
                textbutton "돌아가기" action Return() xalign 1.0 id "affection_return"
            if m33_active():
                text "감상 중인 장면에서의 관계" style "muted"
            if panel == "values":
                grid 2 2:
                    spacing 18
                    for heroine, name, accent in AFFECTION_HEROINES:
                        $ known = affection_name_known(heroine)
                        frame:
                            xsize 518
                            ysize 238
                            background Solid("#223340")
                            padding (24, 20)
                            vbox:
                                spacing 6
                                text (name if known else "???"):
                                    size 27
                                    color (accent if known else "#a9b6c4")
                                    id "affection_name_" + heroine
                                if known:
                                    $ context=m42_relationship(heroine)
                                    text context["label"] size 27 color "#f1ece2" id "affection_status_" + heroine
                                    text context["description"] size 20 xmaximum 466 id "affection_description_" + heroine
                                    if context["memory"]:
                                        text ("기억 · "+context["memory"]) size 18 color "#a9b6c4" xmaximum 466
                                else:
                                    text "아직 이름을 모릅니다." style "muted"
            elif panel == "cho":
                $ cho_view = cho_relationship_view()
                text "초 챙" size 27 color "#b5c7e5"
                text cho_view["label"] size 27
                text cho_view["description"] size 23
                viewport:
                    ysize 365 mousewheel True draggable True scrollbars "vertical"
                    vbox:
                        spacing 16
                        for entry in vn["choices"]:
                            if entry["choice_id"].startswith("Y5_CHO_"):
                                text entry["option_text"] size 22 substitute False
            else:
                $ changed_entries = [entry for entry in vn.get("affection_history", []) if entry["changes"]]
                viewport:
                    id "affection_history_viewport"
                    ysize 428
                    mousewheel True
                    draggable True
                    pagekeys True
                    scrollbars "vertical"
                    vbox:
                        spacing 14
                        if not changed_entries:
                            text "아직 관계 변화 기록이 없습니다." size 25
                        for entry in reversed(changed_entries):
                            frame:
                                xsize 1030
                                background Solid("#223340")
                                padding (20,16)
                                vbox:
                                    spacing 8
                                    text affection_history_title(entry) size 19 color "#a9b6c4" substitute False
                                    text entry["text"] size 23 xmaximum 970 substitute False
                                    for heroine,change in entry["changes"].items():
                                        text (affection_short_name(heroine)+" · "+affection_change_text(change["delta"])):
                                            size 23
                                            color ("#b8dcda" if change["delta"] > 0 else "#e3b1aa")
            text "R 키로 열고 닫기 · Esc로 돌아가기" size 18 color "#8e9eac"
    key "game_menu" action Return()
    key "K_r" action Return()

screen notify(message):
    zorder 160
    if not main_menu:
        frame:
            xalign 1.0
            # Keep relationship feedback below the skip control.
            ypos (122 if renpy.get_screen("say") and not renpy.context()._menu else 66)
            xoffset -22
            padding (22,14)
            background Solid("#162a36ed")
            text message size 23 color "#deece5" substitute False
    timer 4.5 action Hide("notify")
