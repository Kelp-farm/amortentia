screen mpr_requirements(state,full=False,width=1000):
    vbox:
        spacing 7
        for requirement in mpr_condition_rows(state,full):
            $ status_color="#bad6d1" if requirement["status"]=="충족됨" else "#e4ac9c" if requirement["status"]=="충족 실패" else "#c5c9cd"
            text (requirement["title"]+"  ·  {color="+status_color+"}"+requirement["status"]+"{/color}") size 19 xmaximum width

screen mpr_conditions(state=None,sid=None):
    zorder 210
    modal True
    key "game_menu" action Hide("mpr_conditions")
    default source=state_copy(state if state is not None else vn)
    add Solid("#101d29")
    frame:
        align (0.5,0.5) xsize 1140 ysize 660 padding (28,22)
        vbox:
            spacing 14
            text "카리나 히든루트 조건" style "heading"
            text ("초기 히든 진입 조건 충족" if carina_hidden_committed(source) else "현재 이력의 조건") size 23
            viewport:
                ysize 440 mousewheel True draggable True scrollbars "vertical"
                vbox:
                    spacing 14
                    use mpr_requirements(source,full=True,width=1030)
                    if sid and mpr_scene_reason(sid,source):
                        text mpr_scene_reason(sid,source) size 21 color "#e4c398" xmaximum 1020
                    text "공개·비밀 교제 모두 진입할 수 있습니다. 호감도만으로 위 선택을 대신하지 않습니다." size 20 xmaximum 1020
            textbutton "돌아가기" action Hide("mpr_conditions") id "mpr_conditions_back"

screen mpr_choices(state=None,choice=None):
    tag menu
    modal True
    default source=state_copy(state if state is not None else vn)
    default rows=mpr_choice_rows(source)
    default selected=choice if choice in [r["choice_id"] for r in rows] else (rows[0]["choice_id"] if rows else None)
    default answer=None
    default available={}
    $ current=next((r for r in rows if r["choice_id"]==selected),None)
    $ effective=answer if current and answer in [o["id"] for o in CHOICES[selected]["options"]] else (current["option_id"] if current else None)
    if current and selected not in available:
        $ available[selected]={o["id"]:mpr_can_change(selected,o["id"],source) for o in CHOICES[selected]["options"]}
    add Solid("#101d29")
    frame:
        align (0.5,0.5) xsize 1200 ysize 680 padding (26,20)
        vbox:
            spacing 14
            hbox:
                spacing 24
                text "선택 변경" style "heading"
                if m33_developer_available():
                    textbutton "루트 조건" action Show("mpr_conditions",state=source) text_size 21 id "mpr_conditions_button"
            hbox:
                spacing 20
                viewport:
                    xsize 395 ysize 440 mousewheel True draggable True scrollbars "vertical"
                    vbox:
                        spacing 9
                        for row in rows:
                            textbutton (mrv_choice_title(row["choice_id"])+"\n"+row["option_text"]):
                                action [SetScreenVariable("selected",row["choice_id"]),SetScreenVariable("answer",None)]
                                selected selected==row["choice_id"] selected_background Solid("#416c70")
                                xfill True text_size 18 id "mpr_choice_"+row["choice_id"]
                frame:
                    xsize 725 ysize 440 padding (18,14)
                    viewport:
                        mousewheel True draggable True scrollbars "vertical"
                        vbox:
                            spacing 14
                            if current:
                                text mrv_choice_title(selected) size 25
                                text ("현재 선택 · "+current["option_text"]) size 21 xmaximum 660
                                for option in CHOICES[selected]["options"]:
                                    textbutton m42_choice_text(selected,option,source):
                                        action SetScreenVariable("answer",option["id"])
                                        selected effective==option["id"] selected_background Solid("#416c70")
                                        text_size 22 xfill True id "mpr_option_"+option["id"]
                                if not available[selected].get(effective):
                                    text "이 응답으로 돌아갈 수 있는 이전 진행 기록이 없습니다." size 21 color "#e4c398" xmaximum 660
                                text "바뀐 선택 뒤의 사건은 다시 진행합니다. 현재 진행은 전환 전에 자동 보관합니다." size 21 xmaximum 660
                            else:
                                text "아직 선택한 이력이 없습니다." size 25
                            if m33_developer_available() and mpr_current_scene():
                                textbutton "검수용 이전 선택 조정":
                                    action ShowMenu("mrv_scene_setup",sid=mpr_current_scene(),origin=m42_chart_origin())
                                    text_size 22 id "mpr_review_adjust"
                                text "검수용으로 만든 과거는 여기서 조정할 수 있습니다." size 19 color "#b5c9cb" xmaximum 660
            hbox:
                spacing 24
                textbutton "이 선택으로 변경":
                    action Function(mpr_switch,selected,effective,source)
                    sensitive bool(current and effective!=current["option_id"] and available[selected].get(effective))
                    id "mpr_apply"
                if renpy.can_load("scene-continue-backup"):
                    textbutton "변경 전 진행 불러오기" action Function(renpy.load,"scene-continue-backup") text_size 21 id "mpr_restore"
                textbutton "돌아가기" action Return() id "mpr_back"
