screen y3_timeline_changed():
    modal True
    key "game_menu" action NullAction()
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 980 padding (36,30)
        vbox:
            spacing 22
            text "이 장의 이야기 흐름이 바뀌었습니다" size 31
            text "호그스미드 방문 순서, 겨울 빗자루 선물, 3학년 조사·화해·구출·고백 분기가 수정되었습니다. 수정 전 장면의 중간 저장은 이 지점에서 바로 이어갈 수 없습니다." size 24
            text "원래 저장 파일과 감상 기록은 그대로 남습니다. 직접 고른 선택을 이어가려면 이전 장의 저장을 불러오세요. 새 대본은 장면 선택으로 바로 확인할 수 있습니다." size 23
            hbox:
                spacing 24
                textbutton "다른 저장 불러오기" action ShowMenu("load")
                textbutton "장면 선택으로" action ShowMenu("y3_scene_select",chapter=4 if vn.get("current_chapter") in ("Y3-C4","Y3-C5","Y3-C6") else 2)
                textbutton "처음 화면으로" action MainMenu(confirm=False)

screen y3_stage(scene_id):
    zorder -5
    $ meta=Y3_SCENES[scene_id]
    $ bg=vc_background(vc_background_key) if vc_background_key else (y3_background_override or Y3_BACKGROUNDS[scene_id])
    if bg:
        add bg xysize (1280,720)
    else:
        add Solid("#182733")
        text "배경 일러스트 준비 중" xpos 30 ypos 460 size 16 color "#9aadb7" slow_cps 0
    if not vc_hide_standing and y3_portrait in Y3_SPRITES and y3_portrait not in y3_offscreen:
        add y3_sprite(y3_portrait,scene_id) id "y3_speaker_portrait" xpos 0.58 xanchor 0.5
    if y3_train_shade:
        add Solid("#050a12") alpha y3_train_shade
    frame:
        xpos 22 ypos 54 padding (12,7) background Solid("#111e29c9")
        hbox:
            spacing 18
            text (vc_location or meta["location"]) size 22 slow_cps 0
            text meta["time"] size 16 color "#b5c2ca" yalign 0.5 slow_cps 0

screen y3_event_cg(asset_id):
    $ asset_id = canonical_name(asset_id)
    zorder -4
    add Y3_CGS[asset_id] xysize (1280,720) fit "cover"

screen y3_scene_select(chapter=1):
    tag menu
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1180 ysize 680 padding (24,18)
        vbox:
            spacing 9
            text "3학년 · 챕터와 장면" style "heading"
            hbox:
                spacing 10
                for n in range(1,7):
                    textbutton ("%d장"%n) action ShowMenu("y3_scene_select",chapter=n) selected chapter==n id "y3_tab_%d"%n
            text Y3_TITLES[chapter-1] size 25
            viewport:
                ysize 280 mousewheel True draggable True scrollbars "vertical"
                vbox:
                    spacing 5
                    for sid,meta in Y3_SCENES.items():
                        if meta["number"]==chapter:
                            $ action=Start("review_"+meta["label"])
                            textbutton (meta["title"] + (" · 조건부" if meta["optional"] else "")):
                                xfill True text_size 22 padding (14,7) id "scene_"+sid
                                action ShowMenu("m4e_review_detail",sid=sid)
            text "장면을 고르면 필요한 분기만 표시됩니다. 공통 장면은 별도 설정 없이 시작합니다." size 18 color "#b8dcda"
            hbox:
                spacing 12
                textbutton "불러오기" action ShowMenu("load")
                textbutton "학년 선택" action ShowMenu("review_year_select") id "y3_review_years"
                textbutton "돌아가기" action Return() id "y3_review_back"

screen y3_ending():
    modal True
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1060
        vbox:
            spacing 18
            text "3학년 · 끝" style "heading"
            text ("시리우스는 결백을 인정받았습니다." if vn["world"]["sirius_legal"]=="cleared" else "시리우스는 살아서 떠났습니다. 수배는 아직 풀리지 않았습니다.") size 25
            text ("페티그루는 붙잡혔습니다. 그의 자리를 전제로 했던 이후 사건도 달라져야 합니다." if vn["world"]["pettigrew_status"]=="captured" else "페티그루는 도망쳤습니다. 이후 행방은 아직 알 수 없습니다.") size 22
            text ("%s와 %s 시간을 되돌렸습니다." % ("카리나" if vn["world"]["y3_rescue_companion"]=="carina" else "헤르미온느", "네" if y3_finale_turns()==4 else "세")) size 23
            if y3_flag("y3_ring_confession"):
                text ("카리나와 사귀기로 했습니다. 친구들도 두 사람의 관계를 압니다." if vn["romance"]["carina"]["visibility"] == "public" else "카리나와 서로 마음을 전하고 비밀리에 만나기로 했습니다.") size 23
            elif vn["world"]["carina_early_romance_blocked"]:
                text "카리나와의 다툼은 풀지 못했습니다. 두 사람의 거리는 남아 있습니다." size 23
            elif y3_carina_reconciled():
                text "카리나와 화해했습니다. 아직 사귀는 사이는 아닙니다." size 23
            text "이 기록은 학년 완료입니다. 최종 연애 엔딩은 확정되지 않았습니다. 4학년에서 이 선택들을 이어갑니다." style "muted"
            hbox:
                spacing 12
                textbutton "이야기 흐름도" action ShowMenu("story_flow",year=3,chapter=6)
                textbutton "감상실" action ShowMenu("story_collection",tab="ending")
            textbutton "4학년으로" action Return("year4") id "continue_year4"
            textbutton "완료 기록 저장" action ShowMenu("save")
            textbutton "처음 화면으로" action Return() id "y3_finish"
