screen y4_stage(scene_id, close=False):
    zorder -5
    $ meta=Y4_SCENES[scene_id]
    add (vc_background(vc_background_key) if vc_background_key else y4_background(scene_id)) xysize (1280,720)
    if not vc_hide_standing and y4_portrait in Y4_SPRITES and y4_portrait not in y4_offscreen:
        if close and y4_portrait == "carina":
            add Transform(y3_sprite_path("carina", scene_id), crop=(0,0,1024,1536), zoom=0.98, ypos=25) id "y4_speaker_portrait" xpos 0.58 xanchor 0.5
        else:
            add y4_sprite(y4_portrait,scene_id) id "y4_speaker_portrait" xpos 0.58 xanchor 0.5
    frame:
        xpos 22 ypos 54 padding (12,7) background Solid("#111e29c9")
        hbox:
            spacing 18
            text (vc_location or y4_location_override or meta["location"]) size 22 slow_cps 0
            text meta["time"] size 16 color "#b5c2ca" yalign 0.5 slow_cps 0

screen y4_event_cg(asset_id):
    $ asset_id = canonical_name(asset_id)
    zorder -4
    add Y4_CGS[asset_id] xysize (1280,720) fit "cover"

screen y4_scene_select(chapter=1):
    tag menu
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1180 ysize 680 padding (24,18)
        vbox:
            spacing 8
            text "4학년 · 챕터와 장면" style "heading"
            hbox:
                spacing 8
                for n in range(1,9):
                    textbutton ("%d장"%n) action ShowMenu("y4_scene_select",chapter=n) selected chapter==n id "y4_tab_%d"%n
            text Y4_TITLES[chapter-1] size 24
            viewport:
                ysize 245 mousewheel True draggable True scrollbars "vertical"
                vbox:
                    spacing 4
                    for sid,meta in Y4_SCENES.items():
                        if meta["number"]==chapter:
                            $ action=Start("review_"+meta["label"])
                            textbutton (meta["title"]+(" · 조건부" if meta["optional"] else "")):
                                xfill True text_size 22 padding (12,6) id "scene_"+sid
                                action ShowMenu("m4e_review_detail",sid=sid)
            text "장면을 고르면 필요한 분기만 표시됩니다. 공통 장면은 별도 설정 없이 시작합니다." size 18 color "#b8dcda"
            hbox:
                spacing 12
                textbutton "불러오기" action ShowMenu("load")
                textbutton "학년 선택" action ShowMenu("review_year_select")
                textbutton "돌아가기" action Return() id "y4_review_back"

screen y4_ending():
    modal True
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1060 padding (30,24)
        vbox:
            spacing 16
            text "4학년 · 끝" style "heading"
            text ("해리는 묘지에서 볼드모트의 귀환을 목격했습니다." if vn["world"]["y4_resurrection"]=="graveyard" else "시합 뒤의 조사를 통해 은밀히 이루어진 귀환을 알게 되었습니다.") size 24
            text ("세드릭은 살아 돌아왔습니다." if vn["world"]["y4_cedric"]=="alive" else "세드릭은 돌아오지 못했습니다.") size 24
            if m732_altered():
                text "카리나의 연애 기억을 바꿨습니다. 해리는 함께했던 일을 기억합니다." size 23
            elif vn["world"]["y4_carina_separation"]=="war_pressure":
                text "카리나와 헤어졌지만 함께 쌓은 마음과 기억은 남아 있습니다." size 23
            text "마법부는 귀환을 인정하지 않습니다." size 23
            hbox:
                spacing 12
                textbutton "흐름도" action ShowMenu("story_flow",year=4,chapter=8)
                textbutton "감상실" action ShowMenu("story_collection",tab="ending")
            textbutton "5학년으로" action Return("year5") id "year5_continue"
            textbutton "완료 기록 저장" action ShowMenu("save")
            textbutton "처음 화면으로" action Return() id "y4_finish"
