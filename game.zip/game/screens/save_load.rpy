screen save():
    tag menu
    use file_slots(y1_ui("저장", "Save"))

screen load():
    tag menu
    use file_slots(y1_ui("불러오기", "Load"))

screen file_slots(title):
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1140
        vbox:
            spacing 18
            text title style "heading"
            hbox:
                spacing 20
                text (y1_ui("페이지 ", "Page ") + FilePageName()) style "muted"
                textbutton "흐름도" action ShowMenu("story_flow") style "m21_button"
                textbutton "감상실" action ShowMenu("story_collection") style "m21_button"
            if m21_replay_source:
                text ("재감상 중 · " + m21_replay_source["date"]) size 17 color "#b8dcda"
            grid 3 2:
                spacing 16
                for slot in range(1, 7):
                    button:
                        id ("slot_%d" % slot)
                        xsize 344
                        ysize 175
                        action FileAction(slot)
                        vbox:
                            spacing 7
                            add FileScreenshot(slot) xysize (192, 108)
                            text FileTime(slot, format="%Y-%m-%d %H:%M", empty=y1_ui("비어 있음", "Empty slot")) size 18
            hbox:
                spacing 14
                textbutton y1_ui("이전 페이지", "Previous page") action FilePagePrevious()
                textbutton y1_ui("다음 페이지", "Next page") action FilePageNext()
                textbutton y1_ui("돌아가기", "Return") action Return()
                textbutton y1_ui("처음 화면", "Main menu") action MainMenu()

