screen route_evaluation():
    modal True
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1140
        vbox:
            spacing 18
            text "Route evaluation | M0 demonstration" style "heading"
            text "Temporary requirements. Select an available path to confirm it." style "muted"
            $ evaluations = evaluate_routes()
            for route in ROUTE_NAMES:
                hbox:
                    spacing 20
                    textbutton ROUTE_NAMES[route]:
                        id ("route_" + route)
                        xsize 320
                        sensitive evaluations[route]["eligible"]
                        action Return(route)
                    vbox:
                        xsize 690
                        if evaluations[route]["eligible"]:
                            text "Available" color "#b8dcda" size 22
                        else:
                            text "Requirements have not been met." size 22
                        if route == "no_romance":
                            text "A complete path in its own right." style "muted"
            text "No route is selected automatically by affection." style "muted"

screen personality_result():
    modal True
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1140
        ysize 650
        vbox:
            spacing 14
            text "Harry | Decisions reflected" style "heading"
            text "A short record of this playthrough, not a psychological diagnosis." style "muted"
            if vn["debug_modified"]:
                text "Developer edits are present; this is a test result." color "#efc895" size 19
            viewport:
                ysize 440
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 18
                    for row in personality_summary():
                        vbox:
                            spacing 5
                            text (row["endpoints"][0] + " / " + row["endpoints"][1]) color "#b8dcda" size 22
                            text row["text"] size 22
                            text ("Recorded decisions: %d" % row["evidence"]) style "muted"
            textbutton "Finish summary" action Return() id "finish_summary"
