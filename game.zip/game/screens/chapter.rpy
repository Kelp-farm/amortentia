screen chapter_title(chapter_id):
    modal True
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 960
        vbox:
            spacing 24
            text ("%d장" % CHAPTERS[chapter_id]["number"]) style "muted"
            text (y7_chapter_title(CHAPTERS[chapter_id]["number"]) if chapter_id.startswith("Y7-") else CHAPTERS[chapter_id]["title"]) style "heading"
            text ("호그와트 · %d학년" % CHAPTERS[chapter_id]["year"]) style "muted"
            textbutton y1_ui("읽기 시작", "Begin chapter") action Return() id "begin_chapter"

screen pov_interlude(title):
    modal True
    add Solid("#263343")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 900
        vbox:
            spacing 24
            text title style "heading"
            text y1_ui("시점 · " + y1_pov_name(), "POV: " + POV_NAMES[vn["current_pov"]])
            textbutton y1_ui("계속", "Continue") action Return() id "pov_continue"

screen chapter_statistics(chapter_id):
    modal True
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1160
        ysize 650
        vbox:
            spacing 14
            text ("%d학년 %d장 · 나의 선택" % (CHAPTERS[chapter_id]["year"], CHAPTERS[chapter_id]["number"])) style "heading"
            text vn["chapters"][chapter_id]["summary"] size 21 substitute False
            viewport:
                ysize 435
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 16
                    $ rows = chapter_statistics_rows(chapter_id)
                    if not rows:
                        text y1_ui("표시할 선택이 없습니다.", "No choices to display.") style "muted"
                    for row in rows:
                        frame:
                            xfill True
                            vbox:
                                spacing 8
                                text row["choice"]["choice_text"] size 23 substitute False
                                text (y1_ui("내 선택: ", "You chose: ") + row["choice"]["option_text"]) size 22 substitute False
                                if row["percent"] is not None:
                                    text ("%g%% selected this option" % row["percent"]) color "#b8dcda"
                                    text row["source"] style "muted" substitute False
            hbox:
                spacing 14
                textbutton y1_ui("계속", "Continue") action Return() id "stats_continue"
                textbutton "이야기 흐름도" action ShowMenu("story_flow")
                textbutton "감상실" action ShowMenu("story_collection")
