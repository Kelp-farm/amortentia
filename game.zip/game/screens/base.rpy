init -90 python:
    import json as vn_font_json
    VN_FONT = FontGroup().add("DejaVuSans.ttf", 0x0000, 0x2fff)
    # FontGroup uses the first matching range. Preserve existing glyph metrics
    # and fill genuine holes with the complete font, including all Hangul.
    with renpy.file("fonts/SourceHanSansLite-coverage.json") as _vn_font_file:
        for _vn_start, _vn_end in vn_font_json.load(_vn_font_file):
            VN_FONT.add("fonts/SourceHanSansLite.ttf", _vn_start, _vn_end)
    VN_FONT.add("fonts/SourceHanSansK-Regular.otf", 0x3000, 0xffff)
    del _vn_font_file, _vn_start, _vn_end

style default:
    font VN_FONT
    size 24
    color "#e2e7ec"
style text:
    outlines []
style button:
    background Solid("#2c4050")
    hover_background Solid("#405e70")
    insensitive_background Solid("#27303a")
    padding (18, 10)
style button_text:
    size 23
    color "#f0f4f7"
    hover_color "#ffffff"
    insensitive_color "#78838d"
style frame:
    background Solid("#16222eee")
    padding (28, 24)
style window:
    background Solid("#101a25f2")
    padding (36, 22)
style heading is text:
    size 34
    color "#b8dcda"
style muted is text:
    size 19
    color "#a9b6c4"
style say_label is text:
    color "#b8dcda"
    bold True
style say_dialogue is text:
    size 27
style scrollbar:
    xsize 12
    base_bar Solid("#243444")
    thumb Solid("#718997")
style vscrollbar:
    xsize 12
    base_bar Solid("#243444")
    thumb Solid("#718997")

screen say(who, what):
    window:
        id "window"
        xfill True
        yalign 1.0
        ysize (118 if (renpy.get_screen("y1_event_cg") or renpy.get_screen("y2_event_cg") or renpy.get_screen("y3_event_cg") or renpy.get_screen("y4_event_cg") or renpy.get_screen("y5_event_cg")) else 215)
        padding ((30, 10) if (renpy.get_screen("y1_event_cg") or renpy.get_screen("y2_event_cg") or renpy.get_screen("y3_event_cg") or renpy.get_screen("y4_event_cg") or renpy.get_screen("y5_event_cg")) else (36, 22))
        vbox:
            spacing (6 if (renpy.get_screen("y1_event_cg") or renpy.get_screen("y2_event_cg") or renpy.get_screen("y3_event_cg") or renpy.get_screen("y4_event_cg") or renpy.get_screen("y5_event_cg")) else 12)
            if who is not None:
                text who id "who" style "say_label"
            text what id "what" style "say_dialogue" size (24 if (renpy.get_screen("y1_event_cg") or renpy.get_screen("y2_event_cg") or renpy.get_screen("y3_event_cg") or renpy.get_screen("y4_event_cg") or renpy.get_screen("y5_event_cg")) else 27)

screen choice(items):
    vbox:
        xalign 0.5
        yalign 0.4
        spacing 12
        for item in items:
            textbutton item.caption action item.action xsize 950

screen important_choice(choice_id):
    if mpr_auto_ready(choice_id):
        timer 0.01 action [Function(mpr_take_auto,choice_id), Return(mpr_auto_option(choice_id))]
    elif m42_direct_ready(choice_id):
        timer 0.01 action [Function(m42_take_direct), Return(m42_direct_choice["option"])]
    on "show" action [Function(m41_stop_skip),Function(mpr_validate_auto,choice_id)]
    $ choice_id = canonical_name(choice_id)
    modal True
    $ definition = CHOICES[choice_id]
    if not m33_active() and m21_capture_done != choice_id:
        timer 0.05 action Function(m21_capture, choice_id)
    frame:
        xalign 0.5
        yalign 0.82
        xsize 1060
        vbox:
            spacing 16
            if m21_capture_error:
                text m21_capture_error size 18 color "#e5c49f"
            if definition["text"]:
                text definition["text"] size 27 substitute False
            $ public_hint = carina_public_hint(choice_id)
            if public_hint:
                text public_hint size 19 color "#c9c2b5"
            for option in definition["options"]:
                textbutton m42_choice_text(choice_id,option):
                    sensitive m33_option_available(choice_id, option["id"])
                    id option["id"]
                    action [Function(m21_capture, choice_id), Return(option["id"])]
                    xfill True

screen vn_hud():
    zorder 100
    if not m33_active() and not main_menu and vn["current_chapter"]:
        frame:
            xalign 0.0
            yalign 0.0
            padding (18, 10)
            hbox:
                spacing 16
                text y1_ui("시점 · " + y1_pov_name(), "POV: " + POV_NAMES[vn["current_pov"]]) size 18
                textbutton "흐름도" action ShowMenu("story_flow", year=(7 if vn["flags"].get("y7_campaign") else 6 if vn["flags"].get("y6_campaign") else 5 if vn["flags"].get("y5_campaign") else 4 if vn["flags"].get("y4_campaign") else 3 if vn["flags"].get("y3_campaign") else 2 if vn["flags"].get("y2_campaign") else 1), chapter=int(vn["current_chapter"].split("-C")[1]) if vn["current_chapter"].startswith("Y") else 1) text_size 18 padding (10,2) id "flow_hud"
                textbutton "선택 변경" action ShowMenu("mpr_choices") text_size 18 padding (10,2) id "mpr_hud"
                textbutton y1_ui("저장", "Save") action ShowMenu("save") text_size 18 padding (10, 2)
                textbutton y1_ui("불러오기", "Load") action ShowMenu("load") text_size 18 padding (10, 2)
                textbutton y1_ui("뒤로", "Back") action Rollback() text_size 18 padding (10, 2) id "rollback_hud"
                textbutton "대화 로그" action ShowMenu("history") text_size 18 padding (10, 2) id "history_hud"
                textbutton "관계" action ShowMenu("affection") text_size 18 padding (10, 2) id "affection_hud"
                textbutton "음량" action ShowMenu("preferences") text_size 18 padding (10, 2) id "volume_hud"
                if m33_developer_available() and vn["flags"].get("y7_campaign"):
                    textbutton "7학년 장면" action ShowMenu("y7_scene_select", chapter=int(vn["current_chapter"].split("-C")[1]),hidden=y7_hidden()) text_size 18 padding (10,2) id "y7_scene_hud"
                elif m33_developer_available() and vn["flags"].get("y6_campaign"):
                    textbutton "6학년 장면" action ShowMenu("y6_scene_select", chapter=int(vn["current_chapter"].split("-C")[1])) text_size 18 padding (10,2) id "y6_scene_hud"
                elif m33_developer_available() and vn["flags"].get("y5_campaign"):
                    textbutton "5학년 장면" action ShowMenu("y5_scene_select", chapter=int(vn["current_chapter"].split("-C")[1])) text_size 18 padding (10,2) id "y5_scene_hud"
                elif m33_developer_available() and vn["flags"].get("y4_campaign"):
                    textbutton "4학년 장면" action ShowMenu("y4_scene_select", chapter=int(vn["current_chapter"].split("-C")[1])) text_size 18 padding (10,2) id "y4_scene_hud"
                elif m33_developer_available() and vn["flags"].get("y3_campaign"):
                    textbutton "3학년 장면" action ShowMenu("y3_scene_select", chapter=int(vn["current_chapter"].split("-C")[1])) text_size 18 padding (10,2) id "y3_scene_hud"
                elif m33_developer_available() and vn["flags"].get("y2_campaign"):
                    textbutton "2학년 장면" action ShowMenu("y2_scene_select", chapter=int(vn["current_chapter"].split("-C")[1])) text_size 18 padding (10, 2) id "y2_scene_hud"
                elif m33_developer_available() and vn["flags"].get("y1_campaign"):
                    textbutton "챕터 선택" action ShowMenu("y1_chapter_select") text_size 18 padding (10, 2) id "chapter_select_hud"
                    textbutton "장면 선택" action ShowMenu("y1_scene_select", chapter=int(vn["current_chapter"].split("-C")[1])) text_size 18 padding (10, 2) id "scene_select_hud"
        key "K_l" action ShowMenu("history")
        key "K_r" action ShowMenu("affection")
    if not m33_active() and not main_menu and config.developer:
        key "K_F3" action ShowMenu("debug_state")
        textbutton "Debug":
            xalign 1.0
            yalign 0.0
            text_size 18
            action ShowMenu("debug_state")

screen main_menu():
    tag menu
    add Solid("#14222d")
    if renpy.loadable("images/production/courtyard.webp"):
        add "images/production/courtyard.webp" xysize (1280, 720)
        add Solid("#101a2560")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 780
        vbox:
            spacing 5
            text "AMORTENTIA" style "heading"
            text "A Hogwarts Love Story" size 25 color "#e6d5b2"
            if M33_QA_BUILD:
                text "개발 검수용 · QA 장면 감상 지원" size 19 color "#e5c49f"
            text "1–7학년 · 선공개 버전" size 21
            textbutton "새 이야기" action Start() xfill True id "new_story"
            if m33_developer_available():
                textbutton "챕터 선택" action ShowMenu("review_year_select") xfill True id "chapter_select"
            if config.developer:
                textbutton "Start demo" action Start("m0_demo_start") xfill True text_size 18
            textbutton y1_ui("불러오기", "Load") action ShowMenu("load") xfill True
            hbox:
                spacing 12
                textbutton "이야기 흐름도" action ShowMenu("story_flow") xsize 350 id "flow_main"
                textbutton "감상실" action ShowMenu("story_collection") xsize 362 id "gallery"
            textbutton "설정" action ShowMenu("preferences") xfill True
            if not renpy.variant("web"):
                textbutton "종료" action Quit(confirm=False) xfill True

screen review_year_select():
    tag menu
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 780
        vbox:
            spacing 10
            text "챕터 선택" style "heading"
            text "학년을 고르면 챕터와 장면을 선택할 수 있습니다." size 23
            if m33_developer_available():
                textbutton "1학년" action ShowMenu("y1_chapter_select") xfill True id "year1_select"
                textbutton "2학년" action ShowMenu("y2_scene_select", chapter=1) xfill True id "year2_select"
                textbutton "3학년" action ShowMenu("y3_scene_select", chapter=1) xfill True id "year3_select"
                textbutton "4학년" action ShowMenu("y4_scene_select", chapter=1) xfill True id "year4_select"
                textbutton "5학년" action ShowMenu("y5_scene_select", chapter=1) xfill True id "year5_select"
                textbutton "6학년" action ShowMenu("y6_scene_select", chapter=1) xfill True id "year6_select"
                textbutton "7학년 · 결말" action ShowMenu("y7_scene_select", chapter=1) xfill True id "year7_select"
            textbutton "돌아가기" action Return() id "year_select_back"

screen confirm(message, yes_action, no_action):
    modal True
    zorder 200
    add Solid("#000a")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 800
        vbox:
            spacing 20
            text y1_confirm_message(message)
            hbox:
                spacing 24
                textbutton y1_ui("예", "Yes") action yes_action
                textbutton y1_ui("아니요", "No") action no_action
    key "game_menu" action no_action

screen preferences():
    tag menu
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 720
        vbox:
            spacing 18
            text "음량 · 설정" style "heading"
            text "막대를 누르거나 드래그해서 조절하세요." style "muted"
            text ("현재 음악 · "+m43_music_title()) style "muted"
            for mixer, title, pref in (("music", "배경 음악", "music"), ("sfx", "효과음", "sound")):
                hbox:
                    spacing 20
                    text title xsize 180 yalign 0.5
                    text ("%d%%" % round(preferences.get_mixer(mixer) * 100)) xsize 90 yalign 0.5
                    textbutton ("소리 켜기" if preferences.get_mute(mixer) else "음소거"):
                        action Preference(pref + " mute", "toggle")
                        id "mute_" + mixer
                        selected preferences.get_mute(mixer)
                bar:
                    value Preference(pref + " volume")
                    style "vn_volume_bar"
                    id "volume_" + mixer
            hbox:
                spacing 20
                textbutton "효과음 들어보기" action Function(m43_sfx,"ui") id "audio_test_sfx"
                if m33_developer_available():
                    textbutton "음원 검수" action ShowMenu("m43_audio_review") id "audio_review"
            if not renpy.variant("web"):
                hbox:
                    spacing 16
                    textbutton "창 모드" action Preference("display", "window")
                    textbutton "전체 화면" action Preference("display", "fullscreen")
            textbutton y1_ui("돌아가기", "Return") action Return() id "preferences_return"

style vn_volume_bar:
    xsize 650
    ysize 34
    left_bar Solid("#79b5b1")
    right_bar Solid("#354b5b")
    thumb Solid("#e9f4f1", xsize=18, ysize=34)
    thumb_offset 9

screen input(prompt):
    window:
        vbox:
            text prompt
            input id "input"

