screen ginny_timeline_changed():
    modal True
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1000 padding (32,28)
        vbox:
            spacing 24
            text "이전 버전의 저장입니다" style "heading"
            text "지니와의 이야기 순서가 바뀌어 현재 지점에서 바로 이어갈 수 없습니다. 5학년 우승 파티 이전의 저장을 불러와 주세요." size 25
            text "기존 저장 파일은 그대로 남아 있습니다." size 23
            textbutton "처음 화면으로" action Return() id "ginny_timeline_restart"

screen m6_commitment_changed():
    modal True
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1000 padding (32,28)
        vbox:
            spacing 24
            text "이전 버전의 저장입니다" style "heading"
            text "이전 진행 내용이 현재 이야기와 맞지 않아 바로 이어갈 수 없습니다. 2학년 일기장 선택 전의 저장을 불러오거나 장면 감상을 이용해 주세요." size 25
            text "기존 저장 파일과 감상 기록은 그대로 남아 있습니다." size 23
            textbutton "처음 화면으로" action Return() id "m6_restart"

screen y6_stage(scene_id):
    zorder -5
    $ meta=Y6_SCENES[scene_id]
    add y6_background(scene_id) xysize (1280,720) fit "cover"
    if not vc_hide_standing and y6_portrait in Y6_SPRITES and y6_portrait not in y6_offscreen:
        add y6_sprite(y6_portrait,scene_id) id "y6_speaker_portrait" xpos 0.58 xanchor 0.5 alpha vc_portrait_alpha(y6_portrait,scene_id)
    frame:
        xpos 22 ypos 54 padding (12,7) background Solid("#111e29c9")
        hbox:
            spacing 18
            text (vc_location or meta["location"]) size 22 slow_cps 0
            text meta["time"] size 16 color "#b5c2ca" yalign 0.5 slow_cps 0

screen y6_event_cg(asset_id):
    zorder -4
    add Y6_CGS[asset_id] xysize (1280,720) fit "cover"

screen y6_scene_select(chapter=1):
    tag menu
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1180 ysize 680 padding (24,18)
        vbox:
            spacing 10
            text "6학년 · 챕터와 장면" style "heading"
            hbox:
                spacing 8
                for n in range(1,9):
                    textbutton ("%d장"%n) action ShowMenu("y6_scene_select",chapter=n) selected chapter==n id "y6_tab_%d"%n
            text Y6_TITLES[chapter-1] size 24
            viewport:
                ysize 420 mousewheel True draggable True scrollbars "vertical"
                vbox:
                    spacing 4
                    for sid,meta in Y6_SCENES.items():
                        if meta["number"]==chapter:
                            textbutton (("히든 · " if sid in Y6_SOURCE_SCENES else "본편 · ")+meta["title"]):
                                xfill True text_size 22 padding (12,6) id "scene_"+sid
                                action [SetVariable("m33_qa",True),ShowMenu("m33_scene_detail",nid=sid)]
            text "감상은 임시 이력으로 진행됩니다. 실제 저장과 해금 기록은 바뀌지 않습니다." size 18 color "#b8dcda"
            hbox:
                spacing 12
                textbutton "학년 선택" action ShowMenu("review_year_select")
                textbutton "돌아가기" action Return()

screen y6_ending():
    modal True
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1080 padding (30,24)
        vbox:
            spacing 18
            text "6학년 · 끝" style "heading"
            if y6_hidden():
                text "볼드모트의 육체는 패배했지만, 해리 안의 영혼 조각은 남아 있습니다." size 25
                text "보호가 끝나는 날은 2032년 7월 31일. 카리나와 함께 그날 이후에도 살아갈 방법을 찾아야 합니다." size 23
            else:
                text "덤블도어가 남긴 단서와 찾지 못한 호크룩스가 있습니다." size 25
                text "곁에 남은 사람들과 함께 다음 싸움을 준비합니다." size 23
            text Y6_CONTINUATIONS["hidden" if y6_hidden() else "main"]["title"] size 24 color "#b8dcda"
            textbutton "7학년으로" action Jump("y7_start") id "y6_continue_y7"
            textbutton "완료 기록 저장" action ShowMenu("save") id "y6_save"
            hbox:
                spacing 12
                textbutton "흐름도" action ShowMenu("story_flow",year=6,chapter=8) id "y6_flow"
                textbutton "감상실" action ShowMenu("story_collection",tab="ending")
                textbutton "처음 화면으로" action Return() id "y6_finish"
