screen y7_stage(scene_id):
    zorder -5
    $ meta=Y7_SCENES[scene_id]
    add y7_background(scene_id) xysize (1280,720) fit "cover"
    if not vc_hide_standing and y7_portrait in Y7_SPRITES and y7_portrait not in y7_offscreen:
        add y7_sprite(y7_portrait,scene_id) id "y7_speaker_portrait" xpos 0.58 xanchor 0.5
    frame:
        xpos 22 ypos 54 padding (12,7) background Solid("#111e29c9")
        hbox:
            spacing 18
            text (vc_location or meta["location"]) size 22 slow_cps 0
            text meta["time"] size 16 color "#b5c2ca" yalign 0.5 slow_cps 0

screen y7_event_cg(asset_id):
    zorder -4
    add Y7_CGS[asset_id] xysize (1280,720) fit "cover"

screen y7_scene_select(chapter=1,hidden=False):
    tag menu
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1180 ysize 680 padding (24,18)
        vbox:
            spacing 10
            hbox:
                spacing 24
                text "7학년 · 마지막 이야기" style "heading"
                textbutton "본편" action ShowMenu("y7_scene_select",chapter=chapter,hidden=False) selected not hidden
                textbutton "카리나 히든" action ShowMenu("y7_scene_select",chapter=chapter,hidden=True) selected hidden
            hbox:
                spacing 3
                for n in range(1,13):
                    textbutton ("%d장"%n) action ShowMenu("y7_scene_select",chapter=n,hidden=hidden) selected chapter==n id "y7_tab_%d"%n text_size 21 padding (12,8)
            text (Y7_HIDDEN_TITLES if hidden else Y7_TITLES)[chapter-1] size 24
            viewport:
                ysize 408 mousewheel True draggable True scrollbars "vertical"
                vbox:
                    spacing 4
                    for sid,meta in Y7_SCENES.items():
                        if meta["number"]==chapter and (sid in Y7_SOURCE_SCENES)==hidden:
                            textbutton meta["title"]:
                                xfill True text_size 22 padding (12,6) id "scene_"+sid
                                action [SetVariable("m33_qa",True),ShowMenu("m33_scene_detail",nid=sid)]
            text "감상에서는 실제 저장과 발견·엔딩 기록이 바뀌지 않습니다." size 18 color "#b8dcda"
            hbox:
                spacing 12
                textbutton "학년 선택" action ShowMenu("review_year_select")
                textbutton "돌아가기" action Return()

screen y7_ending():
    modal True
    add Solid("#14222d")
    $ result=vn["year7"]["ending"]
    frame:
        align (0.5,0.5) xsize 1030 padding (36,30)
        vbox:
            spacing 20
            text "일곱 해의 끝" style "heading"
            text M21_ENDINGS["route_"+result]["title"] size 33 color "#e1cd9b"
            text "함께 걸어온 이야기는 여기서 마칩니다." size 25
            if result=="carina_hidden":
                text "카리나와 함께 · 빼앗기지 않은 내일" size 23
            elif vn["year7"]["career"]=="auror":
                text "오러로서 시작한 새로운 삶" size 23
            else:
                text "호그와트에서 마친 마지막 학년" size 23
            text "감상실에서 발견한 결말과 그림을 다시 볼 수 있습니다." size 21
            textbutton "완료 기록 저장" action ShowMenu("save") id "y7_save"
            hbox:
                spacing 20
                textbutton "엔딩 감상실" action ShowMenu("story_collection",tab="ending") id "y7_collection"
                textbutton "흐름도" action ShowMenu("story_flow",year=7,chapter=12) id "y7_flow"
                textbutton "처음 화면으로" action MainMenu(confirm=False) id "y7_finish"
