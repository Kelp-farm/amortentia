screen msc_scene_continue(sid, preferred=None):
    tag menu
    modal True
    default selected_history = preferred
    $ entries = msc_records(sid)
    $ effective = selected_history if selected_history in [r["resume_key"] for r in entries] else (entries[0]["resume_key"] if entries else None)
    $ current = next((r for r in entries if r["resume_key"] == effective), None)
    add Solid("#101d29")
    frame:
        align (0.5,0.5) xsize 1120 ysize 640 padding (28,24)
        vbox:
            spacing 12
            text "장면에서 이어하기" style "heading"
            text M21_NODES[sid]["title"] size 28
            if entries:
                text "이 장면에 도달했을 때의 이력으로 시작합니다. 장면 안의 선택은 다시 고를 수 있습니다." size 23 xmaximum 1050
                text "이후 장면도 본편으로 이어지며 저장할 수 있습니다." size 21 color "#bad6d1"
                viewport:
                    ysize 120 mousewheel True draggable True scrollbars "vertical"
                    vbox:
                        spacing 12
                        for entry in entries:
                            textbutton msc_history_title(entry):
                                action SetScreenVariable("selected_history", entry["resume_key"])
                                selected effective == entry["resume_key"]
                                selected_background Solid("#416c70")
                                xfill True text_size 22 id "msc_history_"+entry["resume_key"]
                if current and any(k.endswith("review_preset") and v for k,v in current["state"].get("flags",{}).items()):
                    text "검수용 시작 지점에서 이어진 이력입니다." size 20 color "#e5c49f"
                if not main_menu:
                    text "현재 진행은 전환 전에 자동으로 보관됩니다." size 20
                textbutton "이 이력으로 이어하기":
                    action Function(msc_launch, sid, effective, not main_menu)
                    sensitive current is not None
                    text_size 25 id "msc_start"
            else:
                text "이 장면의 도달 이력이 없습니다." size 25
                text "이전 버전의 해금 표시만으로 앞선 선택을 복원할 수는 없습니다." size 21 xmaximum 1050
                if m33_developer_available():
                    textbutton "검수용 이력으로 시작" action ShowMenu("m4e_review_detail",sid=sid) text_size 23 id "msc_review_start"
            if renpy.can_load(MSC_BACKUP_SLOT):
                textbutton "전환 전 진행 불러오기":
                    action Confirm("전환 전에 보관한 진행을 불러올까요?",Function(renpy.load,MSC_BACKUP_SLOT))
                    text_size 22 id "msc_restore"
            textbutton "돌아가기" action ShowMenu("m33_scene_detail",nid=sid) text_size 22 id "msc_back"
