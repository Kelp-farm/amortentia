# The viewpoint character is never represented by a sprite or placeholder card.
screen y1_stage(scene_id, focus=None, expressions=None, background=None, location=None):
    zorder -5
    # Retired scenes in older saves may be evaluated once while hiding.
    if scene_id in Y1_SCENES:
        $ meta = Y1_SCENES[scene_id]
        $ members = ([] if vc_hide_standing else y1_visible_members(scene_id, focus))
        $ expressions = expressions or {}
        $ backdrop = background or (vc_background(vc_background_key) if vc_background_key else Y1_BACKGROUNDS.get(scene_id))
        if backdrop:
            add backdrop xysize (1280, 720)
        else:
            add Solid(meta["color"])
            if m33_developer_available():
                text "배경 일러스트 준비 중" xpos 30 ypos 460 size 16 color "#9aadb7" slow_cps 0
        for index, member in enumerate(members):
            $ expression = y1_sprite_expression(scene_id, member, expressions)
            add y1_production_sprite(member, expression, scene_id) id "y1_speaker_portrait" xpos y1_sprite_position(index, len(members)) xanchor 0.5
        frame:
            xpos 22
            ypos (76 if m33_active() else 54)
            padding (12, 7)
            background Solid("#111e29c9")
            hbox:
                spacing 18
                text (location or vc_location or meta["location"]) id "scene_location" size 22 slow_cps 0
                text "1학년" id "scene_time" size 16 color "#b5c2ca" yalign 0.5 slow_cps 0

screen y1_event_cg(asset_id):
    $ asset_id = canonical_name(asset_id)
    zorder -4
    add Y1_CGS[asset_id] xysize (1280, 720)

# Compatibility aliases: no path exposes locked artwork.
screen y1_gallery():
    tag menu
    use story_collection()

screen y1_gallery_image(asset_id):
    tag menu
    use story_cg("Y1:" + asset_id)

screen y1_ending():
    modal True
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 940
        vbox:
            spacing 22
            text "1학년 · 끝" style "heading"
            text "돌아오고 싶은 곳" size 27
            textbutton "2학년으로" action Return("year2") id "continue_year2"
            hbox:
                spacing 12
                textbutton "이야기 흐름도" action ShowMenu("story_flow")
                textbutton "감상실" action ShowMenu("story_collection", tab="ending")
            textbutton "완료 기록 저장" action ShowMenu("save")
            textbutton "처음 화면으로" action Return() id "y1_finish"
