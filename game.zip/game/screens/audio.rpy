screen m43_audio_review():
    tag menu
    modal True
    default previous_music = renpy.music.get_playing(channel="music")
    default previous_position = renpy.music.get_pos(channel="music")
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1160
        ysize 660
        vbox:
            spacing 12
            text "음원 검수 · 개발용" style "heading"
            text ("재생 중 · "+m43_music_title()) id "audio_current"
            text ("재생 위치 %.1f초 / 전체 %.1f초"%((renpy.music.get_pos(channel="music") or 0),(renpy.music.get_duration(channel="music") or 0))) style "muted"
            text ("음악 %d%% · %s"%(round(preferences.get_mixer("music")*100),"음소거" if preferences.get_mute("music") else "소리 켜짐")) style "muted"
            viewport:
                ysize 350
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 8
                    for key,title in M43_TRACKS.items():
                        textbutton title action Function(m43_play,key,0.4) id "audio_"+key
                    textbutton "무음 전환" action Function(m43_play,None,0.5) id "audio_silence"
            text "미리듣기는 이야기·해금·선택 이력을 바꾸지 않습니다. 돌아가면 원래 음악을 재개합니다." style "muted" size 18
            textbutton "돌아가기" action [Function(m43_restore_preview,previous_music,previous_position),Return()] id "audio_review_return"
    timer 0.25 action Function(renpy.restart_interaction) repeat True
    key "game_menu" action [Function(m43_restore_preview,previous_music,previous_position),Return()]
