screen route_guide(target=None):
    tag menu
    modal True
    default archive = m41_checkpoint_rows()
    default selected_target = target
    default guide_section = m41_guide_section(target)
    default show_requirements = False
    $ level = m41_hint_level()
    add Solid("#101d29")
    on "show" action Function(m41_stop_skip)
    frame:
        align (0.5,0.5) xsize 1230 ysize 680 padding (24,20)
        vbox:
            spacing 12
            hbox:
                spacing 16
                text "엔딩 탐색 가이드" style "heading"
                textbutton "흐름도로" action ShowMenu("story_flow") style "m21_button" id "guide_flow"
                textbutton "돌아가기" action Return() style "m21_button" id "guide_back"
            text ("1–7학년 · " + m41_guide_summary()) style "muted"
            hbox:
                spacing 12
                textbutton "최종 엔딩":
                    action [SetScreenVariable("guide_section","endings"),SetScreenVariable("selected_target",None),SetScreenVariable("show_requirements",False)]
                    selected guide_section=="endings" selected_background Solid("#416c70") style "m21_button" id "guide_endings"
                textbutton "중간 결과":
                    action [SetScreenVariable("guide_section","events"),SetScreenVariable("selected_target",None),SetScreenVariable("show_requirements",False)]
                    selected guide_section=="events" selected_background Solid("#416c70") style "m21_button" id "guide_events"
                textbutton ("스포일러 도움 · " + ("켜짐" if persistent.m41_spoilers else "꺼짐")):
                    action ToggleField(persistent,"m41_spoilers") style "m21_button" id "guide_spoilers"
            hbox:
                spacing 18
                viewport:
                    xsize 380 ysize 485 mousewheel True draggable True scrollbars "vertical"
                    vbox:
                        spacing 6
                        for group,name in M41_GROUPS:
                            $ group_targets=m41_guide_targets(guide_section,group)
                            if group_targets:
                                text name size 22 color "#b8dcda"
                                for tid in group_targets:
                                    textbutton m41_guide_label(tid,level):
                                        action SetScreenVariable("selected_target",tid)
                                        selected selected_target==tid selected_background Solid("#416c70")
                                        xsize 355 text_size 20 padding (10,7)
                                        id "guide_target_"+tid
                frame:
                    xsize 780 ysize 485 padding (18,16)
                    viewport:
                        ysize 453 mousewheel True draggable True scrollbars "vertical"
                        vbox:
                            spacing 13
                            if not selected_target:
                                text ("살펴볼 엔딩을 골라 주세요." if guide_section=="endings" else "살펴볼 중간 결과를 골라 주세요.") size 27
                                text "무도회 동행, 교제 공개 여부, 인물의 생사 등은 중간 결과입니다. 여러 결과를 함께 경험할 수 있으며 각각이 별도 엔딩을 뜻하지는 않습니다." size 22
                                text "감상은 장면만 다시 봅니다. 다시 진행은 실제 체크포인트를 불러옵니다. 이 화면에서는 조건과 돌아갈 곳만 확인합니다." size 22
                                text "첫 학년 완료 전에는 미래 결과를 감춥니다. 완료 뒤에는 힌트를, 스포일러 도움을 켜면 구체적인 선택과 조건을 볼 수 있습니다." style "muted"
                            else:
                                $ meta=M41_TARGETS[selected_target]
                                if meta["kind"]=="future":
                                    text meta["title"] size 26
                                    text meta["hint"] size 22
                                    text "준비 중 · 완료율에서 제외" color "#d7c293" size 22
                                elif level==0 and not m41_known(selected_target):
                                    text ("아직 발견하지 않은 엔딩" if guide_section=="endings" else "아직 발견하지 않은 중간 결과") size 27
                                    text "먼저 한 학년을 끝까지 읽어 보세요. 지금 확인하려면 스포일러 도움을 켤 수 있습니다." size 22
                                elif level<2 and not m41_known(selected_target):
                                    text "다른 선택을 위한 힌트" size 27
                                    text meta["hint"] size 24
                                    text "구체적인 조건과 저장 위치는 스포일러 도움을 켰을 때 표시합니다." style "muted"
                                else:
                                    text meta["title"] size 27
                                    text ("감상 완료" if m41_known(selected_target) else "아직 감상하지 않은 결과") size 21 color "#b8dcda"
                                    $ current=m41_evaluate(selected_target,vn)
                                    text "현재 진행의 조건" size 23
                                    text M41_STATUS[current["status"]] size 22
                                    textbutton ("조건 접기" if show_requirements else "조건 자세히 보기"):
                                        action ToggleScreenVariable("show_requirements") text_size 20 id "guide_requirements"
                                    if level==2 and show_requirements:
                                        for row in current["rows"]:
                                            text (M41_STATUS[row["status"]]+" · "+row["text"]) size 20 xmaximum 710 color ("#d7a59f" if row["status"]=="impossible" else "#c7d3df")
                                    $ recommendation=m41_recommend(selected_target,archive[0])
                                    $ best=recommendation["best"]
                                    $ guide_y,guide_c,guide_n=m42_guide_destination(selected_target)
                                    textbutton "관련 갈래를 흐름도에서 보기":
                                        action ShowMenu("story_flow",year=guide_y,chapter=guide_c,selected=guide_n,target=selected_target)
                                        id "guide_divergence"
                                    text "강조된 갈래와 재개 가능한 저장은 다릅니다." style "muted"
                                    text "다시 진행할 곳" size 24 color "#b8dcda"
                                    if best:
                                        $ node=M21_NODES[best["cid"]]
                                        text ("%d학년 %s장 · %s" % (node["year"],node["chapter"].split("-C")[1],node["title"])) size 23
                                        text (best["meta"]["m21_date"]+" · "+best["meta"]["m21_origin"]+"에서 남긴 실제 선택 직전 기록") style "muted"
                                        text "필수 조건을 바꿀 여지가 남은 저장 중 이야기상 가장 가까운 지점입니다. 같은 지점에서는 최근 기록을 골랐습니다." size 21
                                        textbutton "이 지점부터 다시 진행":
                                            action Confirm("선택 직전의 기록을 불러올까요?\n저장하지 않은 현재 진행은 사라집니다.\n수동 저장과 감상 기록은 유지됩니다.",Function(m21_replay,best["slot"],best["cid"]))
                                            sensitive not m33_active() id "guide_replay"
                                        textbutton "흐름도에서 위치 확인":
                                            action ShowMenu("story_flow",year=node["year"],chapter=int(node["chapter"].split("-C")[1]),selected=best["cid"],target=selected_target)
                                            id "guide_node"
                                        if level==2 and best["result"]["plan"]:
                                            text "불러온 뒤 필요한 선택" size 22
                                            for cid,oid in sorted(best["result"]["plan"].items(),key=lambda p:M41_CHOICE_ORDER[p[0]]):
                                                text ("· "+next(o["text"] for o in CHOICES[cid]["options"] if o["id"]==oid)) size 20 substitute False xmaximum 710
                                    else:
                                        text "이 결과를 위한 유효한 체크포인트가 없습니다." size 23
                                        text "더 이른 수동 저장이나 새 진행이 필요합니다. 저장하지 않은 과거 선택을 만들어 내지는 않습니다." size 21
                                        if recommendation["uncertain"]:
                                            text "조건을 확실히 증명할 수 없는 기록은 추천에서 제외했습니다. 특히 3학년 이전부터 공개 교제에 필요한 호감을 쌓는 계산과 4학년의 늦은 교제 후 이별은 안내 범위 밖입니다." style "muted"
                                    if archive[1]:
                                        text ("확인할 수 없는 체크포인트 %d개는 제외했습니다." % archive[1]) style "muted"
    key "game_menu" action Return()

screen m41_route_groups():
    for group,name in M41_GROUPS:
        frame:
            xsize 1130 padding (18,12)
            vbox:
                spacing 8
                text (name+" · 최종 엔딩") size 24
                $ implemented=m41_guide_targets("endings",group)
                text ("감상한 엔딩 %d / %d" % (sum(m41_known(t) for t in implemented),len(implemented))) size 20 color "#b8dcda"
                for tid in implemented:
                    $ meta=M41_TARGETS[tid]
                    $ known=m41_known(tid)
                    hbox:
                        spacing 12
                        text (meta["title"]+" · 감상 완료" if known else "미발견 엔딩") size 21 yalign 0.5
                        textbutton "목표 경로 확인" action ShowMenu("route_guide",target=tid) text_size 19 id "collection_target_"+tid
                if group=="carina" and m41_hint_level()==2:
                    text "카리나 본편과 히든은 다른 엔딩입니다. 공개·비밀 교제는 같은 히든 엔딩 안의 이력입니다." style "muted"
