screen y2_stage(scene_id):
    zorder -5
    $ meta = Y2_SCENES[scene_id]
    $ backdrop = (vc_background(vc_background_key) if vc_background_key else (y2_stage_background if y2_stage_background is not None else Y2_BACKGROUNDS.get(scene_id)))
    if backdrop:
        add backdrop xysize (1280,720)
    else:
        add Solid("#182733")
        text "배경 일러스트 준비 중" xpos 30 ypos 460 size 16 color "#9aadb7" slow_cps 0
    for member in ([] if vc_hide_standing else y2_visible_members(scene_id)):
        add y2_sprite(member,scene_id) xpos 0.58 xanchor 0.5
    frame:
        xpos 22
        ypos 54
        padding (12,7)
        background Solid("#111e29c9")
        hbox:
            spacing 18
            text (vc_location or y2_stage_location or meta["location"]) size 22 slow_cps 0
            text meta["time"] size 16 color "#b5c2ca" yalign 0.5 slow_cps 0

screen y2_event_cg(asset_id):
    $ asset_id = canonical_name(asset_id)
    zorder -4
    add Y2_CGS[asset_id] xysize (1280,720)

screen y2_scene_select(chapter=1):
    tag menu
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1120
        vbox:
            spacing 10
            text "2학년 · 챕터와 장면" style "heading"
            hbox:
                spacing 10
                for n in range(1,7):
                    textbutton ("%d장" % n) action ShowMenu("y2_scene_select",chapter=n) selected chapter == n id "y2_tab_%d" % n
            text Y2_TITLES[chapter-1] size 26
            for sid,meta in Y2_SCENES.items():
                if meta["number"] == chapter:
                    $ entry_action = Start("review_"+meta["label"])
                    textbutton (meta["title"] + (" · 협력 경로" if sid == "Y2-C6-S06" else "")):
                        xfill True
                        text_size 22
                        padding (14,7)
                        id "scene_"+sid
                        action ShowMenu("m4e_review_detail",sid=sid)
            text "장면을 고르면 필요한 분기만 표시됩니다. 공통 장면은 별도 설정 없이 시작합니다." size 18 color "#b8dcda"
            hbox:
                spacing 12
                textbutton "불러오기" action ShowMenu("load")
                textbutton "학년 선택" action ShowMenu("review_year_select") id "y2_review_years"
                textbutton "돌아가기" action Return() id "y2_review_back"

screen y2_ending():
    modal True
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 940
        vbox:
            spacing 22
            text "이 학년 · 끝" style "heading"
            text "비밀의 방은 닫혔습니다." size 27
            text ("도비는 자기 갈 곳을 고르게 되었습니다." if vn["world"]["dobby_status"] == "free_harry" else "도비는 아직 말포이 가문에 남아 있습니다.") size 23
            text ("카리나는 가족의 비밀을 지키기 위해 협력합니다. 다른 학생들 앞에서 두 사람은 여전히 라이벌입니다." if vn["world"]["carina_cooperation"] == "pressured" else "카리나와 비밀 협력을 맺지 않았습니다. 두 사람의 경쟁은 이어집니다.") size 23
            text "이 선택들을 그대로 이어 3학년을 시작할 수 있습니다." style "muted"
            hbox:
                spacing 12
                textbutton "이야기 흐름도" action ShowMenu("story_flow")
                textbutton "감상실" action ShowMenu("story_collection", tab="ending")
            textbutton "3학년으로" action Return("year3") id "year3_continue"
            textbutton "완료 기록 저장" action ShowMenu("save")
            textbutton "처음 화면으로" action Return() id "y2_finish"
