screen y1_chapter_select():
    tag menu
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1060
        vbox:
            spacing 14
            text "1학년 · 챕터와 장면" style "heading"
            text "원하는 장부터 시작해 학년 말까지 이어서 읽을 수 있습니다." size 23
            hbox:
                spacing 12
                textbutton "장면별로 고르기" action ShowMenu("y1_scene_select", chapter=1) id "scene_select"
                use y1_review_scene_button("Y1-C4-S12", "병문안 · 포옹", "quick_hug")
                use y1_review_scene_button("Y1-C4-S14", "열차 · 작별", "quick_farewell")
            for number in (1, 2, 3, 4):
                $ chapter = CHAPTERS["Y1-C%d" % number]
                $ start_action = Start("y1_review_c%d" % number)
                textbutton ("%d장  ·  %s" % (number, chapter["title"])):
                    id "review_chapter_%d" % number
                    xfill True
                    action (start_action if main_menu else Confirm("이 장부터 새로 시작할까요?\n저장하지 않은 진행은 사라집니다.", start_action))
            text "이전 선택은 검수용 기본 흐름으로 설정됩니다." size 21 color "#b8dcda"
            text "카리나에게 다시 관심을 갖고, 헤르미온느에게 실습을 부탁하며, 금지된 복도는 교수에게 알립니다. 4장에서는 거울 앞에서 카리나와 부모님 이야기를 나눈 상태로 시작합니다." size 19 color "#a9b6c4"
            text "직접 고른 선택을 이어가려면 저장 기록을 불러오세요. 기존 저장 파일은 바뀌지 않습니다." size 19 color "#a9b6c4"
            hbox:
                spacing 14
                if not main_menu:
                    textbutton "현재 진행 저장" action ShowMenu("save")
                textbutton "학년 선택" action ShowMenu("review_year_select") id "review_years"
                textbutton "돌아가기" action Return() id "review_back"

screen y1_review_scene_button(scene_id, caption, button_id):
    $ entry = Y1_REVIEW_SCENES[scene_id]
    $ scene_action = Start("review_" + entry["label"])
    textbutton caption:
        id button_id
        action (scene_action if main_menu else Confirm("이 장면부터 새로 시작할까요?\n저장하지 않은 진행은 사라집니다.", scene_action))

screen y1_scene_select(chapter=4):
    tag menu
    add Solid("#14222d")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1120
        vbox:
            spacing 12
            text "장면 선택" style "heading"
            hbox:
                spacing 12
                for number in (1, 2, 3, 4):
                    textbutton ("%d장" % number):
                        action ShowMenu("y1_scene_select", chapter=number)
                        selected chapter == number
                        id "scene_tab_%d" % number
                text CHAPTERS["Y1-C%d" % chapter]["title"] size 24 yalign 0.5
            $ entries = [(sid, row) for sid, row in Y1_REVIEW_SCENES.items() if row["chapter"] == chapter]
            $ row_count = (len(entries) + 1) // 2
            grid 2 row_count:
                spacing 10
                for sid, entry in entries:
                    fixed:
                        xsize 522
                        ysize 49
                        use y1_review_scene_button(sid, "%02d  ·  %s" % (entry["offset"] + 1, entry["title"]), "scene_" + sid)
                if len(entries) % 2:
                    null width 522 height 49
            text "선택한 장면부터 이후 이야기로 이어집니다. 이전 선택은 검수용 기본 흐름입니다." size 20 color "#b8dcda"
            if chapter == 4:
                text "앞선 독서는 함께하고, 숲에서는 카리나의 팔을 잡아당기며, 돌을 지키러 갈 때는 구조 요청을 남깁니다." size 18 color "#a9b6c4"
            text "기존 저장 파일은 바뀌지 않습니다. 직접 고른 선택을 유지하려면 저장 기록을 불러오세요." size 18 color "#a9b6c4"
            hbox:
                spacing 12
                textbutton "챕터 목록" action ShowMenu("y1_chapter_select") id "scene_chapters"
                if not main_menu:
                    textbutton "현재 진행 저장" action ShowMenu("save")
                textbutton "돌아가기" action Return() id "scene_back"
