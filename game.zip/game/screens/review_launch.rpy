screen mrv_scene_setup(sid,origin="main"):
    tag menu
    modal True
    $ variants = mrv_presets(sid,origin)
    default preset = variants[0]
    default changes = {}
    default draft = mrv_preview(sid,preset,origin)
    $ prior_choices = mrv_prior_choices(draft)
    add Solid("#101d29")
    frame:
        align (0.5,0.5) xsize 1220 ysize 680 padding (24,18)
        vbox:
            spacing 12
            text "이 장면부터 연속 검수" style "heading"
            text m42_node_title(sid,origin) size 26
            text "앞선 전개를 정하면 이 장면부터 본편처럼 이어집니다. 장면 안의 선택은 직접 고릅니다." size 21
            hbox:
                spacing 20
                viewport:
                    xsize 345 ysize 370 scrollbars "vertical" mousewheel True draggable True
                    vbox:
                        spacing 9
                        text "앞선 전개" size 23 color "#bad6d1"
                        for variant in variants:
                            textbutton M33_QA_PRESETS[variant]["title"]:
                                action Function(mrv_change,sid,variant,origin,{})
                                selected preset==variant selected_background Solid("#416c70")
                                xfill True text_size 20 id "mrv_preset_"+variant
                viewport:
                    xsize 795 ysize 370 scrollbars "vertical" mousewheel True draggable True
                    vbox:
                        spacing 12
                        text "장면 이전의 주요 선택" size 23 color "#bad6d1"
                        if not prior_choices:
                            text "추가로 정할 주요 선택이 없습니다." size 21
                        for row in prior_choices:
                            $ cid = row["choice_id"]
                            text mrv_choice_title(cid) size 21 color "#dfc799"
                            for option in CHOICES[cid]["options"]:
                                textbutton m42_choice_text(cid,option,draft["state"]):
                                    action Function(mrv_change,sid,preset,origin,changes,cid,option["id"])
                                    selected row["option_id"]==option["id"] selected_background Solid("#416c70")
                                    xfill True text_size 20 id "mrv_answer_"+cid+"_"+option["id"]
                        if draft["note"]:
                            text draft["note"] size 21 color "#efb8a8" xmaximum 730
            text ("현재 진행은 전환 전에 자동 보관됩니다. 앞선 선택은 검수용 이력입니다." if not main_menu else "앞선 선택은 검수용 이력입니다. 기존 저장과 감상 기록은 유지됩니다.") size 19 color "#bad6d1"
            hbox:
                spacing 25
                textbutton "이 설정으로 시작":
                    action Function(mrv_launch,draft,not main_menu)
                    sensitive draft["available"] id "mrv_start"
                if renpy.can_load("scene-continue-backup"):
                    textbutton "전환 전 진행 불러오기" action Confirm("전환 전에 보관한 진행을 불러올까요?",Function(renpy.load,"scene-continue-backup")) text_size 20
                textbutton "흐름도로" action ShowMenu("story_flow",year=M21_NODES[sid]["year"],chapter=int(M21_NODES[sid]["chapter"].split("-C")[1]),selected=sid,origin=origin) id "mrv_back"
