default y5_preview_preset = "main"

screen y5_revision_changed():
    modal True
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1000 padding (32,28)
        vbox:
            spacing 24
            text "5학년 대본이 개정되었습니다" style "heading"
            text "이 저장은 개정 전 5–7학년의 진행입니다. 별도 남동생을 삭제하고 습격 경고의 전달자를 바꾸어, 이전 장면의 선택을 새 행동으로 옮길 수 없습니다. 저장 파일은 삭제하지 않았습니다. 4학년 완료 저장이나 개정된 장면 감상에서 시작해 주세요." size 25
            textbutton "처음 화면으로" action Return() id "y5_revision_return"

screen y5_stage(scene_id):
    zorder -5
    $ meta=Y5_SCENES[scene_id]
    add y5_background(scene_id) xysize (1280,720) fit "cover"
    if not vc_hide_standing and y5_portrait in Y5_SPRITES and y5_portrait not in y5_offscreen:
        add y5_sprite(y5_portrait,scene_id) id "y5_speaker_portrait" xpos 0.58 xanchor 0.5
    frame:
        xpos 22 ypos 54 padding (12,7) background Solid("#111e29c9")
        hbox:
            spacing 18
            text (vc_location or meta["location"]) size 22 slow_cps 0
            text meta["time"] size 16 color "#b5c2ca" yalign 0.5 slow_cps 0

screen y5_event_cg(asset_id):
    zorder -4
    add Y5_CGS[asset_id] xysize (1280,720) fit "cover"

screen y5_scene_select(chapter=1):
    tag menu
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1180 ysize 680 padding (24,18)
        vbox:
            spacing 10
            text "5학년 · 챕터와 장면" style "heading"
            hbox:
                spacing 8
                for n in range(1,7):
                    textbutton ("%d장"%n) action ShowMenu("y5_scene_select",chapter=n) selected chapter==n id "y5_tab_%d"%n
            text Y5_TITLES[chapter-1] size 24
            viewport:
                ysize 420 mousewheel True draggable True scrollbars "vertical"
                vbox:
                    spacing 4
                    for sid,meta in Y5_SCENES.items():
                        if meta["number"]==chapter:
                            textbutton (("카리나 사건 경로 · " if sid in Y5_SOURCE_SCENES else "원작 사건 경로 · ")+meta["title"]):
                                xfill True text_size 22 padding (12,6) id "scene_"+sid
                                action [SetVariable("m33_qa",True),ShowMenu("m33_scene_detail",nid=sid)]
            text "감상은 임시 이력으로 진행됩니다. 직접 저장한 게임은 바뀌지 않습니다." size 18 color "#b8dcda"
            hbox:
                spacing 12
                textbutton "학년 선택" action ShowMenu("review_year_select")
                textbutton "돌아가기" action Return()

screen y5_ending():
    modal True
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1080 padding (30,24)
        vbox:
            spacing 18
            if y5_captured():
                text "닫힌 출구" style "heading"
                text "확인 없이 홀로 들어간 함정에서 돌아오지 못했습니다." size 25
                text "흐름도에서 앞선 선택의 체크포인트를 확인할 수 있습니다." size 22
            else:
                text "5학년 · 끝" style "heading"
                text ("시리우스를 잃은 여름이 시작됩니다." if vn["world"]["sirius_status"]=="dead" else "시리우스는 살아 있습니다. 남은 사람들과 다음을 준비합니다.") size 25
                text ("마법부는 볼드모트의 귀환을 인정했습니다." if y5_flag("y5_voldemort_public") else "귀환을 직접 본 공적인 증언은 아직 확보하지 못했습니다.") size 23
                text "친구들과의 약속, 카리나와의 갈등을 안고 6학년으로 이어집니다." size 22
                textbutton "6학년으로" action Return("year6") id "y5_to_y6"
                textbutton "완료 기록 저장" action ShowMenu("save")
            hbox:
                spacing 12
                textbutton "흐름도" action ShowMenu("story_flow",year=5,chapter=5)
                textbutton "감상실" action ShowMenu("story_collection",tab="ending")
                textbutton "처음 화면으로" action Return() id "y5_finish"
