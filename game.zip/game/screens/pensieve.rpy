transform pensieve_monochrome:
    matrixcolor SaturationMatrix(0.0)

screen pensieve_stage():
    zorder -3
    if pensieve_frame:
        fixed:
            at pensieve_monochrome
            add pensieve_background() xysize (1280,720) fit "cover" id "pensieve_background"
            if pensieve_frame["portrait"] and pensieve_frame["cast"].get(pensieve_frame["portrait"]):
                add pensieve_sprite() xpos 0.58 xanchor 0.5 id "pensieve_portrait"
            if pensieve_frame["obscured"]:
                add Solid("#ddddddcc") id "pensieve_obscured"
        frame:
            xpos 22 ypos 54 padding (12,7) background Solid("#171717e8")
            text ("펜시브 · " + pensieve_frame["title"]) size 22 color "#eeeeee" slow_cps 0
