# The engine collects rendered speaker names and text in the current context.
# ShowMenu suspends reading; Return restores the same line or choice.
screen history():
    tag menu
    modal True
    zorder 220
    predict False
    add Solid("#101d29")
    frame:
        align (0.5, 0.5)
        xsize 1160
        ysize 664
        padding (28, 20)
        vbox:
            spacing 12
            hbox:
                spacing 28
                text "대화 로그" style "heading" yalign 0.5
                textbutton "돌아가기" action Return() id "history_return"
            text "최근 500개의 대사와 지문 · L 키로 열고 닫기 · Esc로 돌아가기" style "muted"
            viewport:
                id "history_viewport"
                ysize 500
                yinitial 1.0
                mousewheel True
                draggable True
                pagekeys True
                scrollbars "vertical"
                vbox:
                    spacing 18
                    xfill True
                    for entry in _history_list:
                        vbox:
                            spacing 5
                            if entry.who:
                                text entry.who:
                                    substitute False
                                    size 21
                                    bold True
                                    color entry.who_args.get("color", "#b8dcda")
                            text renpy.filter_text_tags(entry.what, allow=["b", "i", "u", "s", "color"]):
                                substitute False
                                size 25
                                xmaximum 1030
                    if not _history_list:
                        text "아직 기록된 대사가 없습니다." size 25
                        text "이후 읽는 대사와 지문부터 여기에 기록됩니다." style "muted"
    key "game_menu" action Return()
    key "K_l" action Return()
