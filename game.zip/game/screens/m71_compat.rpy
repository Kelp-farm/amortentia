screen m71_viewpoint_changed():
    modal True
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1000 padding (32,28)
        vbox:
            spacing 24
            text "이 장면의 시점이 바뀌었습니다" style "heading"
            text "2학년 마지막 카리나의 독백을 해리가 받는 편지로 바꾸었습니다. 이 장면 안에서 만든 이전 저장은 이어 재생할 수 없습니다. 파일은 보존되며, 직전 열차 장면의 저장이나 새 장면 감상에서 시작할 수 있습니다." size 25
            textbutton "처음 화면으로" action Return()
