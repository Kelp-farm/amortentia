screen m71_viewpoint_changed():
    modal True
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 1000 padding (32,28)
        vbox:
            spacing 24
            text "이전 버전의 저장입니다" style "heading"
            text "이 장면의 내용이 바뀌어 바로 이어갈 수 없습니다. 직전 열차 장면의 저장을 불러오거나 장면 감상을 이용해 주세요. 기존 저장 파일은 그대로 남아 있습니다." size 25
            textbutton "처음 화면으로" action Return()
