screen m33_replay_bar():
    zorder 190
    key "game_menu" action EndReplay(confirm=False)
    key "K_F10" action EndReplay(confirm=False)
    key "K_l" action ShowMenu("history")
    key "K_r" action ShowMenu("affection")
    frame:
        xalign 0.5 ypos 8 padding (18,8)
        hbox:
            spacing 20
            text ("개발용 QA 감상" if m33_request["qa"] else "장면 감상") size 19 color "#b8dcda" yalign 0.5
            text "선택과 진행은 저장되지 않습니다" size 18 yalign 0.5
            textbutton "뒤로" action Rollback() text_size 20 id "m33_rollback"
            textbutton "대화 로그" action ShowMenu("history") text_size 20 id "m33_history"
            textbutton "관계" action ShowMenu("affection") text_size 20 id "m33_affection"
            textbutton "감상 종료 · 흐름도로" action EndReplay(confirm=False) text_size 20 id "m33_exit"

screen m33_unavailable():
    modal True
    add Solid("#14222d")
    frame:
        align (0.5,0.5) xsize 850
        vbox:
            spacing 20
            text "이 이력으로는 열 수 없는 장면입니다" style "heading"
            text "흐름도로 돌아가 다른 QA 이력을 골라 주세요." size 23
            textbutton "돌아가기" action Return() id "m33_unavailable_back"

screen m33_scene_detail(nid,origin=None):
    tag menu
    modal True
    default selected_scene = None
    default selected_preset = None
    default selected_record = 0
    $ qa = m33_qa_enabled()
    $ scene_ids = m33_scenes(nid)
    $ sid = selected_scene if selected_scene in scene_ids else (scene_ids[0] if scene_ids else None)
    $ known = sid and m21_seen_node(sid)
    $ framework = origin or m42_chart_origin()
    $ preferred = [p for p in m33_presets(sid) if p.startswith("main")== (framework=="main")] if sid else []
    $ effective_preset = selected_preset if sid and selected_preset in m33_presets(sid) else ((preferred or m33_presets(sid))[0] if sid and m33_presets(sid) else "standard")
    $ qa_preview=mrv_preview(sid,effective_preset,"main" if effective_preset.startswith("main") else "hidden") if qa and sid and m33_implemented(sid) else None
    add Solid("#101d29")
    frame:
        align (0.5,0.5) xsize 1160 ysize 650 padding (26,22)
        vbox:
            spacing 14
            hbox:
                spacing 18
                text "장면 보기" style "heading"
                if qa:
                    text "개발용 QA · 미발견 장면 포함" size 20 color "#e5c49f" yalign 0.5
            if not sid or not m33_implemented(sid):
                text "구현된 감상 장면이 없습니다." size 25
            elif not known and not qa:
                text "???" size 30
                text "아직 발견하지 않은 장면입니다." size 24
            else:
                $ replay_origin=("main" if effective_preset.startswith("main") else "hidden") if qa else m42_origin(m33_records(sid)[min(selected_record,len(m33_records(sid))-1)]["state"]) if m33_records(sid) else m42_chart_origin()
                text m42_node_title(sid,replay_origin) size 28
                text "장면 감상은 진행을 바꾸지 않습니다. 이어하기는 해당 이력에서 본편을 계속합니다." style "muted"
                if len(scene_ids)>1:
                    hbox:
                        for item in scene_ids:
                            textbutton (M21_NODES[item]["title"] if qa or m21_seen_node(item) else "???") action SetScreenVariable("selected_scene",item)
                viewport:
                    ysize 345 mousewheel True draggable True scrollbars "vertical"
                    vbox:
                        spacing 10
                        if qa_preview:
                            text "카리나 히든루트 조건" size 23
                            use mpr_requirements(qa_preview["state"])
                            if mpr_scene_reason(sid,qa_preview["state"]):
                                text mpr_scene_reason(sid,qa_preview["state"]) size 21 color "#e4c398" xmaximum 1030
                            if not qa_preview["available"]:
                                text qa_preview["note"] size 21 color "#e4ac9c" xmaximum 1030
                            textbutton "전체 조건 보기" action Show("mpr_conditions",state=qa_preview["state"],sid=sid) text_size 20
                        if qa and len(m33_presets(sid)) > 1:
                            text "앞선 이력과 응답을 골라 감상하세요" size 23
                            text "기본 이력은 장면 안에서 직접 선택합니다. 특정 결과 이력은 해당 응답을 바로 보여 줍니다." style "muted" xmaximum 1030
                            for preset in m33_presets(sid):
                                textbutton mpr_preview_title(sid,preset):
                                    action SetScreenVariable("selected_preset",preset)
                                    selected effective_preset==preset
                                    selected_background Solid("#416c70")
                                    xfill True id "m33_preset_"+preset
                        elif qa:
                            text "이 장면은 바로 감상할 수 있습니다." size 23
                            text "장면 안의 대화 선택지는 읽으면서 고를 수 있습니다." style "muted"
                        else:
                            $ records=m33_records(sid)
                            if records:
                                text "직접 읽은 이력" size 23
                                for index,record in enumerate(records):
                                    textbutton ("감상 기록 %d" % (index+1)):
                                        action SetScreenVariable("selected_record",index)
                                        selected selected_record==index
                                        selected_background Solid("#416c70")
                                        xfill True id "m33_record_%d" % index
                                text "당시의 선택 응답을 감상합니다. 다른 결과는 본편에서 경험한 뒤 별도 기록으로 남습니다." style "muted"
                            else:
                                text "감상용 이력이 아직 없습니다" size 25
                                text "이전 버전의 발견 기록은 보존됩니다. 이 버전에서 장면을 끝까지 읽으면 당시의 선택으로 감상할 수 있습니다." size 22 xmaximum 1030
                hbox:
                    spacing 20
                    textbutton "감상하기":
                        action [m33_action(sid,qa,effective_preset,selected_record), ShowMenu("story_flow",year=M21_NODES[nid]["year"],chapter=int(M21_NODES[nid]["chapter"].split("-C")[1]),selected=nid,origin=(("hidden" if nid in Y6_SOURCE_SCENES else "main") if M21_NODES[nid]["year"]==6 else m42_chart_origin()))]
                        sensitive m33_can_view(sid,qa,selected_record) and (not qa or qa_preview["available"])
                        xsize 300 id "m33_watch"
                    textbutton "이 선택으로 변경":
                        action (Function(mpr_review_launch,sid,effective_preset,replay_origin) if qa else Function(mpr_record_launch,sid,selected_record))
                        sensitive (qa_preview["available"] if qa else bool(m33_records(sid))) and not m33_active()
                        xsize 280 id "mpr_detail_apply"
                    textbutton "여기서 이어하기":
                        action ShowMenu("msc_scene_continue",sid=sid,preferred=(msc_record_key(m33_records(sid)[selected_record]) if 0 <= selected_record < len(m33_records(sid)) else None))
                        sensitive bool(known and not m33_active())
                        xsize 330 id "msc_detail"
            textbutton "돌아가기 · 흐름도" action ShowMenu("story_flow",year=M21_NODES[nid]["year"],chapter=int(M21_NODES[nid]["chapter"].split("-C")[1]),selected=nid,origin=(("hidden" if nid in Y6_SOURCE_SCENES else "main") if M21_NODES[nid]["year"]==6 else m42_chart_origin())) id "m33_back"
    key "game_menu" action ShowMenu("story_flow",year=M21_NODES[nid]["year"],chapter=int(M21_NODES[nid]["chapter"].split("-C")[1]),selected=nid,origin=(("hidden" if nid in Y6_SOURCE_SCENES else "main") if M21_NODES[nid]["year"]==6 else m42_chart_origin()))

screen m4e_review_detail(sid):
    tag menu
    default selected_preset = None
    $ variants = m33_presets(sid)
    $ preferred = mrv_presets(sid,m42_chart_origin())
    $ preset = selected_preset if selected_preset in variants else preferred[0]
    $ preview=mrv_preview(sid,preset,"main" if preset.startswith("main") else "hidden")
    $ node = M21_NODES[sid]
    $ chapter = int(node["chapter"].split("-C")[1])
    add Solid("#101d29")
    frame:
        align (0.5,0.5) xsize 1100 ysize 640 padding (28,24)
        vbox:
            spacing 18
            text m42_node_title(sid,"main" if preset.startswith("main") else "hidden") style "heading"
            text "장면 직전까지의 임시 이력으로 새로 시작합니다. 이후에는 본편으로 이어집니다." size 22
            viewport:
                ysize 350 mousewheel True draggable True scrollbars "vertical"
                vbox:
                    spacing 10
                    text "카리나 히든루트 조건" size 23
                    use mpr_requirements(preview["state"])
                    if mpr_scene_reason(sid,preview["state"]):
                        text mpr_scene_reason(sid,preview["state"]) size 21 color "#e4c398" xmaximum 1000
                    if not preview["available"]:
                        text preview["note"] size 21 color "#e4ac9c" xmaximum 1000
                    textbutton "전체 조건 보기" action Show("mpr_conditions",state=preview["state"],sid=sid) text_size 20
                    if len(variants)>1:
                        text "장면에 필요한 앞선 이력" size 23
                        for variant in variants:
                            textbutton mpr_preview_title(sid,variant):
                                action SetScreenVariable("selected_preset",variant)
                                selected preset==variant
                                xfill True id "m4e_variant_"+variant
                    else:
                        text "이 장면은 별도의 분기 설정 없이 시작할 수 있습니다." size 24
                        text "대화 중의 선택지는 읽으면서 고릅니다." style "muted"
            $ start_action = [SetVariable("m4e_start_sid",sid),SetVariable("m4e_start_preset",preset),Start("m4e_review_start")]
            textbutton "이 장면부터 시작":
                action Function(mpr_review_launch,sid,preset,"main" if preset.startswith("main") else "hidden")
                sensitive preview["available"]
                id "m4e_start_scene"
            textbutton "장면 목록으로" action ShowMenu("y%d_scene_select"%node["year"],chapter=chapter) id "m4e_review_back"
    key "game_menu" action ShowMenu("y%d_scene_select"%node["year"],chapter=chapter)

default m4e_start_sid = None
default m4e_start_preset = None

label m4e_review_start:
    if not m33_developer_available():
        return
    $ M33_QA_BUILDERS[M21_NODES[m4e_start_sid]["year"]](m4e_start_sid,M33_QA_PRESETS[m4e_start_preset])
    if M21_NODES[m4e_start_sid]["year"] == 1:
        jump y1_review_continue
    elif M21_NODES[m4e_start_sid]["year"] == 2:
        jump y2_continue
    elif M21_NODES[m4e_start_sid]["year"] == 3:
        jump y3_continue
    elif M21_NODES[m4e_start_sid]["year"] == 5:
        jump y5_continue
    elif M21_NODES[m4e_start_sid]["year"] == 6:
        jump y6_continue
    elif M21_NODES[m4e_start_sid]["year"] == 7:
        jump y7_continue
    else:
        jump y4_continue
