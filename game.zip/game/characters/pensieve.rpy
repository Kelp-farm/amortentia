# Memory presentation is transient, rollbackable and separate from world state.
default pensieve_frame = None

init -5 python:
    PENSIEVE_ROOT = "images/production/pensieve/"
    PENSIEVE_NEW_CAST = {
        "snape_student": (176, 18, 1515), "lily_student": (164, 18, 1515),
        "james_student": (176, 18, 1515), "riddle_child": (142, 18, 1515),
        "riddle_student": (176, 18, 1515), "marvolo": (165, 18, 1515),
        "slughorn_memory": (163, 18, 1515),
    }

    def pensieve_begin(sid, title, background, cast, portrait=None, obscured=False):
        if not sid.startswith(("Y4-", "Y6-", "Y7-")) or sid not in {"Y4":Y4_SCENES,"Y6":Y6_SCENES,"Y7":Y7_SCENES}[sid[:2]]:
            raise ValueError("Unknown Pensieve scene")
        if portrait is not None and portrait not in cast:
            raise ValueError("Memory portrait must belong to this memory")
        store.pensieve_frame = dict(scene=sid, title=title, background=background,
            cast=dict(cast), portrait=portrait, obscured=obscured)

    def pensieve_speaker(member):
        frame = dict(store.pensieve_frame)
        if member == "harry":
            return  # The observing Harry has no standing in the memory.
        frame["portrait"] = member if frame["cast"].get(member) else None
        store.pensieve_frame = frame

    def pensieve_end():
        store.pensieve_frame = None

    def pensieve_background():
        key = store.pensieve_frame["background"]
        if key == "orphanage":
            return PENSIEVE_ROOT + "bg_orphanage.png"
        if key == "gaunt_hut":
            return vc_background("hut")
        if key == "school_lake":
            return vc_background("lawn")
        if key == "school_corridor":
            return "images/production/m2/corridor.webp"
        if key == "potions":
            return Y3_ART_ROOT + "bg_potions.png"
        if key in Y6_NEW_BACKGROUNDS:
            return Y6_ART_ROOT + "bg_" + key + ".png"
        if key == "requirement":
            return Y5_ART_ROOT + "bg_requirement.png"
        return vc_background(key)

    def pensieve_cast_sprite(variant):
        height, crown, ground = PENSIEVE_NEW_CAST[variant]
        zoom = (height + 2) * 6.4 / float(ground - crown)
        # Fixed dialogue lens; framing does not depend on the live roster.
        floor = max(1200, 64 + (ground-crown) * zoom)
        return Transform(PENSIEVE_ROOT + variant + ".png", crop=(0,0,1024,1536), zoom=zoom,
            ypos=int(floor), yanchor=ground/1536.0)

    def pensieve_sprite():
        frame = store.pensieve_frame
        variant = frame["cast"][frame["portrait"]]
        if variant in PENSIEVE_NEW_CAST:
            return pensieve_cast_sprite(variant)
        sid = frame["scene"]
        if variant == "bellatrix": return y5_sprite(variant, sid)
        if sid.startswith("Y4-"): return y4_sprite(variant, sid)
        return y6_sprite(variant, sid) if sid.startswith("Y6-") else y7_sprite(variant, sid)

init python:
    config.overlay_screens.append("pensieve_stage")

define memory_snape = Character("세베루스 스네이프", callback=y1_speaker_callback("snape"))
define memory_lily = Character("릴리 에번스", callback=y1_speaker_callback("lily"))
define memory_james = Character("제임스 포터", callback=y1_speaker_callback("james"))
define memory_marvolo = Character("마볼로 곤트", callback=y1_speaker_callback("marvolo"))
define memory_ogden = Character("오그던", callback=y1_speaker_callback("ogden"))
define memory_merope = Character("메로프", callback=y1_speaker_callback("merope"))
define memory_slughorn = Character("슬러그혼 교수", callback=y1_speaker_callback("slughorn"))
define memory_harry = Character("기억 속 해리", callback=y1_speaker_callback("harry"))
define memory_riddle_voice = Character("해리의 목소리", callback=y1_speaker_callback("riddle_voice"))

define memory_lupin_student = Character("어린 리무스 루핀", callback=y1_speaker_callback("lupin_student"))
define memory_school_friend = Character("친구의 목소리", callback=y1_speaker_callback("school_friend"))
