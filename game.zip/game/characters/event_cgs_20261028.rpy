# The original 14 CGs, Year 3 replacement, and Oct 29 ferret CG are owner-approved.
init 2 python:
    EVENT_CG_ROOT = "images/production/events_20261028/"
    Y1_CGS["carina_forest"] = EVENT_CG_ROOT + "carina_forest.webp"
    Y2_CGS.update({key: EVENT_CG_ROOT + key + ".webp" for key in
        ("carina_sleeve", "hermione_stone", "hermione_cat")})
    Y3_CGS["carina_reach"] = EVENT_CG_ROOT + "carina_reach.webp"
    Y3_CGS["pursuit_kiss"] = EVENT_CG_ROOT + "pursuit_kiss.webp"
    Y3_CGS["carina_meal"] = EVENT_CG_ROOT + "carina_meal.webp"
    Y4_CGS["carina_tent"] = EVENT_CG_ROOT + "carina_tent.webp"
    Y4_CGS["egg_corridor"] = EVENT_CG_ROOT + "egg_corridor.webp"
    Y4_CGS["carina_ferret"] = "images/production/events_20261029/carina_ferret.webp"
    Y5_CGS.update({key: EVENT_CG_ROOT + key + ".webp" for key in
        ("ginny_practice", "ginny_waiting", "luna_practice", "carina_supervisor")})
    Y6_CGS["memory_handoff"] = EVENT_CG_ROOT + "memory_handoff.webp"
    Y7_CGS["luna_cellar"] = EVENT_CG_ROOT + "luna_cellar.webp"
