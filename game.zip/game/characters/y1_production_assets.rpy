# M1.4R: heroine-led prototype art; user approval remains separate.
init -14 python:
    import json
    import datetime
    import re
    with renpy.file("characters/height_standards.json") as _height_file:
        Y1_HEIGHTS = json.load(_height_file)
    Y1_ART_ROOT = "images/production/m14r/"
    Y1_REVISED_ART_ROOT = "images/production/m14s/"
    # Stable union crops across expressions. Calibration uses anatomical crown,
    # not hair tips; virtual floor and pixels/cm are shared by every student.
    Y1_SPRITE_CROPS = {"carina": (195, 0, 638, 1536),
        "hermione": (205, 0, 643, 1536), "ron": (206, 0, 630, 1536),
        "ginny": (205, 0, 650, 1536)}
    Y1_CALIBRATION = {"carina": (36, 1515), "hermione": (40, 1517), "ron": (35, 1517),
        "ginny": (18, 1517)}
    Y1_CGS = {key: Y1_ART_ROOT + key + ".webp" for key in
        ("first_encounter", "trio_friendship", "potion_farewell", "year_end")}
    Y1_CGS.update({key: Y1_REVISED_ART_ROOT + key + ".webp" for key in ("first_encounter", "year_end")})
    Y1_CGS["reunion_hug"] = "images/production/m14x/reunion_hug.webp"
    Y1_CGS["train_offered_hand"] = "images/production/m31k/train_offered_hand.png"
    Y1_CGS["first_flight"] = "images/production/m733/first_flight.webp"
    Y1_CGS["trio_friendship_before"] = "images/production/m733/trio_friendship_before.webp"
    Y1_CG_NAMES = {"first_encounter": "처음 불러 본 이름", "trio_friendship": "셋으로 나눈 아침",
        "potion_farewell": "손을 놓기 전에", "reunion_hug": "의무실의 포옹", "year_end": "다음 학기에 봐",
        "train_offered_hand": "잡지 않은 손", "first_flight": "와서 가져가 봐"}
    Y1_BACKGROUNDS = {"Y1-C1-S03": Y1_REVISED_ART_ROOT + "malkin.webp",
        "Y1-C1-S02": "images/production/m3d/diagon_alley.png",
        "Y1-C1-S06": "images/production/m3/bg_train.png",
        "Y1-C2-S03": "images/production/courtyard.webp",
        "Y1-C4-S01": "images/production/library.webp"}
    Y1_GUARDED_SCENES = {"Y1-C1-S06", "Y1-C2-S02", "Y1-C2-S03", "Y1-C2-S04", "Y1-C2-S06", "Y1-C2-S07", "Y1-C4-S02", "Y1-C4-S03", "Y1-C4-S04", "Y1-C3-S10", "Y1-C4-S14"}
    Y1_THOUGHTFUL_SCENES = {"Y1-C2-S07", "Y1-C3-S01", "Y1-C3-S04", "Y1-C4-S02", "Y1-C4-S05", "Y1-C4-S12"}
    def y1_visible_members(scene_id, focus=None):
        meta = Y1_SCENES[scene_id]
        candidates = focus if focus is not None else ([store.y1_portrait] if store.y1_active_scene == scene_id else [])
        return [m for m in candidates if m in vc_participants(scene_id)
            and m != meta["pov"] and m != "harry" and (m in Y1_SPRITE_CROPS or m31_has_sprite(m, 1))][:1]
    def y1_height_cm(member, scene_id):
        date_text = Y1_SCENES[scene_id]["time"]
        parts = re.match(r"(\d{4})-(\d{2})(?:-(\d{2}))?", date_text)
        year, month, day = parts.groups()
        date = datetime.date(int(year), int(month), int(day or 15))
        fraction = max(0.0, min(1.0, (date - datetime.date(2026, 9, 1)).days / 365.0))
        heights = Y1_HEIGHTS["students"][member]["heights_cm"]
        return heights["Y1_start"] + (heights["Y2_start"] - heights["Y1_start"]) * fraction
    def y1_production_sprite(member, expression="neutral", scene_id="Y1-C2-S01"):
        if member == "carina" and expression == "crying":
            crown, floor = Y1_CALIBRATION[member]
            return m31_standing("images/production/m733/carina_y1_crying.webp",
                member, scene_id, Y1_SPRITE_CROPS[member], crown, floor)
        if vc_has_asset(member, scene_id):
            return vc_sprite(member, scene_id)
        if m31_has_sprite(member, 1):
            return m31_support_sprite(member, scene_id)
        crown, floor = Y1_CALIBRATION[member]
        if member == "ginny":
            # Before her own first year: the established casual outfit, scaled
            # to her Y1 date/height. Never fall through to a school uniform.
            return m31_standing("images/production/m2/ginny_casual.webp",
                member, scene_id, Y1_SPRITE_CROPS[member], crown, floor)
        art_root = Y1_REVISED_ART_ROOT if member == "carina" else Y1_ART_ROOT
        return m31_standing(art_root + member + "_" + expression + ".webp",
            member, scene_id, Y1_SPRITE_CROPS[member], crown, floor)
    def y1_sprite_expression(scene_id, member, overrides):
        if scene_id == "Y1-C1-S03" and member == "carina":
            return "fitting"
        if member in overrides:
            return overrides[member]
        if member == "carina" and scene_id in Y1_GUARDED_SCENES:
            return "guarded"
        if member in ("carina", "hermione") and scene_id in Y1_THOUGHTFUL_SCENES:
            return "thoughtful"
        return "neutral"
    def y1_sprite_position(index, total):
        return 0.58 if total == 1 else (0.31, 0.71)[index]
