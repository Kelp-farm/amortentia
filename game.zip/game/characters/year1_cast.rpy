default y1_active_scene = None
default y1_portrait = None

init -15 python:
    def y1_speaker_callback(member):
        def update(event, **kwargs):
            if event != "begin" or not store.vn["flags"].get("y1_campaign"):
                return
            if getattr(store,"pensieve_frame",None):
                pensieve_speaker(member)
                return
            if store.vn["flags"].get("y7_campaign"):
                y7_speaker(member)
                return
            if store.vn["flags"].get("y6_campaign"):
                y6_speaker(member)
                return
            if store.vn["flags"].get("y5_campaign"):
                y5_speaker(member)
                return
            if store.vn["flags"].get("y4_campaign"):
                y4_speaker(member)
                return
            if store.vn["flags"].get("y3_campaign"):
                y3_speaker(member)
                return
            if store.vn["flags"].get("y2_campaign"):
                y2_speaker(member)
                return
            scene_id = store.y1_active_scene
            if scene_id not in Y1_SCENES:
                return
            meta = Y1_SCENES[scene_id]
            if member == meta["pov"]:
                return
            store.y1_portrait = member if (member in Y1_SPRITE_CROPS or m31_has_sprite(member, 1)) and member in meta["participants"] else None
        return update

# Separate Korean display names keep the existing English M0 demo intact.
define yh = Character("해리", color="#bcd8d1", callback=y1_speaker_callback("harry"))
define yr = Character("론", color="#e8b49b", callback=y1_speaker_callback("ron"))
define ye = Character("헤르미온느", color="#dfc799", callback=y1_speaker_callback("hermione"))
define yk = Character("카리나", color="#b6dbc3", callback=y1_speaker_callback("carina"))
define yvi = Character("빅토리아 크래브", color="#c6d4b0", callback=y1_speaker_callback("victoria"))
define yga = Character("그레이스 고일", color="#b4cbbb", callback=y1_speaker_callback("grace"))
define ypc = Character("퍼시벌 파킨슨", color="#bbc4d6", callback=y1_speaker_callback("percival"))
define yg = Character("해그리드", callback=y1_speaker_callback("hagrid"))
define yv = Character("버넌 이모부", callback=y1_speaker_callback("vernon"))
define yp = Character("페투니아 이모", callback=y1_speaker_callback("petunia"))
define ydud = Character("더들리", callback=y1_speaker_callback("dudley"))
define ygr = Character("그립훅", callback=y1_speaker_callback("griphook"))
define ym = Character("마담 말킨", callback=y1_speaker_callback("malkin"))
define yo = Character("올리밴더", callback=y1_speaker_callback("ollivander"))
define ymo = Character("몰리 위즐리", callback=y1_speaker_callback("molly"))
define yi = Character("지니", callback=y1_speaker_callback("ginny"))
# Use these only before Harry can identify the speaker by name. Keeping the
# reveal in the script also restores the right label on load, rollback and
# scene review, without a global discovery flag leaking across playthroughs.
# Inherit the real speaker's callback and styling so the portrait stays right.
define yr_unknown = Character("???", kind=yr)
define ye_unknown = Character("???", kind=ye)
define yk_unknown = Character("???", kind=yk)
define yi_unknown = Character("???", kind=yi)
define yf = Character("프레드", callback=y1_speaker_callback("fred"))
define yge = Character("조지", callback=y1_speaker_callback("george"))
define yn = Character("네빌", callback=y1_speaker_callback("neville"))
define ymc = Character("맥고나걸 교수", callback=y1_speaker_callback("mcgonagall"))
define yd = Character("덤블도어", callback=y1_speaker_callback("dumbledore"))
define ys = Character("스네이프 교수", callback=y1_speaker_callback("snape"))
define yho = Character("후치 부인", callback=y1_speaker_callback("hooch"))
define yw = Character("우드", callback=y1_speaker_callback("wood"))
define yfl = Character("플리트윅 교수", callback=y1_speaker_callback("flitwick"))
define ype = Character("퍼시", callback=y1_speaker_callback("percy"))
define yq = Character("퀴렐 교수", callback=y1_speaker_callback("quirrell"))
define yfil = Character("필치", callback=y1_speaker_callback("filch"))
define ypo = Character("폼프리 부인", callback=y1_speaker_callback("pomfrey"))
define yfr = Character("피렌체", callback=y1_speaker_callback("firenze"))
define yvo = Character("볼드모트", callback=y1_speaker_callback("voldemort"))
