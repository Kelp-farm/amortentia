init -6 python:
    Y6_ART_ROOT="images/production/m6/"
    Y6_SPRITES=Y5_SPRITES+("slughorn","kingsley")
    Y6_CGS={k:Y6_ART_ROOT+k+".png" for k in ("carina_tower","last_protection","carina_reunion")}
    Y6_CGS["night_visit"] = Y6_ART_ROOT+"carina_night_visit_v2.png"
    Y6_NEW_BACKGROUNDS=("cave","island","island_room","shop")
    def y6_background(sid):
        key=store.vc_background_key or Y6_SCENES[sid]["bg"]
        if key=="manor_guestroom_night": return Y6_ART_ROOT+"bg_manor_guestroom_night_v1.png"
        if key in Y6_NEW_BACKGROUNDS: return Y6_ART_ROOT+"bg_"+key+".png"
        if key in Y5_NEW_BACKGROUNDS and key!="alley": return Y5_ART_ROOT+"bg_"+key+".png"
        if key in Y4_BG_REUSE: return Y4_BG_REUSE[key]
        if key=="potions": return Y3_ART_ROOT+"bg_potions.png"
        return vc_background({"diagon":"alley","hagrid":"hut"}.get(key,key))
    def y6_speaker(member):
        sid=store.y6_active_scene
        if sid not in Y6_SCENES or member=="harry": return
        store.y6_portrait=member if member in Y6_SPRITES and member in Y6_SCENES[sid]["participants"] and member not in store.y6_offscreen else None
    def y6_sprite(member,sid):
        if member in Y7_PORTRAITS: return late_student_sprite(member,sid)
        if member not in ("slughorn","kingsley"): return y5_sprite(member,sid)
        ground=1510; crown=20
        zoom=6.4*({"slughorn":163,"kingsley":190}[member])/(ground-crown)
        floor=max(m31_sprite_floor("harry",sid),56+ground*zoom)
        if member == "kingsley":
            # Fix the full-body source bounds before scaling, as for the cast atlases.
            return Transform(Y6_ART_ROOT+member+".png",crop=(0,0,1024,1536),zoom=zoom,ypos=int(floor),yanchor=ground/1536.0)
        return Transform(Y6_ART_ROOT+member+".png",zoom=zoom,ypos=int(floor),yanchor=ground/1536.0)

define ysl = Character("슬러그혼 교수",callback=y1_speaker_callback("slughorn"))
define y6su = Character("수잔 본즈",callback=y1_speaker_callback("susan"))
define y6le = Character("리앤",callback=y1_speaker_callback("leanne"))
define y6na = Character("나시사 말포이",callback=y1_speaker_callback("narcissa"))
define y6ki = Character("킹슬리",callback=y1_speaker_callback("kingsley"))
