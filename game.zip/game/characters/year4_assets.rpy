init -8 python:
    Y4_ART_ROOT="images/production/m4/"
    Y4_CGS={k:Y4_ART_ROOT+k+".png" for k in (
        "practice_carina","practice_hermione","practice_ginny","practice_luna",
        "ball_carina","ball_hermione","ball_ginny","ball_luna","separation","graveyard","letter")}
    Y4_NEW_CAST=("cedric","cho","krum","fleur","moody","crouch","crouch_jr","snape")
    Y4_CGS["cloak_date"]="images/production/m71/cloak_date.png"
    Y4_SPRITES=Y3_SPRITES+Y4_NEW_CAST
    Y4_ATLAS_CAST={h:("students",i) for i,h in enumerate(("cedric","cho","krum","fleur"))}
    Y4_ATLAS_CAST.update({h:("adults",i) for i,h in enumerate(("moody","crouch","crouch_jr","snape"))})
    Y4_FORMAL_BOYS={h:i for i,h in enumerate(("cedric","harry","ron","krum"))}
    Y4_FORMAL_GIRLS={"cho":0,"fleur":1}
    Y4_NEW_CALIBRATION={"cedric":(24,991),"cho":(99,990),"krum":(22,997),"fleur":(65,990),
        "moody":(25,989),"crouch":(19,996),"crouch_jr":(24,993),"snape":(20,1000)}
    Y4_FORMAL_CALIBRATION={"cedric":(17,997),"harry":(86,995),"ron":(65,991),"krum":(16,996),
        "cho":(25,1008),"fleur":(15,1008),"carina":(15,1520),"hermione":(18,1518)}
    Y4_BG_ATLAS={"classroom":("rooms",0),"hall":("rooms",1),"common":("rooms",2),"office":("rooms",3),
        "camp":("outside",0),"arena":("outside",1),"maze":("outside",2),"graveyard":("outside",3)}
    Y4_BG_REUSE={"forest":Y3_ART_ROOT+"bg_forest.png","train":Y3_ART_ROOT+"bg_train.png",
        "infirmary":Y3_ART_ROOT+"bg_infirmary.png","lake":Y3_ART_ROOT+"bg_lake.png",
        "courtyard":"images/production/courtyard.webp","library":"images/production/library.webp",
        "corridor":"images/production/m2/corridor.webp",
        "corridor_winter":"images/production/m71/bg_corridor_winter.png"}

    def y4_background(sid):
        key=store.y4_bg_override or Y4_SCENES[sid]["bg"]
        if key=="forest_night": return vc_background(key)
        if key in Y4_BG_ATLAS:
            atlas,index=Y4_BG_ATLAS[key]
            return Transform(Y4_ART_ROOT+"bg_"+atlas+".png",crop=((index%2)*768,(index//2)*512,768,512),xysize=(1280,720),fit="cover")
        if key in ("tent","underwater"):
            return Transform(Y4_ART_ROOT+"bg_water_tent.png",crop=(0,0 if key=="underwater" else 512,1536,512),xysize=(1280,720),fit="cover")
        return Y4_BG_REUSE.get(key,Y4_ART_ROOT+"bg_"+key+".png")

    def y4_speaker(member):
        sid=store.y4_active_scene
        if sid not in Y4_SCENES or member=="harry": return
        store.y4_portrait=member if member in Y4_SPRITES and member in vc_participants(sid) and member not in store.y4_offscreen else None

    def y4_sprite(member,sid):
        formal=m31_meta(sid)["outfit"]=="formal"
        if not formal and vc_has_asset(member, sid):
            return vc_sprite(member, sid)
        if formal and member in M733_YULE_FORMAL:
            path=M733_YULE_ROOT+member+"_formal.webp"
            crop=(0,0,1024,1536);crown,ground=M733_YULE_FORMAL[member]
        elif member in ("ginny","luna"):
            path=Y4_ART_ROOT+member+"_atlas.png"
            crop=(768 if formal else 0,0,768,1024)
            crown,ground=16,1010
        elif formal and member in ("carina","hermione"):
            path=Y4_ART_ROOT+member+"_formal.png"
            crop=(0,0,1024,1536);crown,ground=Y4_FORMAL_CALIBRATION[member]
        elif formal and member in Y4_FORMAL_BOYS:
            path=Y4_ART_ROOT+"formal_boys.png"
            crop=(Y4_FORMAL_BOYS[member]*384,0,384,1024);crown,ground=Y4_FORMAL_CALIBRATION[member]
        elif formal and member in Y4_FORMAL_GIRLS:
            path=Y4_ART_ROOT+"formal_guests.png"
            crop=(Y4_FORMAL_GIRLS[member]*768,0,768,1024);crown,ground=Y4_FORMAL_CALIBRATION[member]
        elif member in Y4_ATLAS_CAST:
            atlas,index=Y4_ATLAS_CAST[member]
            path=Y4_ART_ROOT+atlas+".png"
            crop=(index*384,0,384,1024);crown,ground=Y4_NEW_CALIBRATION[member]
            if member=="moody": crop=(0,0,426,1024)
            elif member=="crouch": crop=(426,0,370,1024)
        else:
            return y3_sprite(member,sid)
        geometry=m31_standing_geometry(member,sid,crop,crown,ground)
        if member in Y4_NEW_CAST:
            geometry["ypos"]=int(max(geometry["ypos"],56+(ground-crop[1])*geometry["zoom"]))
        return Transform(path,crop=crop,**geometry)

    def y4_music(sid):
        return "audio/ost/"+m43_scene_track(sid)+".ogg"

define yal = Character("무디 교수",callback=y1_speaker_callback("moody"))
define ycr = Character("바티 크라우치",callback=y1_speaker_callback("crouch"))
define ycj = Character("바티 크라우치 주니어",callback=y1_speaker_callback("crouch_jr"))
define ykr = Character("빅토르 크룸",callback=y1_speaker_callback("krum"))
define yfd = Character("플뢰르 들라쿠르",callback=y1_speaker_callback("fleur"))
define ych = Character("초 챙",callback=y1_speaker_callback("cho"))
define yzs = Character("자카리아스 스미스",callback=y1_speaker_callback("zacharias"))

define ycc = Character("콜린 크리비",callback=y1_speaker_callback("colin"))

define review_lee = Character("리 조던", callback=y1_speaker_callback("lee"))

define review_bagman = Character("루도 배그먼", callback=y1_speaker_callback("bagman"))
