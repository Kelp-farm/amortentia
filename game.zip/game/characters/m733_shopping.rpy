# Clothing is presentation state; Y6_H_SHOP remains the sole historical choice.
init 0 python:
    M733_SHOP_ROOT = "images/production/m733/shopping/"
    # Retain the recorded third-choice ID; its approved design is now H-line.
    M733_SHOP_FILES = {"jeans":"jeans.webp", "skirt":"skirt.webp", "trousers":"hline.webp"}
    M733_SHOP_FOLLOWUPS = ("Y6-C7-S11", "Y6-C7-S12", "Y6-C7-S13")

    def m733_shopping_outfit(member, sid):
        if member != "carina":
            return None
        if sid == "Y6-C6-S15":
            outfit = getattr(store, "m733_shop_tryon", None)
            return outfit if outfit in M733_SHOP_GEOMETRY and chose("Y6_H_SHOP",outfit) else None
        if sid in M733_SHOP_FOLLOWUPS:
            return next((outfit for outfit in M733_SHOP_GEOMETRY if chose("Y6_H_SHOP",outfit)),None)
        # Never replace school, nightwear, or adult epilogue portraits globally.
        return None

default m733_shop_tryon = None

label m733_try_on(outfit):
    $ m733_shop_tryon = outfit
    $ y6_portrait = "carina"
    with Dissolve(0.25)
    return
