init -1 python:
    # Functional private-room staging while the dedicated D50 background remains deferred.
    # Crop the existing night room's bed out; never use DA practice dummies here.
    VC_REUSE["private_requirement"]=Transform(Y6_ART_ROOT+"bg_manor_guestroom_night_v1.png",crop=(0,0,1400,941),xysize=(1280,720),fit="cover")
    Y4_CGS["memory_farewell"]="images/production/m732/memory_farewell.png"
    Y7_CGS["memory_restoration"]="images/production/m732/memory_restoration.png"
    Y7_CGS["memory_renewal"]="images/production/m732/memory_renewal.png"
