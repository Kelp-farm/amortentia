# M7.3.3: art only; no story state or audio changes.
init 0 python:
    M733_ART_ROOT = "images/production/m733/"
    M733_EXPRESSIONS = ("neutral","slight_smile","annoyed","surprised","concerned","serious")
    # Scene-specific acting only. Explicit existing expression overrides win.
    M733_SCENE_EXPRESSIONS = {
        ("victoria","Y1-C1-S07"):"surprised",
        ("victoria","Y1-C2-S02"):"concerned",
        ("grace","Y1-C2-S02"):"serious",
        ("victoria","Y1-C4-S14"):"slight_smile",
        ("victoria","Y3-C1-S03"):"concerned",
        ("victoria","Y3-C3-S04"):"concerned",
        ("victoria","Y3-C4-S04"):"serious",
        ("victoria","Y4-C2-S03"):"concerned",
    }
    def m733_sprite_key(member, sid):
        year=int(sid[1])
        band="young" if year<=2 else "middle" if year<=5 else "late"
        expressions=getattr(store,"y%d_expressions"%year,{})
        expression=expressions.get(member,M733_SCENE_EXPRESSIONS.get((member,sid),"neutral"))
        expression={"smile":"slight_smile","alternate":"serious","worried":"concerned","angry":"annoyed"}.get(expression,expression)
        if expression not in M733_EXPRESSIONS: expression="neutral"
        return member+"_"+band+"_"+expression

    def m733_support_sprite(member, sid):
        key=m733_sprite_key(member,sid)
        crop,crown,waist=M733_SPRITE_GEOMETRY[key]
        # These images end at the waist. Never scale that edge as a shoe floor.
        band=key.split("_")[1]
        span={"young":65.0,"middle":74.0,"late":78.0}[band]
        zoom=span*m31_pixels_per_cm(sid)/(waist-crown)
        crown_y=m31_sprite_floor(member,sid)-(m31_height(member,sid)+2.0)*m31_pixels_per_cm(sid)
        return Transform(M733_ART_ROOT+key+".webp",crop=crop,zoom=zoom,
            ypos=int(round(crown_y-crown*zoom)),yanchor=0)

    Y3_CGS["carina_reach"]=M733_ART_ROOT+"carina_reach.webp"
    Y5_CGS["ginny_victory"]=M733_ART_ROOT+"ginny_victory.webp"
    Y5_CGS["da_practice"]=M733_ART_ROOT+"da_practice.webp"
    Y6_CGS["luna_confession"]=M733_ART_ROOT+"luna_confession.webp"
    Y6_CGS["hermione_confession"]=M733_ART_ROOT+"hermione_confession.webp"
    # Owner selected the short-arm first-person embrace; expression changes in-place.
    Y4_CGS["memory_farewell"]=M733_ART_ROOT+"memory_farewell.webp"
    Y4_CGS["memory_startled"]=M733_ART_ROOT+"memory_startled.webp"
    Y6_CGS["tower_death"]=M733_ART_ROOT+"tower_death.webp"
    VC_REUSE["private_requirement"]=M733_ART_ROOT+"private_requirement.webp"
