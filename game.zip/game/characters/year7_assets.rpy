# Years 6-7 share late-adolescent portraits; years 1-5 keep their own art.
init -6 python:
    Y7_ART_ROOT = "images/production/m7/"
    Y7_SPRITES = tuple(Y6_SPRITES)
    Y7_PORTRAITS = ("carina", "hermione", "ginny", "luna", "ron")
    Y7_CGS = {k:Y7_ART_ROOT+v+".png" for k,v in {
        "manor_carina":"manor_carina_v2", "camp_hermione":"camp_hermione",
        "battle_friends":"battle_friends", "apology":"apology_ministry_v2",
        "star_carina":"star_carina", "star_carina_harry":"star_carina_harry",
        "star_hermione":"star_hermione", "star_ginny":"star_ginny", "star_luna":"star_luna",
        "family_carina":"family_carina", "family_hermione":"family_hermione",
        "family_ginny":"family_ginny_v2", "family_luna":"family_luna",
        "hidden_awakening":"hidden_awakening_school_v2", "hidden_soul":"hidden_soul",
        "hidden_future":"hidden_future", "family_carina_hidden":"family_carina_hidden"}.items()}
    Y7_BACKGROUNDS = {k:"bg_"+k for k in ("cafe","old_house","cell","shore","cottage","vault",
        "ravenclaw","ruins","burning_room","limbo","tower_night","lovegood","trunk","graves","home","teashop",
        "burrow_attic","burrow_yard","wedding_tent")}
    Y7_BACKGROUNDS.update(camp="bg_camp_v2",tent="bg_tent_v2")
    Y7_CALIBRATION = {"carina_casual":(12,1518),"carina_school":(12,1520),"carina_nightwear":(11,1527),
        "hermione_casual":(15,1515),"hermione_school":(12,1522),
        "ginny_casual":(12,1518),"ginny_school":(12,1523),
        "luna_casual":(12,1521),"luna_school":(12,1522),"ron_casual":(12,1524)}

    def y7_background(sid):
        key = store.vc_background_key or Y7_SCENES[sid]["bg"]
        if key in Y7_BACKGROUNDS: return Y7_ART_ROOT+Y7_BACKGROUNDS[key]+".png"
        if key == "graveyard":
            return Transform(Y4_ART_ROOT+"bg_outside.png",crop=(768,512,768,512),xysize=(1280,720),fit="cover")
        if key in Y5_NEW_BACKGROUNDS: return Y5_ART_ROOT+"bg_"+key+".png"
        if key in Y4_BG_REUSE: return Y4_BG_REUSE[key]
        return vc_background({"common_room":"common"}.get(key,key))

    def y7_speaker(member):
        sid = store.y7_active_scene
        if sid not in Y7_SCENES: return
        # Distant family scenes use adult CGs, never school-age portraits.
        eligible = Y7_SCENES[sid]["time"] < "2040" and member != "harry"
        store.y7_portrait = member if eligible and member in Y7_SPRITES and member in Y7_SCENES[sid]["participants"] and member not in store.y7_offscreen else None

    def late_student_outfit(member,sid):
        meta = m31_meta(sid)
        if member == "carina" and sid == "Y6-C7-S14": return "nightwear"
        if member == "ron": return "casual"
        if sid.startswith("Y6"):
            # M6 metadata defaults to school clothes even in the summer
            # and the established Malfoy-family holiday scenes.
            if meta["time"][5:7] in ("07","08") or vc_costume(member,sid):
                return "casual"
        return "school" if meta["outfit"] == "school" else "casual"

    def late_student_path(member,sid):
        shopping = m733_shopping_outfit(member,sid)
        if shopping: return M733_SHOP_ROOT+M733_SHOP_FILES[shopping]
        if member == "carina" and sid == "Y6-C7-S14": return Y6_ART_ROOT+"carina_nightwear_v2.png"
        return Y7_ART_ROOT+member+"_"+late_student_outfit(member,sid)+".png"

    def late_student_geometry(member,sid):
        key = member+"_"+late_student_outfit(member,sid)
        shopping = m733_shopping_outfit(member,sid)
        crown,ground = M733_SHOP_GEOMETRY[shopping] if shopping else Y7_CALIBRATION[key]
        geometry = m31_standing_geometry(member,sid,(0,0,1024,1536),crown,ground)
        # Keep the shared 6.4 px/cm scale, but frame the late-adolescent
        # upper body above the dialogue panel. Tall Ron keeps headroom.
        geometry["ypos"] = int(max(geometry["ypos"]-110, 62+ground*geometry["zoom"]))
        return geometry

    def late_student_sprite(member,sid):
        # Clear a preceding adult portrait's sheet crop on the reused widget.
        return Transform(late_student_path(member,sid),crop=(0,0,1024,1536),**late_student_geometry(member,sid))

    def y7_sprite(member,sid):
        if member not in Y7_PORTRAITS: return y6_sprite(member,sid)
        return late_student_sprite(member,sid)

define y7ab = Character("애버포스",callback=y1_speaker_callback("aberforth"))
define y7al = Character("알버스",callback=y1_speaker_callback("albus"))
define y7da = Character("돌리시",callback=y1_speaker_callback("dawlish"))
define y7leo = Character("레오",callback=y1_speaker_callback("leo"))
define y7he = Character("헬레나",callback=y1_speaker_callback("helena"))
define y7iris = Character("아이리스",callback=y1_speaker_callback("iris"))
define y7kr = Character("크리처",callback=y1_speaker_callback("kreacher"))
define y7lyra = Character("리라",callback=y1_speaker_callback("lyra"))
define y7rowan = Character("로언",callback=y1_speaker_callback("rowan"))
define y7xe = Character("러브굿 씨",callback=y1_speaker_callback("xenophilius"))
