# On-camera speakers added by approved screenplay revisions. These are visual
# rosters, not new story participants, encounters, or relationship events.
default vc_disguises = {}

init 1 python:
    VC_SPEAKING_CAST = {
        "Y1-C1-S03": ("hagrid",),
        "Y3-C6-S09": ("ron",),
        "Y4-C1-S01": ("dumbledore",),
        "Y4-C2-S03": ("hagrid",),
        "Y4-C3-S11": ("carina", "sirius"),
        "Y4-C5-S01": ("carina",),
        "Y4-C5-S02": ("neville",),
        "Y4-C5-S03": ("carina",),
        "Y4-C5-S05": ("carina", "sirius"),
        "Y4-C6-S03": ("dumbledore",),
        "Y4-C7-S01": ("ron", "sirius"),
        "Y4-C8-S08": ("cedric",),
        "Y6-C3-S04": ("ginny",),
        "Y6-C5-S03": ("carina",),
        "Y6-C3-S13": ("voldemort",),
        "Y6-C4-S12": ("fred", "george", "moody"),
        "Y6-C4-S16": ("snape",),
        "Y7-C2-S13": ("hagrid",),
    }

    def vc_participants(sid):
        base = m42_participants(sid) if sid.startswith("Y3-") else m31_meta(sid)["participants"]
        return tuple(dict.fromkeys(tuple(base) + VC_SPEAKING_CAST.get(sid, ())))

    def vc_focus(member):
        # Selection is transient and still obeys each year's asset/offscreen rules.
        for year in range(7, 0, -1):
            if store.vn["flags"].get("y%d_campaign" % year):
                if year == 1:
                    y1_speaker_callback(member)("begin")
                else:
                    globals()["y%d_speaker" % year](member)
                return

    def vc_portrait_alpha(member, sid):
        # This is a wand's echo of Snape, not the living professor arriving.
        return 0.55 if (sid, member) == ("Y6-C4-S16", "snape") else 1.0
