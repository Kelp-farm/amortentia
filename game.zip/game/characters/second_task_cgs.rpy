# Requested recovery CGs; owner art review remains separate from integration.
init 2 python:
    for _heroine in ("carina", "hermione", "ginny", "luna"):
        _asset = _heroine + "_lake_recovery"
        Y4_CGS[_asset] = "images/production/events_20261029/" + _asset + ".webp"
