init -10 python:
    Y3_ART_ROOT = "images/production/m3/"
    Y3_CGS = {key:Y3_ART_ROOT+key+".png" for key in ("hogsmeade","ring","hermione_rescue","carina_rescue","train_first_kiss")}
    Y3_CGS.update({key:"images/production/m31c/"+key+".png" for key in ("train_first_kiss","shared_patronus","ring_confession")})
    Y3_CGS["shared_patronus"] = "images/production/m31d/shared_patronus.png"
    Y3_CGS["train_first_kiss"] = "images/production/m31e/train_first_kiss.png"
    Y3_SPRITES = ("carina","hermione","ron","ginny","luna","victoria","grace","percival")
    Y3_CALIBRATION = dict(Y2_CALIBRATION,carina=(35,1515),ron=(35,1515),hermione=(40,1515),victoria=(58,990),grace=(32,989),percival=(66,990))
    Y3_SUPPORT_CROPS = {"victoria":(70,0,450,1024),"grace":(540,0,440,1024),"percival":(1050,0,420,1024)}
    Y3_BACKGROUNDS = {}
    for sid,meta in Y3_SCENES.items():
        loc=meta["location"]
        if "열차" in loc: bg="train"
        elif "의무실" in loc: bg="infirmary"
        elif "호수" in loc or "호숫" in loc or "숲" in loc or "오두막" in loc: bg="lake"
        elif loc in ("호그스미드","허니듀크"): bg="village"
        elif "도서관" in loc: bg="library"
        elif "안뜰" in loc or "온실" in loc: bg="courtyard"
        else: bg="corridor"
        Y3_BACKGROUNDS[sid] = {"library":"images/production/library.webp","courtyard":"images/production/courtyard.webp","corridor":"images/production/m2/corridor.webp"}.get(bg,Y3_ART_ROOT+"bg_"+bg+".png")
    for sid in ("Y3-C1-S03",):
        Y3_BACKGROUNDS[sid]=Y3_ART_ROOT+"bg_forest.png"
    Y3_BACKGROUNDS["Y3-C3-S03"]=Y3_ART_ROOT+"bg_winter.png"
    Y3_BACKGROUNDS["Y3-C2-S04"]=Y3_ART_ROOT+"bg_sweets.png"
    Y3_BACKGROUNDS["Y3-C2-S10"]=Y3_ART_ROOT+"bg_sweets.png"
    Y3_BACKGROUNDS["Y3-C2-S05"]=Y3_ART_ROOT+"bg_winter.png"
    Y3_BACKGROUNDS["Y3-C2-S02"]=None  # A common-room painting has not been produced yet.
    for sid in ("Y3-C1-S06","Y3-C1-S07"):
        Y3_BACKGROUNDS[sid]=None  # Dining-hall art is still pending.
    # The screenplay is integrated; a dedicated pitch background is still pending.
    Y3_BACKGROUNDS["Y3-C6-S08"]=None
    Y3_BACKGROUNDS["Y3-C3-S05"]=None  # Empty practice classroom art is pending.
    Y3_BACKGROUNDS["Y3-C4-S08"]=None  # Investigation classroom has no approved painting yet.
    Y3_BACKGROUNDS["Y3-C3-S06"]=None  # Never place a corridor or grounded sprite in flight.
    for sid in ("Y3-C1-S05","Y3-C3-S04"):
        Y3_BACKGROUNDS[sid]=Y3_ART_ROOT+"bg_potions.png"

    Y3_CGS["ring_confession"] = "images/production/m31q/ring_confession.png"
    for sid in ("Y3-C4-S07","Y3-C6-S10"):
        Y3_BACKGROUNDS[sid] = None  # No pitch/dining-hall illustration yet.

    def y3_speaker(member):
        sid=store.y3_active_scene
        if sid not in Y3_SCENES or member == "harry": return
        store.y3_portrait = member if member in Y3_SPRITES and member in m42_participants(sid) and member not in store.y3_offscreen else None

    def y3_height_cm(member,sid):
        date=datetime.date(*map(int,Y3_SCENES[sid]["time"].split("-")))
        f=max(0.0,min(1.0,(date-datetime.date(2028,9,1)).days/365.0))
        heights=Y1_HEIGHTS["students"][member]["heights_cm"]
        return heights["Y3_start"]+(heights["Y4_start"]-heights["Y3_start"])*f

    def y3_sprite_path(member,sid):
        if member == "carina" and (sid in ("Y3-C1-S04", "Y3-C1-S05", "Y3-C1-S06")
                or (sid == "Y3-C1-S07" and not y3_flag("y3_bandage_removed"))):
            return M31_ART_ROOT + "carina_bandaged.png"
        if member in Y3_SUPPORT_CROPS: return Y3_ART_ROOT+"slytherin_classmates.png"
        expression=(store.y6_expressions if sid.startswith("Y6") else store.y5_expressions if sid.startswith("Y5") else store.y4_expressions if sid.startswith("Y4") else store.y3_expressions).get(member,"neutral")
        if member == "hermione" and sid.startswith(("Y3-C3","Y3-C4-S01","Y3-C5","Y3-C6-S02")):
            expression=store.y3_expressions.get(member,"concerned")
        if member in ("ginny","luna"):
            return Y2_ART_ROOT+member+"_neutral.webp"
        if member == "hermione":
            path=Y3_ART_ROOT+"hermione_full_"+expression+".png"
            return path if renpy.loadable(path) else Y3_ART_ROOT+"hermione_full_neutral.png"
        path=Y3_ART_ROOT+member+"_"+expression+".png"
        return path if renpy.loadable(path) else Y3_ART_ROOT+member+"_neutral.png"

    def y3_sprite(member,sid):
        if member in ("victoria", "grace"):
            return m733_support_sprite(member, sid)
        if vc_has_asset(member, sid):
            return vc_sprite(member, sid)
        if member in M31_SUPPORT:
            return m31_support_sprite(member, sid)
        path=y3_sprite_path(member,sid)
        crown,floor=Y3_CALIBRATION[member]
        crop=Y3_SUPPORT_CROPS.get(member,Y2_SPRITE_CROPS.get(member))
        return m31_standing(path,member,sid,crop,crown,floor)

define ysi = Character("시리우스",callback=y1_speaker_callback("sirius"))
define yrl = Character("루핀 교수",callback=y1_speaker_callback("lupin"))
define yrl_unknown = Character("???", kind=yrl)
define ypet = Character("피터 페티그루",callback=y1_speaker_callback("peter"))
define yce = Character("세드릭 디고리",callback=y1_speaker_callback("cedric"))

define yhp = Character("후플푸프 선수")
