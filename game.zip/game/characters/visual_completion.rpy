# Completed screenplay visual coverage. Original prompts and review evidence:
# docs/VISUAL_COMPLETION.md. Asset delivery is not final art approval.
default vc_background_key = None
default vc_location = None
default vc_hide_standing = False

init -7 python:
    VC_ROOT = "images/production/completion/"
    VC_ROOM_INDEX = {"classroom": 0, "hall": 1, "common": 2, "office": 3}
    VC_REUSE = {"corridor": "images/production/m2/corridor.webp",
        "courtyard": "images/production/courtyard.webp",
        "alley": "images/production/m3d/diagon_alley.png",
        "infirmary": "images/production/m3/bg_infirmary.png",
        "potions": "images/production/m3/bg_potions.png",
        "village": "images/production/m3/bg_village.png",
        "winter": "images/production/m3/bg_winter.png"}
    VC_REUSE["cave"] = "images/production/m6/bg_cave.png"

    def vc_background(key):
        if key in VC_ROOM_INDEX:
            i = VC_ROOM_INDEX[key]
            return Transform("images/production/m4/bg_rooms.png",
                crop=((i % 2) * 768, (i // 2) * 512, 768, 512),
                xysize=(1280, 720), fit="cover")
        return VC_REUSE.get(key, VC_ROOT + "bg_" + key + ".png")

    def vc_reset_stage():
        store.pensieve_frame = None
        store.vc_background_key = None
        store.vc_location = None
        store.vc_hide_standing = False
        store.vc_disguises = {}

    def vc_set_stage(key, location, hide=False, focus=None):
        store.vc_background_key = key
        store.vc_location = location
        store.vc_hide_standing = hide
        # A previous speaker must not travel into a different room by accident.
        for prefix in ("y1", "y2", "y3", "y4", "y5", "y6", "y7"):
            setattr(store, prefix + "_portrait", None)
        if focus is not None and not hide:
            vc_focus(focus)

    VC_SCENE_BACKGROUNDS = {
        "Y1-C1-S05":"platform", "Y1-C1-S07":"hall",
        "Y1-C2-S01":"classroom", "Y1-C2-S04":"lawn", "Y1-C2-S06":"hall", "Y1-C2-S07":"hall",
        "Y1-C3-S01":"classroom", "Y1-C3-S02":"hall", "Y1-C3-S03":"bathroom",
        "Y1-C3-S04":"infirmary", "Y1-C3-S05":"pitch", "Y1-C3-S10":"common",
        "Y1-C4-S02":"hut", "Y1-C4-S03":"tower", "Y1-C4-S04":"forest_night", "Y1-C4-S05":"hall",
        "Y1-C4-S06":"common", "Y1-C4-S07":"common", "Y1-C4-S08":"snare",
        "Y1-C4-S09":"chess", "Y1-C4-S10":"puzzle",
        "Y2-C1-S01":"privet", "Y2-C1-S02":"burrow", "Y2-C1-S03":"bookshop",
        "Y2-C2-S01":"greenhouse", "Y2-C2-S02":"pitch", "Y2-C2-S03":"lake_day", "Y2-C2-S06":"pitch",
        "Y2-C2-S05":"infirmary_night", "Y2-C6-S02":"lawn",
        "Y2-C3-S01":"hall", "Y2-C3-S02":"bathroom", "Y2-C3-S03":"bathroom", "Y2-C3-S04":"common",
        "Y2-C3-S05":"corridor", "Y2-C4-S04":"infirmary", "Y2-C4-S05":"bathroom",
        "Y2-C5-S01":"chamber", "Y2-C5-S02":"chamber", "Y2-C6-S01":"hall",
        "Y2-C6-S04":"classroom", "Y2-C6-S06":"privet",
        "Y3-C1-S06":"hall", "Y3-C1-S07":"hall", "Y3-C2-S02":"common", "Y3-C2-S08":"hall",
        "Y3-C3-S05":"classroom", "Y3-C3-S06":"pitch_storm_ground", "Y3-C6-S10":"hall", "Y3-C6-S11":"hall",
        "Y3-C4-S08":"classroom", "Y3-C4-S07":"pitch_air", "Y3-C4-S04":"common", "Y3-C4-S06":"common",
        "Y3-C4-S09":"hut", "Y3-C5-S01":"forest_night", "Y3-C5-S02":"forest_night",
        "Y3-C5-S04":"infirmary_night", "Y3-C6-S02":"forest_night", "Y3-C6-S03":"forest_night",
        "Y3-C6-S08":"pitch",
        "Y4-C1-S01":"worldcup_final", "Y4-C1-S02":"forest_night", "Y4-C1-S07":"corridor",
        "Y4-C5-S02":"lake_day", "Y4-C8-S01":"infirmary_night", "Y4-C8-S06":"lake_day"}
    for _sid, _key in VC_SCENE_BACKGROUNDS.items():
        if _sid.startswith("Y4"):
            Y4_BG_REUSE["vc_" + _key] = vc_background(_key)
            Y4_SCENES[_sid]["bg"] = "vc_" + _key
        else:
            {"Y1":Y1_BACKGROUNDS,"Y2":Y2_BACKGROUNDS,"Y3":Y3_BACKGROUNDS}[_sid[:2]][_sid] = vc_background(_key)

    # Anatomical crowns/shoe contact, rather than transparent canvas bounds.
    VC_CAST_CALIBRATION = {"hagrid":(35,1515), "malkin":(60,1515), "molly":(40,1515),
        "neville":(50,1498), "pomfrey":(85,1515), "hooch":(65,1515),
        "filch":(95,1515), "percy":(50,1515), "arthur":(55,1515),
        "flint":(45,1515), "wood":(48,1495), "firenze":(48,995), "voldemort":(30,1515)}
    VC_CAST = tuple(VC_CAST_CALIBRATION) + ("snape", "cedric")
    Y3_SPRITES = tuple(dict.fromkeys(Y3_SPRITES + VC_CAST))
    Y4_SPRITES = tuple(dict.fromkeys(Y4_SPRITES + VC_CAST))
    VC_ADULTS = ("hagrid","malkin","molly","pomfrey","hooch","filch","arthur","firenze","voldemort","snape","cedric","wood","flint","percy")
    VC_COSTUME_CALIBRATION = {"carina_quidditch_y2":(35,1512),"carina_quidditch_y3":(40,1512),
        "carina_casual_y4":(35,1515),"ron_casual":(35,1502),"hermione_casual":(40,1512),"cedric_quidditch":(48,1515),
        "cedric_graduate":(14,1508)}

    def vc_costume(member, sid):
        # Cedric completes his seventh year while Harry completes year five.
        # The scene's shared school outfit must not put graduates back in uniform.
        if member == "cedric" and m31_meta(sid)["time"] >= "2031-07-01":
            return "cedric_graduate"
        if member == "cedric" and sid in ("Y3-C3-S06", "Y3-C4-S07", "Y3-C6-S08"):
            return "cedric_quidditch"
        if member == "carina":
            if sid in ("Y2-C2-S02", "Y2-C2-S06"):
                return "carina_quidditch_y2"
            if sid in ("Y3-C3-S06", "Y3-C4-S07", "Y5-C3-S06", "Y5-C3-S12"):
                return "carina_quidditch_y3"
            if sid in ("Y4-C1-S01", "Y4-C1-S06", "Y6-C6-S15", "Y6-C6-S16", "Y6-C7-S11", "Y6-C7-S12", "Y6-C7-S13"):
                return "carina_casual_y4"
        if member in ("ron", "hermione") and sid in ("Y2-C1-S02", "Y2-C1-S03", "Y5-C1-S04", "Y5-C1-S05", "Y6-C1-S03"):
            return member + "_casual"
        return None

    def vc_has_asset(member, sid):
        return member in VC_CAST or vc_costume(member, sid) is not None

    def vc_sprite(member, sid):
        costume = vc_costume(member, sid)
        if costume:
            path = VC_ROOT + costume + ".png"
            crop = (0,0,1024,1536)
            crown, ground = VC_COSTUME_CALIBRATION[costume]
        elif member in ("snape", "cedric"):
            atlas, index = Y4_ATLAS_CAST[member]
            path = Y4_ART_ROOT + atlas + ".png"
            crop = (index*384,0,384,1024)
            crown, ground = Y4_NEW_CALIBRATION[member]
        else:
            path = VC_ROOT + member + ".png"
            crop = (0,0,1536,1024) if member == "firenze" else (0,0,1024,1536)
            crown, ground = VC_CAST_CALIBRATION[member]
        geometry = m31_standing_geometry(member, sid, crop, crown, ground)
        if member in VC_ADULTS:
            geometry["ypos"] = int(max(geometry["ypos"], 56 + (ground-crop[1])*geometry["zoom"]))
        return Transform(path, crop=crop, **geometry)
