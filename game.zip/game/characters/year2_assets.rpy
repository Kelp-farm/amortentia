init -12 python:
    Y2_ART_ROOT = "images/production/m2/"
    Y2_CGS = {key: Y2_ART_ROOT + key + ".webp" for key in ("luna_lake","ginny_chamber","carina_diary")}
    Y2_SPRITE_CROPS = dict(Y1_SPRITE_CROPS, ginny=(205,0,650,1536), luna=(195,0,675,1536))
    Y2_CALIBRATION = dict(Y1_CALIBRATION, ginny=(18,1517), luna=(24,1514))
    Y2_BACKGROUNDS = {sid: "images/production/courtyard.webp" for sid in ("Y2-C1-S05","Y2-C2-S02","Y2-C6-S02")}
    Y2_BACKGROUNDS.update({sid:"images/production/library.webp" for sid in ("Y2-C3-S05","Y2-C4-S01","Y2-C6-S03")})
    Y2_BACKGROUNDS.update({sid:Y2_ART_ROOT+"corridor.webp" for sid in ("Y2-C1-S04","Y2-C2-S04","Y2-C4-S04","Y2-C5-S03","Y2-C6-S04")})
    def y2_speaker(member):
        sid = store.y2_active_scene
        if sid not in Y2_SCENES:
            return
        meta = Y2_SCENES[sid]
        if member == meta["pov"]:
            return
        hidden = sid == "Y2-C3-S03" and member == "hermione"
        store.y2_portrait = member if (member in Y2_SPRITE_CROPS or m31_has_sprite(member, 2)) and member in vc_participants(sid) and member not in store.y2_offscreen and not hidden else None
    def y2_visible_members(sid):
        member = store.y2_portrait
        return [member] if (member in Y2_SPRITE_CROPS or m31_has_sprite(member, 2)) and member in vc_participants(sid) and member not in store.y2_offscreen and member != Y2_SCENES[sid]["pov"] and member != "harry" else []
    def y2_height_cm(member,sid):
        parts = re.match(r"(\d{4})-(\d{2})(?:-(\d{2}))?",Y2_SCENES[sid]["time"])
        year,month,day = parts.groups()
        date = datetime.date(int(year),int(month),int(day or 15))
        heights = Y1_HEIGHTS["students"][member]["heights_cm"]
        origin = datetime.date(2027,9,1)
        if date < origin:
            f = (date-datetime.date(2026,9,1)).days/365.0
            return heights["Y1_start"]+(heights["Y2_start"]-heights["Y1_start"])*f
        f = min(1.0,(date-origin).days/366.0)
        return heights["Y2_start"]+(heights["Y3_start"]-heights["Y2_start"])*f
    def y2_sprite(member,sid):
        member = store.vc_disguises.get(member, member)
        if vc_has_asset(member, sid):
            return vc_sprite(member, sid)
        if m31_has_sprite(member, 2):
            return m31_support_sprite(member, sid)
        crown,floor = Y2_CALIBRATION[member]
        if member in ("ginny","luna"):
            expression = "casual" if member == "ginny" and sid in ("Y2-C1-S02","Y2-C1-S03") else "neutral"
            path = Y2_ART_ROOT+member+"_"+expression+".webp"
        else:
            expression = "guarded" if member == "carina" else "thoughtful" if member == "hermione" and sid.startswith(("Y2-C3","Y2-C4")) else "neutral"
            path = (Y1_REVISED_ART_ROOT if member == "carina" else Y1_ART_ROOT)+member+"_"+expression+".webp"
        return m31_standing(path,member,sid,Y2_SPRITE_CROPS[member],crown,floor)

define yl = Character("루나",color="#c6d5ed",callback=y1_speaker_callback("luna"))
# Her current first line follows Ginny's introduction, so it uses yl.
define yl_unknown = Character("???", kind=yl)
define ydb = Character("도비",callback=y1_speaker_callback("dobby"))
define ylu = Character("루시우스",callback=y1_speaker_callback("lucius"))
define ya = Character("아서 위즐리",callback=y1_speaker_callback("arthur"))
define yt = Character("톰 리들",callback=y1_speaker_callback("riddle"))
define yflt = Character("마커스 플린트",callback=y1_speaker_callback("flint"))
