init -6 python:
    Y5_ART_ROOT="images/production/m5/"
    Y5_NEW_CAST=("umbridge","tonks","bellatrix")
    Y5_SPRITES=Y4_SPRITES+Y5_NEW_CAST
    Y5_CGS={k:Y5_ART_ROOT+k+".png" for k in ("luna_after","carina_door")}
    Y5_NEW_BACKGROUNDS=("grimmauld","requirement","pink_office","atrium","prophecy","veil","court","alley")
    def y5_background(sid):
        key=store.vc_background_key or Y5_SCENES[sid]["bg"]
        if key in Y5_NEW_BACKGROUNDS: return Y5_ART_ROOT+"bg_"+key+".png"
        if key=="cell": return Y4_BG_REUSE["corridor"]
        if key in Y4_BG_REUSE: return Y4_BG_REUSE[key]
        return vc_background(key)
    def y5_speaker(member):
        sid=store.y5_active_scene
        if sid not in Y5_SCENES or member=="harry": return
        store.y5_portrait=member if member in Y5_SPRITES and member in vc_participants(sid) and member not in store.y5_offscreen else None
    def y5_sprite(member,sid):
        if member not in Y5_NEW_CAST: return y4_sprite(member,sid)
        # Full-body portrait sources; keep adult framing above the text window.
        heights={"umbridge":155,"tonks":168,"bellatrix":175}
        crowns={"umbridge":10,"tonks":10,"bellatrix":10}
        ground=1515; crown=crowns[member]
        zoom=(heights[member]+2)*6.4/(ground-crown)
        floor=m31_sprite_floor("harry",sid)
        floor=max(floor,56+ground*zoom)
        # The screen reuses one portrait widget. An omitted crop inherits the
        # preceding atlas cell and can cut off (or entirely hide) this image.
        return Transform(Y5_ART_ROOT+member+".png",crop=(0,0,1024,1536),zoom=zoom,ypos=int(floor),yanchor=ground/1536.0)

define yum = Character("엄브리지 교수",callback=y1_speaker_callback("umbridge"))
define yto = Character("통스",callback=y1_speaker_callback("tonks"))
define ybe = Character("벨라트릭스",callback=y1_speaker_callback("bellatrix"))
define yfig = Character("피그 부인",callback=y1_speaker_callback("figg"))
define yfu = Character("퍼지 장관",callback=y1_speaker_callback("fudge"))
define yri = Character("리타 스키터",callback=y1_speaker_callback("rita"))
define yma = Character("마리에타",callback=y1_speaker_callback("marietta"))
define yka = Character("카르카로프",callback=y1_speaker_callback("karkaroff"))
# A voice from Dumbledore's silver vapour, not a visitor in the office.
define ytr_echo = Character("트릴로니의 목소리",callback=y1_speaker_callback("trelawney_echo"))
