# Original supporting cast. One speaker at a time; portraits are not new events.
init -9 python:
    M31_ART_ROOT = "images/production/m31/"
    M31_SUPPORT = ("dumbledore", "mcgonagall", "lucius", "narcissa", "fred", "george", "sirius", "lupin", "peter", "dobby")
    M31_CLASSMATES = ("victoria", "grace", "percival")
    # Anatomical crown / shoe floor in the 1536x1024 two-expression atlases.
    M31_CALIBRATION = {"dumbledore": (81, 994), "mcgonagall": (121, 994),
        "lucius": (34, 994), "narcissa": (33, 994), "fred": (62, 994),
        "george": (64, 994), "sirius": (51, 994), "lupin": (49, 994),
        "peter": (93, 991), "dobby": (45, 991)}
    M31_CHILD_CALIBRATION = {"victoria": (83, 991), "grace": (65, 991), "percival": (90, 991)}
    Y3_SPRITES += M31_SUPPORT

    def m31_has_sprite(member, year):
        return member in VC_CAST or member in M31_SUPPORT or (year < 3 and member in M31_CLASSMATES)

    def m31_meta(sid):
        return {"Y1": Y1_SCENES, "Y2": Y2_SCENES, "Y3": Y3_SCENES, "Y4": Y4_SCENES, "Y5": Y5_SCENES, "Y6": Y6_SCENES, "Y7": Y7_SCENES}[sid[:2]][sid]

    def m31_height(member, sid):
        if member in Y1_HEIGHTS["fixed_cast"]:
            return Y1_HEIGHTS["fixed_cast"][member]["height_cm"]
        parts = re.match(r"(\d{4})-(\d{2})(?:-(\d{2}))?", m31_meta(sid)["time"])
        year, month, day = parts.groups()
        date = datetime.date(int(year), int(month), int(day or 15))
        heights = Y1_HEIGHTS["students"][member]["heights_cm"]
        samples = [(key,datetime.date(*map(int,d.split("-"))))
            for key,d in zip(Y1_HEIGHTS["timeline"],Y1_HEIGHTS["timeline_dates"]) if key in heights]
        keys,dates = zip(*samples)
        if date <= dates[0]:
            return heights[keys[0]]
        for i in range(1, len(dates)):
            if date <= dates[i]:
                f = (date-dates[i-1]).days / float((dates[i]-dates[i-1]).days)
                return heights[keys[i-1]] + (heights[keys[i]]-heights[keys[i-1]]) * f
        return heights[keys[-1]]

    def m31_pixels_per_cm(sid):
        # Dialogue close-up: a fixed lens for every date, speaker and roster.
        # Never pull the student camera back for an offscreen adult.
        return 6.4

    def m31_sprite_floor(member, sid):
        # Follow Harry's gradual growth; peers retain their relative head levels.
        if member == "dobby":
            return 650.0
        return 90.0 + (m31_height("harry", sid) + 12.0) * m31_pixels_per_cm(sid)

    def m31_standing_geometry(member, sid, crop, crown, ground):
        shoe = 0.0 if member == "dobby" else 2.0
        zoom = (m31_height(member, sid) + shoe) * m31_pixels_per_cm(sid) / (ground-crown)
        floor = m31_sprite_floor(member, sid)
        # Adults/older twins have their own single-speaker upward framing.
        # Preserve their scale and leave room for hats instead of shrinking peers.
        if member in M31_SUPPORT:
            floor = max(floor, 56.0 + (ground-crop[1]) * zoom)
        # Ren'Py interprets float positions as viewport fractions, ints as pixels.
        return dict(zoom=zoom, ypos=int(round(floor)), yanchor=(ground-crop[1])/float(crop[3]))

    def m31_standing(path, member, sid, crop, crown, ground):
        return Transform(path, crop=crop,
            **m31_standing_geometry(member, sid, crop, crown, ground))

    def m31_support_expression(member, sid):
        if sid.startswith("Y3") and member in store.y3_expressions:
            return store.y3_expressions[member]
        if member == "dobby":
            return "alternate" if store.vn["world"].get("dobby_status") == "free_harry" else "neutral"
        if member in ("fred", "george"):
            return "alternate"
        if member == "lucius" and sid == "Y2-C5-S03":
            return "alternate"
        if member == "peter" or (member == "lupin" and sid == "Y3-C5-S02"):
            return "alternate"
        if member == "dumbledore" or (member == "mcgonagall" and sid in ("Y1-C3-S03", "Y1-C4-S03", "Y2-C4-S02")):
            return "alternate"
        return "neutral"

    def m31_support_sprite(member, sid):
        if member in ("victoria", "grace"):
            return m733_support_sprite(member, sid)
        if member in M31_CLASSMATES:
            path = M31_ART_ROOT + "slytherin_childhood.png"
            crop = Y3_SUPPORT_CROPS[member]
            crown, floor = M31_CHILD_CALIBRATION[member]
        else:
            path = M31_ART_ROOT + member + ".png"
            crop = (768 if m31_support_expression(member, sid) == "alternate" else 0, 0, 768, 1024)
            crown, floor = M31_CALIBRATION[member]
        return m31_standing(path, member, sid, crop, crown, floor)

    # Reuse only locations that match. Missing specialist rooms remain explicit.
    for sid in ("Y1-C4-S12",):
        Y1_BACKGROUNDS[sid] = Y3_ART_ROOT + "bg_infirmary.png"
    Y1_BACKGROUNDS["Y1-C2-S02"] = Y3_ART_ROOT + "bg_potions.png"
    # The train interior is a closer match for the farewell than a stone corridor.
    Y1_BACKGROUNDS["Y1-C4-S14"] = Y3_ART_ROOT + "bg_train.png"
    for sid in ("Y2-C2-S05", "Y2-C4-S02", "Y2-C5-S04", "Y2-C6-S01"):
        if sid in Y2_SCENES and "의무실" in Y2_SCENES[sid]["location"]:
            Y2_BACKGROUNDS[sid] = Y3_ART_ROOT + "bg_infirmary.png"
    Y2_BACKGROUNDS["Y2-C6-S05"] = Y3_ART_ROOT + "bg_train.png"
