# M7.5 uses the owner's approved Cho identity, with new expression variants.
init -4 python:
    M75_ART_ROOT="images/production/m75/"
    Y5_CGS.update({key:M75_ART_ROOT+key+".webp" for key in ("cho_kiss","cho_date")})
    VC_REUSE["puddifoot"]=M75_ART_ROOT+"bg_puddifoot.webp"

    def m75_cho_sprite(sid):
        formal=m31_meta(sid)["outfit"]=="formal"
        year=int(sid[1])
        if year==7 or formal or year<5:
            key="graduate" if year==7 else "formal" if formal else "uniform"
            path=M75_ART_ROOT+"cho_"+key+".webp"
            crop=(0,0,1024,1536)
            # Knees-up master: the virtual floor below the crop keeps head size
            # consistent with the full-body classmates, rather than shrinking her.
            geometry=m31_standing_geometry("cho",sid,crop,4,2040)
        else:
            expr=getattr(store,"y%d_expressions"%year,{}).get("cho","smile")
            index={"smile":0,"neutral":0,"concerned":1,"shy":2,"grief":3,"frustrated":4,"resigned":5}.get(expr,0)
            crop=((index%3)*512,(index//3)*512,512,512)
            path=M75_ART_ROOT+"cho_sheet.webp"
            geometry=m31_standing_geometry("cho",sid,crop,crop[1]+4,crop[1]+680)
        return Transform(path,crop=crop,**geometry)

label m75_cho_cg(asset):
    show screen y5_event_cg(asset)
    with Dissolve(0.3)
    $ m21_unlock_cg("Y5:"+asset)
    return
