define harry = Character("Harry Potter", color="#bcd8d1")
define ginny = Character("Ginny Weasley", color="#e8b49b")
define hermione = Character("Hermione Granger", color="#dfc799")
define luna = Character("Luna Lovegood", color="#bdc8ed")
define carina = Character("Carina Malfoy", color="#b6dbc3")

# Text cards and flat colours are intentional temporary art.
image bg demo_room = Solid("#23323c")
image bg demo_later = Solid("#303442")
image harry neutral = Text("HARRY\nplaceholder", size=42, text_align=0.5, color="#bcd8d1")
image luna neutral = Text("LUNA\nplaceholder", size=42, text_align=0.5, color="#bdc8ed")
image carina neutral = Text("CARINA\nplaceholder", size=42, text_align=0.5, color="#b6dbc3")
transform placeholder_left:
    xalign 0.24
    yalign 0.36
transform placeholder_right:
    xalign 0.76
    yalign 0.36
