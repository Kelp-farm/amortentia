# Authored QA histories for the restored winter purchase decision.
init 4 python:
    M33_QA_PRESETS["y3_firebolt_buy"] = dict(
        title="직접 주문한 파이어볼트",profile="carina",prior={"Y3_FIREBOLT":"buy"},local={})
    M21_NODES["Y3-C6-S11"]["replay"]["presets"].append("y3_firebolt_buy")
    M33_SCENE_VARIANTS["Y3-C6-S10"] = ["carina"]
    M33_SCENE_VARIANTS["Y3-C6-S11"] = ["main","carina","y3_firebolt_buy"]
