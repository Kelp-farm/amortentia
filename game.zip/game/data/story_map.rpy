# Stable IDs are the story's existing scene/choice IDs. Never recycle them.
init -5 python:
    M21_CHECKPOINT_FORMAT = 1
    M21_CHECKPOINT_COMPAT = "m21-0.6.0"
    M21_NODES = {}
    M21_CHAPTER_NODES = {}
    for year, scenes in ((1, Y1_REVIEW_SCENES), (2, Y2_SCENES), (3, Y3_SCENES), (4, Y4_SCENES), (5, Y5_SCENES), (6, Y6_SCENES), (7, Y7_SCENES)):
        for sid, scene in scenes.items():
            chapter = "Y1-C%d" % scene["chapter"] if year == 1 else scene["chapter"]
            source = Y1_SCENES[sid] if year == 1 else scene
            node = dict(id=sid, year=year, chapter=chapter, type="scene",
                title=scene["title"], label=scene["label"], scene=sid,
                heroines=[h for h in source["participants"] if h in ("carina", "hermione", "ginny", "luna")],
                implemented=True, optional=(sid == "Y2-C6-S06" or scene.get("optional",False)))
            M21_NODES[sid] = node
            chain = M21_CHAPTER_NODES.setdefault(chapter, [])
            chain.append(sid)
            candidates = [x[0] for x in scene["choices"]] if year == 1 else scene["choices"]
            if sid == "Y1-C4-S14":
                candidates = ["Y1_C4_FAREWELL"]
            for cid in candidates:
                definition = CHOICES[cid]
                if definition.get("legacy") or definition.get("tier", 1) < 2:
                    continue
                M21_NODES[cid] = dict(id=cid, year=year, chapter=chapter,
                    type="choice", title=scene["title"] + " · 선택", label=scene["label"],
                    scene=sid, choice=cid, heroines=node["heroines"], implemented=True,
                    optional=(node["optional"] or cid in ("Y1_C4_BOOK", "Y1_C4_FAREWELL", "Y3_PROMISE_CHANGE", "Y3_PROMISE_REPLY", "Y3_SECRET", "Y3_WINTER_WORDS", "Y3_RECONCILE", "Y3_RON_WARNING", "Y3_PETER", "Y3_FIREBOLT")))
                chain.append(cid)
    for chapter, chain in M21_CHAPTER_NODES.items():
        for index, nid in enumerate(chain):
            M21_NODES[nid]["next"] = chain[index+1:index+2]
            M21_NODES[nid]["previous"] = chain[max(0,index-1):index]

    M21_YEARS = {year: dict(implemented=(year in (1,2,3,4,5,6,7)), chapters=sorted({int(n["chapter"].split("-C")[1]) for n in M21_NODES.values() if n["year"] == year})) for year in range(1,8)}

    M21_CGS = {
        "Y1:train_offered_hand": dict(year=1, asset="train_offered_hand", title="잡지 않은 손", scene="Y1-C1-S06"),
        "Y1:first_encounter": dict(year=1, asset="first_encounter", title="이전 연출 · 양장점의 악수", scene="Y1-C1-S03", legacy=True),
        "Y1:trio_friendship": dict(year=1, asset="trio_friendship", title="셋으로 나눈 아침", scene="Y1-C3-S04"),
        "Y1:potion_farewell": dict(year=1, asset="potion_farewell", title="손을 놓기 전에", scene="Y1-C4-S10"),
        "Y1:reunion_hug": dict(year=1, asset="reunion_hug", title="의무실의 포옹", scene="Y1-C4-S12"),
        "Y1:year_end": dict(year=1, asset="year_end", title="다음 학기에 봐", scene="Y1-C4-S14"),
        "Y2:luna_lake": dict(year=2, asset="luna_lake", title="호숫가의 루나", scene="Y2-C2-S03"),
        "Y2:ginny_chamber": dict(year=2, asset="ginny_chamber", title="다시 눈을 뜬 지니", scene="Y2-C5-S02"),
        "Y2:carina_diary": dict(year=2, asset="carina_diary", title="두 사람만의 비밀", scene="Y2-C6-S04"),
    }
    for asset,title,sid in (("train_first_kiss","뜻밖의 첫키스","Y3-C1-S01"),("hogsmeade","정오의 약속","Y3-C2-S05"),("ring","말하지 못한 반지","Y3-C4-S05"),("hermione_rescue","세 시간을 함께","Y3-C6-S02"),("carina_rescue","호수 너머의 빛","Y3-C6-S04"),("shared_patronus","같은 모습의 빛","Y3-C6-S04"),("ring_confession","네가 끼워 줘","Y3-C6-S09")):
        M21_CGS["Y3:"+asset] = dict(year=3,asset=asset,title=title,scene=sid)
    M21_CGS["Y3:hogsmeade"].update(legacy=True,title="이전 연출 · 가을 마을의 약속")
    M21_CGS["Y3:ring"].update(legacy=True,title="이전 연출 · 반지의 설명")
    M21_CGS["Y3:carina_rescue"].update(legacy=True,title="이전 연출 · 호수 너머의 빛")
    for asset,title,sid in (("practice_carina","틀린 발부터","Y4-C3-S07"),("practice_hermione","책에 없는 박자","Y4-C3-S08"),("practice_ginny","이번엔 내가 먼저","Y4-C3-S09"),("practice_luna","음악이 돌아올 때","Y4-C3-S10"),("ball_carina","남들이 보는 곳에서","Y4-C4-S02"),("ball_hermione","낯익은 목소리","Y4-C4-S03"),("ball_ginny","오늘의 파트너","Y4-C4-S04"),("ball_luna","은빛 장식 아래","Y4-C4-S05"),("separation","음악 없는 교실","Y4-C6-S04"),("graveyard","돌아올 길","Y4-C7-S04"),("letter","숨겨진 글씨","Y4-C8-S02")):
        M21_CGS["Y4:"+asset]=dict(year=4,asset=asset,title=title,scene=sid)
    M21_CGS["Y4:cloak_date"]=dict(year=4,asset="cloak_date",title="망토 안의 두 걸음",scene="Y4-C5-S07")
    M21_ENDINGS = {
        "annual_y6": dict(title="육 학년 · 두 갈래의 여름",year=6,implemented=True,kind="annual",scene="Y6-C8-S05"),
        "annual_y5": dict(title="오 학년 · 서로의 주소",year=5,implemented=True,kind="annual",scene="Y5-C6-S08"),
        "y5_captured": dict(title="닫힌 출구",year=5,implemented=True,kind="bad",scene="Y5-C5-S10"),
        "annual_y4": dict(title="사 학년 · 여름으로 가져갈 것",year=4,implemented=True,kind="annual",scene="Y4-C8-S09"),
        "annual_y3": dict(title="삼 학년 · 다시 돌아온 세 시간",year=3,implemented=True,kind="annual",scene="Y3-C6-S07"),
        "annual_y1": dict(title="일 학년 · 돌아오고 싶은 곳", year=1, implemented=True, kind="annual", scene="Y1-C4-S14"),
        "annual_y2": dict(title="이 학년 · 비밀의 방", year=2, implemented=True, kind="annual", scene="Y2-C6-S05"),
    }
    for route, name in (("ginny", "지니"), ("hermione", "헤르미온느"), ("luna", "루나"), ("carina", "카리나"), ("no_romance", "연애 없이")):
        M21_ENDINGS["route_" + route] = dict(title=name, year=7, implemented=False, kind="route", route=route,
            variants=(["cooperation", "rivalry"] if route == "carina" else []))
