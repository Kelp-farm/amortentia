# The shared scene ID contains a classroom lesson or the couple's bathroom visit.
# Keep those histories selectable even if the generated variant list is stale.
init 4 python:
    M33_SCENE_VARIANTS["Y4-C5-S01"] = ["main", "m4_dating_private", "m4_dating_public"]
