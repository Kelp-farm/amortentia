# M3 is additive. Never reinterpret the established life-status or Year 2 choices.
init -44 python:
    WORLD_DEFAULTS.update({"sirius_legal": "unknown", "pettigrew_status": "unknown",
        "buckbeak_status": "unknown", "y3_rescue_companion": "none",
        "carina_ring": "none", "y3_hogsmeade_promise": "none", "y3_firebolt": "none",
        "y3_carina_bond": "rivalry", "carina_early_romance_blocked": False,
        "carina_secret_dating": False, "y3_carina_dating": False,
        "y3_carina_visibility": "none", "y4_worldline": "pending",
        "y3_time_turner_holder": "hermione"})
    WORLD_ENUMS.update({
        "y3_carina_bond": ("rivalry","close","hurt","reconciled","estranged"),
        "y3_carina_visibility": ("none","private","public"),
        "y4_worldline": ("pending","fanfic","canon_adjacent"),
        "y3_time_turner_holder": ("hermione","harry_carina","school"),"sirius_legal": ("unknown","fugitive","cleared"),
        "pettigrew_status": ("unknown","hiding","escaped","captured"),
        "buckbeak_status": ("unknown","under_review","condemned","isolated","free"),
        "y3_rescue_companion": ("none","hermione","carina"),
        "carina_ring": ("none","bought","withheld","delivered","worn","returned"),
        "y3_firebolt": ("none","ordered","purchased","sirius_gift","legacy_gift"),
        "y3_hogsmeade_promise": ("none","made","kept","broken","prevented")})

init -18 python:
    Y3_TITLES = ("차가운 창문", "마을로 가는 길", "말하지 않은 것", "한 짝의 반지", "호수의 밤", "세 시간과 여름")
    for _i,_title in enumerate(Y3_TITLES,1):
        CHAPTERS["Y3-C%d" % _i] = dict(year=3,number=_i,title=_title,pov="harry",demo=False)
    def _y3_choice(cid, chapter, tier, options):
        CHOICES[cid] = dict(chapter_id="Y3-C%d" % chapter,text="",tier=tier,statistics=tier>1,
            tags=["year3","butterfly" if tier==3 else "conversation"],
            options=[dict(id=oid,text=text,effects=effects) for oid,text,effects in options])
    def _y3_memory(h,key,text):
        return ("relationship_event",h,key,"memory",text,False)
    _y3_choice("Y3_TRAIN_KISS",1,2,[
        ("stand","첫키스까지 걱정해 주다니, 고맙네. (그냥 일어난다)",[("flag","y3_train_first_kiss",False)]),
        ("kiss","그럼 첫키스 상대는 바꿔야겠네. (카리나에게 키스한다)",[("flag","y3_train_first_kiss",True)])])
    _y3_choice("Y3_TRAIN",1,1,[
        ("share","지니에게 초콜릿을 나눠 준다.",[("relationship","ginny","affection",1)]),
        ("quiet","지니 옆에 말없이 앉아 있는다.",[])])
    _y3_choice("Y3_TIMETABLE",1,1,[
        ("bag","책은 내가 들어 줄게.",[("relationship","hermione","affection",1)]),
        ("seat","앉아서 얘기하자. 또 수업 가야 해?",[])])
    _y3_choice("Y3_BUCKBEAK_CARE",1,2,[
        ("help","구경하는 아이들을 물리고 카리나 곁에 앉는다.",[_y3_memory("carina","y3_infirmary_care","벅빅에게 다친 뒤 구경꾼들을 물리고 곁에 있었다."),("relationship","carina","affection",1)]),
        ("hagrid","치료는 폼프리 부인에게 맡기고 해그리드에게 간다.",[_y3_memory("carina","y3_infirmary_left","치료가 시작되자 해그리드에게 돌아갔다.")])])
    _y3_choice("Y3_POTIONS_SEAT",1,1,[
        ("hermione","헤르미온느 옆에 앉는다.",[]),
        ("carina","카리나 옆에 앉는다.",[])])
    _y3_choice("Y3_POTIONS_VOLUNTEER",1,2,[
        ("help","손을 들고 내가 하겠다고 한다.",[("flag","y3_potions_volunteered",True)]),
        ("ron","론에게 맡기고 내 재료를 손질한다.",[("flag","y3_potions_volunteered",False)])])
    _y3_choice("Y3_MEAL_HELP",1,2,[
        ("cut","뼈에서 살을 발라 주겠다고 나선다.",[]),
        ("leave","카리나에게 맡기고 내 자리로 간다.",[])])
    _y3_choice("Y3_BRUSH_HELP",1,3,[
        ("offer","양치도 도와줄까?",[]),
        ("leave","그럼 수업에서 보자.",[])])
    _y3_choice("Y3_FIRST_WARNING",2,2,[
        ("tease","나 걱정돼서 기다린 거야?",[("flag","y3_teased_concern",True)]),
        ("friends","론하고 헤르미온느랑 같이 있을게.",[("flag","y3_teased_concern",False)])])
    _y3_choice("Y3_BUCKBEAK_APPEAL",1,3,[
        ("ask","다친 건 알아. 그래도 죽이지는 말아 줘.",[("flag","y3_asked_buckbeak_mercy",True)]),
        ("support","네가 그렇게 다쳤는데 화나는 게 당연하지.",[("flag","y3_supported_buckbeak_injury",True)])])
    _y3_choice("Y3_INVITATION",3,2,[
        ("meet","알았어. 오두막 앞에서 보자.",[("world","y3_hogsmeade_promise","made"),_y3_memory("carina","y3_outing_promised","겨울 외출 때 비명을 지르는 오두막 앞에서 만나기로 했다.")]),
        ("tease","둘이서 만나자는 거야?",[("relationship","carina","affection",1)]),
        ("avoid","갈 수 있으면 갈게. 기다리지는 마.",[]),
        ("stop","할 말 있으면 여기서 해.",[("relationship","carina","affection",-1)])])
    _y3_choice("Y3_OUTING",3,2,[
        ("trio","론과 헤르미온느를 찾아간다.",[("flag","y3_outing_trio",True)]),
        ("carina","카리나가 말한 오두막으로 간다.",[("flag","y3_outing_carina",True)]),
        ("ginny","학교에 남아 지니와 시간을 보낸다.",[("flag","y3_outing_ginny",True)]),
        ("luna","지니와 루나 옆에 앉아 잡지를 구경한다.",[("flag","y3_outing_luna",True)])])
    _y3_choice("Y3_SWEETS",3,1,[
        ("sour","신맛 나는 걸로 골라 줘.",[]),
        ("together","네가 고른 거 나도 먹어 볼래.",[("relationship","hermione","affection",1)])])
    _y3_choice("Y3_PROMISE_CHANGE",3,2,[
        ("tell","빅토리아에게 못 간다고 전해 달라고 부탁한다.",[("flag","y3_promise_cancelled",True)]),
        ("silent","아무 말 없이 다른 곳으로 간다.",[("flag","y3_promise_cancelled",False)])])
    _y3_choice("Y3_CARINA_OUTING",3,2,[
        ("again","다음엔 이렇게 추운 데 말고, 가게 안에서 보자.",[("relationship","carina","affection",2),_y3_memory("carina","y3_private_outing","다음 호그스미드 방문에도 둘이 만나고 싶다고 말했다.")]),
        ("rivals","춥다. 무슨 얘긴지 먼저 말해 줄래?",[_y3_memory("carina","y3_outing_rivals","오두막에서 카리나가 꺼내려는 용건부터 물었다.")])])
    _y3_choice("Y3_GINNY_OUTING",3,1,[
        ("race","좋아. 이번에는 제대로 던져 봐.",[("relationship","ginny","affection",2),_y3_memory("ginny","y3_courtyard_game","과하게 봐주지 않고 지니와 안뜰에서 시합했다.")]),
        ("teach","손목은 어떻게 쓰는 거야?",[("relationship","ginny","affection",1),_y3_memory("ginny","y3_courtyard_lesson","지니에게 던지는 요령을 배웠다.")])])
    _y3_choice("Y3_LUNA_OUTING",3,1,[
        ("listen","좀 더 볼래. 이 옆에 있는 건 뭐야?",[("relationship","luna","affection",1),_y3_memory("luna","y3_corridor_listening","지니와 함께 잡지를 보다가 남아서 루나에게 그림에 관해 물었다.")]),
        ("draw","빈칸에 나도 하나 그려 봐도 돼?",[("relationship","luna","affection",1),_y3_memory("luna","y3_corridor_drawing","잡지 여백에 그린 엉뚱한 새를 지니와 루나에게 보여 주었다.")]),
        ("leave","난 숙제부터 해야겠다. 다음에 봐.",[])])
    _y3_choice("Y3_PROMISE_REPLY",3,2,[
        ("apologize","기다리게 해서 미안해. 내가 잘못했어.",[("relationship","carina","affection",1),_y3_memory("carina","y3_promise_apology","지키지 못한 외출 약속을 변명하지 않고 사과했다.")]),
        ("dismiss","그렇게 오래 기다릴 줄은 몰랐어.",[("relationship","carina","affection",-2)])])
    _y3_choice("Y3_RECOVERY_FIRST",3,1,[
        ("carina","카리나는 괜찮아? 같이 떨어졌어?",[]),
        ("match","경기는 어떻게 됐어?",[])])
    _y3_choice("Y3_RECOVERY",3,1,[
        ("hermione","헤르미온느에게 잠깐 더 있어 달라고 한다.",[("relationship","hermione","affection",1)]),
        ("friends","다들 와 줘서 고맙다고 한다.",[("special","friendship_stability",1)])])
    _y3_choice("Y3_SECRET",3,3,[
        ("include","앞으로도 같이 알아보자.",[("flag","y3_carina_informed",True)]),
        ("exclude","여기서 손을 떼, 말포이.",[("flag","y3_carina_excluded",True)])])
    _y3_choice("Y3_WINTER_WORDS",3,2,[
        ("listen","잠깐만. 네 얘기부터 들을게.",[("relationship","carina","affection",1)]),
        ("family","네 가족까지 위험해질 수 있잖아.",[("relationship","carina","affection",-2)])])
    _y3_choice("Y3_FIREBOLT",6,2,[
        ("buy","나도 같은 걸로 주문해야겠다.",[("world","y3_firebolt","ordered"),("flag","y3_matching_broom_chosen",True)]),
        ("wait","지금은 사지 말자.",[])])
    CHOICES["Y3_FIREBOLT"]["legacy"] = True
    _y3_choice("Y3_HERMIONE_REST",4,2,[
        ("stay","숙제는 잠깐 두자. 내가 차 가져올게.",[("relationship","hermione","affection",2),_y3_memory("hermione","y3_library_rest","지친 헤르미온느와 도서관을 나와 따뜻한 차를 마셨다.")]),
        ("ask","책 찾는 건 내가 할까?",[("relationship","hermione","affection",1),_y3_memory("hermione","y3_library_help","헤르미온느에게 필요한 도움이 무엇인지 물었다.")])])
    _y3_choice("Y3_GINNY_CONFIDENCE",4,1,[
        ("listen","기대할게.",[("relationship","ginny","affection",1)]),
        ("laugh","론한테는 네가 직접 말해. 표정 좀 보고 싶다.",[("relationship","ginny","affection",1)])])
    _y3_choice("Y3_LUNA_SPRING",4,1,[
        ("keep","이거 하나 가져가도 돼? 나중에 보고 접어 보게.",[_y3_memory("luna","y3_paper_bird","도서관에서 지니와 루나를 만나 종이접기 견본을 하나 받아 왔다.")]),
        ("learn","하나만 가르쳐 줘.",[("relationship","luna","affection",1)]),
        ("leave","오늘은 책부터 찾아야겠다. 다음에 가르쳐 줘.",[])])
    _y3_choice("Y3_RING",4,2,[
        ("wear","낀다.",[("world","carina_ring","worn"),_y3_memory("carina","y3_ring_worn","빅토리아가 전한 반지를 오른손 약지에 꼈다. 아직 기능은 듣지 못했다.")]),
        ("keep","끼지 않는다.",[("world","carina_ring","delivered"),_y3_memory("carina","y3_ring_kept","반지는 받되 아직 착용하지 않았다.")])])
    _y3_choice("Y3_RECONCILE",4,2,[
        ("talk","내가 네 말을 안 들었어. 미안해.",[("relationship","carina","affection",2),_y3_memory("carina","y3_reconciled","다퉜던 일을 사과하고 카리나와 다시 이야기했다.")]),
        ("leave","지금은 얘기하기 힘들어.",[_y3_memory("carina","y3_quarrel_unresolved","카리나와의 대화를 미뤘다.")])])
    CHOICES["Y3_RECONCILE"]["legacy"] = True
    _y3_choice("Y3_RON_WARNING",4,2,[
        ("tell","론에게 스캐버스의 정체를 알려 준다.",[("flag","y3_ron_warned",True),("special","friendship_stability",1)]),
        ("wait","정체를 확실히 확인한 뒤 말하기로 한다.",[("flag","y3_ron_warned",False)])])
    _y3_choice("Y3_RESCUE",5,3,[
        ("hermione","헤르미온느, 같이 가자.",[("world","y3_rescue_companion","hermione")]),
        ("carina","카리나에게 같이 가 달라고 부탁한다.",[("world","y3_rescue_companion","carina")])])
    _y3_choice("Y3_PETER",6,3,[
        ("secure","도망치기 전에 페티그루를 기절시켜 붙잡는다.",[("world","pettigrew_status","captured")]),
        ("friends","친구들이 있는 쪽을 지킨다.",[("world","pettigrew_status","escaped")])])
    _y3_choice("Y3_COMMITMENT",6,3,[
        ("confess","좋아해. 너랑 사귀고 싶어.",[]),
        ("friends","네가 위험해질까 봐 겁나. 지금은 사귀자는 말을 못 하겠어.",[])])
    _y3_choice("Y3_DATING_VISIBILITY",6,2,[
        ("public","다른 사람이 물어도, 네가 내 여자 친구라고 말할래.",[]),
        ("private","당분간은 우리 둘만 알고 있으면 좋겠어.",[])])
    _y3_choice("Y3_HERMIONE_FAREWELL",6,1,[
        ("summer","방학 때도 편지할게.",[_y3_memory("hermione","y3_summer_letters","헤르미온느와 방학 편지를 약속했다.")]),
        ("rest","이번 방학엔 좀 쉬어.",[])])
    _y3_choice("Y3_CARINA_FAREWELL",6,1,[
        ("letter","방학 편지 이야기를 꺼낸다.",[_y3_memory("carina","y3_summer_letters","카리나에게 방학 편지를 보내도 좋다는 답을 들었다.")]),
        ("rival","가을에 봐, 말포이.",[])])

    # Each scene is a real chapter entry, including the mutually exclusive outing scenes.
    Y3_SCENES = {}
    _y3_rows = [
        (1,"차가워진 객실","2028-09-01","호그와트 급행열차",["harry","ron","hermione","ginny","carina","lupin"],["Y3_TRAIN_KISS","Y3_TRAIN"]),
        (1,"겹쳐 있는 시간표","2028-09-02","돌계단",["harry","hermione","ron"],["Y3_TIMETABLE"]),
        (1,"벅빅의 발톱","2028-09-03","숲 앞 수업장",["harry","carina","hermione","ron","hagrid","victoria","grace","percival"],[]),
        (1,"오른팔의 붕대","2028-09-03","의무실",["harry","carina","pomfrey"],["Y3_BUCKBEAK_CARE"]),
        (1,"한 손으로 하는 수업","2028-09-05","마법약 교실",["harry","carina","hermione","ron","snape"],["Y3_POTIONS_SEAT","Y3_POTIONS_VOLUNTEER","Y3_BUCKBEAK_APPEAL"]),
        (2,"외출하는 날","2028-10-27","현관 홀",["harry","carina","victoria","grace"],["Y3_INVITATION"]),
        (2,"텅 빈 양피지","2028-10-28","그리핀도르 휴게실",["harry","fred","george"],[]),
        (2,"첫 외출일","2028-10-31","호그와트 복도",["harry","ginny","luna","victoria"],["Y3_OUTING","Y3_PROMISE_CHANGE"]),
        (2,"허니듀크의 세 사람","2028-10-31","허니듀크",["harry","hermione","ron"],["Y3_SWEETS"]),
        (2,"가게 문 앞의 카리나","2028-10-31","호그스미드",["harry","carina"],["Y3_CARINA_OUTING"]),
        (2,"학교에 남은 지니","2028-10-31","안뜰",["harry","ginny"],["Y3_GINNY_OUTING"]),
        (2,"온실 뒤의 바람","2028-10-31","온실 뒤",["harry","luna"],["Y3_LUNA_OUTING"]),
        (2,"돌아온 뒤","2028-10-31","대연회장 입구",["harry","carina","hermione","ron"],[]),
        (3,"비가 그친 경기장","2028-11-05","의무실",["harry","hermione","ron","carina"],["Y3_RECOVERY_FIRST","Y3_RECOVERY"]),
        (3,"검은 개에 관한 소식","2028-12-15","호그와트 복도",["harry","sirius","hermione"],[]),
        (3,"겨울의 오두막","2028-12-17","비명을 지르는 오두막",["harry","carina","sirius"],["Y3_SECRET","Y3_WINTER_WORDS","Y3_PROMISE_REPLY"]),
        (3,"닫힌 서랍","2029-01-08","마법약 교실 앞",["harry","carina","victoria","grace","hermione"],[]),
        (4,"한 페이지를 세 번","2029-02-10","도서관",["harry","hermione"],["Y3_HERMIONE_REST"]),
        (4,"지니의 빗자루","2029-03-02","안뜰",["harry","ginny","ron"],["Y3_GINNY_CONFIDENCE"]),
        (4,"접어 둔 새","2029-03-12","호숫가",["harry","luna"],["Y3_LUNA_SPRING"]),
        (4,"빅토리아의 심부름","2029-04-04","돌계단",["harry","victoria"],["Y3_RING"]),
        (4,"끝내지 않은 대화","2029-04-05","빈 복도",["harry","carina","hermione"],["Y3_RECONCILE"]),
        (4,"지도 위의 이름","2029-06-06","그리핀도르 휴게실",["harry","hermione","ron"],["Y3_RON_WARNING"]),
        (5,"사라진 론","2029-06-06","현관과 숲 입구",["harry","hermione","carina","lupin","sirius"],[]),
        (5,"호수로 향하는 발자국","2029-06-06","숲길",["harry","hermione","ron","sirius","lupin","peter"],[]),
        (5,"호수의 은빛","2029-06-06","호숫가",["harry","hermione","ron","sirius","peter"],[]),
        (5,"시계의 주인","2029-06-06","의무실",["harry","hermione","carina","dumbledore"],["Y3_RESCUE"]),
        (6,"세 시간 전의 복도","2029-06-06","호그와트 복도와 루핀의 방",["harry","hermione","carina"],[]),
        (6,"헤르미온느와 숲에서","2029-06-06","숲 가장자리",["harry","hermione"],[]),
        (6,"반지의 짝","2029-06-06","지하 복도와 학교 앞뜰",["harry","carina"],[]),
        (6,"빛이 닿은 자리","2029-06-06","호숫가와 성의 별실",["harry","hermione","carina","sirius","snape","peter","dumbledore"],["Y3_PETER"]),
        (6,"돌아온 사람들","2029-06-07","의무실",["harry","hermione","ginny","luna","ron","carina"],[]),
        (6,"내려놓은 시간표","2029-06-28","호그와트 급행열차",["harry","hermione","ron","ginny","luna"],["Y3_HERMIONE_FAREWELL"]),
        (6,"주머니 속의 반지","2029-06-28","열차 복도",["harry","carina","victoria","grace","percival"],["Y3_CARINA_FAREWELL"]),
    ]
    _counts = {}
    for n,title,date,location,members,choices in _y3_rows:
        _counts[n] = _counts.get(n,0)+1
        sid = "Y3-C%d-S%02d" % (n,_counts[n])
        Y3_SCENES[sid] = dict(chapter="Y3-C%d"%n,number=n,offset=_counts[n]-1,
            label="y3_c%d_s%02d"%(n,_counts[n]),title=title,time=date,location=location,
            participants=members,pov="harry",choices=choices,
            optional=(sid in ("Y3-C2-S04","Y3-C2-S05","Y3-C2-S06","Y3-C2-S07","Y3-C4-S04","Y3-C4-S05","Y3-C6-S02","Y3-C6-S03")))

    # Insert new beats before the train without recycling any shipped scene IDs.
    _y3_ordered = {}
    for _sid, _meta in Y3_SCENES.items():
        if _sid == "Y3-C6-S06":
            for _extra, _title, _location, _members in (
                ("08", "마지막 경기와 손수건", "퀴디치 경기장", ["harry", "carina", "victoria", "cedric", "ron"]),
                ("09", "다시 끼운 반지", "성으로 가는 회랑", ["harry", "carina"]),
            ):
                _new_sid = "Y3-C6-S" + _extra
                _y3_ordered[_new_sid] = dict(chapter="Y3-C6", number=6, offset=0,
                    label="y3_c6_s" + _extra, title=_title, time="2029-06-21",
                    location=_location, participants=_members, pov="harry", choices=[], optional=True)
        _y3_ordered[_sid] = _meta
    Y3_SCENES = _y3_ordered
    for _offset, _meta in enumerate(m for m in Y3_SCENES.values() if m["number"] == 6):
        _meta["offset"] = _offset

    # M31G: IDs remain stable; metadata/order, not ID spelling, determine chapters.
    _winter_ids = ["Y3-C2-S01","Y3-C2-S03","Y3-C2-S04","Y3-C2-S05","Y3-C2-S06","Y3-C2-S07"]
    for _sid in _winter_ids:
        Y3_SCENES[_sid].update(chapter="Y3-C3",number=3,time="2028-12-17")
    Y3_SCENES["Y3-C2-S01"]["title"] = "다시 나가는 날"
    Y3_SCENES["Y3-C2-S03"]["title"] = "겨울 외출의 약속"
    Y3_SCENES["Y3-C2-S05"].update(title="오두막 앞의 카리나",location="비명을 지르는 오두막")
    Y3_SCENES["Y3-C3-S03"].update(title="미처 끝내지 못한 말",location="오두막 또는 학교 복도")
    for _sid,_title,_location,_members,_choices in (
        ("Y3-C2-S09","현관에서의 충고","현관 홀",["harry","carina","victoria","grace"],["Y3_FIRST_WARNING"]),
        ("Y3-C2-S10","처음 밟는 마을","허니듀크와 마을 골목",["harry","hermione","ron"],[])):
        Y3_SCENES[_sid] = dict(chapter="Y3-C2",number=2,offset=0,label=_sid.lower().replace('-','_'),
            title=_title,time="2028-10-31",location=_location,participants=_members,pov="harry",choices=_choices,optional=False)
    # M31H: practice and the autumn match precede the stable infirmary entry.
    Y3_SCENES["Y3-C3-S01"]["title"] = "의무실에서 깨어나"
    for _sid,_title,_date,_location,_members in (
        ("Y3-C3-S05","은빛 안개를 연습하며","2028-11-03","빈 교실",["harry","lupin"]),
        ("Y3-C3-S06","폭풍우 속의 스니치","2028-11-05","퀴디치 경기장",["harry","carina","hermione"])):
        Y3_SCENES[_sid] = dict(chapter="Y3-C3",number=3,offset=0,label=_sid.lower().replace('-','_'),
            title=_title,time=_date,location=_location,participants=_members,pov="harry",choices=[],optional=False)
    _chapter_orders = {
        1:["Y3-C1-S01","Y3-C1-S02","Y3-C1-S03","Y3-C1-S04","Y3-C1-S05","Y3-C1-S06","Y3-C1-S07"],
        2:["Y3-C2-S02","Y3-C2-S09","Y3-C2-S10","Y3-C2-S08"],
        3:["Y3-C3-S05","Y3-C3-S06","Y3-C3-S01","Y3-C3-S02"]+_winter_ids+["Y3-C3-S03","Y3-C3-S04"]}
    for _sid,_title,_date,_location,_members,_choices in (
        ("Y3-C1-S06","저녁 식사의 나이프","2028-09-05","대연회장",["harry","carina","victoria","grace"],["Y3_MEAL_HELP"]),
        ("Y3-C1-S07","붕대를 풀 때","2028-09-06","대연회장",["harry","carina","victoria","grace","lucius"],["Y3_BRUSH_HELP"])):
        Y3_SCENES[_sid] = dict(chapter="Y3-C1",number=1,offset=0,label=_sid.lower().replace('-','_'),
            title=_title,time=_date,location=_location,participants=_members,pov="harry",choices=_choices,optional=False)
    Y3_SCENES["Y3-C2-S07"].update(title="창가에 펼친 잡지",location="현관 홀",participants=["harry","ginny","luna"])
    Y3_SCENES["Y3-C4-S03"].update(title="도서관의 종이 새",location="도서관",participants=["harry","ginny","luna"])
    # M31P: common broom choices, and the earlier match that motivates the final.
    for _sid,_n,_title,_date,_location,_members,_choices in (
        ("Y3-C4-S07",4,"슬리데린의 패배","2029-03-20","퀴디치 경기장",["harry","ron","carina","cedric"],[]),
        ("Y3-C6-S10",3,"카리나의 새 빗자루","2029-01-09","대연회장",["harry","ron","carina","victoria","grace","flint"],[]),
        ("Y3-C6-S11",3,"보낸 이 없는 소포","2029-01-11","대연회장",["harry","ron","hermione","mcgonagall"],[])):
        Y3_SCENES[_sid] = dict(chapter="Y3-C%d"%_n,number=_n,offset=0,label=_sid.lower().replace('-','_'),
            title=_title,time=_date,location=_location,participants=_members,pov="harry",choices=_choices,optional=False)
    _chapter_orders[4] = ["Y3-C4-S01","Y3-C4-S02","Y3-C4-S03","Y3-C4-S04","Y3-C4-S07","Y3-C4-S06"]
    _chapter_orders[3].extend(["Y3-C6-S10","Y3-C6-S11"])
    _chapter_orders[6] = ["Y3-C6-S01","Y3-C6-S02","Y3-C6-S03","Y3-C6-S04","Y3-C6-S05","Y3-C4-S05","Y3-C6-S08","Y3-C6-S09","Y3-C6-S06","Y3-C6-S07"]
    # Same repair beat/ID, moved after the pursuit. No separate apology choice.
    Y3_SCENES["Y3-C4-S05"].update(chapter="Y3-C6",number=6,time="2029-06-08",
        title="다시 마주친 시선",location="의무실 앞 복도",participants=["harry","carina"],choices=[])
    # M3.2 adds preparatory beats without recycling existing IDs.
    for _sid,_title,_date,_place,_members in (
        ("Y3-C4-S08","없어진 쥐를 찾는 시간","2029-01-12","빈 교실",["harry","hermione","ron"]),
        ("Y3-C4-S09","비어 있는 말뚝","2029-06-06","해그리드의 오두막",["harry","hermione","hagrid"])):
        Y3_SCENES[_sid] = dict(chapter="Y3-C4",number=4,offset=0,label=_sid.lower().replace('-','_'),
            title=_title,time=_date,location=_place,participants=_members,pov="harry",choices=[],optional=False)
    _chapter_orders[4].insert(0,"Y3-C4-S08")
    _chapter_orders[4].append("Y3-C4-S09")
    Y3_SCENES["Y3-C4-S04"].update(time="2029-03-19",location="그리핀도르 휴게실 앞",participants=["harry","ron","victoria"])
    Y3_SCENES["Y3-C6-S09"]["choices"] = ["Y3_COMMITMENT","Y3_DATING_VISIBILITY"]
    _ordered = {}
    for _n in range(1,7):
        _ids = _chapter_orders.get(_n,[sid for sid,m in Y3_SCENES.items() if m["number"]==_n])
        for _offset,_sid in enumerate(_ids):
            Y3_SCENES[_sid]["offset"] = _offset
            _ordered[_sid] = Y3_SCENES[_sid]
    Y3_SCENES = _ordered

    # Approved editorial fork, final production choice registration is deferred.
    _y3_choice("REVIEW_Y3_SIRIUS_REVEAL",3,3,[
        ("reveal","검은 개가 시리우스라는 사실을 밝힌다.",[]),
        ("withhold","정체를 숨기고 카리나에게 그만 알아보라고 한다.",[("flag","review_y3_identity_withheld",True),("flag","y3_carina_excluded",True)])])
    Y3_SCENES["Y3-C1-S05"]["choices"] = ["Y3_BUCKBEAK_APPEAL","Y3_POTIONS_SEAT","Y3_POTIONS_VOLUNTEER"]
    Y3_SCENES["Y3-C2-S05"]["choices"] = ["Y3_CARINA_OUTING","REVIEW_Y3_SIRIUS_REVEAL"]
    Y3_SCENES["Y3-C3-S02"].update(title="기다리는 소식",location="그리핀도르 휴게실",participants=["harry","hermione"])
    Y3_SCENES["Y3-C3-S03"]["location"] = "오두막 앞 / 정체 공개 시 실내"
    Y3_SCENES["Y3-C4-S04"].update(title="은빛 고리",participants=["harry","ron","victoria","carina"])
