init -20 python:
    # TECHNICAL DEMO THRESHOLDS ONLY. No Year 7 balance is implied.
    ROUTE_RULES = {
        "ginny": {"minimums": {"affection": 3},
                  "keys": ["independence_supported"],
                  "special_min": {"ginny_independence": 1},
                  "world_allowed": {"ministry_truth": ("wavering", "confirmed")}, "choices": []},
        "hermione": {"minimums": {"affection": 3},
                     "keys": ["honest_partnership"],
                     "special_min": {"friendship_stability": 1},
                     "world_allowed": {"snape_cover": ("intact", "suspected")}, "choices": []},
        "luna": {"minimums": {"affection": 3},
                 "keys": ["accepted_without_mockery"],
                 "special_min": {"luna_social_confidence": 1},
                 "world_allowed": {"dobby_status": ("free_harry", "free_carina")},
                 "choices": [("M0_C1_LUNA", "listen")]},
        "carina": {"minimums": {"affection": 3},
                   "keys": ["honest_alliance"],
                   "special_min": {},
                   "world_allowed": {"dobby_status": ("free_harry", "free_carina")},
                   "choices": [("M0_C1_CARINA", "cooperate")]},
    }
