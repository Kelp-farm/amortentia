# M4.2: story origin is independent of the chosen heroine and Y4 incident variant.
init -43 python:
    WORLD_DEFAULTS["story_origin"] = "pending"
    WORLD_ENUMS["story_origin"] = ("pending", "main", "hidden", "legacy")

init -15 python:
    _y1_choice("Y1_MALKIN_GUIDE", 1, "", [
        ("decline", "해그리드가 기다리랬으니 여기 있을게.", [("world", "story_origin", "main")]),
        ("accept", "좋아. 같이 가자.", [("world", "story_origin", "hidden")]),
    ], ["story_origin", "butterfly"], True, 3)
    Y1_REVIEW_SCENES["Y1-C1-S03"]["choices"].insert(1, ("Y1_MALKIN_GUIDE", "accept"))
    Y1_REVIEW_CHOICES[1] = (("Y1_C1_RIVAL", "boundary"), ("Y1_MALKIN_GUIDE", "accept"), ("Y1_C1_NOTICE", "curious"), ("Y1_C1_TABLE", "seat"))

    M42_HIDDEN_SCENES = {"Y2-C6-S06", "Y3-C1-S06", "Y3-C1-S07", "Y3-C2-S01",
        "Y3-C3-S03", "Y3-C4-S04", "Y3-C4-S05", "Y3-C6-S03", "Y3-C6-S08", "Y3-C6-S09", "Y3-C6-S10"}
    M42_HIDDEN_SCENES.update(sid for sid,meta in Y4_SCENES.items()
        if meta["condition"] in ("fanfic","other_partner_dating","carina_cover","hidden_cloak_date")
        or meta["condition"]=="carina_dating" and meta["chapter"]=="Y4-C1")
    # Reuse scene IDs for the same calendar event; executable alternate labels
    # replace only the incompatible version, never the original hidden script.
    M42_MAIN_SCENES = {
        "Y2-C6-S04": "남겨진 책임",
        "Y3-C1-S01": "멈춰 선 열차", "Y3-C1-S05": "마법약 수업의 빈자리",
        "Y3-C2-S10": "마을에서 들은 이름", "Y3-C2-S08": "찢어진 초상화",
        "Y3-C2-S05": "눈길의 라이벌", "Y3-C3-S02": "말하지 못한 분노",
        "Y3-C3-S06": "비바람 속 후플푸프전", "Y3-C3-S01": "침대 곁의 친구들",
        "Y3-C4-S08": "지도 위의 낯선 이름", "Y3-C4-S07": "마지막 경기를 앞두고",
        "Y3-C4-S06": "사라진 스캐버스", "Y3-C4-S09": "오두막에서 들린 소리",
        "Y3-C5-S01": "버드나무 아래로", "Y3-C5-S02": "네 사람의 오래된 비밀",
        "Y3-C5-S03": "호숫가에 남은 빛", "Y3-C5-S04": "세 시간을 돌려서",
        "Y3-C6-S01": "다시 오두막 뒤로", "Y3-C6-S02": "헤르미온느와 기다리며",
        "Y3-C6-S04": "이번에는 내가", "Y3-C6-S05": "닫힌 문 너머",
        "Y3-C6-S07": "돌아갈 곳의 약속",
    }
    M42_MAIN_CHOICES = {
        "Y2-C6-S04": ["M42_DIARY_BOUNDARY"], "Y3-C1-S01": ["Y3_TRAIN"],
        "Y3-C1-S05": ["Y3_POTIONS_SEAT", "M42_CLASS_HELP"],
        "Y3-C2-S10": ["M42_SIRIUS_NEWS"], "Y3-C2-S05": ["M42_CARINA_SNOW"],
        "Y3-C3-S02": ["M42_RON_ARGUMENT"], "Y3-C3-S01": ["M42_RECOVERY"],
        "Y3-C4-S06": ["M42_SCABBERS"], "Y3-C5-S02": ["M42_PETER_JUSTICE"],
        "Y3-C5-S04": ["M42_RESCUE_PLAN"], "Y3-C6-S07": ["M42_CARINA_FAREWELL"],
    }
    def m42_choice(cid, chapter, options, tier=2):
        CHOICES[cid] = dict(chapter_id=chapter, text="", options=[dict(id=o,text=t,effects=e) for o,t,e in options],
            tags=["main_story", "relationship"],statistics=True,tier=tier)
    m42_choice("M42_DIARY_BOUNDARY", "Y2-C6", [
        ("answer", "지니는 네 아버지 때문에 죽을 뻔했어.", [("flag","m42_carina_confronted",True)]),
        ("pass", "오늘은 너랑 싸우고 싶지 않아.", []),
    ])
    m42_choice("M42_CLASS_HELP", "Y3-C1", [
        ("help", "자르는 것만 해 줄게. 나머지는 네가 해.", [("relationship","carina","affection",1),("flag","m42_carina_helped",True)]),
        ("own", "스네이프 교수님께 짝을 바꿔 달라고 해.", []),
    ])
    m42_choice("M42_SIRIUS_NEWS", "Y3-C2", [
        ("share", "나 혼자 있고 싶진 않아.", [("flag","m42_sirius_shared",True),("special","friendship_stability",2)]),
        ("alone", "먼저 가. 조금 있다가 따라갈게.", [("flag","m42_sirius_shared",False)]),
    ])
    m42_choice("M42_CARINA_SNOW", "Y3-C2", [
        ("talk", "옆에 앉아도 돼?", [("relationship","carina","affection",1),("flag","m42_carina_conversation",True)]),
        ("rival", "경기장에서 보자.", [("flag","m42_carina_rival",True)]),
    ])
    m42_choice("M42_RON_ARGUMENT", "Y3-C3", [
        ("explain", "화난 건 너한테가 아니야. 미안해.", [("flag","m42_ron_distance",False),("special","friendship_stability",2)]),
        ("withdraw", "오늘은 그 얘기 그만하자.", [("flag","m42_ron_distance",True),("special","friendship_stability",-1)]),
    ])
    m42_choice("M42_RECOVERY", "Y3-C3", [("friends","너희는 괜찮아?",[]),("match","경기는 어떻게 됐어?",[])],1)
    m42_choice("M42_SCABBERS", "Y3-C4", [
        ("search", "같이 찾아보자. 아직 본 사람은 없잖아.", [("flag","m42_trio_search",True),("special","friendship_stability",2)]),
        ("blame", "헤르미온느, 고양이는 좀 데리고 있어 줘.", [("flag","m42_hermione_friction",True),("relationship","hermione","affection",-1)]),
    ])
    m42_choice("M42_PETER_JUSTICE", "Y3-C5", [
        ("trial", "죽이지 마세요. 데려가서 증언하게 해야 해요.", [("personality","harry_mercy",3)]),
        ("ron", "론, 네 눈으로 본 걸 꼭 말해 줘.", [("special","friendship_stability",2)]),
    ])
    m42_choice("M42_RESCUE_PLAN", "Y3-C5", [
        ("together", "어디로 가야 하는지 같이 확인하자.", [("flag","m42_rescue_listened",True),("relationship","hermione","affection",1)]),
        ("hurry", "알았어. 서두르자.", []),
    ])
    m42_choice("M42_CARINA_FAREWELL", "Y3-C6", [
        ("friendly", "잘 지내. 다음 학기에 보자.", [("flag","m42_carina_farewell",True),("relationship","carina","affection",1)]),
        ("rival", "다음 경기엔 핑계 없기다.", [("flag","m42_carina_rival",True)]),
    ])
    # Index alternatives alongside hidden choices; execution filters by origin.
    for _sid,_choices in M42_MAIN_CHOICES.items():
        _scenes=Y2_SCENES if _sid.startswith("Y2") else Y3_SCENES
        _scenes[_sid]["choices"] += [c for c in _choices if c not in _scenes[_sid]["choices"]]
        for _cid in _choices:
            if _cid.startswith("M42_"):
                CHOICES[_cid]["chapter_id"]=_scenes[_sid]["chapter"]
