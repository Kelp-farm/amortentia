init -15 python:
    _y5_choice("Y5_HERMIONE_CHO",4,2,[
        ("friends","응. 초랑 잘 지내 보고 싶어.",[]),
        ("overlap","초와는 계속 만나면서, 너하고도 데이트하고 싶어.",[_y5_aff("hermione",-2)])])
    _y5_choice("Y5_GINNY_CHO",4,2,[
        ("friends","응. 초랑 잘 지내 보고 싶어.",[]),
        ("overlap","초와는 계속 만나면서, 너하고도 데이트하고 싶어.",[_y5_aff("ginny",-2)])])
    _y5_choice("Y5_HERMIONE_CLEAR",4,2,[
        ("apologize","초와 사귀면서 너한테 그런 말을 한 건 잘못했어. 미안해.",[]),
        ("later","그때 했던 말은 꺼내지 않는다.",[])])
    _y5_choice("Y5_GINNY_CLEAR",4,2,[
        ("apologize","초와 사귀면서 너한테 그런 말을 한 건 잘못했어. 미안해.",[]),
        ("later","그때 했던 말은 꺼내지 않는다.",[])])
    _y5_scene(4,24,"말해 주고 싶었던 일","2031-01-18","그리핀도르 휴게실","hermione","common",["HERMIONE_CHO"],"cho_active",music="hermione")
    _y5_scene(4,25,"연습을 마친 오후","2031-02-25","퀴디치 연습장","ginny","pitch",["GINNY_CHO"],"cho_active",music="ginny")
    _y5_scene(4,26,"다시 꺼낸 이야기","2031-04-06","그리핀도르 휴게실","hermione ginny","common",["HERMIONE_CLEAR","GINNY_CLEAR"],"cho_ended",music="warm")
    for _sid,_offset in {"Y5-C4-S24":0.25,"Y5-C4-S25":1.75,"Y5-C4-S26":5.75}.items():
        Y5_SCENES[_sid]["offset"]=_offset
    Y5_CHO_ROMANTIC_SCENES.update(("Y5-C4-S24","Y5-C4-S25","Y5-C4-S26"))

