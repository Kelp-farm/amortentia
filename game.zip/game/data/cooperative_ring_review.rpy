# Winter gift and rescue histories remain separate from the source quarrel.
init 4 python:
    for _key,_title,_answer,_companion in (
        ("coop_ring_wear","협력 유지 · 겨울 반지 착용","wear","carina"),
        ("coop_ring_keep","협력 유지 · 겨울 반지 보관","keep","hermione"),
        ("coop_ring_hermione","겨울 반지 착용 · 헤르미온느 동행","wear","hermione")):
        M33_QA_PRESETS[_key]=dict(title=_title,profile="carina",
            prior={"REVIEW_Y3_SIRIUS_REVEAL":"reveal","Y3_SECRET":"include","Y3_COOP_RING":_answer,"Y3_RESCUE":_companion},
            local={"Y3_SECRET":"include","Y3_COOP_RING":_answer})
        for _sid in ("Y3-C3-S03","Y3-C6-S01"):
            M21_NODES[_sid]["replay"]["presets"].append(_key)
            M33_SCENE_VARIANTS[_sid].append(_key)
        if _answer=="wear" and _companion=="carina":
            M21_NODES["Y3-C6-S03"]["replay"]["presets"].append(_key)
            M33_SCENE_VARIANTS["Y3-C6-S03"].append(_key)
