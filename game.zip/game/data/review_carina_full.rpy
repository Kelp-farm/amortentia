# Approved 2026-10-26 screenplay promoted to production by explicit owner instruction.
init -15 python:
    _y4_choice("Y4_REVIEW_JEALOUSY",2,1,[
        ("admit","크룸이랑 있는 걸 보고 질투했어. 먼저 물어볼 걸 그랬다.",[]),
        ("ask","며칠째 못 만났잖아. 무슨 일로 그렇게 바빴어?",[])])
    _y4_choice("Y4_REVIEW_MOODY",3,3,[
        ("trust","무디를 믿는다. 기사에 관해서는 덤블도어 교수님께 확인하자.",[("flag","review_y4_moody_attacked",False)]),
        ("attack","무디를 의심한다. 시리우스와 함께 기습한다.",[("flag","review_y4_moody_attacked",True)])])
    Y4_SCENES["Y4-C2-S04"]["choices"].insert(0,"Y4_REVIEW_JEALOUSY")
    Y4_SCENES["Y4-C3-S11"]["choices"].append("Y4_REVIEW_MOODY")

define review_andromeda = Character("안드로메다 통스", callback=y1_speaker_callback("andromeda"))

init -13 python:
    _y5_choice("Y5_H_REVIEW_SCANDAL",4,2,[
        ("publish","실어. 대신 진짜 기억 이야기는 한 줄도 넣지 마.",[("flag","review_y5_scandal_published",True)]),
        ("omit","빼자. 없는 연애까지 지어낼 필요는 없잖아.",[("flag","review_y5_scandal_published",False)])])
    Y5_SCENES["Y5-C4-S17"]["choices"].append("Y5_H_REVIEW_SCANDAL")

init -12 python:
    CHOICES["Y7_H_REVIEW_COMFORT"]={"chapter_id":"Y7-C4","text":"","tier":1,"statistics":False,"tags":["year7","conversation"],"options":[
        {"id":"hug","text":"카리나를 안아 준다.","effects":[]},
        {"id":"reassure","text":"네가 해 준 일을 후회하게 하고 싶지 않아.","effects":[]}]}
    CHOICES["Y7_H_REVIEW_WAND"]={"chapter_id":"Y7-C5","text":"","tier":1,"statistics":False,"tags":["year7","conversation"],"options":[
        {"id":"lower","text":"지팡이를 내린다.","effects":[]},
        {"id":"turn","text":"카리나에게서 지팡이를 돌려, 내 쪽으로 향한다.","effects":[]}]}
    Y7_SCENES["Y7-C4-S11"]["choices"].append("Y7_H_REVIEW_COMFORT")
    Y7_SCENES["Y7-C5-S13"]["choices"].append("Y7_H_REVIEW_WAND")

define review_cormac = Character("코맥 맥클라건", callback=y1_speaker_callback("cormac"))
