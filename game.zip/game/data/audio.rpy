# M4.3: choices and world states are inputs only; audio never mutates the story.
init -2 python:
    M43_TRACKS = {
        "title": "문 너머의 계절", "school": "창가의 수업",
        "warm": "남겨 둔 자리", "mischief": "뒤집힌 시간표",
        "village": "작은 가게의 오후", "anticipation": "아직 하지 않은 말",
        "carina": "은빛으로 접어 둔 말", "hermione": "여백에 적은 대답",
        "ginny": "먼저 달려온 발소리", "luna": "다른 쪽 창문",
        "mystery": "계단 아래의 물음", "danger": "닫히는 출구",
        "separation": "접어 보내지 못한 편지", "waltz": "촛불 사이의 세 걸음",
        "reflection": "다음 역의 여름", "practice": "처음 맞추는 박자",
    }
    M43_SCENE_MUSIC = {}
    _m43_groups = {
        "title": "Y1-C1-S02 Y1-C1-S07",
        "carina": "Y1-C1-S03 Y1-C1-S06 Y1-C2-S02 Y1-C2-S07 Y2-C2-S02 Y2-C6-S05 Y3-C1-S05 Y3-C4-S05 Y3-C6-S10 Y4-C3-S06",
        "hermione": "Y1-C3-S04 Y1-C4-S10 Y2-C6-S01 Y3-C2-S06 Y3-C4-S01 Y4-C3-S03 Y4-C8-S05",
        "ginny": "Y2-C6-S02 Y3-C4-S02 Y4-C3-S04",
        "luna": "Y2-C1-S05 Y2-C6-S03 Y3-C2-S07 Y3-C4-S03 Y4-C2-S06 Y4-C3-S05 Y4-C8-S07",
        "warm": "Y1-C1-S05 Y1-C2-S01 Y1-C4-S05 Y1-C4-S08 Y2-C1-S01 Y2-C1-S02 Y2-C3-S03 Y2-C3-S05 Y2-C4-S02 Y2-C5-S02 Y2-C6-S06 Y3-C1-S06 Y3-C3-S01 Y3-C3-S03 Y3-C4-S08 Y3-C6-S06 Y4-C2-S04 Y4-C5-S04 Y4-C5-S05 Y4-C8-S01 Y4-C8-S06",
        "mischief": "Y1-C2-S03 Y2-C1-S03 Y2-C2-S01 Y2-C2-S03 Y2-C2-S05 Y3-C1-S07 Y3-C2-S09 Y4-C2-S02 Y4-C3-S11",
        "village": "Y3-C2-S10 Y3-C2-S01 Y3-C2-S03 Y3-C2-S04",
        "anticipation": "Y3-C6-S03 Y3-C6-S05 Y3-C6-S09 Y4-C1-S06 Y4-C2-S07 Y4-C3-S01 Y4-C3-S02 Y4-C3-S12 Y4-C4-S07 Y4-C5-S06",
        "mystery": "Y1-C2-S06 Y1-C3-S10 Y1-C4-S01 Y1-C4-S02 Y1-C4-S03 Y1-C4-S06 Y2-C2-S04 Y2-C3-S02 Y2-C3-S04 Y2-C4-S01 Y2-C4-S05 Y2-C5-S01 Y2-C5-S03 Y2-C5-S04 Y2-C6-S04 Y3-C1-S04 Y3-C2-S08 Y3-C3-S02 Y3-C3-S04 Y3-C4-S04 Y3-C4-S09 Y3-C5-S01 Y3-C5-S02 Y3-C5-S04 Y3-C6-S01 Y4-C1-S07 Y4-C2-S01 Y4-C2-S03 Y4-C5-S01 Y4-C5-S02 Y4-C6-S01 Y4-C6-S02 Y4-C7-S01 Y4-C7-S03 Y4-C8-S02 Y4-C8-S03 Y4-C8-S04",
        "danger": "Y1-C3-S01 Y1-C3-S02 Y1-C3-S03 Y1-C3-S05 Y1-C4-S04 Y1-C4-S07 Y1-C4-S09 Y2-C1-S04 Y2-C2-S06 Y2-C3-S01 Y2-C4-S04 Y3-C3-S05 Y3-C3-S06 Y3-C5-S03 Y3-C6-S02 Y3-C6-S04 Y4-C1-S02 Y4-C2-S05 Y4-C5-S03 Y4-C7-S02 Y4-C7-S04",
        "separation": "Y4-C6-S03 Y4-C6-S04 Y4-C8-S08",
        "practice": "Y4-C3-S07 Y4-C3-S08 Y4-C3-S09 Y4-C3-S10",
        "waltz": "Y4-C4-S01 Y4-C4-S02 Y4-C4-S03 Y4-C4-S04 Y4-C4-S05 Y4-C4-S06",
        "reflection": "Y1-C4-S12 Y1-C4-S14 Y3-C6-S07 Y4-C7-S05 Y4-C8-S09",
    }
    for _track, _scenes in _m43_groups.items():
        for _sid in _scenes.split():
            if _sid in M43_SCENE_MUSIC: raise ValueError("Duplicate audio scene: "+_sid)
            M43_SCENE_MUSIC[_sid] = _track
    M43_SCENE_MUSIC["Y3-C4-S06"]="mystery"
    M43_SCENE_MUSIC["Y4-C2-S08"]="warm"
    M43_SCENE_MUSIC["Y4-C2-S09"]="mystery"
    M43_SCENE_MUSIC["Y4-C5-S07"]="carina"
    M43_ENTRY_SFX = {
        "Y1-C1-S05":"train", "Y2-C3-S04":"water",
        "Y3-C6-S11":"owl", "Y3-C2-S10":"footsteps", "Y3-C4-S09":"footsteps", "Y3-C3-S06":"thunder",
        "Y4-C1-S02":"wind", "Y4-C3-S11":"cloth", "Y4-C5-S03":"water",
        "Y4-C6-S03":"page", "Y4-C6-S04":"door", "Y4-C7-S01":"wind",
    }
