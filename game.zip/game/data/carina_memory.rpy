# Deliberate original-game divergence, outside the fanfiction-fidelity baseline.
init -11 python:
    for _sid in ("Y6-C2-S14","Y6-C2-S15"):
        Y6_SCENES[_sid]["bg"]="private_requirement"
    _y4_choice("Y4_MEMORY_PLAN",8,3,[
        ("keep","기억까지 바꾸고 싶지는 않아. 다른 방법을 찾자.",[]),
        ("prepare","어디까지 바꿀 수 있는지부터 알아보자. 아직 하겠다는 약속은 아니야.",[])])
    _y4_choice("Y4_MEMORY_CONSENT",8,3,[
        ("stop","그만두자. 네가 기억하는 채로 돌아갔으면 좋겠어.",[]),
        ("proceed","설명한 범위만 바꿀게. 지금도 네 뜻이 같다면.",[])])
    _y4_scene(8,10,"지우지 않을 것들","2030-06-26","빈 교실","carina dumbledore","classroom",["Y4_MEMORY_PLAN"],"memory_offer")
    _y4_scene(8,11,"한 사람에게 남길 기억","2030-06-29","마지막 저녁의 빈 교실","carina","classroom",["Y4_MEMORY_CONSENT"],"memory_consent")
    _before={"Y4-C8-S05":["Y4-C8-S10"],"Y4-C8-S08":["Y4-C8-S11"]}
    _new={}
    for _sid,_meta in list(Y4_SCENES.items()):
        if _sid in ("Y4-C8-S10","Y4-C8-S11"): continue
        for _extra in _before.get(_sid,[]): _new[_extra]=Y4_SCENES[_extra]
        _new[_sid]=_meta
    Y4_SCENES=_new
    for _chapter in range(1,9):
        for _offset,_sid in enumerate(s for s,m in Y4_SCENES.items() if m["number"]==_chapter and s!="Y4-C2-S09"):
            Y4_SCENES[_sid]["offset"]=_offset
    # The alternate dragon reveals occupy one traversal slot, including after
    # adding the memory-branch scenes. Do not shift existing save offsets.
    Y4_SCENES["Y4-C2-S09"]["offset"] = Y4_SCENES["Y4-C2-S04"]["offset"]

    _y7_choice("Y7_MEMORY_OFFER",9,3,[
        ("tell","네게 돌려줘야 할 이야기가 있어. 들을지는 네가 정했으면 해.",[]),
        ("defer","지금은 이야기하지 않는다. 기록과 반지는 안전하게 보관한다.",[])])
    _y7_choice("Y7_MEMORY_RESTORE",9,3,[
        ("restore","네가 읽고 정한 범위대로 해 보자. 멈추고 싶으면 바로 말해.",[]),
        ("decline","오늘은 하지 말자. 네가 원하지 않는다면 돌려놓지 않을게.",[])])
    _y7_choice("Y7_MEMORY_FUTURE",9,3,[
        ("friends","네 기억이 돌아와서 다행이야. 지금은 서로의 삶을 존중하고 싶어.",[]),
        ("again","그때로 돌아가자는 말은 아니야. 지금의 너와 다시 만나고 싶어.",[])])
    _y7_choice("Y7_MEMORY_CURRENT",9,3,[
        ("stay","너와 계속 만나고 싶어. 카리나의 기억을 돌려준 것과는 별개로.",[]),
        ("end","다른 사람에게 마음이 남아 있는데 너와 계속 사귈 수는 없어. 여기서 그만 만나자.",[])])
    _y7_choice("Y7_MEMORY_LISTEN",9,2,[
        ("listen","내가 모르는 동안 네가 어떻게 지냈는지도 듣고 싶어.",[("relationship","carina","affection",4)]),
        ("explain","네가 모르는 동안 내가 어떻게 지냈는지 이야기하고 싶어.",[])])
    _y7_choice("Y7_MEMORY_PRESENT",9,2,[
        ("present","다음 주에는 뭘 하고 싶어? 네가 가고 싶은 곳이 있으면 같이 가자.",[("relationship","carina","affection",4)]),
        ("past","우리 처음 같이 걸었던 길을 다시 가 보고 싶어.",[])])
    _y7_scene(9,20,"돌려주지 못한 것","2033-06-23","호그와트의 빈 교실","classroom","carina",["Y7_MEMORY_OFFER"],"carina_pressure","memory")
    _y7_scene(9,21,"기록에 남긴 동의","2033-07-02","성 뭉고의 상담실","office","carina",["Y7_MEMORY_RESTORE"],"reflection","memory")
    _y7_scene(9,22,"기억 다음의 대답","2033-07-09","병원 정원의 벤치","courtyard","carina",["Y7_MEMORY_FUTURE"],"carina_reconcile","memory")
    _y7_scene(9,23,"먼저 해야 할 이야기","2033-07-06","호그와트 호숫가","lake","hermione ginny luna",["Y7_MEMORY_CURRENT"],"reflection","memory")
    _y7_scene(9,24,"서로 모르던 시간","2033-07-08","다이애건 앨리의 찻집","teashop","carina",["Y7_MEMORY_LISTEN","Y7_MEMORY_PRESENT"],"reflection","memory")
    _y7_scene(11,20,"오늘부터 세는 날","2034-03-19","해 질 무렵의 안뜰","courtyard","carina",[],"carina_reconcile","memory")
    _new={}
    for _sid,_meta in list(Y7_SCENES.items()):
        if _sid in ("Y7-C9-S20","Y7-C9-S21","Y7-C9-S22","Y7-C9-S23","Y7-C9-S24","Y7-C11-S20"): continue
        if _sid=="Y7-C9-S05":
            for _extra in ("Y7-C9-S20","Y7-C9-S21","Y7-C9-S23","Y7-C9-S24","Y7-C9-S22"): _new[_extra]=Y7_SCENES[_extra]
        if _sid=="Y7-C11-S06": _new["Y7-C11-S20"]=Y7_SCENES["Y7-C11-S20"]
        _new[_sid]=_meta
    Y7_SCENES=_new
    for _sid in ("Y7-C9-S20","Y7-C9-S21","Y7-C9-S22","Y7-C9-S23","Y7-C9-S24","Y7-C11-S20"):
        Y7_SCENES[_sid].update(story_lane="memory",source="M7.3.2 · approved original expansion",outfit="school" if "C11" in _sid else "casual")
    # Keep all existing offsets, which are also saved replay entry locations.
    for _sid,_off in (("Y7-C9-S20",3.1),("Y7-C9-S21",3.2),("Y7-C9-S23",3.25),("Y7-C9-S24",3.27),("Y7-C9-S22",3.3),("Y7-C11-S20",4.5)):
        Y7_SCENES[_sid]["offset"]=_off
