init -42 python:
    WORLD_DEFAULTS.update({"y6_phase":"pending","y6_dumbledore_killer":"none",
        "y6_voldemort":"active","y6_soul":"unidentified","y6_protection":"unknown",
        "y6_snape":"alive","y6_carina":"guarded","y6_cabinet":"unknown",
        "y6_next_campaign":"pending"})
    WORLD_ENUMS.update({"y6_phase":("pending","school","counterattack","aftermath","complete"),
        "y6_dumbledore_killer":("none","snape","voldemort_through_harry"),
        "y6_voldemort":("active","body_defeated"),
        "y6_soul":("unidentified","remaining_fragment"),
        "y6_protection":("unknown","active","expired"),
        "y6_snape":("alive","dead_protecting_harry","fugitive"),
        "y6_carina":("guarded","sleeping","recovering","reunited","fled"),
        "y6_cabinet":("unknown","suspected","repaired","infiltration","counterattack","closed"),
        "y6_next_campaign":("pending","main_horcrux_hunt","hidden_soul_summer")})
    WORLD_ENUMS["dumbledore_status"] += ("dead_hidden",)
    WORLD_ENUMS["hogwarts_control"] += ("mcgonagall",)
