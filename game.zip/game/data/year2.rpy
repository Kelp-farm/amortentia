init -45 python:
    WORLD_DEFAULTS.update({"diary_status": "unencountered", "carina_cooperation": "none", "horcrux_research": "none"})
    WORLD_ENUMS.update({"diary_status": ("unencountered", "active", "destroyed"),
        "carina_cooperation": ("none", "pressured"),
        "horcrux_research": ("none", "identified")})

init -19 python:
    Y2_TITLES = ("다시 열린 문", "복도에 남은 말", "빈 페이지", "사라진 아이", "돌아오는 길", "말포이의 대답")
    for _i, _title in enumerate(Y2_TITLES, 1):
        CHAPTERS["Y2-C%d" % _i] = {"year": 2, "number": _i, "title": _title, "pov": "harry", "demo": False}
    def _y2_choice(cid, chapter, tier, options):
        CHOICES[cid] = {"chapter_id": "Y2-C%d" % chapter, "text": "", "tier": tier,
            "statistics": tier > 1, "tags": ["year2", "butterfly" if tier == 3 else "conversation"],
            "options": [{"id": oid, "text": text, "effects": effects} for oid, text, effects in options]}
    def _y2_memory(h, key, text):
        return ("relationship_event", h, key, "memory", text, False)
    _y2_choice("Y2_WARNING",1,1,[
        ("sit","일단 앉아. 다치잖아.",[("world","dobby_trust",2)]),
        ("ask","누가 위험한데? 나만?",[])])
    _y2_choice("Y2_GINNY_BOOK",1,1,[
        ("birds","새 그림이 있는 쪽부터 볼까?",[]),
        ("spells","제일 먼저 해 보고 싶은 주문 있어?",[])])
    _y2_choice("Y2_REUNION",1,1,[
        ("late","다친 데는 없어. 정말이야.",[]),
        ("missed","그래도 너희 얼굴 보니까 좋다.",[("relationship","hermione","affection",1)])])
    _y2_choice("Y2_LUNA_NOTE",1,2,[
        ("return","펴 보지 않고 노트를 돌려준다.",[("relationship","luna","affection",2),_y2_memory("luna","y2_notebook_returned","허락 없이 노트를 펼치지 않았다.")]),
        ("ask","이거 네 노트야? 펼쳐 봐도 돼?",[("relationship","luna","affection",1),_y2_memory("luna","y2_notebook_asked","그림을 보기 전에 허락을 물었다.")])])
    _y2_choice("Y2_GINNY_TABLE",1,1,[
        ("save","끝자리 남겨 둘게.",[("relationship","ginny","affection",1)]),
        ("wave","먼저 가. 식탁에서 보자.",[])])
    _y2_choice("Y2_HERB",2,1,[
        ("trade","내 건 잘 안 맞아. 바꿔 써 볼래?",[]),
        ("laugh","론 표정 좀 봐. 벌써 귀가 아픈가 봐.",[])])
    _y2_choice("Y2_PITCH",2,2,[
        ("object","헤르미온느가 빗자루 얘기했지, 네 혈통 물었어?",[("relationship","hermione","affection",1),_y2_memory("carina","y2_prejudice_challenged","헤르미온느를 모욕한 말을 해리가 따졌다.")]),
        ("leave","그만 가자. 이 얘기 더 듣기 싫어.",[_y2_memory("hermione","y2_left_pitch","경기장 앞의 모욕적인 대화에서 함께 나왔다.")])])
    # Retain the old definition only for old save/statistics records; never reinterpret it.
    CHOICES["Y2_PITCH"]["legacy"] = True
    _y2_choice("Y2_SLUG_RESPONSE",2,2,[
        ("help","카리나에게 다가가 몸을 가려 준다.",[_y2_memory("carina","y2_slug_helped","민달팽이 주문을 맞았을 때 구경하는 사람들을 가리고 오두막까지 부축했다.")]),
        ("mock","꼴좋다고 생각하며 돌아선다.",[("relationship","carina","affection",-1),_y2_memory("carina","y2_slug_abandoned","민달팽이 주문을 맞은 자신을 보고 해리가 외면했다.")])])
    _y2_choice("Y2_GINNY_PRACTICE",2,1,[
        ("target","좀 더 멀리서 던져 봐.",[("relationship","ginny","affection",1)]),
        ("ron","빗자루 타면서도 잘 던지겠다.",[])])
    _y2_choice("Y2_LUNA_WATCH",2,2,[
        ("stay","잠깐만. 이번에는 나도 보고 있을게.",[("relationship","luna","affection",1),_y2_memory("luna","y2_lake_watch","지니와 함께 쉬다가 산책길에 잠깐 남아 루나와 새 그림을 보았다.")]),
        ("later","오늘은 가 봐야 해. 뭐였는지 나중에 알려 줘.",[_y2_memory("luna","y2_lake_declined","호숫가 관찰은 다음으로 미뤘다.")])])
    _y2_choice("Y2_RUMOR",2,1,[
        ("tell","벽 안에서 목소리가 들렸어.",[("personality","harry_reliance",3),("flag","y2_voice_shared",True)]),
        ("later","여기 말고. 사람 없는 데 가서 얘기하자.",[])])
    _y2_choice("Y2_DUEL_REPLY",3,1,[
        ("explain","물러서라고 한 거야. 저스틴을 물라고 한 게 아니고.",[]),
        ("question","내가 무슨 말을 했는데? 너희한테 어떻게 들렸어?",[])])
    _y2_choice("Y2_DIARY_REPLY",3,1,[
        ("school","학교에 무슨 일이 있었는지 묻는다.",[]),
        ("owner","전에 누가 이 일기장을 썼는지 묻는다.",[])])
    _y2_choice("Y2_GINNY_WORRY",3,2,[
        ("room","여기 앉을래? 론은 아직 수업 중이야.",[("relationship","ginny","affection",2),_y2_memory("ginny","y2_waited_for_words","말을 꺼내기 어려워하는 지니 옆에서 기다렸다.")]),
        ("help","얼굴이 안 좋아. 폼프리 부인한테 같이 갈까?",[("relationship","ginny","affection",1),_y2_memory("ginny","y2_offered_clinic","혼자 참지 않도록 의무실에 함께 가자고 했다.")])])
    _y2_choice("Y2_HERMIONE_STUDY",4,2,[
        ("stay","내가 날짜 찾을게. 넌 제목 봐.",[("relationship","hermione","affection",1),_y2_memory("hermione","y2_archive_help","오래된 신문을 나눠 찾아 읽었다.")]),
        ("later","론부터 찾아올게. 셋이 하면 빨리 끝나겠지.",[_y2_memory("hermione","y2_archive_trio","혼자 남기지 않고 론과 돌아와 기록을 찾았다.")])])
    _y2_choice("Y2_LUNA_RUMOR",3,1,[
        ("birds","저 새들은 나를 보고도 안 도망가네.",[]),
        ("tired","나 보자마자 조용해지는 게 더 싫어.",[("relationship","luna","affection",1)])])
    _y2_choice("Y2_CARINA_APPROACH",6,3,[
        ("pressure","일기장의 비밀로 카리나를 협박한다.",[("relationship","carina","affection",-3),_y2_memory("carina","y2_coercion","일기장의 정체와 가족에게 닥칠 보복을 협박 수단으로 썼다.")]),
        ("leave","일기장을 가방에 넣고 카리나를 지나친다.",[("world","carina_cooperation","none")])])
    _y2_choice("Y2_EMPTY_SEAT",4,1,[
        ("read","헤르미온느가 접어 둔 페이지를 소리 내어 읽는다.",[]),
        ("quiet","책을 덮고 잠깐 곁에 앉아 있는다.",[])])
    _y2_choice("Y2_GINNY_MISSING",4,1,[
        ("ron","론의 어깨를 붙잡고 함께 출발한다.",[("personality","harry_reliance",2)]),
        ("message","맥고나걸 교수에게 발견한 단서를 남긴다.",[("flag","y2_rescue_message",True)])])
    _y2_choice("Y2_CHAMBER_GINNY",5,1,[
        ("name","지니의 이름을 다시 부른다.",[]),
        ("hand","차가운 손을 붙잡고 숨을 확인한다.",[])])
    CHOICES["Y2_CHAMBER_GINNY"]["legacy"] = True
    _y2_choice("Y2_DOBBY",5,3,[
        ("free","양말을 일기장 안에 끼워 넣는다.",[("world","dobby_status","free_harry"),("world","dobby_trust",8),("flag","y2_dobby_freed_by_harry",True)]),
        ("bound","일기장을 그대로 돌려준다.",[("flag","y2_dobby_left_bound",True)])])
    _y2_choice("Y2_GINNY_AFTER",5,2,[
        ("stay","응. 론 올 때까지만 있을게.",[("relationship","ginny","affection",1),_y2_memory("ginny","y2_recovery_company","지니가 원하는 만큼만 병실에 머물렀다.")]),
        ("leave","알았어. 내일 다시 와도 돼?",[("relationship","ginny","affection",2),_y2_memory("ginny","y2_recovery_space","지니가 쉴 시간을 주고 다음 방문을 물었다.")])])
    _y2_choice("Y2_HERMIONE_RETURN",6,1,[
        ("book","네 책 가져왔어. 돌려주려고.",[]),
        ("missed","네가 없으니까 정말 이상했어.",[("relationship","hermione","affection",1)])])
    _y2_choice("Y2_GINNY_FIELD",6,2,[
        ("play","좋아. 어디서 던질까?",[("relationship","ginny","affection",1),_y2_memory("ginny","y2_fair_practice","회복 뒤 지니가 정한 연습에 함께했다.")]),
        ("watch","이번엔 볼게. 다음엔 나도 끼워 줘.",[_y2_memory("ginny","y2_practice_watched","지니와 친구들의 연습을 구경했다.")])])
    _y2_choice("Y2_LUNA_SUMMER",6,2,[
        ("draw","그 새 그림, 한 장 받아도 돼?",[("relationship","luna","affection",1),_y2_memory("luna","y2_drawing_requested","루나가 그린 새 그림을 부탁했다.")]),
        ("news","지니, 너도 이 새 봤어?",[_y2_memory("luna","y2_shared_friendship","지니와 루나에게 새를 보았던 이야기를 들었다.")])])
    _y2_choice("Y2_SUMMER",6,1,[
        ("letters","편지 보내. 이번엔 꼭 답장할게.",[("flag","y2_owl_post_interest",True)]),
        ("friends","다음 학기엔 우리 좀 조용히 지내자.",[("flag","y2_friendship_focus",True)])])

    # Retired definitions remain historical; M2E records exposure and coercion separately.
    CHOICES["Y2_DOBBY"]["legacy"] = True
    CHOICES["Y2_CARINA_APPROACH"]["legacy"] = True
    _y2_choice("Y2_DIARY_DECISION",5,3,[
        ("free","양말을 끼워 일기장을 루시우스에게 건넨다.",[("world","dobby_status","free_harry"),("world","dobby_trust",8),("flag","y2_dobby_freed_by_harry",True),("flag","y2_diary_with_harry",False),("flag","y2_diary_with_lucius",True)]),
        ("pressure","카리나를 협박할 증거로 일기장을 챙긴다.",[("flag","y2_dobby_left_bound",True),("flag","y2_diary_with_harry",True),("flag","y2_diary_with_lucius",False)])])

    CHOICES["Y2_DIARY_DECISION"]["legacy"] = True
    _y2_choice("Y2_DIARY_EXPOSURE",5,3,[
        ("expose","양말을 끼운 일기장을 루시우스에게 내민다.",[("world","dobby_status","free_harry"),("world","dobby_trust",8),("flag","y2_dobby_freed_by_harry",True),("flag","y2_lucius_saw_diary",True)]),
        ("hide","일기장을 가방에 숨긴 채 루시우스를 보낸다.",[("flag","y2_dobby_left_bound",True),("flag","y2_lucius_saw_diary",False)])])
    _y2_choice("Y2_CARINA_DECISION",6,3,[
        ("pressure","일기장의 비밀을 밝히겠다고 협박해 카리나의 협력을 요구한다.",[("relationship","carina","affection",-3),_y2_memory("carina","y2_coercion","일기장의 정체와 가족에게 닥칠 보복을 협박 수단으로 썼다.")]),
        ("leave","아무 말 없이 지나간다.",[("world","carina_cooperation","none")])])

    # Editorial choice only; not registered in the production game.
    _y2_choice("REVIEW_Y2_INVESTIGATION_METHOD",3,1,[
        ("polyjuice","크래브와 고일로 변장해 잠입한다.",[]),
        ("feigned_death","죽은 척해서 카리나를 떠본다.",[])])
