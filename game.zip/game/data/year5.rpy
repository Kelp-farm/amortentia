# M5: additive state; the Y4 worldline remains the single source of truth.
init -42 python:
    WORLD_DEFAULTS.update({"y5_phase":"pending", "y5_prophecy":"untouched",
        "y5_ending":"pending", "y5_carina_da":"unknown", "y5_arthur":"safe",
        "y5_companions":"none", "y5_carina_conflict":"unresolved"})
    WORLD_ENUMS.update({"y5_phase":("pending","school","ministry","aftermath","complete","captured"),
        "y5_prophecy":("untouched","destroyed","stolen"),
        "y5_ending":("pending","bereaved","survivors","averted","captured"),
        "y5_carina_da":("unknown","silent","exposed"),
        "y5_arthur":("safe","recovering"),
        "y5_companions":("none","alone","da"),
        "y5_carina_conflict":("unresolved","boundaries","distance")})

init -16 python:
    Y5_TITLES=("말할 수 없는 여름","가르치지 않는 수업","우리에게 필요한 마법",
        "닫히는 학교","아홉 번째 지하층","남겨진 사람들")
    for _n,_t in enumerate(Y5_TITLES,1):
        CHAPTERS["Y5-C%d"%_n]=dict(year=5,number=_n,title=_t,pov="harry",demo=False)
    def _y5_choice(cid,c,t,options):
        CHOICES[cid]=dict(chapter_id="Y5-C%d"%c,text="",tier=t,statistics=t>1,
            tags=["year5","butterfly" if t==3 else "conversation"],
            options=[dict(id=o,text=s,effects=e) for o,s,e in options])
    def _y5_aff(h,n): return ("relationship",h,"affection",n)
    _y5_choice("Y5_LETTERS",1,1,[("angry","나만 빼고 다 알고 있었던 거야?",[]),("hear","왜 말 못 했는지라도 알려 줘.",[])])
    _y5_choice("Y5_SUMMER",1,2,[("share","악몽을 꾼다는 것도 말한다.",[("flag","y5_shared_nightmares",True)]),("later","지금은 같이 있고 싶다고 말한다.",[])])
    _y5_choice("Y5_CONTACT",1,2,[("mirror","급할 때 쓸 연락 방법부터 정한다.",[("flag","y5_contact_agreed",True)]),("visit","다음에 언제 만날 수 있는지 묻는다.",[])])
    _y5_choice("Y5_CARINA_TRAIN",2,2,[("hear","네 얘기도 듣고 싶어.",[_y5_aff("carina",1),("flag","y5_carina_conversation",True)]),("leave","알았어. 여기서 그만하자.",[])])
    _y5_choice("Y5_THESTRAL",2,1,[("ask","처음 봤을 때는 어땠어?",[_y5_aff("luna",1)]),("space","얘기하고 싶어지면 들어 줄게.",[])])
    _y5_choice("Y5_CLASS",2,1,[("question","연습도 안 하고 실기 시험을 어떻게 보죠?",[]),("truth","볼드모트가 돌아왔어요. 이론만 배워선 안 돼요.",[])])
    _y5_choice("Y5_QUILL",2,2,[("show","손등을 보여 주고 도움을 청한다.",[("flag","y5_quill_documented",True)]),("hide","아직은 말하지 않는다.",[])])
    _y5_choice("Y5_PAPER_HARM",2,2,[("help","내가 도울 일이 있으면 말해 줘.",[_y5_aff("luna",1),("flag","y5_press_support",True)]),("apologize","내 얘기를 싣다가 이렇게 된 거잖아. 미안해.",[])])
    _y5_choice("Y5_DA_RULE",3,2,[("agree","위험과 연락 방법부터 모두에게 설명한다.",[("flag","y5_da_safety",True)]),("practice","오늘은 무장 해제 주문부터 연습하자.",[])])
    _y5_choice("Y5_DA_RON",3,1,[("partner","론, 네가 나랑 시범 좀 보여 줘.",[("flag","y5_ron_demonstration",True)]),("organize","론, 두 명씩 짝짓는 것 좀 도와줘.",[])])
    _y5_choice("Y5_HERMIONE_TIME",3,2,[("stay","정리 끝날 때까지 같이 있을게.",[_y5_aff("hermione",2),("flag","y5_hermione_time",True)]),("rest","오늘은 여기까지만 하자. 같이 나가자.",[])])
    _y5_choice("Y5_GINNY_PRACTICE",3,2,[("play","좋아. 이번에는 내가 골대를 지킬게.",[_y5_aff("ginny",2),("flag","y5_ginny_practice",True)]),("watch","오늘은 구경해도 돼? 네가 뛰는 걸 보고 싶어.",[_y5_aff("ginny",1)])])
    _y5_choice("Y5_LUNA_LESSON",3,2,[("together","한 번만 더 해 볼까? 내가 옆에서 맞춰 줄게.",[_y5_aff("luna",2),("flag","y5_luna_training",True)]),("ask","이번에는 네가 보고 내 문제를 말해 줘.",[_y5_aff("luna",1)])])
    _y5_choice("Y5_PITCH",3,2,[("restrain","손을 거두고 론과 함께 자리를 떠난다.",[("flag","y5_pitch_restraint",True)]),("strike","카리나의 뺨을 때린다.",[("flag","y5_pitch_struck",True),_y5_aff("carina",-3)])])
    _y5_choice("Y5_VISION_SHARE",3,2,[("tell","뱀의 눈으로 본 것 같았다고 털어놓는다.",[("flag","y5_possession_shared",True)]),("fear","내가 가까이 있어도 괜찮겠냐고 묻는다.",[])])
    _y5_choice("Y5_OCCLUMENCY",4,2,[("continue","다시 해 보겠습니다.",[("flag","y5_occlumency_practiced",True)]),("stop","오늘은 더 못 하겠어요.",[])])
    _y5_choice("Y5_PRESS",4,2,[("facts","직접 겪은 일과 전해 들은 일을 구분해 싣는다.",[("flag","y5_press_precise",True)]),("anger","마법부가 입을 막은 일부터 알린다.",[])])
    _y5_choice("Y5_SQUAD",4,2,[("record","피해를 본 학생들의 말을 모은다.",[("flag","y5_squad_evidence",True)]),("confront","카리나를 불러 세운다.",[])])
    _y5_choice("Y5_CARINA_BOUNDARY",4,2,[("account","다른 애들한테 그러는 건 그만둬.",[("flag","y5_carina_accountability",True)]),("cold","너하고 더 할 얘기는 없어.",[])])
    _y5_choice("Y5_DA_FRACTURE",4,2,[("vote","계속할지 각자 정하게 하자.",[("flag","y5_da_consent",True)]),("urge","지금 그만두면 다들 더 위험해져.",[])])
    _y5_choice("Y5_RAID",4,2,[("evacuate","아직 남은 애들부터 내보낸다.",[("flag","y5_evacuation_ready",True)]),("papers","명단과 연락 기록을 회수한다.",[("flag","y5_records_protected",True)])])
    _y5_choice("Y5_EXAM",4,1,[("joke","이번만 끝나면 시험 얘기는 한동안 안 할 거야.",[]),("admit","사실 좀 떨려. 너희도 그래?",[])])
    _y5_choice("Y5_VERIFY",5,3,[("contact","연락부터 하자. 내가 본 게 진짜인지 확인해야 해.",[("flag","y5_order_contacted",True)]),("rush","시간이 없어. 론, 가면서 기사단에 알려 줘.",[])])
    _y5_choice("Y5_OFFICE",5,2,[("listen","왜 못 가게 하는지 말해. 이번에는 듣고 갈게.",[("flag","y5_carina_warning_heard",True)]),("duel","비켜. 더는 막지 마.",[("flag","y5_carina_stunned",True)])])
    _y5_choice("Y5_DEPART",5,3,[("wait","확인된 소식을 기다린다. 친구들과 학교에 남는다.",[]),("team","함께 가되 서로 떨어지지 않기로 약속한다.",[]),("alone","론에게 연락을 맡기고 먼저 출발한다.",[])])
    _y5_choice("Y5_PROPHECY",5,3,[("break","예언을 깨뜨려 적의 목적을 막는다.",[]),("trade","예언을 넘기는 대신 안전하게 보내 달라고 한다.",[])])
    _y5_choice("Y5_BATTLE",5,3,[("cover","시리우스에게 물러나라고 외치며 엄호한다.",[]),("pursue","지팡이를 겨눈 벨라트릭스를 뒤쫓는다.",[])])
    _y5_choice("Y5_EXPOSE",5,3,[("alarm","중앙 홀의 경보를 울려 사람들을 부른다.",[]),("wounded","다친 사람들을 출구까지 옮긴다.",[])])
    _y5_choice("Y5_LUCIUS",5,3,[("secure","무장 해제된 루시우스를 기사단에 넘긴다.",[]),("rescue","잔해 아래 깔린 동료를 먼저 끌어낸다.",[])])
    _y5_choice("Y5_AFTERMATH",6,1,[("stay","지금은 옆에 있어 줬으면 좋겠어.",[]),("quiet","잠깐 혼자 있고 싶어. 나중에 다시 와 줄래?",[])])
    _y5_choice("Y5_HERMIONE_FUTURE",6,2,[("honest","다음에도 의견이 다르면 숨기지 말고 얘기하자.",[_y5_aff("hermione",1)]),("thanks","끝까지 같이 있어 줘서 고마워.",[])])
    _y5_choice("Y5_GINNY_FUTURE",6,2,[("respect","다음에는 네가 할 수 있는 일부터 물어볼게.",[_y5_aff("ginny",1)]),("thanks","DA에서 같이 연습해 줘서 든든했어.",[])])
    _y5_choice("Y5_CARINA_FAREWELL",6,2,[("boundaries","널 걱정하는 것과 네가 한 일을 받아들이는 건 달라.",[("world","y5_carina_conflict","boundaries")]),("distance","지금은 서로 시간을 갖는 게 좋겠어.",[("world","y5_carina_conflict","distance")])])
    _y5_choice("Y5_LUNA_AFTER",6,2,[("help","찾는 물건 목록 좀 줘. 나도 같이 찾을게.",[_y5_aff("luna",2),("flag","y5_luna_aftermath",True)]),("walk","잠깐 같이 걸을래?",[_y5_aff("luna",1)])])
    _y5_choice("Y5_SUMMER_PLAN",6,1,[("write","이번에는 소식을 자주 보내자.",[]),("visit","만날 수 있는 날도 정해 보자.",[])])

    Y5_SCENES={}
    def _y5_scene(c,s,title,date,place,people,bg,choices=(),condition="always",music="school"):
        sid="Y5-C%d-S%02d"%(c,s)
        Y5_SCENES[sid]=dict(chapter="Y5-C%d"%c,number=c,offset=s-1,label=sid.lower().replace("-","_"),
            title=title,time=date,location=place,participants=["harry"]+people.split(),pov="harry",
            choices=["Y5_"+x for x in choices],optional=condition!="always",condition=condition,bg=bg,outfit="school",music=music)
    _y5_scene(1,1,"도착하지 않는 소식","2030-08-02","프리벳가의 방","dudley","privet",music="mystery")
    _y5_scene(1,2,"여름의 냉기","2030-08-02","리틀 위닝의 골목","dudley figg","alley",music="danger")
    _y5_scene(1,3,"문패에 없는 집","2030-08-06","그리몰드 광장 12번지","tonks moody lupin","grimmauld",music="mystery")
    _y5_scene(1,4,"같은 방에 모여서","2030-08-06","그리몰드 광장의 침실","ron hermione ginny","grimmauld",["LETTERS","SUMMER"],music="warm")
    _y5_scene(1,5,"기사단의 식탁","2030-08-07","그리몰드 광장의 부엌","sirius lupin molly arthur ron hermione ginny","grimmauld",music="warm")
    _y5_scene(1,6,"먼저 연락하는 법","2030-08-08","그리몰드 광장의 응접실","sirius lupin","grimmauld",["CONTACT"],music="reflection")
    _y5_scene(1,7,"지하 법정","2030-08-12","마법부 청문회장","fudge umbridge dumbledore arthur figg","court",music="mystery")
    _y5_scene(2,1,"반장들의 빈자리","2030-09-01","호그와트행 열차","ron hermione ginny luna","train",music="warm")
    _y5_scene(2,2,"복도에서 마주친 얼굴","2030-09-01","열차 복도","carina victoria grace percival","train",["CARINA_TRAIN"],music="separation")
    _y5_scene(2,3,"마차 앞의 빈자리","2030-09-01","호그와트 마차 승강장","luna ginny ron","forest",["THESTRAL"],music="luna")
    _y5_scene(2,4,"분홍색 옷의 교수","2030-09-01","대연회장","umbridge dumbledore ron hermione ginny","hall",music="mystery")
    _y5_scene(2,5,"지팡이를 넣으세요","2030-09-02","어둠의 마법 방어술 교실","umbridge ron hermione","classroom",["CLASS"])
    _y5_scene(2,6,"잉크 없는 깃펜","2030-09-03","엄브릿지의 집무실과 휴게실","umbridge ron hermione","pink_office",["QUILL"],music="danger")
    _y5_scene(2,7,"접혀 버린 신문","2030-09-08","안뜰","carina ginny luna hermione ron","courtyard",["PAPER_HARM"],music="separation")
    _y5_scene(3,1,"우리가 배운다면","2030-10-05","호그스 헤드의 뒷방","hermione ron ginny luna cho neville marietta","village",["DA_RULE"],music="anticipation")
    _y5_scene(3,2,"필요한 방","2030-10-07","필요의 방","hermione ron ginny luna neville cho dobby","requirement",["DA_RON"],music="practice")
    _y5_scene(3,3,"책을 덮은 다음","2030-10-18","필요의 방","hermione ron","requirement",["HERMIONE_TIME"],music="hermione")
    _y5_scene(3,4,"골대 아래 약속","2030-10-24","퀴디치 연습장","ginny ron","pitch",["GINNY_PRACTICE"],music="ginny")
    _y5_scene(3,5,"다시 해 보는 주문","2030-11-01","필요의 방","luna neville","requirement",["LUNA_LESSON"],music="luna")
    _y5_scene(3,6,"왕을 부르는 노래","2030-11-08","퀴디치 경기장","ron carina fred george hooch","pitch",["PITCH"],music="danger")
    _y5_scene(3,7,"빼앗긴 빗자루","2030-11-08","맥고나걸의 집무실","mcgonagall umbridge ron hermione ginny","office",music="separation")
    _y5_scene(3,9,"복도 끝에서 본 것","2030-12-18","기숙사와 교장실","ron mcgonagall dumbledore","office",music="danger")
    _y5_scene(3,10,"그건 내가 알아","2030-12-24","성 뭉고 병원 대기실","ginny ron hermione arthur molly neville","infirmary",["VISION_SHARE"],music="warm")
    _y5_scene(4,1,"문을 닫는 연습","2031-01-10","스네이프의 집무실","snape","office",["OCCLUMENCY"],music="mystery")
    _y5_scene(4,2,"우리의 말로 된 기사","2031-02-14","호그스미드의 찻집","luna hermione ron ginny rita","village",["PRESS"],music="luna")
    _y5_scene(4,3,"가슴의 새 배지","2031-03-03","대연회장과 현관","carina victoria grace percival hermione ron umbridge","hall",["SQUAD"],music="danger")
    _y5_scene(4,4,"보고하지 않은 것","2031-03-05","7층 복도","carina","corridor",["CARINA_BOUNDARY"],music="separation")
    _y5_scene(4,5,"남을 사람들의 대답","2031-03-19","필요의 방","ron hermione ginny luna cho neville marietta","requirement",["DA_FRACTURE"],music="anticipation")
    _y5_scene(4,6,"뜨거워진 동전","2031-04-02","7층 복도와 교장실","dobby hermione ron carina umbridge dumbledore","corridor",["RAID"],music="danger")
    _y5_scene(4,7,"학교를 나가는 방법","2031-04-12","호그와트 현관","fred george ginny ron hermione umbridge","courtyard",music="mischief")
    _y5_choice("Y5_GINNY_KISS",4,2,[("kiss","지니에게 입을 맞춘다.",[]),("cheer","웃으며 우승을 축하한다.",[])])
    _y5_scene(4,9,"경기가 끝날 때까지","2031-05-24","엄브릿지의 집무실","umbridge","pink_office",music="anticipation")
    _y5_scene(4,10,"우승 파티","2031-05-24","그리핀도르 휴게실","ginny ron hermione","common",["GINNY_KISS"],music="ginny")
    _y5_scene(4,8,"시험이 끝나기 전","2031-06-12","대연회장 앞","ron hermione ginny luna","hall",["EXAM"])
    # Preserve established scene identities while placing the May final before exams.
    Y5_SCENES["Y5-C4-S09"]["offset"]=7
    Y5_SCENES["Y5-C4-S10"]["offset"]=8
    Y5_SCENES["Y5-C4-S08"]["offset"]=9
    _y5_scene(5,1,"또 하나의 환상","2031-06-18","시험장 밖 교실","ron hermione ginny luna neville sirius snape","classroom",["VERIFY"],music="danger")
    _y5_scene(5,2,"벽난로 앞을 막은 사람","2031-06-18","엄브릿지의 집무실","carina ron hermione umbridge snape","pink_office",["OFFICE"],music="danger")
    _y5_scene(5,3,"출발하기 전에","2031-06-18","학교 밖 회랑","ron hermione ginny luna neville","courtyard",["DEPART"],music="anticipation")
    _y5_scene(5,4,"도착한 곳에는","2031-06-18","마법부 중앙 홀","lucius bellatrix crouch_jr karkaroff ron hermione ginny luna neville","atrium",condition="departed",music="danger")
    _y5_scene(5,5,"내 이름이 적힌 구슬","2031-06-18","미스터리 부서 예언의 방","lucius bellatrix ron hermione ginny luna neville","prophecy",["PROPHECY"],"departed",music="danger")
    _y5_scene(5,6,"돌아갈 길을 향해","2031-06-18","미스터리 부서의 석실","sirius lupin tonks bellatrix ron hermione ginny luna neville","veil",["BATTLE"],"departed",music="danger")
    _y5_scene(5,7,"열린 문 너머의 증인","2031-06-18","마법부 중앙 홀","dumbledore voldemort fudge lucius lupin ron hermione ginny luna","atrium",["EXPOSE","LUCIUS"],"escaped",music="danger")
    _y5_scene(5,8,"기다리는 쪽의 밤","2031-06-18","호그와트의 잠긴 교실","ron hermione ginny luna neville carina snape","classroom",condition="stayed",music="mystery")
    _y5_scene(5,9,"돌아온 목소리","2031-06-19","호그와트 의무실","lupin mcgonagall ron hermione ginny luna","infirmary",condition="survived",music="reflection")
    _y5_scene(5,10,"닫힌 출구","2031-06-18","이름 모를 감금실","lucius bellatrix","cell",condition="captured",music="danger")
    _y5_scene(6,1,"깨어 있는 사람들","2031-06-20","호그와트 의무실","ron hermione ginny luna","infirmary",["AFTERMATH"],music="warm")
    _y5_scene(6,2,"숨겨 두었던 말","2031-06-21","교장실","dumbledore","office",music="reflection")
    _y5_scene(6,3,"대부의 자리","2031-06-22","호그와트 호숫가","sirius lupin tonks molly arthur carina","lake",music="reflection")
    _y5_scene(6,4,"다음에도 말해 줘","2031-06-24","도서관 앞","hermione ron","library",["HERMIONE_FUTURE"],music="hermione")
    _y5_scene(6,5,"내가 할 수 있는 일","2031-06-25","퀴디치 경기장 입구","ginny","pitch",["GINNY_FUTURE"],music="ginny")
    _y5_scene(6,6,"쉽게 돌아갈 수 없는 곳","2031-06-26","회랑","carina victoria narcissa","corridor",["CARINA_FAREWELL"],music="separation")
    _y5_scene(6,7,"찾아야 할 물건들","2031-06-27","호숫가와 안뜰","luna","lake",["LUNA_AFTER"],music="luna")
    _y5_scene(6,8,"서로의 주소","2031-06-30","런던행 열차","ron hermione ginny luna carina","train",["SUMMER_PLAN"],music="reflection")
