# Authoritative choice registry for the Korean Year 1 screenplay.
init -19 python:
    CHAPTERS.update({
        "Y1-C1": {"year": 1, "number": 1, "title": "문 너머의 이름들", "pov": "harry", "demo": False},
        "Y1-C2": {"year": 1, "number": 2, "title": "같은 학교, 다른 편", "pov": "harry", "demo": False},
        "Y1-C3": {"year": 1, "number": 3, "title": "돌아가야 할 사람", "pov": "harry", "demo": False},
        "Y1-C4": {"year": 1, "number": 4, "title": "갖지 않으려는 마음", "pov": "harry", "demo": False},
    })
    def _y1_choice(cid, chapter, text, options, tags, statistics=True, tier=1):
        CHOICES[cid] = {"chapter_id": "Y1-C%d" % chapter, "text": text,
            "options": [{"id": oid, "text": caption, "effects": effects} for oid, caption, effects in options],
            "tags": tags, "statistics": statistics, "tier": tier}
    _y1_choice("Y1_C1_RIVAL", 1, "", [
        ("boundary", "기숙사는 자기가 고르는 거야?", [("relationship", "carina", "affection", 2), ("personality", "harry_autonomy", 5)]),
        ("challenge", "넌 벌써 학교 다녀온 것처럼 말한다.", [("relationship", "carina", "affection", 1), ("personality", "harry_risk", 4)]),
    ], ["rivalry", "later_callback"])
    _y1_choice("Y1_C1_TABLE", 1, "", [
        ("seat", "여기 앉아도 돼?", []),
        ("toad", "이번엔 두꺼비 안 찾고 있네.", []),
    ], ["expression"], False)
    _y1_choice("Y1_C2_FRIENDSHIP", 2, "", [
        ("invite", "헤르미온느, 천천히 한 번만 보여 줄래?", [("relationship", "hermione", "affection", 2), ("special", "friendship_stability", 2), ("personality", "harry_reliance", 5)]),
        ("defend", "잠깐만. 론 아직 하고 있잖아.", [("relationship", "hermione", "affection", 1), ("personality", "harry_autonomy", 4)]),
    ], ["friendship", "later_callback"])
    _y1_choice("Y1_C2_DUEL", 2, "", [
        ("own_words", "론, 내가 대답할게.", []),
        ("face", "좋아. 대신 너도 직접 와.", []),
    ], ["expression", "later_callback"], False)
    _y1_choice("Y1_C2_RULE", 2, "어젯밤 본 개와 그 아래의 문이 마음에 걸린다.", [
        ("report", "교수에게 어젯밤 본 것을 알린다.", [("personality", "harry_authority", -5), ("personality", "harry_risk", -4)]),
        ("probe", "론과 멀리서 출입하는 사람을 확인한다.", [("personality", "harry_authority", 5), ("personality", "harry_risk", 4)]),
    ], ["risk_authority", "later_callback"])
    _y1_choice("Y1_C3_TROLL", 3, "헤르미온느가 남아 있는 곳으로 돌아가기 전에…", [
        ("signal", "퍼시에게 위치를 외치고 론과 함께 달린다.", [("personality", "harry_reliance", 5), ("flag", "y1_troll_signal", True)]),
        ("rush", "사람들 틈을 빠져나와 론과 곧장 달린다.", [("personality", "harry_risk", 5)]),
    ], ["risk", "immediate_consequence"])
    _y1_choice("Y1_C3_REPAIR", 3, "", [
        ("listen", "오늘 수업은 우리 옆에 앉을래?", [("relationship", "hermione", "affection", 2), ("special", "friendship_stability", 4)]),
        ("admit", "나도 미안해. 화장실에 있는 줄 알았는데.", [("relationship", "hermione", "affection", 2), ("special", "friendship_stability", 4)]),
    ], ["friendship", "later_callback"])
    _y1_choice("Y1_C3_MIRROR", 3, "론에게 거울 이야기를 할까?", [
        ("tell", "부모님이 보이는 거울을 찾았다고 말한다.", [("personality", "harry_trust", 4), ("personality", "harry_reliance", 4)]),
        ("quiet", "거울 이야기는 하지 않고 혼자 간다.", [("personality", "harry_autonomy", 2)]),
    ], ["friendship", "later_callback"])
    _y1_choice("Y1_C3_MIRROR_REPLY", 3, "", [
        ("tell", "난 부모님이 보여.", []),
        ("keep", "내가 본 건 말하고 싶지 않아.", []),
    ], ["expression", "private_conversation"], False)
    _y1_choice("Y1_C4_DRAGON", 4, "해그리드는 노버트를 보내자는 말에 대답하지 않았다.", [
        ("home", "찰리가 있는 곳에선 마음껏 날 수도 있을 거예요.", []),
        ("visit", "찰리한테 사진을 보내 달라고 하면 어때요?", []),
    ], ["expression"], False)
    _y1_choice("Y1_C4_PLAN", 4, "교장 선생님이 떠난 날, 누군가 돌을 노리고 있다.", [
        ("message", "확인한 사실을 적어 교직원에게 남기고 움직인다.", [("personality", "harry_reliance", 5), ("flag", "y1_left_message", True)]),
        ("direct", "더 지체하지 않고 셋이 함께 금지된 복도로 간다.", [("personality", "harry_risk", 5)]),
    ], ["cooperation", "later_callback"])
    _y1_choice("Y1_C4_CHESS", 4, "론이 위험한 수를 제안했다.", [
        ("trust", "알았어. 끝나면 바로 너한테 갈게.", [("personality", "harry_trust", 5)]),
        ("alternative", "잠깐만. 다른 길을 한 번 더 보자.", [("personality", "harry_risk", -3), ("personality", "harry_reliance", 3)]),
    ], ["friendship", "immediate_consequence"])
    _y1_choice("Y1_C4_FAREWELL", 4, "", [
        ("goodbye", "잘 지내, 카리나.", []),
        ("write", "방학에 편지해도 돼?", []),
    ], ["relationship", "optional_event", "open_future"])

    # Tier 2 emotional decisions; danger alone does not make a fixed event Tier 3.
    for _cid in ("Y1_C1_RIVAL", "Y1_C2_FRIENDSHIP", "Y1_C3_REPAIR", "Y1_C3_MIRROR", "Y1_C4_FAREWELL"):
        CHOICES[_cid]["tier"] = 2
    def _y1_memory(heroine, key, text):
        return ("relationship_event", heroine, key, "memory", text, False)
    _y1_choice("Y1_C1_NOTICE", 1, "카리나가 떠난 골목을 돌아본다.", [
        ("curious", "다음에 만나면 또 얘기하고 싶다.", [("relationship", "carina", "affection", 1), _y1_memory("carina", "y1_first_interest", "양장점에서 만난 카리나와 다시 이야기하고 싶었다.")]),
        ("rival", "잘난 척은 좀 심하네.", []),
    ], ["everyday", "personal_interest"], False)
    _y1_choice("Y1_C4_STUDY", 4, "헤르미온느가 집에서 가져온 책을 같이 보자고 한다.", [
        ("stay", "좋아. 네가 좋아하는 책도 궁금해.", [("relationship", "hermione", "affection", 1), _y1_memory("hermione", "y1_study_accepted", "숙제 없는 오후를 함께 보내기로 했다.")]),
        ("later", "오늘은 먼저 갈게. 다음에 보여 줘.", [_y1_memory("hermione", "y1_study_declined", "오늘은 쉬겠다고 말했고 헤르미온느가 받아들였다.")]),
    ], ["relationship", "optional_event"], True, 2)
    _y1_choice("Y1_C4_BOOK", 4, "", [
        ("company", "응. 나도 읽을게. 아직 넘기지 마.", [("relationship", "hermione", "affection", 1), _y1_memory("hermione", "y1_quiet_company", "아무것도 가르쳐 주지 않아도 함께 있을 수 있다.")]),
        ("share", "대신 다음 이야기는 내가 골라도 돼?", [("relationship", "hermione", "affection", 1), _y1_memory("hermione", "y1_shared_reading", "서로 책을 골라 주기로 했다.")]),
    ], ["relationship", "later_callback"], True, 2)
    _y1_choice("Y1_C4_SNAPE_DEBT", 4, "덤블도어에게 들은 이야기를 스네이프에게 꺼낼까?", [
        ("tell", "부모님께 목숨을 빚졌다는 이야기를 꺼낸다.", []),
        ("keep", "그 이야기는 스네이프에게 하지 않는다.", []),
    ], ["knowledge", "later_callback"], True, 2)
    _y1_choice("Y1_C4_NEVILLE", 4, "", [
        ("confront", "카리나를 찾아가 네빌에게 한 일을 따진다.", []),
        ("stay", "네빌 곁에 남는다.", []),
    ], ["friendship", "immediate_consequence"], True, 2)
    _y1_choice("Y1_C4_SLUR", 4, "", [
        ("fight", "지팡이를 꺼내 든다.", []),
        ("leave", "모욕한 말을 취소하라고 요구하고 친구들과 돌아간다.", []),
    ], ["conflict", "immediate_consequence"], True, 2)
    _y1_choice("Y1_C4_RELEASE", 4, "", [
        ("step", "뒤로 물러난다.", []),
        ("apologize", "손목은… 미안해. 너무 세게 잡았어.", []),
    ], ["expression"], False, 1)
    _y1_choice("Y1_C4_FOREST", 4, "", [
        ("pull", "카리나의 팔을 잡아 뒤로 끌어당긴다.", [("flag", "y1_forest_reached", True)]),
        ("warn", "카리나에게 뒤로 물러서라고 외친다.", [("flag", "y1_forest_warned", True)]),
        ("help", "카리나에게 해그리드를 불러오라고 한다.", [("flag", "y1_forest_sent_for_help", True)]),
    ], ["danger", "immediate_consequence", "rivalry"], True, 2)
