# M7.3: individual final-file approvals and the owner's later production delegation.
# See assets/audio/m73/final-file-approval.json for the exact file hashes.
init -2 python:
    M73_RECORDING_TITLES = {'carina': '은빛으로 접어 둔 말',
     'school': '창가의 수업',
     'waltz': '촛불 사이의 세 걸음',
     'threat': '닫힌 복도의 발소리',
     'battle': '끝까지 남은 사람들',
     'night_sky': '일곱 해 뒤의 별빛',
     'epilogue': '다음 세대의 첫 기차',
     'carina_reconcile': '은빛 주제 · 화해',
     'carina_pressure': '은빛 주제 · 압박',
     'carina_family': '은빛 주제 · 함께 살아온 날들',
     'family_hermione': '여백의 대답 · 세월',
     'family_ginny': '먼저 달려온 발소리 · 세월',
     'family_luna': '다른 쪽 창문 · 세월',
     'quidditch': '스니치를 향해',
     'inner_conflict': '내면의 경계'}
    M73_NON_LOOPING = {"epilogue", "carina_family", "family_hermione", "family_ginny", "family_luna"}
    M73_SCENE_OVERRIDES = {
        # A ring is not by itself a confession; pursuit precedes reconciliation.
        "Y3-C4-S04": "mystery", "Y3-C4-S05": "warm",
        "Y3-C6-S01": "mystery", "Y3-C6-S02": "danger",
        "Y3-C6-S03": "mystery", "Y3-C6-S09": "carina_pressure",
        # Dance practice is a waltz arrangement, not a generic DA training cue.
        "Y5-C2-S05": "mystery", "Y5-C2-S06": "mystery",
        "Y5-C2-S13": "mystery", "Y5-C3-S02": "warm",
        "Y5-C3-S11": "school", "Y5-C3-S14": "warm",
        "Y5-C3-S16": "mystery", "Y5-C3-S17": "warm",
        "Y5-C4-S03": "mystery", "Y5-C4-S11": "mystery",
        "Y5-C5-S03": "mystery", "Y5-C5-S13": "mystery",
        "Y5-C5-S04": "mystery", "Y5-C5-S14": "mystery",
        "Y5-C5-S06": "danger", "Y5-C5-S16": "danger",
        "Y5-C6-S03": "reflection", "Y5-C6-S11": "reflection",
        # The Hidden victory turns into possession; it is not the Tower betrayal.
        "Y6-C2-S15": "danger", "Y6-C2-S16": "mystery",
        "Y6-C3-S16": "mystery", "Y6-C4-S11": "danger",
        "Y6-C4-S12": "mystery", "Y6-C4-S13": "danger",
        "Y6-C4-S14": "danger", "Y6-C4-S15": "danger",
        "Y6-C4-S16": "danger", "Y6-C4-S17": "reflection",
        "Y6-C5-S11": "mystery", "Y6-C5-S15": "reflection",
        "Y6-C5-S16": "warm", "Y6-C6-S05": "mystery",
        "Y6-C7-S01": "mystery", "Y6-C7-S03": "reflection",
        "Y6-C8-S01": "reflection", "Y6-C8-S11": "reflection",
        # Main: investigation, confrontation, grief and return have space between.
        "Y7-C1-S05": "danger", "Y7-C2-S03": "mystery",
        "Y7-C3-S01": "mystery", "Y7-C3-S03": "mystery",
        "Y7-C3-S05": "danger", "Y7-C4-S04": "mystery",
        "Y7-C4-S05": "mystery", "Y7-C5-S01": "danger",
        "Y7-C5-S02": "danger", "Y7-C6-S01": "danger",
        "Y7-C6-S05": "mystery", "Y7-C7-S01": "mystery",
        "Y7-C7-S03": "danger", "Y7-C7-S04": "danger",
        "Y7-C7-S05": "separation", "Y7-C7-S06": "reflection",
        "Y7-C7-S07": "separation", "Y7-C8-S01": "separation",
        "Y7-C8-S04": "danger", "Y7-C8-S05": "mystery",
        "Y7-C8-S06": "reflection", "Y7-C9-S02": "reflection",
        "Y7-C9-S03": "reflection", "Y7-C9-S05": "warm",
        # Hidden: no Battle of Hogwarts; the conflict remains inside Harry.
        "Y7-C3-S11": "mystery", "Y7-C3-S12": "mystery",
        "Y7-C3-S13": "separation", "Y7-C4-S11": "mystery",
        "Y7-C4-S12": "separation", "Y7-C4-S13": "warm",
        "Y7-C5-S11": "mystery", "Y7-C5-S12": "mystery",
        "Y7-C5-S13": "separation", "Y7-C6-S11": "separation",
        "Y7-C6-S12": "mystery", "Y7-C6-S13": "mystery",
        "Y7-C7-S11": "warm", "Y7-C7-S12": "reflection",
        "Y7-C8-S11": "reflection", "Y7-C8-S13": "anticipation",
        "Y7-C9-S11": "warm", "Y7-C9-S12": "reflection",
        "Y7-C9-S13": "carina", "Y7-C11-S13": "anticipation",
        # The common night starts quietly; each heroine's motif enters in dialogue.
        "Y7-C11-S01": "anticipation", "Y7-C11-S02": "anticipation",
        "Y7-C11-S03": "anticipation", "Y7-C11-S04": "reflection",
        "Y7-C11-S05": "reflection",
        # Different emotional histories: reflection vs an already shared home.
        "Y7-C12-S01": "reflection", "Y7-C12-S02": "reflection",
        "Y7-C12-S03": "reflection", "Y7-C12-S04": "reflection",
        "Y7-C12-S06": "warm", "Y7-C12-S11": "warm",
    }
    M73_MOMENTS = {
        "tower_shock": dict(track=None, fade=0.12, reason="Main: Snape raises his wand; no victory sting"),
        "tower_aftermath": dict(track="separation", fade=1.8, reason="Main: shock becomes grief"),
        "hidden_possession": dict(track=None, fade=0.12, reason="Hidden: Harry loses control of his own voice"),
        "hidden_terror": dict(track="mystery", fade=0.8, reason="Hidden: horror of the act, not a battle victory"),
        "soul_struggle": dict(track="danger", fade=0.5, reason="Internal soul confrontation, not Hogwarts battle"),
        "soul_silence": dict(track=None, fade=0.4, reason="The inner voice ends"),
        "soul_farewell": dict(track="reflection", fade=2.0, reason="Restrained gratitude and return to life"),
        "final_wand_silence": dict(track=None, fade=0.4, reason="Leave the decisive Main exchange unscored"),
        "night_hermione": dict(track="hermione", fade=2.0, reason="Her motif follows the shared night introduction"),
        "night_ginny": dict(track="ginny", fade=2.0, reason="Her confident future remains recognizable"),
        "night_luna": dict(track="luna", fade=2.0, reason="Warm curiosity, not eerie prophecy"),
        "night_carina": dict(track="carina", fade=2.0, reason="Main: the first-year gesture finally answered"),
        "family_hermione": dict(track="hermione", fade=2.0, reason="Recall her motif after the passage-of-time introduction"),
        "family_ginny": dict(track="ginny", fade=2.0, reason="A new generation, with Ginny's own identity"),
        "family_luna": dict(track="luna", fade=2.0, reason="Continue her curiosity into family life"),
        "family_carina_main": dict(track="carina", fade=2.0, reason="Main: rivalry, accountability and a late new beginning"),
        "family_carina_hidden": dict(track="carina", fade=2.5, reason="Hidden: early love, forced separation and recovered shared life"),
    }
    # Final-file approval covers these recordings; no story conditions change.
    M73_SCENE_OVERRIDES.update({'Y5-C2-S06': 'threat',
     'Y5-C2-S15': 'carina_pressure',
     'Y5-C4-S03': 'threat',
     'Y5-C4-S11': 'threat',
     'Y5-C5-S05': 'battle',
     'Y5-C5-S06': 'battle',
     'Y5-C5-S07': 'battle',
     'Y5-C5-S15': 'battle',
     'Y5-C5-S16': 'battle',
     'Y6-C2-S15': 'threat',
     'Y6-C3-S04': 'carina_pressure',
     'Y6-C3-S11': 'threat',
     'Y6-C4-S11': 'battle',
     'Y6-C4-S13': 'battle',
     'Y6-C4-S14': 'battle',
     'Y6-C4-S15': 'battle',
     'Y6-C4-S16': 'battle',
     'Y6-C5-S16': 'carina_reconcile',
     'Y6-C6-S05': 'carina_pressure',
     'Y6-C7-S01': 'threat',
     'Y7-C4-S04': 'threat',
     'Y7-C6-S12': 'threat',
     'Y7-C6-S13': 'threat',
     'Y7-C7-S01': 'threat',
     'Y7-C7-S03': 'battle',
     'Y7-C7-S04': 'battle',
     'Y7-C7-S11': 'carina_reconcile',
     'Y7-C8-S04': 'battle',
     'Y7-C8-S05': 'threat',
     'Y7-C11-S01': 'night_sky',
     'Y7-C11-S02': 'night_sky',
     'Y7-C11-S03': 'night_sky',
     'Y7-C11-S04': 'night_sky',
     'Y7-C11-S05': 'night_sky',
     'Y7-C11-S13': 'carina_reconcile',
     'Y7-C12-S01': 'epilogue',
     'Y7-C12-S02': 'epilogue',
     'Y7-C12-S03': 'epilogue',
     'Y7-C12-S04': 'epilogue',
     'Y7-C12-S11': 'carina_family'})
    M73_SCENE_OVERRIDES.update({'Y4-C6-S03': 'carina_pressure', 'Y5-C2-S11': 'carina_pressure', 'Y5-C3-S13': 'carina_pressure', 'Y6-C1-S11': 'carina_pressure', 'Y7-C3-S13': 'carina_pressure'})
    M73_MOMENTS['hidden_terror']["track"] = 'threat'
    M73_MOMENTS['soul_struggle']["track"] = 'inner_conflict'
    M73_MOMENTS['night_hermione']["track"] = 'family_hermione'
    M73_MOMENTS['night_ginny']["track"] = 'family_ginny'
    M73_MOMENTS['night_luna']["track"] = 'family_luna'
    M73_MOMENTS['night_carina']["track"] = 'carina_reconcile'
    M73_MOMENTS['family_hermione']["track"] = 'family_hermione'
    M73_MOMENTS['family_ginny']["track"] = 'family_ginny'
    M73_MOMENTS['family_luna']["track"] = 'family_luna'
    M73_MOMENTS['family_carina_main']["track"] = 'carina_reconcile'
    M73_MOMENTS['family_carina_hidden']["track"] = 'carina_family'
    M73_MOMENTS.update({"ring_recognition": dict(track="carina_reconcile", fade=1.4, reason="Only after the actual ring recognition"), "shared_patronus": dict(track="carina", fade=1.5, reason="The same actual Carina theme returns with shared feelings")})
    M73_MOMENTS["carina_separation"] = dict(track="carina_pressure", fade=1.8, reason="The actual Carina motif under forced separation")
    M73_SCENE_CONTEXT = {
        sid: "M7.3 explicit cue: " + cue for sid, cue in M73_SCENE_OVERRIDES.items()
    }
    M73_SCENE_CONTEXT.update({
        "Y3-C4-S05": "반지 확인 뒤의 화해; 고백과 분리",
        "Y5-C3-S02": "DA 실습과 학생들의 결속; 무도회 연습곡 제외",
        "Y6-C7-S01": "Main: 의심 → 살해 순간 침묵 → 배신과 애도",
        "Y6-C4-S17": "Hidden: 잠깐의 애도 → 신체 통제 상실 → 공포",
        "Y7-C6-S13": "Hidden: 영혼 대결 → 침묵 → 작별과 회복",
        "Y7-C11-S04": "Main: 전후 별밤·첫 악수 회수",
        "Y7-C12-S04": "Main: 늦게 시작한 관계의 가족 결말; 화해 동기 변주",
        "Y7-C12-S11": "Hidden: 영혼 해결 뒤 함께 살아온 가족 결말; 전용 가족 변주",
    })

init 1 python:
    M43_TRACKS.update(M73_RECORDING_TITLES)
    M43_SCENE_MUSIC.update(M73_SCENE_OVERRIDES)
    M43_ENTRY_SFX.update({"Y5-C3-S02":"door", "Y6-C2-S16":"water",
                         "Y7-C4-S04":"door", "Y7-C12-S01":"train",
                         "Y7-C12-S02":"train", "Y7-C12-S03":"train",
                         "Y7-C12-S04":"train", "Y7-C12-S11":"train"})

init -1 python:
    def m73_cue(moment):
        cue=M73_MOMENTS[moment]
        m43_play(cue["track"],cue["fade"])
