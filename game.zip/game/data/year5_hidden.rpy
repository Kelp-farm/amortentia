# M5R: source-order scenes have their own identities. Old Main scenes are not
# reused for a different event; current Y4 worldline still decides availability.
init -14 python:
    Y5_MAIN_SCENES=set(Y5_SCENES)
    # The retired hybrid scene is not part of either current worldline.
    Y5_RETIRED_SCENES={"Y5-C3-S08"}
    Y5_SCENES.pop("Y5-C3-S08",None)
    Y5_MAIN_SCENES.discard("Y5-C3-S08")
    _y5_choice("Y5_H_PAPER",2,1,[("help","내가 도울 일이 있으면 말해 줘.",[_y5_aff("luna",1)]),("sorry","내 얘기를 싣다가 이렇게 됐구나. 미안해.",[])])
    _y5_choice("Y5_H_SHIELD",3,1,[("again","다시 해 봐. 이번에는 내가 먼저 공격할게.",[]),("show","헤르미온느, 한 번만 더 보여 줄래?",[])])
    _y5_choice("Y5_H_PRINT",4,1,[("fold","접는 건 내가 할게. 몇 부 남았어?",[_y5_aff("luna",1)]),("proof","인쇄하기 전에 나도 한번 읽어 볼까?",[])])
    _y5_choice("Y5_H_AFTERMATH",6,1,[("stay","조금만 더 같이 있어 줘.",[]),("quiet","잠깐 혼자 있을게. 저녁에 보자.",[])])
    _y5_choice("Y5_H_LETTERS",6,1,[("write","집에 도착하면 편지할게.",[]),("visit","방학 때도 볼 수 있겠지?",[])])
    _y5_scene(1,11,"여름의 목소리","2030-08-02","프리벳가","dudley vernon","privet",condition="fanfic",music="mystery")
    _y5_scene(1,12,"사촌의 비명","2030-08-02","리틀 위닝의 골목과 프리벳가","dudley figg vernon sirius lupin tonks moody","alley",condition="fanfic",music="danger")
    _y5_scene(1,13,"법정에서 할 말","2030-08-12","마법부 청문회장","sirius lupin tonks moody fudge umbridge dumbledore","court",condition="fanfic",music="mystery")
    _y5_scene(2,11,"객실 문을 닫고","2030-09-01","호그와트행 열차","ron hermione carina ginny luna","train",condition="fanfic",music="separation")
    _y5_scene(2,12,"연회장의 새 교수","2030-09-01","대연회장","ron hermione ginny luna carina dumbledore umbridge","hall",condition="fanfic")
    _y5_scene(2,13,"실습 없는 방어술","2030-09-02","방어술 교실과 복도","ron hermione umbridge mcgonagall","classroom",condition="fanfic")
    _y5_scene(2,14,"금지된 잡지","2030-09-03","신비한 동물 수업 뒤 안뜰","ron hermione carina ginny luna angelina","courtyard",["H_PAPER"],"fanfic",music="separation")
    _y5_scene(2,15,"깃펜과 왼손","2030-09-05","엄브리지의 집무실","umbridge carina","pink_office",condition="fanfic",music="separation")
    _y5_scene(2,16,"손끝에 남은 분노","2030-09-06","대연회장과 복도","ron hermione ginny carina","hall",condition="fanfic",music="mystery")
    _y5_scene(2,17,"두 번째 호크룩스","2030-09-07","덤블도어의 교장실","dumbledore","office",condition="fanfic",music="mystery")
    _y5_scene(3,11,"연습장의 말다툼","2030-11-07","퀴디치 연습장","ron","pitch",condition="fanfic",music="practice")
    _y5_scene(3,12,"스니치 너머의 얼굴","2030-11-08","퀴디치 경기장","ron carina fred george hooch katie angelina","pitch",condition="fanfic",music="danger")
    _y5_scene(3,13,"경기 뒤에 생긴 법령","2030-11-09","맥고나걸의 집무실과 현관","mcgonagall hermione ron","office",condition="fanfic",music="separation")
    _y5_scene(3,14,"빼앗을 수 없는 수업","2030-11-12","필요의 방 앞과 안","hermione ron ginny luna neville cedric cho marietta terry","requirement",condition="fanfic",music="anticipation")
    _y5_scene(3,15,"마법부에 드나드는 사람","2030-11-15","복도와 필요의 방","hermione ron neville","corridor",condition="fanfic",music="mischief")
    _y5_scene(3,16,"쫓겨나는 교수","2030-11-20","현관과 필요의 방","umbridge dumbledore neville hermione ron","courtyard",["H_SHIELD"],"fanfic",music="practice")
    _y5_scene(3,17,"무효라는 대답","2030-11-28","대연회장","umbridge dumbledore fred george ron carina cedric","hall",condition="fanfic",music="anticipation")
    _y5_scene(4,11,"심문관 특별 조사단","2030-12-01","대연회장","carina ron hermione","hall",condition="fanfic",music="danger")
    _y5_scene(4,12,"같은 방에 모인 이유","2030-12-03","필요의 방","ginny hermione ron neville cedric cho zacharias marietta ernie","requirement",condition="fanfic",music="mystery")
    _y5_scene(4,13,"사라진 문 앞에서","2030-12-03","7층 복도","carina","corridor",condition="fanfic",music="separation")
    _y5_scene(4,14,"인쇄기를 돌리며","2031-01-10","필요의 방","luna neville fred george hermione ron","requirement",["H_PRINT"],"fanfic",music="luna")
    _y5_scene(4,15,"들여보내지 않을 기억","2031-01-12","스네이프의 집무실","snape","office",condition="fanfic",music="mystery")
    _y5_scene(4,16,"문 뒤에 보관된 것","2031-01-15","덤블도어의 교장실","dumbledore","office",condition="fanfic",music="mystery")
    _y5_scene(4,17,"다시 나오는 이러쿵저러쿵","2031-06-17","필요의 방","luna neville hermione ron ginny fred george rita","requirement",condition="fanfic",music="anticipation")
    _y5_scene(5,11,"오늘 밤이라는 말","2031-06-18","필요의 방 앞과 교장실 계단","ron hermione dobby victoria mcgonagall lucius voldemort george","corridor",condition="fanfic",music="danger")
    _y5_scene(5,12,"닫힌 문 앞의 카리나","2031-06-18","엄브리지의 집무실","carina ron","pink_office",condition="fanfic",music="danger")
    _y5_scene(5,13,"론에게 맡긴 연락","2031-06-18","엄브리지의 집무실","ron carina","pink_office",condition="fanfic",music="anticipation")
    _y5_scene(5,14,"비어 있는 중앙 홀","2031-06-18","마법부 중앙 홀","lucius bellatrix crouch_jr karkaroff","atrium",condition="fanfic",music="danger")
    _y5_scene(5,15,"아흔일곱 번째 선반","2031-06-18","미스터리 부서 예언의 방","lucius bellatrix karkaroff","prophecy",condition="fanfic",music="danger")
    _y5_scene(5,16,"내 앞으로 뛰어든 사람","2031-06-18","미스터리 부서 출구","sirius lupin tonks bellatrix ron hermione ginny luna","prophecy",condition="fanfic",music="danger")
    _y5_scene(5,17,"돌아온 사람들","2031-06-19","호그와트 의무실","ron hermione ginny luna lupin mcgonagall","infirmary",condition="fanfic",music="reflection")
    _y5_scene(6,11,"작별하는 날","2031-06-22","호그와트 호숫가","dumbledore lupin tonks ron hermione ginny carina","lake",["H_AFTERMATH"],"fanfic",music="reflection")
    _y5_scene(6,12,"신문에 실린 이름","2031-06-26","호그와트 회랑","ron hermione carina victoria","corridor",condition="fanfic",music="separation")
    _y5_scene(6,13,"여름으로 가는 열차","2031-06-30","런던행 열차","ron hermione ginny luna","train",["H_LETTERS"],"fanfic",music="reflection")
    Y5_SOURCE_SCENES=set(Y5_SCENES)-Y5_MAIN_SCENES
    for _sid,_meta in Y5_SCENES.items():
        if _sid in Y5_MAIN_SCENES:
            _meta["choices"]=[c for c in _meta["choices"] if c not in ("Y5_PAPER_HARM","Y5_OFFICE")]
    for _cid in ("Y5_PAPER_HARM","Y5_OFFICE"):
        CHOICES[_cid]["legacy"]=True
    # A chapter contains alternative story lanes. Playback uses availability;
    # order is shared by replay reconstruction, Word export, and actual play.
    Y5_SCENES=dict(sorted(Y5_SCENES.items(),key=lambda item:(item[1]["number"],item[1]["offset"])))
    for _sid,_meta in Y5_SCENES.items():
        _meta["story_lane"]="fanfic" if _sid in Y5_SOURCE_SCENES else "canon_adjacent"
