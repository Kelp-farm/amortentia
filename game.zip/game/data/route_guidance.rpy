# Implemented intermediate outcomes and final endings are listed separately.
init -3 python:
    M41_GROUPS = (("carina","카리나"),("hermione","헤르미온느"),("ginny","지니"),("luna","루나"),("no_romance","연애 없이"))
    M41_TARGETS = {
        "carina_rescue": dict(group="carina",title="3학년 · 카리나와 시간 여행",hint="3학년의 외출과 관계 회복이 중요합니다.",anchor="Y3-C6-S04",kind="rescue"),
        "carina_private": dict(group="carina",title="3학년 · 비밀 연애",hint="시간 여행 뒤의 마음을 전하는 선택을 살펴보세요.",anchor="Y3-C6-S09",kind="dating",visibility="private"),
        "carina_public": dict(group="carina",title="3학년 · 공개 연애",hint="관계 회복과 충분한 호감이 모두 필요합니다.",anchor="Y3-C6-S09",kind="dating",visibility="public"),
        "world_fanfic": dict(group="carina",title="4학년 · 교제에서 이어지는 세계선",hint="이른 선택으로 쌓은 협력과 3학년 말 화해·교제가 중요합니다. 공개·비밀 교제 모두 이어집니다.",anchor="Y4-C8-S09",kind="world",worldline="fanfic"),
        "carina_separation": dict(group="carina",title="4학년 · 전쟁 속의 이별",hint="현재 교제 중인 두 사람에게 일어나는 사건입니다.",anchor="Y4-C6-S04",kind="separation"),
        "ball_carina": dict(group="carina",title="4학년 · 카리나와 무도회",hint="함께 가자고 묻는 선택이 있습니다.",anchor="Y4-C4-S02",kind="ball",partner="carina"),
        "ball_hermione": dict(group="hermione",title="4학년 · 헤르미온느와 무도회",hint="함께 가자고 묻는 선택이 있습니다.",anchor="Y4-C4-S03",kind="ball",partner="hermione"),
        "ball_ginny": dict(group="ginny",title="4학년 · 지니와 무도회",hint="함께 가자고 묻는 선택이 있습니다.",anchor="Y4-C4-S04",kind="ball",partner="ginny"),
        "ball_luna": dict(group="luna",title="4학년 · 루나와 무도회",hint="친구로도 함께할 수 있습니다.",anchor="Y4-C4-S05",kind="ball",partner="luna"),
        "ball_friends": dict(group="no_romance",title="4학년 · 친구로 함께한 첫 춤",hint="헤르미온느와 친구로 첫 춤을 춥니다. 호감도나 교제가 자동으로 오르지는 않습니다.",anchor="Y4-C4-S06",kind="ball",partner="none"),
        "world_canon": dict(group="no_romance",title="4학년 · 본편 사건 경로",hint="양장점에서 시작한 본편, 또는 다른 이야기에서의 미교제로 이어집니다.",anchor="Y4-C8-S09",kind="world",worldline="canon_adjacent"),
        "cedric_alive": dict(group="no_romance",title="4학년 · 세드릭 생존",hint="세계선에 따라 필요한 준비가 다릅니다.",anchor="Y4-C7-S05",kind="cedric",alive=True),
        "cedric_dead": dict(group="no_romance",title="4학년 · 세드릭 사망",hint="한 세계선에서만 가능한 사건입니다.",anchor="Y4-C7-S04",kind="cedric",alive=False),
    }
    M41_TARGETS.update({
        "y5_sirius_alive":dict(group="no_romance",title="5학년 · 시리우스와 맞는 여름",hint="환상을 확인하고 퇴로를 확보하는 행동을 살펴보세요.",anchor="Y5-C6-S03",kind="y5",result="sirius"),
        "y5_exposure":dict(group="no_romance",title="5학년 · 귀환의 증인",hint="마법부에서 사람들에게 현장을 알릴 기회가 있습니다.",anchor="Y5-C5-S07",kind="y5",result="exposure"),
        "y5_wait":dict(group="no_romance",title="5학년 · 기다리는 쪽의 밤",hint="환상을 확인한 다음 학교에 남을 수 있습니다.",anchor="Y5-C5-S08",kind="y5",result="wait"),
        "y5_hermione":dict(group="hermione",title="5학년 · 연습이 끝난 뒤",hint="수업을 마친 뒤 함께 시간을 보냅니다.",anchor="Y5-C3-S03",kind="y5",result="hermione"),
        "y5_ginny":dict(group="ginny",title="5학년 · 골대 아래 약속",hint="지니의 연습에 함께 참여합니다.",anchor="Y5-C3-S04",kind="y5",result="ginny"),
        "y5_luna":dict(group="luna",title="5학년 · 함께 찾아야 할 것",hint="학년말 루나의 이야기에 귀 기울입니다.",anchor="Y5-C6-S07",kind="y5",result="luna"),
        "y5_carina":dict(group="carina",title="5학년 · 벽난로 앞의 경고",hint="카리나 사건 경로에서 그녀가 막아선 이유를 뒤늦게 알게 됩니다.",anchor="Y5-C5-S14",kind="y5",result="carina"),
    })
    for _group,_name in M41_GROUPS:
        M41_TARGETS["route_"+_group] = dict(group=_group,title=_name+" · 7학년 최종 엔딩",hint="아직 구현되지 않아 조건과 체크포인트를 안내하지 않습니다.",kind="future",anchor=None)

    # Canonical narrative order includes moved scene IDs and every choice tier.
    M41_SCENE_ORDER, M41_CHOICE_ORDER, M41_CHOICE_SCENE = {}, {}, {}
    for _year,_scenes in ((1,Y1_REVIEW_SCENES),(2,Y2_SCENES),(3,Y3_SCENES),(4,Y4_SCENES),(5,Y5_SCENES),(6,Y6_SCENES),(7,Y7_SCENES)):
        for _index,(_sid,_scene) in enumerate(_scenes.items()):
            M41_SCENE_ORDER[_sid] = (_year,_index,0)
            _choices = [x[0] for x in _scene["choices"]] if _year==1 else _scene["choices"]
            for _ci,_cid in enumerate(_choices):
                M41_CHOICE_ORDER[_cid] = (_year,_index,_ci+1)
                M41_CHOICE_SCENE[_cid] = _sid
