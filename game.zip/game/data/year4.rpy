# M4: additive state. The entry worldline is frozen from the explicit Y3 handoff.
init -43 python:
    WORLD_DEFAULTS.update({
        "y4_moody": "unknown", "y4_cedric": "alive", "y4_partner": "none",
        "y4_ball_meaning": "none", "y4_resurrection": "pending",
        "y4_harry_knowledge": "unaware", "y4_ministry_knowledge": "unaware",
        "y4_ministry_response": "pending", "y4_carina_separation": "none",
        "y4_carina_prior_visibility": "none", "y4_ritual_servant": "unknown",
        "y4_crouch_jr": "unknown", "y4_winner": "pending",
        "y4_hostage": "ron", "y4_thestral_witness": False,
        "y4_real_moody_available": False, "y4_blood_taken": False})
    WORLD_ENUMS.update({
        "y4_moody": ("unknown","real_teacher","impostor_exposed"),
        "y4_cedric": ("alive","dead"),
        "y4_partner": ("none","carina","hermione","ginny","luna"),
        "y4_ball_meaning": ("none","friends","dating","confessed","declined"),
        "y4_resurrection": ("pending","graveyard","covert"),
        "y4_harry_knowledge": ("unaware","suspicion","informed","witness"),
        "y4_ministry_knowledge": ("unaware","warned","testimony"),
        "y4_ministry_response": ("pending","denial"),
        "y4_carina_separation": ("none","war_pressure"),
        "y4_carina_prior_visibility": ("none","private","public"),
        "y4_ritual_servant": ("unknown","peter","avery","karkaroff"),
        "y4_crouch_jr": ("unknown","at_large","kissed"),
        "y4_winner": ("pending","harry","cedric","shared"),
        "y4_hostage": ("ron","carina","hermione","ginny","luna")})

init -17 python:
    Y4_TITLES = ("불빛 아래의 표식", "네 번째 이름", "누구와 갈까", "크리스마스의 한 곡",
        "호수에 남은 목소리", "함께할 수 없는 이유", "미로의 끝", "여름으로 가져갈 것")
    for _i, _title in enumerate(Y4_TITLES, 1):
        CHAPTERS["Y4-C%d" % _i] = dict(year=4, number=_i, title=_title, pov="harry", demo=False)

    def _y4_choice(cid, chapter, tier, options):
        CHOICES[cid] = dict(chapter_id="Y4-C%d" % chapter, text="", tier=tier,
            statistics=tier>1, tags=["year4","butterfly" if tier==3 else "conversation"],
            options=[dict(id=oid, text=words, effects=effects) for oid,words,effects in options])

    def _y4_memory(h, key, detail):
        return ("relationship_event",h,"y4_"+key,"memory",detail,False)

    _y4_choice("Y4_CUP_COMPANY",1,1,[
        ("hermione","헤르미온느에게 응원하는 팀을 묻는다.",[]),
        ("ginny","지니와 크룸의 다음 움직임을 맞혀 본다.",[])])
    _y4_choice("Y4_MARK",1,2,[
        ("together","헤어지지 말자. 같이 움직여.",[("special","friendship_stability",1)]),
        ("guide","불빛 보이지? 저쪽으로 가자.",[])])
    _y4_choice("Y4_TRAIN",1,1,[
        ("luna","루나가 읽는 잡지를 같이 본다.",[_y4_memory("luna","train_magazine","열차에서 지니와 함께 루나의 잡지를 읽었다.")]),
        ("ginny","지니에게 방학 동안 연습한 이야기를 묻는다.",[_y4_memory("ginny","summer_flying","방학 동안 지니가 한 비행 연습 이야기를 들었다.")])])
    _y4_choice("Y4_RON_CONFLICT",2,2,[
        ("explain","나도 왜 뽑혔는지 알고 싶어.",[]),
        ("hurt","너까지 내가 거짓말한다고 생각해?",[])])
    _y4_choice("Y4_BADGE",2,1,[
        ("laugh","나 보라고 그렇게 누르는 거야?",[]),
        ("leave","할 말 다 했으면 지나갈게.",[])])
    _y4_choice("Y4_CARINA_INFORMATION",2,2,[
        ("thank","나 때문에 알아본 거야? 고마워.",[_y4_memory("carina","dragon_warning","카리나가 외국 학생들에게 얻은 용의 정보를 들었다.")]),
        ("plan","그럼 어디부터 준비하면 될까?",[])])
    _y4_choice("Y4_DRAGON_PREP",2,2,[
        ("practice","헤르미온느와 소환 주문을 더 연습한다.",[("flag","y4_summoning_practised",True)]),
        ("rest","오늘은 여기까지 할게. 같이 저녁 먹자.",[("flag","y4_summoning_practised",False)])])
    _y4_choice("Y4_RON_RECONCILE",2,1,[
        ("accept","됐어. 나도 너랑 말 못 하는 게 싫었어.",[]),
        ("honest","다음엔 내 말부터 들어 줘.",[])])
    _y4_choice("Y4_H_RON_RECONCILE",2,1,[
        ("accept","네가 삐진 게 더 우울했어.",[]),
        ("honest","다음엔 내 말부터 들어 줘.",[])])
    _y4_choice("Y4_BALL_INTENT",3,3,[
        ("hermione","헤르미온느에게 함께 가자고 한다.",[]),
        ("ginny","지니를 찾아가 본다.",[]),
        ("luna","루나를 초대한다.",[]),
        ("carina","카리나와 이야기한다.",[]),
        ("none","헤르미온느에게 친구로 첫 춤을 부탁한다.",[])])
    _y4_choice("Y4_PRIOR_COMMITMENT",3,2,[
        ("tell","다른 데서 듣게 하고 싶지 않아서 먼저 말하는 거야.",[]),
        ("ask","다른 뜻이 있어서 같이 가자는 건 아니야.",[])])
    for _h,_chapter,_options in (
        ("HERMIONE",3,[("honest","사람들 앞에서보다 네 앞에서 더 긴장되는데.",[]),("count","세는 건 네가 해 줘. 발은 내가 조심할게.",[])]),
        ("GINNY",3,[("follow","이번에는 네가 이끌어 봐.",[]),("again","한 번 더 해 보자. 이번엔 안 밟을게.",[])]),
        ("LUNA",3,[("listen","음악부터 다시 들어 볼까?",[]),("laugh","넘어지면 같이 웃어 주기다.",[])]),
        ("CARINA",3,[("trust","네가 가르쳐 줘. 오늘은 얌전히 들을게.",[]),("tease","무도회에서도 이렇게 엄하게 굴 거야?",[])])):
        _y4_choice("Y4_PRACTICE_"+_h,_chapter,2,_options)
    _y4_choice("Y4_CARINA_COVER",3,2,[
        ("plain","복잡하게 돌려 말하지 말고, 같이 들어가자.",[]),
        ("cover","둘 다 파트너가 없으니 같이 가는 걸로 할까?",[])])
    # Keep historical answers readable; their wording never decided publicity.
    CHOICES["Y4_CARINA_COVER"]["legacy"] = True
    _y4_choice("Y4_CARINA_PUBLICITY",3,3,[
        ("private","둘만의 비밀로 두고, 함께 무도회에 들어간다.",[]),
        ("public","사람들 앞에서 카리나에게 마음을 전한다.",[])])
    for _h,_options in (
        ("CARINA",[("stay","조금만 더 같이 있자.",[]),("air","바람 좀 쐴래? 여기 너무 덥다.",[])]),
        ("HERMIONE",[("say","오늘 너랑 오길 잘했어.",[]),("dance","이번 곡도 출래?",[])]),
        ("GINNY",[("match","좋아. 네가 가는 데로 따라갈게.",[]),("talk","잠깐 앉을까? 너랑 얘기도 하고 싶어.",[])]),
        ("LUNA",[("watch","저 장식, 아까랑 모양이 달라졌네.",[]),("dance","다음 곡은 네 방식으로 춰 보자.",[])])):
        _y4_choice("Y4_DANCE_"+_h,4,2,_options)
    _y4_choice("Y4_BALL_MEANING",4,3,[
        ("friend","오늘 즐거웠어. 다음에도 같이 놀자.",[]),
        ("confess","친구로만 같이 있고 싶은 건 아니야. 너를 좋아해.",[]),
        ("affirm","오늘도 네 옆에 있고 싶었어.",[])])
    _y4_choice("Y4_VISIBILITY",4,3,[
        ("private","우리 얘기는 당분간 우리끼리 간직하자.",[]),
        ("public","누가 물어보면 사귄다고 말하고 싶어. 너는 어때?",[])])
    _y4_choice("Y4_EGG_HELP",5,2,[
        ("share","알에서 들은 말을 친구들에게 그대로 들려준다.",[]),
        ("cedric","세드릭에게 왜 나를 도와줬는지 묻는다.",[])])
    _y4_choice("Y4_CARINA_EGG_REPLY",5,2,[
        ("explain","세드릭만 모르고 시합하면 불공평하잖아.",[]),
        ("thank","먼저 고맙다고 했어야 했네. 네가 알아와 준 덕분이야.",[])])
    _y4_choice("Y4_LAKE_PLAN",5,2,[
        ("signal","위험하면 붉은 불꽃부터 쏘자. 나도 그럴게.",[("flag","y4_cedric_signal_agreed",True)]),
        ("compete","이번에는 내가 먼저 올라갈 거야.",[("flag","y4_cedric_signal_agreed",False)])])
    _y4_choice("Y4_LAKE_RESCUE",5,2,[
        ("both","가브리엘도 함께 데리고 올라간다.",[("flag","y4_gabrielle_rescued",True)]),
        ("signal","인어들에게 가브리엘이 남았다고 알리고 먼저 올라간다.",[("flag","y4_gabrielle_rescued",False)])])
    _y4_choice("Y4_SPRING_COMPANY",5,1,[
        ("ginny","지니의 연습 공을 받아 준다.",[_y4_memory("ginny","spring_practice","봄날 지니의 퀴디치 연습을 도왔다.")]),
        ("luna","루나와 호숫가에 떨어진 깃털을 살펴본다.",[_y4_memory("luna","spring_feather","지니와 헤어진 뒤 루나와 새 깃털을 살펴보았다.")])])
    _y4_choice("Y4_MOODY_REPORT",6,2,[
        ("facts","직접 본 것과 짐작한 것을 나눠 말씀드린다.",[("flag","y4_report_precise",True)]),
        ("friend","카리나가 어디 있는지부터 확인해 달라고 한다.",[("flag","y4_report_precise",False)])])
    _y4_choice("Y4_SEPARATION_REPLY",6,3,[
        ("hear","…알았어. 그래도 널 좋아하는 건 변하지 않아.",[]),
        ("oppose","널 지킬 방법이 있어. 내 곁에 있어 줘.",[])])
    _y4_choice("Y4_MAZE_PREP",7,2,[
        ("remember","세드릭과 구조 신호를 다시 확인한다.",[("flag","y4_cedric_warning_ready",True)]),
        ("focus","내 지팡이와 응급 붕대를 다시 확인한다.",[("flag","y4_cedric_warning_ready",False)])])
    _y4_choice("Y4_FAIR_DUEL",7,2,[
        ("compete","결투로 끝내자. 제대로 이겨 봐, 세드릭.",[]),
        ("yield","내 다리로는 더 못 가겠어. 네가 먼저 가.",[])])
    _y4_choice("Y4_CUP",7,3,[
        ("together","같이 잡자. 여기까지 같이 왔잖아.",[]),
        ("signal","돌아가는 포트키일 수도 있으니 지팡이를 쥐고 준비한다.",[])])
    _y4_choice("Y4_GRAVEYARD",7,3,[
        ("warn","세드릭에게 엎드리라고 외치며 묘석 뒤로 몸을 던진다.",[]),
        ("cup","세드릭에게 컵을 잡으라고 외친다.",[])])
    _y4_choice("Y4_LETTER",8,2,[
        ("teachers","편지를 들고 덤블도어 교수님을 찾아간다.",[]),
        ("hermione","헤르미온느에게 같이 가 달라고 부탁한다.",[])])
    _y4_choice("Y4_HERMIONE_FAREWELL",8,1,[
        ("write","편지할게. 답장도 꼭 해 줘.",[_y4_memory("hermione","summer_letters","힘든 여름에도 편지를 주고받기로 했다.")]),
        ("thanks","지금까지 내 말 믿어 줘서 고마워.",[])])
    _y4_choice("Y4_GINNY_FAREWELL",8,1,[
        ("expect","다음에 연습하는 거 꼭 보여 줘.",[_y4_memory("ginny","summer_expectation","방학 뒤 지니의 비행을 기대한다고 말했다.")]),
        ("stay","조금만 더 여기 앉아 있어도 돼?",[])])
    _y4_choice("Y4_LUNA_FAREWELL",8,1,[
        ("keep","그 그림, 내가 가져도 돼?",[_y4_memory("luna","summer_drawing","루나가 그린 호숫가 새 그림을 받았다.")]),
        ("next","다음엔 살아 있는 새도 같이 보자.",[])])

    _y4_choice("Y4_CUP_REUNION",1,1,[
        ("honest","오랜만에 봐서 자꾸 네 쪽으로 눈이 갔어.",[]),
        ("replay","스니치 잡힐 때 네 표정도 볼래?",[])])
    _y4_choice("Y4_AUTUMN_DATE",1,1,[
        ("stay","종 울리기 전까지만 더 있자.",[]),
        ("next","다음에는 네가 먼저 기다려 줘.",[])])
    _y4_choice("Y4_FERRET_WAIT",2,1,[
        ("coat","바닥이 차가우니까 여기 올라와.",[]),
        ("quiet","알았어. 안 만질게. 옆에만 있을게.",[])])
    _y4_choice("Y4_WINTER_DATE",5,1,[
        ("tea","식기 전에 마셔. 네 것까지 내가 들고 왔는데.",[]),
        ("walk","한 바퀴 더 돌까? 이번에는 네 보폭에 맞출게.",[])])
    _y4_choice("Y4_CLOAK_DATE",5,1,[
        ("tease","네가 당당하게 굴라며. 이제 와서 무르면 안 되지.",[]),
        ("remember","그때 네가 말해 준 건 아직도 기억해. 별것도 아닌 일에 사과하지 말라고.",[])])

    # Order, not the spelling of a stable ID, determines scene traversal.
    Y4_SCENES = {}
    def _y4_scene(n, seq, title, date, place, people, bg, choices=(), condition="always", outfit="school"):
        sid = "Y4-C%d-S%02d" % (n,seq)
        Y4_SCENES[sid] = dict(chapter="Y4-C%d"%n,number=n,offset=seq-1,
            label=sid.lower().replace("-","_"),title=title,time=date,location=place,
            participants=["harry"]+people.split(),pov="harry",choices=list(choices),
            optional=condition!="always",condition=condition,bg=bg,outfit=outfit)
    _y4_scene(1,1,"월드컵의 응원석","2029-08-22","퀴디치 월드컵 일등석","ron hermione ginny carina lucius","camp",["Y4_CUP_COMPANY"])
    _y4_scene(1,6,"경기가 끝난 뒤","2029-08-22","월드컵 야영장","carina","camp",["Y4_CUP_REUNION"],"carina_dating")
    _y4_scene(1,2,"하늘에 남은 표식","2029-08-22","야영장 뒤 숲","ron hermione ginny carina","forest",["Y4_MARK"])
    _y4_scene(1,3,"창가의 빈자리","2029-09-01","호그와트행 열차","ron hermione ginny luna carina","train",["Y4_TRAIN"])
    _y4_scene(1,4,"새 방어술 교수","2029-09-02","방어술 교실","moody ron hermione neville","classroom")
    _y4_scene(1,7,"종이 울리기 전까지","2029-09-26","성 바깥 회랑","carina","courtyard",["Y4_AUTUMN_DATE"],"carina_dating")
    _y4_scene(1,5,"호수 위의 돛","2029-10-30","호그와트 현관","ron hermione ginny luna carina krum fleur dumbledore","courtyard")
    _y4_scene(2,1,"네 번째 이름","2029-10-31","대연회장","ron hermione carina cedric krum fleur moody dumbledore crouch","hall")
    _y4_scene(2,2,"말을 믿어 줬으면","2029-11-01","그리핀도르 휴게실","ron hermione","common",["Y4_RON_CONFLICT"])
    _y4_scene(2,3,"옷깃의 배지","2029-11-03","안뜰","ginny luna carina victoria moody hermione ron","courtyard",["Y4_FERRET_WAIT","Y4_BADGE"])
    _y4_scene(2,8,"시합 전에 돌아온 친구","2029-11-05","그리핀도르 휴게실","ron hermione","common",["Y4_H_RON_RECONCILE"],"fanfic")
    _y4_scene(2,4,"바쁘던 이유","2029-11-06","빈 교실 앞","carina","corridor",["Y4_CARINA_INFORMATION"])
    _y4_scene(2,5,"지팡이가 닿는 거리","2029-11-20","빈 교실","hermione cedric","classroom",["Y4_DRAGON_PREP"])
    _y4_scene(2,6,"용의 그림자","2029-11-24","첫 번째 시험장","hermione carina cedric krum fleur","arena")
    _y4_scene(2,7,"다시 셋이서","2029-11-24","선수 대기실","ron hermione","tent",["Y4_RON_RECONCILE"],"canon_adjacent")
    _y4_scene(3,1,"누구를 초대할까","2029-12-01","그리핀도르 휴게실","ron hermione","common",["Y4_BALL_INTENT"])
    _y4_scene(3,2,"먼저 해야 할 이야기","2029-12-02","회랑","carina","corridor",["Y4_PRIOR_COMMITMENT"],"other_partner_dating")
    _y4_scene(3,3,"책을 덮고","2029-12-02","도서관 앞","hermione ron","library",condition="invite_hermione")
    _y4_scene(3,4,"나한테 묻는 거야?","2029-12-02","그리핀도르 휴게실","ginny","common",condition="invite_ginny")
    _y4_scene(3,5,"함께 갈 사람","2029-12-02","도서관 앞","luna ginny","library",condition="invite_luna")
    _y4_scene(3,6,"초대의 말","2029-12-02","인적 없는 회랑 / 그리핀도르 휴게실","carina hermione","corridor",condition="invite_carina")
    _y4_scene(3,7,"틀린 발부터","2029-12-10","빈 교실","carina","classroom",["Y4_PRACTICE_CARINA"],"partner_carina")
    _y4_scene(3,8,"책에 없는 박자","2029-12-10","빈 교실","hermione","classroom",["Y4_PRACTICE_HERMIONE"],"partner_hermione")
    _y4_scene(3,9,"이번엔 내가 먼저","2029-12-10","빈 교실","ginny","classroom",["Y4_PRACTICE_GINNY"],"partner_ginny")
    _y4_scene(3,10,"음악이 돌아올 때","2029-12-10","빈 교실","luna","classroom",["Y4_PRACTICE_LUNA"],"partner_luna")
    _y4_scene(3,11,"상자에 담긴 예복","2029-12-22","그리핀도르 휴게실","ron hermione ginny","common")
    _y4_scene(3,12,"뒤늦게 내민 손","2029-12-25","대연회장 앞","carina krum hermione cho cedric","corridor",["Y4_CARINA_PUBLICITY"],"carina_cover","formal")
    _y4_scene(4,1,"문이 열리고","2029-12-25","크리스마스 무도회","carina hermione ginny luna ron cedric cho krum fleur","ball",outfit="formal")
    _y4_scene(4,2,"남들이 보는 곳에서","2029-12-25","무도회장","carina","ball",["Y4_DANCE_CARINA"],"partner_carina","formal")
    _y4_scene(4,3,"낯익은 목소리","2029-12-25","무도회장","hermione ron","ball",["Y4_DANCE_HERMIONE"],"partner_hermione","formal")
    _y4_scene(4,4,"오빠라고 부르다가","2029-12-25","무도회장","ginny","ball",["Y4_DANCE_GINNY"],"partner_ginny","formal")
    _y4_scene(4,5,"은빛 장식 아래","2029-12-25","무도회장","luna","ball",["Y4_DANCE_LUNA"],"partner_luna","formal")
    _y4_scene(4,6,"친구로 추는 첫 춤","2029-12-25","대연회장","ron hermione ginny luna","ball",condition="partner_none",outfit="formal")
    _y4_scene(4,7,"한 곡이 끝난 뒤","2029-12-25","무도회장 옆 회랑","carina hermione ginny luna percival","corridor",["Y4_BALL_MEANING","Y4_VISIBILITY"],"has_partner","formal")
    _y4_scene(5,1,"물속에서 들리는 노래","2030-01-10","빈 교실","hermione ron cedric","classroom",["Y4_CARINA_EGG_REPLY","Y4_EGG_HELP"])
    _y4_scene(5,6,"따뜻한 잔 두 개","2030-01-23","겨울의 회랑","carina","corridor",["Y4_WINTER_DATE"],"carina_dating")
    _y4_scene(5,7,"망토 안의 두 걸음","2030-02-03","눈 내리는 안뜰 옆 회랑","carina","corridor_winter",["Y4_CLOAK_DATE"],"hidden_cloak_date")
    _y4_scene(5,2,"돌아오겠다는 약속","2030-02-20","호숫가","carina hermione ginny luna ron cedric","lake",["Y4_LAKE_PLAN"])
    _y4_scene(5,3,"호수 아래의 한 시간","2030-02-24","검은 호수","cedric fleur","underwater",["Y4_LAKE_RESCUE"])
    _y4_scene(5,4,"담요 한 장의 거리","2030-02-24","호숫가 대기실","carina hermione ginny luna ron fleur","tent")
    _y4_scene(5,5,"시합이 없는 오후","2030-03-10","안뜰","ginny luna","courtyard",["Y4_SPRING_COMPANY"])
    _y4_scene(6,1,"누군가 듣고 있었다","2030-03-12","도서관","hermione carina moody","library",["Y4_MOODY_REPORT"])
    _y4_scene(6,2,"진짜 무디의 의심","2030-03-14","호숫가의 수풀과 무디의 트렁크","carina moody sirius dumbledore rita","lake",condition="fanfic")
    _y4_scene(6,3,"집에서 온 편지","2030-05-20","성의 회랑","carina","corridor")
    _y4_scene(6,4,"지키려는 것","2030-06-05","빈 교실","carina","classroom",["Y4_SEPARATION_REPLY"])
    _y4_scene(7,1,"미로에 들어가기 전","2030-06-24","세 번째 시험장 입구","hermione ginny luna carina cedric moody","arena",["Y4_MAZE_PREP"])
    _y4_scene(7,2,"빨판의 상처","2030-06-24","트리위저드 미로","cedric","maze",["Y4_FAIR_DUEL"],"fanfic")
    _y4_scene(7,3,"두 사람과 우승컵","2030-06-24","트리위저드 미로","cedric krum","maze",["Y4_CUP"],"canon_adjacent")
    _y4_scene(7,4,"돌아올 길","2030-06-24","리틀 행글턴 묘지","cedric peter voldemort","graveyard",["Y4_GRAVEYARD"],"canon_adjacent")
    _y4_scene(7,5,"끝난 것처럼 보인 경기","2030-06-24","시험장 심판석","cedric crouch hermione ginny","arena",condition="fanfic")
    _y4_scene(8,1,"의무실의 밤","2030-06-24","호그와트 의무실","hermione ron ginny dumbledore sirius","infirmary")
    _y4_scene(8,2,"반지 아래의 글씨","2030-06-25","호그와트 의무실","hermione dumbledore moody","infirmary",["Y4_LETTER"],"fanfic")
    _y4_scene(8,3,"빌린 얼굴","2030-06-25","방어술 교수 집무실","moody crouch_jr dumbledore snape","office",condition="canon_adjacent")
    _y4_scene(8,4,"돌아왔다는 말","2030-06-26","교장실","dumbledore moody hermione","office")
    _y4_scene(8,5,"편지는 끊지 말자","2030-06-27","도서관 앞","hermione","library",["Y4_HERMIONE_FAREWELL"])
    _y4_scene(8,6,"잠깐 앉아 있어도 돼","2030-06-28","호숫가","ginny","lake",["Y4_GINNY_FAREWELL"])
    _y4_scene(8,7,"돌려주지 않아도 돼","2030-06-28","안뜰","luna ginny","courtyard",["Y4_LUNA_FAREWELL"])
    _y4_scene(8,8,"복도에 남은 사람","2030-06-29","성의 회랑","carina victoria grace","corridor")
    _y4_scene(8,9,"아직 끝나지 않은 여름","2030-06-30","귀향 열차","ron hermione ginny luna","train")

    for _chapter in range(1,9):
        for _offset,_sid in enumerate(s for s,m in Y4_SCENES.items() if m["number"]==_chapter):
            Y4_SCENES[_sid]["offset"]=_offset
