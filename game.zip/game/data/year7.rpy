# M7 metadata is authored alongside executable scenes. Stable IDs are never reused.
init -15 python:
    Y7_TITLES=("세 개의 배낭","돌아갈 수 없는 집","추운 숲의 목소리","붙잡힌 사람들","바닷가의 집",
        "학교로 돌아가는 길","남겨야 할 말","끝까지 남은 사람","전쟁 다음 날","내가 고르는 내일","별이 보이는 밤","다시 출발하는 아침")
    for _n,_t in enumerate(Y7_TITLES,1):
        CHAPTERS["Y7-C%d"%_n]=dict(year=7,number=_n,title=_t,pov="harry",demo=False)
    Y7_SCENES={}
    def _y7_scene(ch,n,title,date,location,bg,people,choices=(),music="reflection",condition="always",source=""):
        sid="Y7-C%d-S%02d"%(ch,n)
        Y7_SCENES[sid]=dict(chapter="Y7-C%d"%ch,number=ch,offset=n-1,label="y7_c%d_s%02d"%(ch,n),
            title=title,time=date,location=location,bg=bg,participants=["harry"]+people.split(),pov="harry",
            outfit="casual",choices=list(choices),music=music,condition=condition,optional=True,
            story_lane="fanfic" if n>=11 else "canon_adjacent",source=source)
    _y7_scene(1,1,"세 사람이 들고 갈 짐","2032-07-28","버로의 다락방","burrow_attic","ron hermione",["Y7_TRIO_PROMISE"])
    _y7_scene(1,2,"사진 속의 세 사람","2032-07-28","버로의 뒷문","burrow_yard","hermione",["Y7_HERMIONE_PARENTS"],"hermione")
    _y7_scene(1,3,"학교에 남을 사람들","2032-07-29","버로의 헛간 앞","burrow_yard","ginny",["Y7_RESISTANCE_CONTACT"],"ginny")
    _y7_scene(1,4,"결혼식의 은빛 전갈","2032-08-01","버로의 결혼식 천막","wedding_tent","luna ron hermione ginny kingsley",music="warm")
    _y7_scene(1,5,"늦은 손님","2032-08-01","런던의 카페","cafe","ron hermione",music="danger")
    _y7_scene(2,1,"레귤러스의 부탁","2032-08-07","그림몰드가","grimmauld","kreacher ron hermione")
    _y7_scene(2,2,"세 잔의 폴리주스","2032-09-01","그림몰드가의 주방","grimmauld","ron hermione",["Y7_MINISTRY_PLAN"],"mystery")
    _y7_scene(2,3,"빼앗겼다고 적힌 지팡이","2032-09-02","마법부 심문실","court","umbridge ron hermione",music="danger")
    _y7_scene(2,4,"돌아가지 말라는 편지","2032-09-02","숲의 임시 야영지","camp","ron hermione")
    _y7_scene(2,5,"첫 번째 밤의 경계","2032-09-03","야영지의 입구","camp","hermione",["Y7_CAMP_WATCH"],"hermione")
    _y7_scene(3,1,"목에 걸린 말","2032-11-07","숲속 텐트","camp","ron hermione",["Y7_RON_ARGUMENT"],"danger")
    _y7_scene(3,2,"늘지 않는 나이","2032-12-24","고드릭 골짜기의 묘지","graveyard","hermione ron")
    _y7_scene(3,3,"대답하지 않는 집","2032-12-24","바틸다의 집","old_house","hermione",music="danger")
    _y7_scene(3,4,"얼음 아래의 검","2032-12-27","얼어붙은 연못","forest_night","ron hermione",music="mystery")
    _y7_scene(3,5,"우리의 대답","2032-12-27","연못 옆 바위","forest_night","ron",music="danger")
    _y7_scene(3,6,"세 장의 지도","2032-12-27","텐트 안","camp","ron hermione",music="warm")

    _y7_scene(4,1,'학교에서 온 작은 소식','2033-01-02','숲속 야영지','camp','ron hermione',[],'mystery','always')
    _y7_scene(4,2,'딸이 없는 집','2033-01-05','러브굿의 집','lovegood','ron hermione xenophilius',[],'mystery','always')
    _y7_scene(4,3,'이름을 잃은 밤','2033-03-21','숲에서 말포이 저택까지','forest_night','ron hermione',[],'danger','always')
    _y7_scene(4,4,'확실하지 않은 얼굴','2033-03-21','말포이 저택 응접실','manor','carina narcissa lucius bellatrix ron hermione',[],'danger','always')
    _y7_scene(4,5,'감방에서 만난 루나','2033-03-21','말포이 저택 지하','cell','luna ron ollivander griphook',[],'luna','always')
    _y7_scene(5,1,'돌아온 집요정','2033-03-21','말포이 저택 지하','cell','dobby luna ron peter',[],'danger','always')
    _y7_scene(5,2,'마지막으로 잡은 손','2033-03-21','말포이 저택 응접실','manor','carina hermione ron dobby bellatrix narcissa',['Y7_MANOR_ESCAPE'],'danger','always')
    _y7_scene(5,3,'바다가 보이는 곳','2033-03-21','조개껍데기 오두막의 해변','shore','luna dobby hermione ron fleur',[],'reflection','always')
    _y7_scene(5,4,'누구에게 응하는가','2033-04-04','조개껍데기 오두막','cottage','ollivander griphook hermione luna',[],'mystery','always')
    _y7_scene(6,1,'금고에서 꺼낸 컵','2033-05-01','그린고트의 금고','vault','ron hermione griphook',[],'danger','always')
    _y7_scene(6,2,'돌아오는 문','2033-05-01','호그스 헤드의 비밀 통로','old_house','aberforth neville ron hermione',[],'mystery','always')
    _y7_scene(6,3,'우리가 있던 방','2033-05-01','필요의 방','requirement','ginny luna neville ron hermione',[],'warm','always')
    _y7_scene(6,4,'모양을 기억하는 사람','2033-05-01','래번클로 탑','ravenclaw','luna helena',[],'luna','always')
    _y7_scene(6,5,'움직이는 성','2033-05-01','호그와트의 현관','hall','mcgonagall snape ginny neville carina percival',[],'danger','always')
    _y7_scene(7,1,'각자가 맡은 길','2033-05-01','현관의 방어선','hall','ginny luna neville cedric cho sirius',['Y7_BATTLE_PREP'],'danger','always')
    _y7_scene(7,2,'독니를 가져온 두 사람','2033-05-02','지하 계단','corridor','hermione ron',[],'hermione','always')
    _y7_scene(7,3,'불이 삼킨 방','2033-05-02','물건을 숨기는 방','burning_room','carina victoria grace ron hermione',[],'danger','always')
    _y7_scene(7,4,'같은 시간의 다른 복도','2033-05-02','무너진 회랑','ruins','ginny luna hermione ron fred percy',[],'danger','always')
    _y7_scene(7,5,'마지막으로 내민 기억','2033-05-02','비명을 지르는 오두막','old_house','snape voldemort hermione ron',[],'separation','always')
    _y7_scene(7,6,'내 안에 남은 것','2033-05-02','교장실의 펜시브','office','dumbledore snape lily james',[],'reflection','always')
    _y7_scene(7,7,'돌아오고 싶다는 말','2033-05-02','대연회장 입구','ruins','hermione ron ginny luna neville',['Y7_FOREST_WORDS'],'separation','always')
    _y7_scene(8,1,'숲으로 가는 발걸음','2033-05-02','금지된 숲','forest_night','lupin sirius voldemort hagrid',[],'separation','always')
    _y7_scene(8,2,'돌아갈 수 있는 곳','2033-05-02','흰 빛 속의 승강장','limbo','dumbledore',[],'reflection','always')
    _y7_scene(8,3,'딸이 있는 곳으로','2033-05-02','금지된 숲에서 성문까지','forest_night','narcissa hagrid ginny hermione luna',[],'separation','always')
    _y7_scene(8,4,'아직 끝나지 않은 싸움','2033-05-02','호그와트 현관과 대연회장','ruins','neville ginny hermione luna molly bellatrix',[],'danger','always')
    _y7_scene(8,5,'마지막 지팡이의 주인','2033-05-02','대연회장','ruins','voldemort carina',[],'danger','always')
    _y7_scene(8,6,'이름을 다시 부르는 아침','2033-05-02','새벽의 대연회장','ruins','ron hermione ginny luna carina grace fred molly',[],'reflection','always')
    _y7_scene(9,1,'각자의 집으로','2033-05-09','호그와트 의무실','infirmary','hermione ginny luna',[],'warm','always')
    _y7_scene(9,2,'없는 말은 하지 않을게','2033-05-23','마법부 지하 법정 앞','corridor','carina narcissa ron hermione kingsley',['Y7_CARINA_ACCOUNT'],'reflection','always',source='User-approved postwar trial; game-reference structure; project-specific testimony')
    _y7_scene(9,3,'그날의 말에 대한 사과','2033-05-23','마법부 법정 밖 복도','corridor','carina hermione ron narcissa',[],'reflection','always',source='User-approved direct apology after trial; game-reference structure')
    _y7_scene(9,4,'위험하지 않은 약속','2033-06-16','호숫가','lake','hermione ginny luna ron',['Y7_RELATIONSHIP'],'warm','always')
    _y7_scene(9,5,'이번에는 제대로 묻는 말','2033-06-23','복구 중인 회랑','courtyard','carina',['Y7_CARINA_POSTWAR'],'carina','carina_conversation')
    _y7_scene(9,6,'두 장의 서류','2033-07-10','마법부 집무실 앞','office','kingsley hermione ron ginny luna carina',['Y7_FUTURE'],'anticipation','always')
    _y7_scene(10,1,'제압한 다음에 할 일','2033-09-01','오러 훈련실','classroom','kingsley ron',[],'school','auror')
    _y7_scene(10,2,'서로 다른 하루','2033-10-23','호그스미드의 찻집','cafe','hermione ginny luna carina ron',[],'warm','auror')
    _y7_scene(10,3,'첫 번째 임명장','2034-06-30','오러 사무실과 집','office','ron',[],'reflection','auror')
    _y7_scene(10,4,'다시 받은 시간표','2033-09-01','급행열차와 첫 수업','classroom','ron hermione ginny luna carina mcgonagall',['Y7_RETURN_CLASS'],'school','return')
    _y7_scene(10,5,'저녁 식사 다음 한 시간','2033-10-23','호그와트 회랑','corridor','hermione ginny luna carina',[],'warm','return')
    _y7_scene(11,1,'설명하지 않아도 되는 별','2034-06-18','통금 뒤의 천문탑','tower_night','hermione',[],'hermione','star_hermione')
    _y7_scene(11,2,'서로의 앞을 달리는 사람','2034-06-18','통금 뒤의 천문탑','tower_night','ginny',[],'ginny','star_ginny')
    _y7_scene(11,3,'아직 모르기로 한 밤','2034-06-18','통금 뒤의 천문탑','tower_night','luna',[],'luna','star_luna')
    _y7_scene(11,4,'이번에는 잡는 손','2034-06-18','통금 뒤의 천문탑','tower_night','carina',['Y7_HANDSHAKE'],'carina','star_carina')
    _y7_scene(11,5,'혼자 있어도 돌아갈 자리','2034-06-18','시험이 끝난 호숫가','lake','hermione ginny luna',[],'reflection','star_none')
    _y7_scene(11,6,'마지막 수업의 끝','2034-06-30','대연회장과 성문','hall','mcgonagall hermione ginny luna carina',[],'warm','return')
    _y7_scene(12,1,'아이리스의 첫 질문','2052-09-01','킹스크로스 승강장','platform','hermione iris ben ron',[],'hermione','end_hermione')
    _y7_scene(12,2,'네 이름으로 살아도 돼','2052-09-01','킹스크로스 승강장','platform','ginny albus james lily',[],'ginny','end_ginny')
    _y7_scene(12,3,'빈 곳이 남은 지도','2052-09-01','킹스크로스 승강장','platform','luna rowan ada',[],'luna','end_luna')
    _y7_scene(12,4,'다시 손을 흔드는 날','2052-09-01','킹스크로스 승강장','platform','carina leo lyra hermione ron',[],'carina','end_carina')
    _y7_scene(12,6,'내가 설 자리','2052-09-01','킹스크로스 승강장','platform','ron hermione ginny luna',[],'warm','end_none')

    Y7_HIDDEN_TITLES=("짧은 여름", "빈 학교로 가는 열차", "살아남는 대가", "닫힌 문 앞에서", "생일 전날", "내 안의 마지막 목소리", "돌아온 사람", "도망가지 않는 결말", "기다린 사람들에게", "마지막 학교생활", "함께 정할 집", "우리 아이의 출발")
    _y7_scene(1,11,"달력에 남은 일주일","2032-07-01","프리벳가의 방","privet","",["Y7_H_PRIVET"],source="EP101")
    _y7_scene(1,12,"데리러 온 카리나","2032-07-08","프리벳가의 현관","privet","carina",source="EP102")
    _y7_scene(1,13,"계단 아래의 방","2032-07-08","프리벳가","privet","carina",source="EP102")
    _y7_scene(2,11,"말을 듣는 은빛 팔","2032-07-08","호그와트 급행열차","train","carina",source="EP103")
    _y7_scene(2,12,"초콜릿 개구리 카드","2032-07-08","급행열차의 객실","train","carina",["Y7_H_TRAIN"],source="EP103")
    _y7_scene(2,13,"방학 중의 학교","2032-07-08","호그와트 회랑","corridor","carina",source="EP103")
    _y7_scene(3,11,"트렁크 안의 죄수","2032-07-19","학교의 빈 교실","classroom","carina cedric kingsley",source="EP104")
    _y7_scene(3,12,"그린델왈드의 제안","2032-07-19","빈 교실","classroom","carina",source="EP104")
    _y7_scene(3,13,"끝없이 갇혀 있는 삶","2032-07-19","빈 교실","classroom","carina",["Y7_H_COST"],source="EP104")
    _y7_scene(4,11,"다른 사람의 목숨","2032-07-20","호그와트 회랑","corridor","carina",source="EP105")
    _y7_scene(4,12,"닫힌 문 앞의 편지","2032-07-21","슬리데린 기숙사 입구","corridor","",["Y7_H_DOOR"],source="EP105")
    _y7_scene(4,13,"대답 대신 온 편지들","2032-07-23","학교의 빈 교실","classroom","moody lupin cedric kingsley",source="EP105")
    _y7_scene(5,11,"이틀 남은 날짜","2032-07-29","그리핀도르 기숙사","common_room","",source="EP106")
    _y7_scene(5,12,"다시 나타난 카리나","2032-07-30","교장실","office","carina moody lupin dawlish",source="EP106")
    _y7_scene(5,13,"마지막으로 감춘 말","2032-07-30","트렁크 안의 방","trunk","carina",source="EP106")
    _y7_scene(6,11,"받아들일 수 없는 제안","2032-07-30","트렁크 안의 방","trunk","carina",music="separation",source="EP106")
    _y7_scene(6,12,"남겨진 보호","2032-07-30","의식 속 대연회장","hall","voldemort dumbledore",music="danger",source="EP106")
    _y7_scene(6,13,"내 안의 마지막 목소리","2032-07-30","의식 속 대연회장","hall","voldemort dumbledore",music="danger",source="EP106")
    _y7_scene(7,11,"다시 부르는 이름","2032-07-30","학교의 회복실","infirmary","carina",["Y7_H_WAKE"],"carina",source="EP106 awakening; original aftermath")
    _y7_scene(7,12,"열일곱 번째 생일","2032-07-31","학교의 회복실","infirmary","carina moody lupin",source="Original approved ending")
    _y7_scene(7,13,"문 밖으로 나가는 허락","2032-08-04","학교의 회복실과 복도","infirmary","carina kingsley dawlish",source="Original approved ending")
    _y7_scene(8,11,"각자가 답해야 할 질문","2032-08-12","마법부 조사실","court","carina narcissa",source="Original approved ending")
    _y7_scene(8,12,"내 이름이 적힌 서류","2032-08-26","마법부 집무실","office","kingsley",source="Original approved ending")
    _y7_scene(8,13,"어디로든 걸어갈 수 있는 오후","2032-08-26","런던의 거리","alley","carina",["Y7_H_FREE_DAY"],"carina",source="Original approved ending")
    _y7_scene(9,11,"돌아왔다는 인사","2032-08-28","버로","burrow","carina ron hermione ginny luna sirius",music="warm",source="Original approved ending; user-approved direct apology at the Burrow")
    _y7_scene(9,12,"두 이름 앞에서","2032-08-30","호그와트의 묘역","graveyard","carina",source="Original approved ending")
    _y7_scene(9,13,"들킬까 봐 멈추지 않아도","2032-09-01","급행열차 복도","train","carina",music="carina",source="Original approved ending")
    _y7_scene(10,11,"우리가 다닐 마지막 학년","2032-09-02","호그와트 교실","classroom","carina hermione ron ginny luna",music="school",source="Original approved ending")
    _y7_scene(10,12,"돌아갈 집에서 하는 말","2032-12-23","말포이 저택","manor","carina narcissa dobby",source="Original approved ending")
    _y7_scene(10,13,"둘의 다른 진로","2033-03-04","도서관","library","carina",["Y7_H_FUTURE"],"carina",source="Original approved ending")
    _y7_scene(11,11,"마지막 급행열차","2033-06-30","호그와트의 성문","courtyard","carina hermione ron ginny luna",music="warm",source="Original approved ending")
    _y7_scene(11,12,"집을 고르는 기준","2035-06-02","호그스미드의 집","cottage","carina",music="carina",source="Original approved ending")
    _y7_scene(11,13,"같이 정할 내일","2037-07-31","두 사람이 고른 집","cottage","carina",music="carina",source="Original approved ending")
    _y7_scene(12,11,"리라의 첫 출발","2052-09-01","킹스크로스 승강장","platform","carina lyra leo hermione",music="carina",source="Original approved ending")

    def _y7_choice(cid,ch,tier,options):
        CHOICES[cid]=dict(chapter_id="Y7-C%d"%ch,text="",tier=tier,statistics=tier>1,
            tags=["year7","butterfly" if tier==3 else "conversation"],
            options=[dict(id=o,text=t,effects=e) for o,t,e in options])
    _y7_choice("Y7_TRIO_PROMISE",1,2,[("share","확실하지 않은 것도 너희에게 먼저 이야기할게.",[("flag","y7_information_shared",True)]),
        ("note","급하게 움직이더라도 어디로 가는지는 꼭 남길게.",[])])
    _y7_choice("Y7_HERMIONE_PARENTS",1,2,[("find","끝나면 부모님을 같이 찾으러 가자.",[("relationship","hermione","affection",1)]),
        ("photo","부모님 사진을 조금 더 봐도 돼?",[])])
    _y7_choice("Y7_RESISTANCE_CONTACT",1,2,[("coin","가짜 갈레온으로 짧게 연락하자.",[("flag","y7_coin_contact",True)]),
        ("order","기사단에 전할 일이 있으면 내가 연결할게.",[("flag","y7_order_contact",True)])])
    _y7_choice("Y7_MINISTRY_PLAN",2,3,[("rescue","붙잡힌 사람들이 나갈 길부터 확인한다.",[("flag","y7_ministry_escape_ready",True)]),
        ("locket","로켓을 찾아 엄브릿지를 막는 순서를 맞춘다.",[])])
    _y7_choice("Y7_CAMP_WATCH",2,1,[("stay","차 마실 때까지만 같이 앉아 있자.",[]),
        ("walk","같이 방어 마법을 확인하고 올까?",[])])
    _y7_choice("Y7_RON_ARGUMENT",3,3,[("remove","목걸이부터 벗어. 그다음에 네 얘기를 들을게.",[("flag","y7_ron_stayed",True)]),
        ("leave","돌아가고 싶으면 가. 억지로 붙잡지는 않을게.",[("flag","y7_ron_departed",True)])])
    _y7_choice("Y7_MANOR_ESCAPE",5,3,[("shield","도비 앞에 방어막을 펼친다.",[("flag","y7_dobby_shielded",True)]),
        ("wands","바닥의 헤르미온느 지팡이까지 챙긴다.",[("flag","y7_hermione_wand_recovered",True)])])
    _y7_choice("Y7_BATTLE_PREP",7,3,[("evacuate","무너질 수 있는 통로에서 사람들을 먼저 빼낸다.",[("flag","y7_evacuation_ready",True)]),
        ("defend","현관의 결계가 약한 곳을 먼저 지킨다.",[("flag","y7_entrance_defended",True)])])
    _y7_choice("Y7_FOREST_WORDS",7,2,[("truth","살 수 있는 길이 보이면 놓지 않을게.",[]),
        ("task","내가 없을 때도 뱀을 찾아줘.",[])])
    _y7_choice("Y7_CARINA_ACCOUNT",9,2,[("listen","네가 직접 이야기하는 건 듣고 싶어.",[("flag","y7_carina_listened",True)]),
        ("testify","내가 본 일은 증언할게. 나머지는 네가 이야기해야 해.",[])])
    _y7_choice("Y7_RELATIONSHIP",9,3,[
        ("hermione","헤르미온느에게 친구 이상으로 좋아한다고 말한다.",[]),
        ("ginny","지니에게 남자 친구가 되고 싶다고 말한다.",[]),
        ("luna","루나와 사귀고 싶다는 마음을 전한다.",[]),
        ("friends","지금처럼 친구들과 지내고 싶다.",[])])
    _y7_choice("Y7_CARINA_POSTWAR",9,3,[("date","이번에는 네 대답을 듣고 싶어. 우리 사귀어 볼래?",[]),
        ("friends","서로 이야기할 수 있는 사이로 남고 싶어.",[])])
    _y7_choice("Y7_FUTURE",9,3,[("auror","오러 특별 채용에 지원하고 훈련을 받는다.",[]),
        ("return","호그와트로 돌아가 중단한 마지막 학년을 마친다.",[])])
    _y7_choice("Y7_RETURN_CLASS",10,1,[("ask","손을 들고 다시 설명해 달라고 한다.",[]),
        ("note","모르는 부분을 적어 수업 뒤에 물어본다.",[])])
    _y7_choice("Y7_HANDSHAKE",11,2,[("harry","이번에는 내가 먼저 손을 내민다.",[]),
        ("carina","카리나가 다시 손을 내밀기를 기다린다.",[])])
    _y7_choice("Y7_H_PRIVET",1,1,[("plain","조금만 더 기다리면 학교로 돌아간다.",[]),("warm","카리나가 오면 무슨 말을 먼저 할까.",[])])
    _y7_choice("Y7_H_TRAIN",2,1,[("ask","누구에게 들었는지, 위험한 일은 없었는지 묻는다.",[]),("thanks","자세한 이야기는 미루고, 돌아와 줘서 고맙다고 말한다.",[])])
    _y7_choice("Y7_H_COST",3,2,[("together","혼자 답을 정하지 말고 나하고 이야기해.",[]),("fear","나도 무서워. 그렇다고 아무거나 할 수는 없어.",[])])
    _y7_choice("Y7_H_DOOR",4,1,[("note","답을 재촉하지 않는 짧은 편지를 두고 간다.",[]),("leave","오늘은 기다리지 않고 돌아간다.",[])])
    _y7_choice("Y7_H_WAKE",7,1,[("sorry","기다리게 해서 미안하다고 말한다.",[]),("hand","계속 손을 잡고 있었는지 묻는다.",[])])
    _y7_choice("Y7_H_FREE_DAY",8,1,[("tea","차부터 마실까?",[]),("walk","조금 걸을래?",[])])
    _y7_choice("Y7_H_FUTURE",10,2,[("service","사람들을 지키는 일을 배우고 싶어.",[]),("teach","학교에서 가르치는 일을 해 보고 싶어.",[])])

init -14 python:
    Y7_SCENES=dict(sorted(Y7_SCENES.items(),key=lambda item:(item[1]["number"],item[1]["offset"])))
    Y7_SOURCE_SCENES={s for s,m in Y7_SCENES.items() if m["story_lane"]=="fanfic"}

init -14 python:
    for _sid in ("Y7-C3-S01","Y7-C3-S06","Y7-C4-S01"):
        Y7_SCENES[_sid]["bg"]="tent"
    Y7_SCENES["Y7-C9-S12"]["bg"]="graves"
    Y7_SCENES["Y7-C10-S02"]["bg"]="teashop"
    Y7_SCENES["Y7-C7-S04"]["bg"]="corridor"
    Y7_SCENES["Y7-C5-S12"]["bg"]="hall"
    Y7_SCENES["Y7-C5-S12"]["location"]="대연회장"
    for _sid in ("Y7-C11-S12","Y7-C11-S13"):
        Y7_SCENES[_sid]["bg"]="home"
    for _sid in ("Y7-C10-S04","Y7-C10-S05","Y7-C11-S04","Y7-C11-S06",
        "Y7-C10-S11","Y7-C10-S13","Y7-C11-S11",
        "Y7-C5-S12","Y7-C5-S13","Y7-C6-S11","Y7-C7-S11","Y7-C7-S12"):
        Y7_SCENES[_sid]["outfit"]="school"
