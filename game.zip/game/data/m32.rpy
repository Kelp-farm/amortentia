# Existing node/discovery/checkpoint framework, with two observed finale events.
init -3 python:
    M32_EVENT_OUTCOMES = {
        "Y3-E-INTERVENTION": {"carina":"카리나가 도움을 부르고 즉시 키스를 막았다.",
            "snape":"스네이프가 일행을 발견하고 성으로 데려왔다."},
        "Y3-E-SIRIUS": {"protected":"페티그루를 넘기고 시리우스를 보호받게 했다.",
            "escaped":"시리우스가 벅빅을 타고 탈출했다."},
    }
    for nid,title,sid,after in (
        ("Y3-E-INTERVENTION","호수에 도착한 도움","Y3-C5-S04","Y3-C5-S04"),
        ("Y3-E-SIRIUS","키스의 위협을 벗어나","Y3-C6-S04","Y3_PETER")):
        parent = M21_NODES[sid]
        M21_NODES[nid] = dict(id=nid,year=3,chapter=parent["chapter"],type="event",
            title=title,label=parent["label"],scene=sid,heroines=parent["heroines"],implemented=True,optional=False)
        chain=M21_CHAPTER_NODES[parent["chapter"]]
        chain.insert(chain.index(after)+1,nid)
    for chapter in ("Y3-C5","Y3-C6"):
        chain=M21_CHAPTER_NODES[chapter]
        for index,nid in enumerate(chain):
            M21_NODES[nid]["next"]=chain[index+1:index+2]
            M21_NODES[nid]["previous"]=chain[max(0,index-1):index]

    def m32_observe(nid,outcome):
        require_key(M32_EVENT_OUTCOMES,nid)
        require_key(M32_EVENT_OUTCOMES[nid],outcome)
        m21_visit(nid)
        m21_add("m21_completed",nid)
        m21_add("m21_outcomes",nid+":"+outcome)
