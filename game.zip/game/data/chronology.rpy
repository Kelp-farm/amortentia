# Project AU chronology, not dates of source publication or research.
init -49 python:
    HOGWARTS_ENTRY_YEAR = 2026
    SCHOOL_YEARS = {year: {"start": "%d-09-01" % (2025 + year),
                          "end_year": 2026 + year,
                          "luna_year": max(0, year - 1),
                          "ginny_year": max(0, year - 1)} for year in range(1, 8)}
    PROJECT_DATES = {"harry_birth": "2015-07-31", "potters_death": "2016-10-31",
                     "yule_ball": "2029-12-25", "voldemort_return_year": 2030,
                     "final_war_years": (2032, 2033), "luna_first_appearance_year": 2}
