# Immutable configuration: never mutate these mappings during a playthrough.
init -50 python:
    SCHEMA_VERSION = 8
    HEROINE_IDS = ("ginny", "hermione", "luna", "carina")
    POV_NAMES = {"harry": "Harry Potter", "ginny": "Ginny Weasley",
                 "hermione": "Hermione Granger", "luna": "Luna Lovegood",
                 "carina": "Carina Malfoy"}
    ROUTE_NAMES = {"ginny": "Ginny Route", "hermione": "Hermione Route",
                   "luna": "Luna Route", "carina": "Carina Route",
                   "no_romance": "No Romance Route"}
    AXIS_LABELS = {
        "harry_trust": ("suspicion", "trust"),
        "harry_reliance": ("solitary decisions", "cooperation"),
        "harry_mercy": ("retribution", "mercy"),
        "harry_autonomy": ("protective control", "respect for autonomy"),
        "harry_risk": ("caution", "risk-taking"),
        "harry_authority": ("institutional obedience", "resistance to authority"),
    }
    SPECIAL_DEFAULTS = {
        "ginny_independence": 0, "ginny_hogwarts_resistance": 0,
        "friendship_stability": 0,
        "luna_social_confidence": 0, "luna_hogwarts_resistance": 0,
        "luna_captivity_state": "free", "luna_ravenclaw_insight": 0,
        "carina_ideology": 0, "carina_family_loyalty": 0,
        "carina_death_eater_access": "none",
    }
    SPECIAL_ENUMS = {
        "luna_captivity_state": ("free", "targeted", "captured", "rescued"),
        "carina_death_eater_access": ("none", "indirect", "insider", "exposed"),
    }
    WORLD_DEFAULTS = {
        "dobby_status": "bound", "dobby_trust": 0,
        "sirius_status": "alive", "lucius_status": "free",
        "ministry_truth": "denial", "death_eaters_exposed": False,
        "dumbledore_status": "active", "snape_cover": "intact",
        "hogwarts_control": "snape", "da_strength": 0, "order_strength": 0,
        "stone_status": "not_started", "quirrell_status": "unknown",
    }
    WORLD_ENUMS = {
        "dobby_status": ("bound", "free_harry", "free_carina", "dead"),
        "sirius_status": ("alive", "wounded", "dead"),
        "lucius_status": ("free", "arrested", "disgraced", "dead"),
        "ministry_truth": ("unaware", "denial", "wavering", "confirmed"),
        "dumbledore_status": ("active", "dying", "dead_tower", "dead_later"),
        "snape_cover": ("intact", "suspected", "blown"),
        "hogwarts_control": ("dumbledore", "snape", "carrows", "contested"),
        "stone_status": ("not_started", "protected", "destroyed"),
        "quirrell_status": ("unknown", "active", "dead"),
    }
    WORLD_BOUNDS = {"dobby_trust": (-100, 100), "da_strength": (0, 100),
                    "order_strength": (0, 100)}
