# One temporary relationship, not a fifth principal heroine or ending engine.
init -41 python:
    WORLD_DEFAULTS.update({"y5_cho_relationship":"none"})
    WORLD_ENUMS.update({"y5_cho_relationship":("none","interested","declined","dating","strained","ended")})

init -15 python:
    _y5_choice("Y5_CHO_INTEREST",3,2,[
        ("friends","다음 모임에서 보자. 마리에타가 기다리겠다.",[]),
        ("pursue","연습이 끝나도 너랑 조금 더 이야기하고 싶어.",[])])
    _y5_choice("Y5_CHO_AUTUMN",3,1,[
        ("listen","응. 어떤 얘기였는데?",[]),
        ("honest","미안해. 아직 그날 얘기는 좀 힘들어.",[])])
    _y5_choice("Y5_CHO_KISS",3,2,[
        ("kiss","초의 손을 잡고 가까이 다가간다.",[]),
        ("friends","미안해. 나는 친구로 지내는 게 좋겠어.",[])])
    _y5_choice("Y5_CHO_DATE",4,1,[
        ("explain","인터뷰 약속이야. 미리 말했어야 했는데.",[]),
        ("awkward","헤르미온느는 그냥 친구야. 너도 같이 갈래?",[])])
    _y5_choice("Y5_CHO_RECONNECT",4,1,[
        ("apologize","그날은 미안했어. 네 말을 제대로 못 들었어.",[]),
        ("try","다음에는 좀 덜 시끄러운 데로 가자.",[])])
    _y5_choice("Y5_CHO_BREAKUP",4,2,[
        ("respect","네가 걱정하는 건 알겠어. 그래도 나까지 괜찮다고 할 수는 없어.",[]),
        ("hurt","우리까지 위험해졌어. 네 친구라는 이유로 넘어갈 수는 없잖아.",[])])
    _y5_scene(3,21,"연습이 끝난 뒤에도","2030-10-12","필요의 방","cho marietta","requirement",["CHO_INTEREST"],music="warm")
    _y5_scene(3,23,"같이 돌아가는 길","2030-11-15","호그와트 회랑","cho","corridor",["CHO_AUTUMN"],"cho_interested",music="anticipation")
    _y5_scene(3,22,"겨우살이 아래","2030-12-17","필요의 방","cho","requirement",["CHO_KISS"],"cho_interested",music="anticipation")
    _y5_scene(4,21,"마담 퍼디풋의 찻집","2031-02-14","호그스미드의 찻집","cho","puddifoot",["CHO_DATE"],"cho_active",music="village")
    _y5_scene(4,22,"다 읽은 기사","2031-02-23","호그와트 회랑","cho","corridor",["CHO_RECONNECT"],"cho_article",music="warm")
    _y5_scene(4,23,"끝내 나누지 못한 말","2031-04-03","호그와트 안뜰","cho hermione","courtyard",["CHO_BREAKUP"],"cho_betrayal",music="separation")
    for _sid,_offset in {"Y5-C3-S21":1.5,"Y5-C3-S23":6.5,"Y5-C3-S22":7,
            "Y5-C4-S21":0.5,"Y5-C4-S22":1.5,"Y5-C4-S23":5.5}.items():
        Y5_SCENES[_sid]["offset"]=_offset
    Y5_CHO_ROMANTIC_SCENES={"Y5-C3-S23","Y5-C3-S22","Y5-C4-S21","Y5-C4-S22","Y5-C4-S23"}

init -8 python:
    Y5_REVIEW_PRESETS.update({"cho":"본편 · 초와 가까워진 이력", "cho_guarded":"본편 · 초와 말이 엇갈린 이력"})

init 0 python:
    Y6_SCENES["Y6-C1-S04"]["participants"].append("cho")
    for key,title,sid in (("cho_kiss","겨우살이 아래의 대답","Y5-C3-S22"),
            ("cho_date","두 잔의 차","Y5-C4-S21")):
        M21_CGS["Y5:"+key]=dict(year=5,asset=key,title=title,scene=sid)

init -6 python:
    Y6_REVIEW_PRESETS["cho"]="본편 · 초와 헤어진 뒤"
    Y7_REVIEW_PRESETS["cho"]="본편 · 초와 헤어진 이력"

init 4 python:
    for _sid,_key in (("Y6-C1-S04","main6_cho"),("Y7-C7-S01","main7_cho")):
        if _key not in M33_SCENE_VARIANTS[_sid]:
            M33_SCENE_VARIANTS[_sid].append(_key)
