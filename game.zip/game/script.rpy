# Stable entry point; keep core systems outside scenario files.
label start:
    jump y1_start

# Keep the M0 labels/from names intact for existing saves and regression tests.
label m0_demo_start:
    $ vn = fresh_state()
    $ set_story_flag("m0_demo")
    call m0_decisions from start_m0_decisions
    call m0_consequences from start_m0_consequences
    "M0 complete. This was a technical demonstration, not a final scenario."
    return
