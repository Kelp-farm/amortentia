# Deliberately outside year1: fictional tests, NOT canon or a Year 1 vertical slice.
label m0_decisions:
    scene bg demo_room
    call vn_chapter("M0-C1") from m0_first_title
    show harry neutral at placeholder_left
    "TECHNICAL DEMO: these scenes use hypothetical states, independent of canon chronology."
    harry "A small decision here will change what becomes possible in the next test scene."
    show luna neutral at placeholder_right
    call vn_choose("M0_C1_LUNA") from m0_luna_choice
    luna "How you treat my ideas matters, whether or not there is any romance."
    hide luna
    show carina neutral at placeholder_right
    call vn_choose("M0_C1_CARINA") from m0_carina_choice
    carina "Trust between us does not decide what I believe, or where my family loyalties lie."
    hide carina
    call vn_choose("M0_C1_DOBBY") from m0_dobby_choice
    "The early decision is now stored. You can save here, then inspect it in the next chapter."
    call vn_end_chapter("Three decisions have been recorded. Their effects belong to this playthrough.") from m0_first_end
    return

label m0_consequences:
    scene bg demo_later
    call vn_chapter("M0-C2") from m0_second_title
    call vn_pov("luna", "Interlude: a different viewpoint") from m0_luna_pov
    show luna neutral at placeholder_right
    luna "From my viewpoint, I can describe what I observed. Harry's hidden thoughts are not mine to read."
    if vn["relationships"]["luna"]["route_key"].get("accepted_without_mockery", False):
        luna "Earlier, someone made room for my decision. I remember that."
    else:
        luna "Earlier, someone decided on my behalf. I remember that too."
    hide luna
    call vn_return_pov("Return to Harry") from m0_harry_return
    show harry neutral at placeholder_left
    if vn["world"]["dobby_status"] == "free_harry":
        harry "Dobby can carry the message. But the earlier intervention has made our covert contact suspect."
    elif vn["world"]["dobby_status"] == "free_carina":
        harry "Dobby can help independently. Carina's exposed access means the inside channel is gone."
    elif vn["world"]["dobby_status"] == "dead":
        harry "Dobby cannot help. We must seek another messenger."
    else:
        harry "Dobby cannot leave. The covert channel remains, but we must find another messenger."
    "The same later scene has read the earlier World State. No option was labelled globally optimal."
    call vn_choose("M0_C2_INTENT") from m0_intent_choice
    call vn_route_demo from m0_route_evaluation
    "Route framework test complete. No Romance is a full outcome; demo thresholds are temporary."
    call vn_end_chapter("The delayed consequence and route framework have been demonstrated.") from m0_second_end
    call screen personality_result
    if config.developer:
        "Developer checkpoint: use Debug or F3 to inspect all state. Close the viewer, then continue."
    return
