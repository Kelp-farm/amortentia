label y7_chapter1(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C1")
    if start_at <= 0 and y7_scene_available("Y7-C1-S01"):
        call y7_c1_s01
    if start_at <= 1 and y7_scene_available("Y7-C1-S02"):
        call y7_c1_s02
    if start_at <= 2 and y7_scene_available("Y7-C1-S03"):
        call y7_c1_s03
    if start_at <= 3 and y7_scene_available("Y7-C1-S04"):
        call y7_c1_s04
    if start_at <= 4 and y7_scene_available("Y7-C1-S05"):
        call y7_c1_s05
    if start_at <= 10 and y7_scene_available("Y7-C1-S11"):
        call y7_c1_s11
    if start_at <= 11 and y7_scene_available("Y7-C1-S12"):
        call y7_c1_s12
    if start_at <= 12 and y7_scene_available("Y7-C1-S13"):
        call y7_c1_s13
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(1))
    return

label y7_chapter2(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C2")
    if start_at <= 0 and y7_scene_available("Y7-C2-S01"):
        call y7_c2_s01
    if start_at <= 1 and y7_scene_available("Y7-C2-S02"):
        call y7_c2_s02
    if start_at <= 2 and y7_scene_available("Y7-C2-S03"):
        call y7_c2_s03
    if start_at <= 3 and y7_scene_available("Y7-C2-S04"):
        call y7_c2_s04
    if start_at <= 4 and y7_scene_available("Y7-C2-S05"):
        call y7_c2_s05
    if start_at <= 10 and y7_scene_available("Y7-C2-S11"):
        call y7_c2_s11
    if start_at <= 11 and y7_scene_available("Y7-C2-S12"):
        call y7_c2_s12
    if start_at <= 12 and y7_scene_available("Y7-C2-S13"):
        call y7_c2_s13
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(2))
    return

label y7_chapter3(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C3")
    if start_at <= 0 and y7_scene_available("Y7-C3-S01"):
        call y7_c3_s01
    if start_at <= 0.5 and y7_scene_available("Y7-C3-S07"):
        call y7_c3_s07
    if start_at <= 1 and y7_scene_available("Y7-C3-S02"):
        call y7_c3_s02
    if start_at <= 2 and y7_scene_available("Y7-C3-S03"):
        call y7_c3_s03
    if start_at <= 3 and y7_scene_available("Y7-C3-S04"):
        call y7_c3_s04
    if start_at <= 4 and y7_scene_available("Y7-C3-S05"):
        call y7_c3_s05
    if start_at <= 5 and y7_scene_available("Y7-C3-S06"):
        call y7_c3_s06
    if start_at <= 10 and y7_scene_available("Y7-C3-S11"):
        call y7_c3_s11
    if start_at <= 11 and y7_scene_available("Y7-C3-S12"):
        call y7_c3_s12
    if start_at <= 12 and y7_scene_available("Y7-C3-S13"):
        call y7_c3_s13
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(3))
    return

label y7_chapter4(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C4")
    if start_at <= 0 and y7_scene_available("Y7-C4-S01"):
        call y7_c4_s01
    if start_at <= 1 and y7_scene_available("Y7-C4-S02"):
        call y7_c4_s02
    if start_at <= 2 and y7_scene_available("Y7-C4-S03"):
        call y7_c4_s03
    if start_at <= 3 and y7_scene_available("Y7-C4-S04"):
        call y7_c4_s04
    if start_at <= 4 and y7_scene_available("Y7-C4-S05"):
        call y7_c4_s05
    if start_at <= 10 and y7_scene_available("Y7-C4-S11"):
        call y7_c4_s11
    if start_at <= 11 and y7_scene_available("Y7-C4-S12"):
        call y7_c4_s12
    if start_at <= 12 and y7_scene_available("Y7-C4-S13"):
        call y7_c4_s13
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(4))
    return

label y7_chapter5(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C5")
    if start_at <= 0 and y7_scene_available("Y7-C5-S01"):
        call y7_c5_s01
    if start_at <= 1 and y7_scene_available("Y7-C5-S02"):
        call y7_c5_s02
    if start_at <= 2 and y7_scene_available("Y7-C5-S03"):
        call y7_c5_s03
    if start_at <= 3 and y7_scene_available("Y7-C5-S04"):
        call y7_c5_s04
    if start_at <= 10 and y7_scene_available("Y7-C5-S11"):
        call y7_c5_s11
    if start_at <= 11 and y7_scene_available("Y7-C5-S12"):
        call y7_c5_s12
    if start_at <= 12 and y7_scene_available("Y7-C5-S13"):
        call y7_c5_s13
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(5))
    return

label y7_chapter6(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C6")
    if start_at <= 0 and y7_scene_available("Y7-C6-S01"):
        call y7_c6_s01
    if start_at <= 1 and y7_scene_available("Y7-C6-S02"):
        call y7_c6_s02
    if start_at <= 2 and y7_scene_available("Y7-C6-S03"):
        call y7_c6_s03
    if start_at <= 3 and y7_scene_available("Y7-C6-S04"):
        call y7_c6_s04
    if start_at <= 4 and y7_scene_available("Y7-C6-S05"):
        call y7_c6_s05
    if start_at <= 10 and y7_scene_available("Y7-C6-S11"):
        call y7_c6_s11
    if start_at <= 11 and y7_scene_available("Y7-C6-S12"):
        call y7_c6_s12
    if start_at <= 12 and y7_scene_available("Y7-C6-S13"):
        call y7_c6_s13
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(6))
    return

label y7_chapter7(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C7")
    if start_at <= 0 and y7_scene_available("Y7-C7-S01"):
        call y7_c7_s01
    if start_at <= 1 and y7_scene_available("Y7-C7-S02"):
        call y7_c7_s02
    if start_at <= 2 and y7_scene_available("Y7-C7-S03"):
        call y7_c7_s03
    if start_at <= 3 and y7_scene_available("Y7-C7-S04"):
        call y7_c7_s04
    if start_at <= 4 and y7_scene_available("Y7-C7-S05"):
        call y7_c7_s05
    if start_at <= 5 and y7_scene_available("Y7-C7-S06"):
        call y7_c7_s06
    if start_at <= 6 and y7_scene_available("Y7-C7-S07"):
        call y7_c7_s07
    if start_at <= 10 and y7_scene_available("Y7-C7-S11"):
        call y7_c7_s11
    if start_at <= 11 and y7_scene_available("Y7-C7-S12"):
        call y7_c7_s12
    if start_at <= 12 and y7_scene_available("Y7-C7-S13"):
        call y7_c7_s13
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(7))
    return

label y7_chapter8(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C8")
    if start_at <= 0 and y7_scene_available("Y7-C8-S01"):
        call y7_c8_s01
    if start_at <= 1 and y7_scene_available("Y7-C8-S02"):
        call y7_c8_s02
    if start_at <= 2 and y7_scene_available("Y7-C8-S03"):
        call y7_c8_s03
    if start_at <= 3 and y7_scene_available("Y7-C8-S04"):
        call y7_c8_s04
    if start_at <= 4 and y7_scene_available("Y7-C8-S05"):
        call y7_c8_s05
    if start_at <= 5 and y7_scene_available("Y7-C8-S06"):
        call y7_c8_s06
    if start_at <= 10 and y7_scene_available("Y7-C8-S11"):
        call y7_c8_s11
    if start_at <= 11 and y7_scene_available("Y7-C8-S12"):
        call y7_c8_s12
    if start_at <= 12 and y7_scene_available("Y7-C8-S13"):
        call y7_c8_s13
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(8))
    return

label y7_chapter9(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C9")
    if start_at <= 0 and y7_scene_available("Y7-C9-S01"):
        call y7_c9_s01
    if start_at <= 1 and y7_scene_available("Y7-C9-S02"):
        call y7_c9_s02
    if start_at <= 2 and y7_scene_available("Y7-C9-S03"):
        call y7_c9_s03
    if start_at <= 3 and y7_scene_available("Y7-C9-S04"):
        call y7_c9_s04
    if start_at <= 3.1 and y7_scene_available("Y7-C9-S20"):
        call y7_c9_s20 from m732_run_y7_c9_s20
    if start_at <= 3.2 and y7_scene_available("Y7-C9-S21"):
        call y7_c9_s21 from m732_run_y7_c9_s21
    if start_at <= 3.25 and y7_scene_available("Y7-C9-S23"):
        call y7_c9_s23 from m732_run_y7_c9_s23
    if start_at <= 3.27 and y7_scene_available("Y7-C9-S24"):
        call y7_c9_s24 from m732_run_y7_c9_s24
    if start_at <= 3.3 and y7_scene_available("Y7-C9-S22"):
        call y7_c9_s22 from m732_run_y7_c9_s22
    if start_at <= 4 and y7_scene_available("Y7-C9-S05"):
        call y7_c9_s05
    if start_at <= 5 and y7_scene_available("Y7-C9-S06"):
        call y7_c9_s06
    if start_at <= 10 and y7_scene_available("Y7-C9-S11"):
        call y7_c9_s11
    if start_at <= 11 and y7_scene_available("Y7-C9-S12"):
        call y7_c9_s12
    if start_at <= 12 and y7_scene_available("Y7-C9-S13"):
        call y7_c9_s13
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(9))
    return

label y7_chapter10(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C10")
    if start_at <= 0 and y7_scene_available("Y7-C10-S01"):
        call y7_c10_s01
    if start_at <= 1 and y7_scene_available("Y7-C10-S02"):
        call y7_c10_s02
    if start_at <= 2 and y7_scene_available("Y7-C10-S03"):
        call y7_c10_s03
    if start_at <= 3 and y7_scene_available("Y7-C10-S04"):
        call y7_c10_s04
    if start_at <= 4 and y7_scene_available("Y7-C10-S05"):
        call y7_c10_s05
    if start_at <= 10 and y7_scene_available("Y7-C10-S11"):
        call y7_c10_s11
    if start_at <= 11 and y7_scene_available("Y7-C10-S12"):
        call y7_c10_s12
    if start_at <= 12 and y7_scene_available("Y7-C10-S13"):
        call y7_c10_s13
    if start_at <= 13 and y7_scene_available("Y7-C10-S14"):
        call y7_c10_s14
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(10))
    return

label y7_chapter11(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C11")
    if start_at <= 0 and y7_scene_available("Y7-C11-S01"):
        call y7_c11_s01
    if start_at <= 1 and y7_scene_available("Y7-C11-S02"):
        call y7_c11_s02
    if start_at <= 2 and y7_scene_available("Y7-C11-S03"):
        call y7_c11_s03
    if start_at <= 3 and y7_scene_available("Y7-C11-S04"):
        call y7_c11_s04
    if start_at <= 4 and y7_scene_available("Y7-C11-S05"):
        call y7_c11_s05
    if start_at <= 4.5 and y7_scene_available("Y7-C11-S20"):
        call y7_c11_s20 from m732_run_y7_c11_s20
    if start_at <= 5 and y7_scene_available("Y7-C11-S06"):
        call y7_c11_s06
    if start_at <= 10 and y7_scene_available("Y7-C11-S11"):
        call y7_c11_s11
    if start_at <= 11 and y7_scene_available("Y7-C11-S12"):
        call y7_c11_s12
    if start_at <= 12 and y7_scene_available("Y7-C11-S13"):
        call y7_c11_s13
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(11))
    return

label y7_chapter12(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y7-C12")
    if start_at <= 0 and y7_scene_available("Y7-C12-S01"):
        call y7_c12_s01
    if start_at <= 1 and y7_scene_available("Y7-C12-S02"):
        call y7_c12_s02
    if start_at <= 2 and y7_scene_available("Y7-C12-S03"):
        call y7_c12_s03
    if start_at <= 3 and y7_scene_available("Y7-C12-S04"):
        call y7_c12_s04
    if start_at <= 5 and y7_scene_available("Y7-C12-S06"):
        call y7_c12_s06
    if start_at <= 10 and y7_scene_available("Y7-C12-S11"):
        call y7_c12_s11
    hide screen y7_event_cg
    hide screen y7_stage
    call vn_end_chapter(y7_chapter_title(12))
    return

label y7_start:
    if m6_route_incompatible(vn):
        call screen m6_commitment_changed
        return
    $ y7_begin()
    $ y7_review_chapter, y7_review_offset = 1, 0
    jump y7_continue

label y7_continue:
    if y7_review_chapter <= 1:
        call y7_chapter1(y7_review_offset if y7_review_chapter == 1 else 0)
    if y7_review_chapter <= 2:
        call y7_chapter2(y7_review_offset if y7_review_chapter == 2 else 0)
    if y7_review_chapter <= 3:
        call y7_chapter3(y7_review_offset if y7_review_chapter == 3 else 0)
    if y7_review_chapter <= 4:
        call y7_chapter4(y7_review_offset if y7_review_chapter == 4 else 0)
    if y7_review_chapter <= 5:
        call y7_chapter5(y7_review_offset if y7_review_chapter == 5 else 0)
    if y7_review_chapter <= 6:
        call y7_chapter6(y7_review_offset if y7_review_chapter == 6 else 0)
    if y7_review_chapter <= 7:
        call y7_chapter7(y7_review_offset if y7_review_chapter == 7 else 0)
    if y7_review_chapter <= 8:
        call y7_chapter8(y7_review_offset if y7_review_chapter == 8 else 0)
    if y7_review_chapter <= 9:
        call y7_chapter9(y7_review_offset if y7_review_chapter == 9 else 0)
    if y7_review_chapter <= 10:
        call y7_chapter10(y7_review_offset if y7_review_chapter == 10 else 0)
    if y7_review_chapter <= 11 and (y7_hidden() or chose("Y7_FUTURE","return")):
        call y7_chapter11(y7_review_offset if y7_review_chapter == 11 else 0)
    if y7_review_chapter <= 12:
        call y7_chapter12(y7_review_offset if y7_review_chapter == 12 else 0)
    $ m21_annual(7)
    $ y7_publish_ending()
    call screen y7_ending
    return
