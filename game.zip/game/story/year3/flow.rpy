label y3_chapter1(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y3-C1") from y3_begin_c1
    if start_at <= 0 and y3_scene_available("Y3-C1-S01"):
        call y3_c1_s01 from y3_run_y3_c1_s01
    if start_at <= 1 and y3_scene_available("Y3-C1-S02"):
        call y3_c1_s02 from y3_run_y3_c1_s02
    if start_at <= 2 and y3_scene_available("Y3-C1-S03"):
        call y3_c1_s03 from y3_run_y3_c1_s03
    if start_at <= 3 and y3_scene_available("Y3-C1-S04"):
        call y3_c1_s04 from y3_run_y3_c1_s04
    if start_at <= 4 and y3_scene_available("Y3-C1-S05"):
        call y3_c1_s05 from y3_run_y3_c1_s05
    if start_at <= 5 and y3_scene_available("Y3-C1-S06"):
        call y3_c1_s06 from y3_run_y3_c1_s06
    if start_at <= 6 and y3_scene_available("Y3-C1-S07"):
        call y3_c1_s07 from y3_run_y3_c1_s07
    hide screen y3_event_cg
    hide screen y3_stage
    call vn_end_chapter(Y3_TITLES[0]) from y3_end_c1
    return

label y3_chapter2(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y3-C2") from y3_begin_c2
    if start_at <= 0 and y3_scene_available("Y3-C2-S02"):
        call y3_c2_s02 from y3_run_y3_c2_s02
    if start_at <= 1 and y3_scene_available("Y3-C2-S09"):
        call y3_c2_s09 from y3_run_y3_c2_s09
    if start_at <= 2 and y3_scene_available("Y3-C2-S10"):
        call y3_c2_s10 from y3_run_y3_c2_s10
    if start_at <= 3 and y3_scene_available("Y3-C2-S08"):
        call y3_c2_s08 from y3_run_y3_c2_s08
    hide screen y3_event_cg
    hide screen y3_stage
    call vn_end_chapter(Y3_TITLES[1]) from y3_end_c2
    return

label y3_chapter3(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y3-C3") from y3_begin_c3
    if start_at <= 0 and y3_scene_available("Y3-C3-S05"):
        call y3_c3_s05 from y3_run_y3_c3_s05
    if start_at <= 1 and y3_scene_available("Y3-C3-S06"):
        call y3_c3_s06 from y3_run_y3_c3_s06
    if start_at <= 2 and y3_scene_available("Y3-C3-S01"):
        call y3_c3_s01 from y3_run_y3_c3_s01
    if start_at <= 3 and y3_scene_available("Y3-C3-S02"):
        call y3_c3_s02 from y3_run_y3_c3_s02
    if start_at <= 4 and y3_scene_available("Y3-C2-S01"):
        call y3_c2_s01 from y3_run_y3_c2_s01
    if start_at <= 5 and y3_scene_available("Y3-C2-S03"):
        call y3_c2_s03 from y3_run_y3_c2_s03
    if start_at <= 6 and y3_scene_available("Y3-C2-S04"):
        call y3_c2_s04 from y3_run_y3_c2_s04
    if start_at <= 7 and y3_scene_available("Y3-C2-S05"):
        call y3_c2_s05 from y3_run_y3_c2_s05
    if start_at <= 8 and y3_scene_available("Y3-C2-S06"):
        call y3_c2_s06 from y3_run_y3_c2_s06
    if start_at <= 9 and y3_scene_available("Y3-C2-S07"):
        call y3_c2_s07 from y3_run_y3_c2_s07
    if start_at <= 10 and y3_scene_available("Y3-C3-S03"):
        call y3_c3_s03 from y3_run_y3_c3_s03
    if start_at <= 11 and y3_scene_available("Y3-C3-S04"):
        call y3_c3_s04 from y3_run_y3_c3_s04
    if start_at <= 12 and y3_scene_available("Y3-C6-S10"):
        call y3_c6_s10 from y3_run_y3_c6_s10
    if start_at <= 13 and y3_scene_available("Y3-C6-S11"):
        call y3_c6_s11 from y3_run_y3_c6_s11
    hide screen y3_event_cg
    hide screen y3_stage
    call vn_end_chapter(Y3_TITLES[2]) from y3_end_c3
    return

label y3_chapter4(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y3-C4") from y3_begin_c4
    if start_at <= 0 and y3_scene_available("Y3-C4-S08"):
        call y3_c4_s08 from y3_run_y3_c4_s08
    if start_at <= 1 and y3_scene_available("Y3-C4-S01"):
        call y3_c4_s01 from y3_run_y3_c4_s01
    if start_at <= 2 and y3_scene_available("Y3-C4-S02"):
        call y3_c4_s02 from y3_run_y3_c4_s02
    if start_at <= 3 and y3_scene_available("Y3-C4-S03"):
        call y3_c4_s03 from y3_run_y3_c4_s03
    if start_at <= 4 and y3_scene_available("Y3-C4-S04"):
        call y3_c4_s04 from y3_run_y3_c4_s04
    if start_at <= 5 and y3_scene_available("Y3-C4-S07"):
        call y3_c4_s07 from y3_run_y3_c4_s07
    if start_at <= 6 and y3_scene_available("Y3-C4-S06"):
        call y3_c4_s06 from y3_run_y3_c4_s06
    if start_at <= 7 and y3_scene_available("Y3-C4-S09"):
        call y3_c4_s09 from y3_run_y3_c4_s09
    hide screen y3_event_cg
    hide screen y3_stage
    call vn_end_chapter(Y3_TITLES[3]) from y3_end_c4
    return

label y3_chapter5(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y3-C5") from y3_begin_c5
    if start_at <= 0 and y3_scene_available("Y3-C5-S01"):
        call y3_c5_s01 from y3_run_y3_c5_s01
    if start_at <= 1 and y3_scene_available("Y3-C5-S02"):
        call y3_c5_s02 from y3_run_y3_c5_s02
    if start_at <= 2 and y3_scene_available("Y3-C5-S03"):
        call y3_c5_s03 from y3_run_y3_c5_s03
    if start_at <= 3 and y3_scene_available("Y3-C5-S04"):
        call y3_c5_s04 from y3_run_y3_c5_s04
    hide screen y3_event_cg
    hide screen y3_stage
    call vn_end_chapter(Y3_TITLES[4]) from y3_end_c5
    return

label y3_chapter6(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y3-C6") from y3_begin_c6
    if start_at <= 0 and y3_scene_available("Y3-C6-S01"):
        call y3_c6_s01 from y3_run_y3_c6_s01
    if start_at <= 1 and y3_scene_available("Y3-C6-S02"):
        call y3_c6_s02 from y3_run_y3_c6_s02
    if start_at <= 2 and y3_scene_available("Y3-C6-S03"):
        call y3_c6_s03 from y3_run_y3_c6_s03
    if start_at <= 3 and y3_scene_available("Y3-C6-S04"):
        call y3_c6_s04 from y3_run_y3_c6_s04
    if start_at <= 4 and y3_scene_available("Y3-C6-S05"):
        call y3_c6_s05 from y3_run_y3_c6_s05
    if start_at <= 5 and y3_scene_available("Y3-C4-S05"):
        call y3_c4_s05 from y3_run_y3_c4_s05
    if start_at <= 6 and y3_scene_available("Y3-C6-S08"):
        call y3_c6_s08 from y3_run_y3_c6_s08
    if start_at <= 7 and y3_scene_available("Y3-C6-S09"):
        call y3_c6_s09 from y3_run_y3_c6_s09
    if start_at <= 8 and y3_scene_available("Y3-C6-S06"):
        call y3_c6_s06 from y3_run_y3_c6_s06
    if start_at <= 9 and y3_scene_available("Y3-C6-S07"):
        call y3_c6_s07 from y3_run_y3_c6_s07
    hide screen y3_event_cg
    hide screen y3_stage
    call vn_end_chapter(Y3_TITLES[5]) from y3_end_c6
    return

label y3_start:
    $ y3_begin()
    $ y3_review_chapter, y3_review_offset = 1, 0
    jump y3_continue

label y3_continue:
    hide screen y1_stage
    hide screen y2_stage
    hide screen y2_event_cg
    if y3_review_chapter <= 1:
        call y3_chapter1(y3_review_offset if y3_review_chapter == 1 else 0) from y3_continue_c1
    if y3_review_chapter <= 2:
        call y3_chapter2(y3_review_offset if y3_review_chapter == 2 else 0) from y3_continue_c2
    if y3_review_chapter <= 3:
        call y3_chapter3(y3_review_offset if y3_review_chapter == 3 else 0) from y3_continue_c3
    if y3_review_chapter <= 4:
        call y3_chapter4(y3_review_offset if y3_review_chapter == 4 else 0) from y3_continue_c4
    if y3_review_chapter <= 5:
        call y3_chapter5(y3_review_offset if y3_review_chapter == 5 else 0) from y3_continue_c5
    if y3_review_chapter <= 6:
        call y3_chapter6(y3_review_offset if y3_review_chapter == 6 else 0) from y3_continue_c6
    $ m21_annual(3)
    call screen y3_ending
    if _return == "year4":
        jump y4_start
    return

label review_y3_c1_s01:
    $ y3_prepare_review("Y3-C1-S01",y3_preview_preset)
    jump y3_continue

label review_y3_c1_s02:
    $ y3_prepare_review("Y3-C1-S02",y3_preview_preset)
    jump y3_continue

label review_y3_c1_s03:
    $ y3_prepare_review("Y3-C1-S03",y3_preview_preset)
    jump y3_continue

label review_y3_c1_s04:
    $ y3_prepare_review("Y3-C1-S04",y3_preview_preset)
    jump y3_continue

label review_y3_c1_s05:
    $ y3_prepare_review("Y3-C1-S05",y3_preview_preset)
    jump y3_continue

label review_y3_c2_s01:
    $ y3_prepare_review("Y3-C2-S01",y3_preview_preset)
    jump y3_continue

label review_y3_c2_s02:
    $ y3_prepare_review("Y3-C2-S02",y3_preview_preset)
    jump y3_continue

label review_y3_c2_s03:
    $ y3_prepare_review("Y3-C2-S03",y3_preview_preset)
    jump y3_continue

label review_y3_c2_s04:
    $ y3_prepare_review("Y3-C2-S04",y3_preview_preset)
    jump y3_continue

label review_y3_c2_s05:
    $ y3_prepare_review("Y3-C2-S05",y3_preview_preset)
    jump y3_continue

label review_y3_c2_s06:
    $ y3_prepare_review("Y3-C2-S06",y3_preview_preset)
    jump y3_continue

label review_y3_c2_s07:
    $ y3_prepare_review("Y3-C2-S07",y3_preview_preset)
    jump y3_continue

label review_y3_c2_s08:
    $ y3_prepare_review("Y3-C2-S08",y3_preview_preset)
    jump y3_continue

label review_y3_c3_s01:
    $ y3_prepare_review("Y3-C3-S01",y3_preview_preset)
    jump y3_continue

label review_y3_c3_s02:
    $ y3_prepare_review("Y3-C3-S02",y3_preview_preset)
    jump y3_continue

label review_y3_c3_s03:
    $ y3_prepare_review("Y3-C3-S03",y3_preview_preset)
    jump y3_continue

label review_y3_c3_s04:
    $ y3_prepare_review("Y3-C3-S04",y3_preview_preset)
    jump y3_continue

label review_y3_c4_s01:
    $ y3_prepare_review("Y3-C4-S01",y3_preview_preset)
    jump y3_continue

label review_y3_c4_s02:
    $ y3_prepare_review("Y3-C4-S02",y3_preview_preset)
    jump y3_continue

label review_y3_c4_s03:
    $ y3_prepare_review("Y3-C4-S03",y3_preview_preset)
    jump y3_continue

label review_y3_c4_s04:
    $ y3_prepare_review("Y3-C4-S04",y3_preview_preset)
    jump y3_continue

label review_y3_c4_s05:
    $ y3_prepare_review("Y3-C4-S05",y3_preview_preset)
    jump y3_continue

label review_y3_c4_s06:
    $ y3_prepare_review("Y3-C4-S06",y3_preview_preset)
    jump y3_continue

label review_y3_c5_s01:
    $ y3_prepare_review("Y3-C5-S01",y3_preview_preset)
    jump y3_continue

label review_y3_c5_s02:
    $ y3_prepare_review("Y3-C5-S02",y3_preview_preset)
    jump y3_continue

label review_y3_c5_s03:
    $ y3_prepare_review("Y3-C5-S03",y3_preview_preset)
    jump y3_continue

label review_y3_c5_s04:
    $ y3_prepare_review("Y3-C5-S04",y3_preview_preset)
    jump y3_continue

label review_y3_c6_s01:
    $ y3_prepare_review("Y3-C6-S01",y3_preview_preset)
    jump y3_continue

label review_y3_c6_s02:
    $ y3_prepare_review("Y3-C6-S02",y3_preview_preset)
    jump y3_continue

label review_y3_c6_s03:
    $ y3_prepare_review("Y3-C6-S03",y3_preview_preset)
    jump y3_continue

label review_y3_c6_s04:
    $ y3_prepare_review("Y3-C6-S04",y3_preview_preset)
    jump y3_continue

label review_y3_c6_s05:
    $ y3_prepare_review("Y3-C6-S05",y3_preview_preset)
    jump y3_continue

label review_y3_c6_s06:
    $ y3_prepare_review("Y3-C6-S06",y3_preview_preset)
    jump y3_continue

label review_y3_c6_s07:
    $ y3_prepare_review("Y3-C6-S07",y3_preview_preset)
    jump y3_continue

label review_y3_c6_s08:
    $ y3_prepare_review("Y3-C6-S08", y3_preview_preset)
    jump y3_continue

label review_y3_c6_s09:
    $ y3_prepare_review("Y3-C6-S09", y3_preview_preset)
    jump y3_continue

label review_y3_c2_s09:
    $ y3_prepare_review("Y3-C2-S09",y3_preview_preset)
    jump y3_continue

label review_y3_c2_s10:
    $ y3_prepare_review("Y3-C2-S10",y3_preview_preset)
    jump y3_continue

label review_y3_c3_s05:
    $ y3_prepare_review("Y3-C3-S05",y3_preview_preset)
    jump y3_continue

label review_y3_c3_s06:
    $ y3_prepare_review("Y3-C3-S06",y3_preview_preset)
    jump y3_continue

label review_y3_c1_s06:
    $ y3_prepare_review("Y3-C1-S06",y3_preview_preset)
    jump y3_continue

label review_y3_c1_s07:
    $ y3_prepare_review("Y3-C1-S07",y3_preview_preset)
    jump y3_continue

label review_y3_c4_s07:
    $ y3_prepare_review("Y3-C4-S07",y3_preview_preset)
    jump y3_continue

label review_y3_c6_s10:
    $ y3_prepare_review("Y3-C6-S10",y3_preview_preset)
    jump y3_continue

label review_y3_c6_s11:
    $ y3_prepare_review("Y3-C6-S11",y3_preview_preset)
    jump y3_continue

label review_y3_c4_s08:
    $ y3_prepare_review("Y3-C4-S08",y3_preview_preset)
    jump y3_continue

label review_y3_c4_s09:
    $ y3_prepare_review("Y3-C4-S09",y3_preview_preset)
    jump y3_continue
