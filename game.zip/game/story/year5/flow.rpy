label y5_chapter1(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y5-C1") from y5_begin_c1
    if start_at <= 0 and y5_scene_available("Y5-C1-S01"):
        call y5_c1_s01 from y5r_run_y5_c1_s01
    if start_at <= 1 and y5_scene_available("Y5-C1-S02"):
        call y5_c1_s02 from y5r_run_y5_c1_s02
    if start_at <= 2 and y5_scene_available("Y5-C1-S03"):
        call y5_c1_s03 from y5r_run_y5_c1_s03
    if start_at <= 3 and y5_scene_available("Y5-C1-S04"):
        call y5_c1_s04 from y5r_run_y5_c1_s04
    if start_at <= 4 and y5_scene_available("Y5-C1-S05"):
        call y5_c1_s05 from y5r_run_y5_c1_s05
    if start_at <= 5 and y5_scene_available("Y5-C1-S06"):
        call y5_c1_s06 from y5r_run_y5_c1_s06
    if start_at <= 6 and y5_scene_available("Y5-C1-S07"):
        call y5_c1_s07 from y5r_run_y5_c1_s07
    if start_at <= 10 and y5_scene_available("Y5-C1-S11"):
        call y5_c1_s11 from y5r_run_y5_c1_s11
    if start_at <= 11 and y5_scene_available("Y5-C1-S12"):
        call y5_c1_s12 from y5r_run_y5_c1_s12
    if start_at <= 12 and y5_scene_available("Y5-C1-S13"):
        call y5_c1_s13 from y5r_run_y5_c1_s13
    hide screen y5_event_cg
    hide screen y5_stage
    call vn_end_chapter(Y5_TITLES[0]) from y5_end_c1
    return

label y5_chapter2(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y5-C2") from y5_begin_c2
    if start_at <= 0 and y5_scene_available("Y5-C2-S01"):
        call y5_c2_s01 from y5r_run_y5_c2_s01
    if start_at <= 1 and y5_scene_available("Y5-C2-S02"):
        call y5_c2_s02 from y5r_run_y5_c2_s02
    if start_at <= 2 and y5_scene_available("Y5-C2-S03"):
        call y5_c2_s03 from y5r_run_y5_c2_s03
    if start_at <= 3 and y5_scene_available("Y5-C2-S04"):
        call y5_c2_s04 from y5r_run_y5_c2_s04
    if start_at <= 4 and y5_scene_available("Y5-C2-S05"):
        call y5_c2_s05 from y5r_run_y5_c2_s05
    if start_at <= 5 and y5_scene_available("Y5-C2-S06"):
        call y5_c2_s06 from y5r_run_y5_c2_s06
    if start_at <= 6 and y5_scene_available("Y5-C2-S07"):
        call y5_c2_s07 from y5r_run_y5_c2_s07
    if start_at <= 10 and y5_scene_available("Y5-C2-S11"):
        call y5_c2_s11 from y5r_run_y5_c2_s11
    if start_at <= 11 and y5_scene_available("Y5-C2-S12"):
        call y5_c2_s12 from y5r_run_y5_c2_s12
    if start_at <= 12 and y5_scene_available("Y5-C2-S13"):
        call y5_c2_s13 from y5r_run_y5_c2_s13
    if start_at <= 13 and y5_scene_available("Y5-C2-S14"):
        call y5_c2_s14 from y5r_run_y5_c2_s14
    if start_at <= 14 and y5_scene_available("Y5-C2-S15"):
        call y5_c2_s15 from y5r_run_y5_c2_s15
    if start_at <= 15 and y5_scene_available("Y5-C2-S16"):
        call y5_c2_s16 from y5r_run_y5_c2_s16
    if start_at <= 16 and y5_scene_available("Y5-C2-S17"):
        call y5_c2_s17 from y5r_run_y5_c2_s17
    hide screen y5_event_cg
    hide screen y5_stage
    call vn_end_chapter(Y5_TITLES[1]) from y5_end_c2
    return

label y5_chapter3(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y5-C3") from y5_begin_c3
    if start_at <= 0 and y5_scene_available("Y5-C3-S01"):
        call y5_c3_s01 from y5r_run_y5_c3_s01
    if start_at <= 1 and y5_scene_available("Y5-C3-S02"):
        call y5_c3_s02 from y5r_run_y5_c3_s02
    if start_at <= 1.5 and y5_scene_available("Y5-C3-S21"):
        call y5_c3_s21 from m75_run_y5_c3_s21
    if start_at <= 2 and y5_scene_available("Y5-C3-S03"):
        call y5_c3_s03 from y5r_run_y5_c3_s03
    if start_at <= 3 and y5_scene_available("Y5-C3-S04"):
        call y5_c3_s04 from y5r_run_y5_c3_s04
    if start_at <= 4 and y5_scene_available("Y5-C3-S05"):
        call y5_c3_s05 from y5r_run_y5_c3_s05
    if start_at <= 5 and y5_scene_available("Y5-C3-S06"):
        call y5_c3_s06 from y5r_run_y5_c3_s06
    if start_at <= 6 and y5_scene_available("Y5-C3-S07"):
        call y5_c3_s07 from y5r_run_y5_c3_s07
    if start_at <= 6.5 and y5_scene_available("Y5-C3-S23"):
        call y5_c3_s23 from m75_run_y5_c3_s23
    if start_at <= 7 and y5_scene_available("Y5-C3-S22"):
        call y5_c3_s22 from m75_run_y5_c3_s22
    if start_at <= 8 and y5_scene_available("Y5-C3-S09"):
        call y5_c3_s09 from y5r_run_y5_c3_s09
    if start_at <= 9 and y5_scene_available("Y5-C3-S10"):
        call y5_c3_s10 from y5r_run_y5_c3_s10
    if start_at <= 10 and y5_scene_available("Y5-C3-S11"):
        call y5_c3_s11 from y5r_run_y5_c3_s11
    if start_at <= 11 and y5_scene_available("Y5-C3-S12"):
        call y5_c3_s12 from y5r_run_y5_c3_s12
    if start_at <= 12 and y5_scene_available("Y5-C3-S13"):
        call y5_c3_s13 from y5r_run_y5_c3_s13
    if start_at <= 13 and y5_scene_available("Y5-C3-S14"):
        call y5_c3_s14 from y5r_run_y5_c3_s14
    if start_at <= 14 and y5_scene_available("Y5-C3-S15"):
        call y5_c3_s15 from y5r_run_y5_c3_s15
    if start_at <= 15 and y5_scene_available("Y5-C3-S16"):
        call y5_c3_s16 from y5r_run_y5_c3_s16
    if start_at <= 16 and y5_scene_available("Y5-C3-S17"):
        call y5_c3_s17 from y5r_run_y5_c3_s17
    hide screen y5_event_cg
    hide screen y5_stage
    call vn_end_chapter(Y5_TITLES[2]) from y5_end_c3
    return

label y5_chapter4(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y5-C4") from y5_begin_c4
    if start_at <= 0 and y5_scene_available("Y5-C4-S01"):
        call y5_c4_s01 from y5r_run_y5_c4_s01
    if start_at <= 0.25 and y5_scene_available("Y5-C4-S24"):
        call y5_c4_s24 from m751_run_y5_c4_s24
    if start_at <= 0.5 and y5_scene_available("Y5-C4-S21"):
        call y5_c4_s21 from m75_run_y5_c4_s21
    if start_at <= 1 and y5_scene_available("Y5-C4-S02"):
        call y5_c4_s02 from y5r_run_y5_c4_s02
    if start_at <= 1.5 and y5_scene_available("Y5-C4-S22"):
        call y5_c4_s22 from m75_run_y5_c4_s22
    if start_at <= 1.75 and y5_scene_available("Y5-C4-S25"):
        call y5_c4_s25 from m751_run_y5_c4_s25
    if start_at <= 2 and y5_scene_available("Y5-C4-S03"):
        call y5_c4_s03 from y5r_run_y5_c4_s03
    if start_at <= 3 and y5_scene_available("Y5-C4-S04"):
        call y5_c4_s04 from y5r_run_y5_c4_s04
    if start_at <= 4 and y5_scene_available("Y5-C4-S05"):
        call y5_c4_s05 from y5r_run_y5_c4_s05
    if start_at <= 5 and y5_scene_available("Y5-C4-S06"):
        call y5_c4_s06 from y5r_run_y5_c4_s06
    if start_at <= 5.5 and y5_scene_available("Y5-C4-S23"):
        call y5_c4_s23 from m75_run_y5_c4_s23
    if start_at <= 5.75 and y5_scene_available("Y5-C4-S26"):
        call y5_c4_s26 from m751_run_y5_c4_s26
    if start_at <= 6 and y5_scene_available("Y5-C4-S07"):
        call y5_c4_s07 from y5r_run_y5_c4_s07
    if start_at <= 7 and y5_scene_available("Y5-C4-S09"):
        call y5_c4_s09 from y5r_run_y5_c4_s09
    if start_at <= 8 and y5_scene_available("Y5-C4-S10"):
        call y5_c4_s10 from y5r_run_y5_c4_s10
    if start_at <= 9 and y5_scene_available("Y5-C4-S08"):
        call y5_c4_s08 from y5r_run_y5_c4_s08
    if start_at <= 10 and y5_scene_available("Y5-C4-S11"):
        call y5_c4_s11 from y5r_run_y5_c4_s11
    if start_at <= 11 and y5_scene_available("Y5-C4-S12"):
        call y5_c4_s12 from y5r_run_y5_c4_s12
    if start_at <= 12 and y5_scene_available("Y5-C4-S13"):
        call y5_c4_s13 from y5r_run_y5_c4_s13
    if start_at <= 13 and y5_scene_available("Y5-C4-S14"):
        call y5_c4_s14 from y5r_run_y5_c4_s14
    if start_at <= 14 and y5_scene_available("Y5-C4-S15"):
        call y5_c4_s15 from y5r_run_y5_c4_s15
    if start_at <= 15 and y5_scene_available("Y5-C4-S16"):
        call y5_c4_s16 from y5r_run_y5_c4_s16
    if start_at <= 16 and y5_scene_available("Y5-C4-S17"):
        call y5_c4_s17 from y5r_run_y5_c4_s17
    hide screen y5_event_cg
    hide screen y5_stage
    call vn_end_chapter(Y5_TITLES[3]) from y5_end_c4
    return

label y5_chapter5(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y5-C5") from y5_begin_c5
    if start_at <= 0 and y5_scene_available("Y5-C5-S01"):
        call y5_c5_s01 from y5r_run_y5_c5_s01
    if start_at <= 1 and y5_scene_available("Y5-C5-S02"):
        call y5_c5_s02 from y5r_run_y5_c5_s02
    if start_at <= 2 and y5_scene_available("Y5-C5-S03"):
        call y5_c5_s03 from y5r_run_y5_c5_s03
    if start_at <= 3 and y5_scene_available("Y5-C5-S04"):
        call y5_c5_s04 from y5r_run_y5_c5_s04
    if start_at <= 4 and y5_scene_available("Y5-C5-S05"):
        call y5_c5_s05 from y5r_run_y5_c5_s05
    if start_at <= 5 and y5_scene_available("Y5-C5-S06"):
        call y5_c5_s06 from y5r_run_y5_c5_s06
    if start_at <= 6 and y5_scene_available("Y5-C5-S07"):
        call y5_c5_s07 from y5r_run_y5_c5_s07
    if start_at <= 7 and y5_scene_available("Y5-C5-S08"):
        call y5_c5_s08 from y5r_run_y5_c5_s08
    if start_at <= 8 and y5_scene_available("Y5-C5-S09"):
        call y5_c5_s09 from y5r_run_y5_c5_s09
    if start_at <= 9 and y5_scene_available("Y5-C5-S10"):
        call y5_c5_s10 from y5r_run_y5_c5_s10
    if start_at <= 10 and y5_scene_available("Y5-C5-S11"):
        call y5_c5_s11 from y5r_run_y5_c5_s11
    if start_at <= 11 and y5_scene_available("Y5-C5-S12"):
        call y5_c5_s12 from y5r_run_y5_c5_s12
    if start_at <= 12 and y5_scene_available("Y5-C5-S13"):
        call y5_c5_s13 from y5r_run_y5_c5_s13
    if start_at <= 13 and y5_scene_available("Y5-C5-S14"):
        call y5_c5_s14 from y5r_run_y5_c5_s14
    if start_at <= 14 and y5_scene_available("Y5-C5-S15"):
        call y5_c5_s15 from y5r_run_y5_c5_s15
    if start_at <= 15 and y5_scene_available("Y5-C5-S16"):
        call y5_c5_s16 from y5r_run_y5_c5_s16
    if start_at <= 16 and y5_scene_available("Y5-C5-S17"):
        call y5_c5_s17 from y5r_run_y5_c5_s17
    hide screen y5_event_cg
    hide screen y5_stage
    if y5_captured():
        return
    call vn_end_chapter(Y5_TITLES[4]) from y5_end_c5
    return

label y5_chapter6(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y5-C6") from y5_begin_c6
    if start_at <= 0 and y5_scene_available("Y5-C6-S01"):
        call y5_c6_s01 from y5r_run_y5_c6_s01
    if start_at <= 1 and y5_scene_available("Y5-C6-S02"):
        call y5_c6_s02 from y5r_run_y5_c6_s02
    if start_at <= 2 and y5_scene_available("Y5-C6-S03"):
        call y5_c6_s03 from y5r_run_y5_c6_s03
    if start_at <= 3 and y5_scene_available("Y5-C6-S04"):
        call y5_c6_s04 from y5r_run_y5_c6_s04
    if start_at <= 4 and y5_scene_available("Y5-C6-S05"):
        call y5_c6_s05 from y5r_run_y5_c6_s05
    if start_at <= 5 and y5_scene_available("Y5-C6-S06"):
        call y5_c6_s06 from y5r_run_y5_c6_s06
    if start_at <= 6 and y5_scene_available("Y5-C6-S07"):
        call y5_c6_s07 from y5r_run_y5_c6_s07
    if start_at <= 7 and y5_scene_available("Y5-C6-S08"):
        call y5_c6_s08 from y5r_run_y5_c6_s08
    if start_at <= 10 and y5_scene_available("Y5-C6-S11"):
        call y5_c6_s11 from y5r_run_y5_c6_s11
    if start_at <= 11 and y5_scene_available("Y5-C6-S12"):
        call y5_c6_s12 from y5r_run_y5_c6_s12
    if start_at <= 12 and y5_scene_available("Y5-C6-S13"):
        call y5_c6_s13 from y5r_run_y5_c6_s13
    hide screen y5_event_cg
    hide screen y5_stage
    call vn_end_chapter(Y5_TITLES[5]) from y5_end_c6
    return

label y5_start:
    $ y5_begin()
    $ y5_review_chapter, y5_review_offset = 1, 0
    jump y5_continue

label y5_continue:
    if y5_review_chapter <= 1:
        call y5_chapter1(y5_review_offset if y5_review_chapter == 1 else 0) from y5_continue_c1
    if y5_review_chapter <= 2:
        call y5_chapter2(y5_review_offset if y5_review_chapter == 2 else 0) from y5_continue_c2
    if y5_review_chapter <= 3:
        call y5_chapter3(y5_review_offset if y5_review_chapter == 3 else 0) from y5_continue_c3
    if y5_review_chapter <= 4:
        call y5_chapter4(y5_review_offset if y5_review_chapter == 4 else 0) from y5_continue_c4
    if y5_review_chapter <= 5:
        call y5_chapter5(y5_review_offset if y5_review_chapter == 5 else 0) from y5_continue_c5
    if y5_captured():
        $ m21_add("m21_endings", "y5_captured")
        call screen y5_ending
        return
    if y5_review_chapter <= 6:
        call y5_chapter6(y5_review_offset if y5_review_chapter == 6 else 0) from y5_continue_c6
    $ m21_annual(5)
    call screen y5_ending
    if _return == "year6":
        jump y6_start
    return


label review_y5_c1_s01:
    $ y5_prepare_review("Y5-C1-S01",y5_preview_preset)
    jump y5_continue

label review_y5_c1_s02:
    $ y5_prepare_review("Y5-C1-S02",y5_preview_preset)
    jump y5_continue

label review_y5_c1_s03:
    $ y5_prepare_review("Y5-C1-S03",y5_preview_preset)
    jump y5_continue

label review_y5_c1_s04:
    $ y5_prepare_review("Y5-C1-S04",y5_preview_preset)
    jump y5_continue

label review_y5_c1_s05:
    $ y5_prepare_review("Y5-C1-S05",y5_preview_preset)
    jump y5_continue

label review_y5_c1_s06:
    $ y5_prepare_review("Y5-C1-S06",y5_preview_preset)
    jump y5_continue

label review_y5_c1_s07:
    $ y5_prepare_review("Y5-C1-S07",y5_preview_preset)
    jump y5_continue

label review_y5_c1_s11:
    $ y5_prepare_review("Y5-C1-S11",y5_preview_preset)
    jump y5_continue

label review_y5_c1_s12:
    $ y5_prepare_review("Y5-C1-S12",y5_preview_preset)
    jump y5_continue

label review_y5_c1_s13:
    $ y5_prepare_review("Y5-C1-S13",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s01:
    $ y5_prepare_review("Y5-C2-S01",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s02:
    $ y5_prepare_review("Y5-C2-S02",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s03:
    $ y5_prepare_review("Y5-C2-S03",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s04:
    $ y5_prepare_review("Y5-C2-S04",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s05:
    $ y5_prepare_review("Y5-C2-S05",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s06:
    $ y5_prepare_review("Y5-C2-S06",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s07:
    $ y5_prepare_review("Y5-C2-S07",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s11:
    $ y5_prepare_review("Y5-C2-S11",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s12:
    $ y5_prepare_review("Y5-C2-S12",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s13:
    $ y5_prepare_review("Y5-C2-S13",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s14:
    $ y5_prepare_review("Y5-C2-S14",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s15:
    $ y5_prepare_review("Y5-C2-S15",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s16:
    $ y5_prepare_review("Y5-C2-S16",y5_preview_preset)
    jump y5_continue

label review_y5_c2_s17:
    $ y5_prepare_review("Y5-C2-S17",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s01:
    $ y5_prepare_review("Y5-C3-S01",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s02:
    $ y5_prepare_review("Y5-C3-S02",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s03:
    $ y5_prepare_review("Y5-C3-S03",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s04:
    $ y5_prepare_review("Y5-C3-S04",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s05:
    $ y5_prepare_review("Y5-C3-S05",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s06:
    $ y5_prepare_review("Y5-C3-S06",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s07:
    $ y5_prepare_review("Y5-C3-S07",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s09:
    $ y5_prepare_review("Y5-C3-S09",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s10:
    $ y5_prepare_review("Y5-C3-S10",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s11:
    $ y5_prepare_review("Y5-C3-S11",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s12:
    $ y5_prepare_review("Y5-C3-S12",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s13:
    $ y5_prepare_review("Y5-C3-S13",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s14:
    $ y5_prepare_review("Y5-C3-S14",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s15:
    $ y5_prepare_review("Y5-C3-S15",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s16:
    $ y5_prepare_review("Y5-C3-S16",y5_preview_preset)
    jump y5_continue

label review_y5_c3_s17:
    $ y5_prepare_review("Y5-C3-S17",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s01:
    $ y5_prepare_review("Y5-C4-S01",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s02:
    $ y5_prepare_review("Y5-C4-S02",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s03:
    $ y5_prepare_review("Y5-C4-S03",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s04:
    $ y5_prepare_review("Y5-C4-S04",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s05:
    $ y5_prepare_review("Y5-C4-S05",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s06:
    $ y5_prepare_review("Y5-C4-S06",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s07:
    $ y5_prepare_review("Y5-C4-S07",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s09:
    $ y5_prepare_review("Y5-C4-S09",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s10:
    $ y5_prepare_review("Y5-C4-S10",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s08:
    $ y5_prepare_review("Y5-C4-S08",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s11:
    $ y5_prepare_review("Y5-C4-S11",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s12:
    $ y5_prepare_review("Y5-C4-S12",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s13:
    $ y5_prepare_review("Y5-C4-S13",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s14:
    $ y5_prepare_review("Y5-C4-S14",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s15:
    $ y5_prepare_review("Y5-C4-S15",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s16:
    $ y5_prepare_review("Y5-C4-S16",y5_preview_preset)
    jump y5_continue

label review_y5_c4_s17:
    $ y5_prepare_review("Y5-C4-S17",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s01:
    $ y5_prepare_review("Y5-C5-S01",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s02:
    $ y5_prepare_review("Y5-C5-S02",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s03:
    $ y5_prepare_review("Y5-C5-S03",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s04:
    $ y5_prepare_review("Y5-C5-S04",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s05:
    $ y5_prepare_review("Y5-C5-S05",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s06:
    $ y5_prepare_review("Y5-C5-S06",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s07:
    $ y5_prepare_review("Y5-C5-S07",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s08:
    $ y5_prepare_review("Y5-C5-S08",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s09:
    $ y5_prepare_review("Y5-C5-S09",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s10:
    $ y5_prepare_review("Y5-C5-S10",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s11:
    $ y5_prepare_review("Y5-C5-S11",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s12:
    $ y5_prepare_review("Y5-C5-S12",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s13:
    $ y5_prepare_review("Y5-C5-S13",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s14:
    $ y5_prepare_review("Y5-C5-S14",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s15:
    $ y5_prepare_review("Y5-C5-S15",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s16:
    $ y5_prepare_review("Y5-C5-S16",y5_preview_preset)
    jump y5_continue

label review_y5_c5_s17:
    $ y5_prepare_review("Y5-C5-S17",y5_preview_preset)
    jump y5_continue

label review_y5_c6_s01:
    $ y5_prepare_review("Y5-C6-S01",y5_preview_preset)
    jump y5_continue

label review_y5_c6_s02:
    $ y5_prepare_review("Y5-C6-S02",y5_preview_preset)
    jump y5_continue

label review_y5_c6_s03:
    $ y5_prepare_review("Y5-C6-S03",y5_preview_preset)
    jump y5_continue

label review_y5_c6_s04:
    $ y5_prepare_review("Y5-C6-S04",y5_preview_preset)
    jump y5_continue

label review_y5_c6_s05:
    $ y5_prepare_review("Y5-C6-S05",y5_preview_preset)
    jump y5_continue

label review_y5_c6_s06:
    $ y5_prepare_review("Y5-C6-S06",y5_preview_preset)
    jump y5_continue

label review_y5_c6_s07:
    $ y5_prepare_review("Y5-C6-S07",y5_preview_preset)
    jump y5_continue

label review_y5_c6_s08:
    $ y5_prepare_review("Y5-C6-S08",y5_preview_preset)
    jump y5_continue

label review_y5_c6_s11:
    $ y5_prepare_review("Y5-C6-S11",y5_preview_preset)
    jump y5_continue

label review_y5_c6_s12:
    $ y5_prepare_review("Y5-C6-S12",y5_preview_preset)
    jump y5_continue

label review_y5_c6_s13:
    $ y5_prepare_review("Y5-C6-S13",y5_preview_preset)
    jump y5_continue
