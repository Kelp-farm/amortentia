
label y2_chapter1(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y2-C1") from y2_begin_c1
    if start_at <= 0:
        call y2_c1_s01 from y2_run_y2_c1_s01
    if start_at <= 1:
        call y2_c1_s02 from y2_run_y2_c1_s02
    if start_at <= 2:
        call y2_c1_s03 from y2_run_y2_c1_s03
    if start_at <= 3:
        call y2_c1_s04 from y2_run_y2_c1_s04
    if start_at <= 4:
        call y2_c1_s05 from y2_run_y2_c1_s05
    hide screen y2_event_cg
    hide screen y2_stage
    call vn_end_chapter(Y2_TITLES[0]) from y2_end_c1
    return

label y2_chapter2(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y2-C2") from y2_begin_c2
    if start_at <= 0:
        call y2_c2_s01 from y2_run_y2_c2_s01
    if start_at <= 1:
        call y2_c2_s02 from y2_run_y2_c2_s02
    if start_at <= 2:
        call y2_c2_s03 from y2_run_y2_c2_s03
    if start_at <= 3:
        call y2_c2_s04 from y2_run_y2_c2_s04
    if start_at <= 4:
        call y2_c2_s06 from y2_run_y2_c2_s06
    if start_at <= 5:
        call y2_c2_s05 from y2_run_y2_c2_s05
    hide screen y2_event_cg
    hide screen y2_stage
    call vn_end_chapter(Y2_TITLES[1]) from y2_end_c2
    return

label y2_chapter3(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y2-C3") from y2_begin_c3
    if start_at <= 0:
        call y2_c3_s01 from y2_run_y2_c3_s01
    if start_at <= 1:
        call y2_c3_s02 from y2_run_y2_c3_s02
    if start_at <= 2:
        call y2_c3_s03 from y2_run_y2_c3_s03
    if start_at <= 3:
        call y2_c3_s04 from y2_run_y2_c3_s04
    if start_at <= 4:
        call y2_c3_s05 from y2_run_y2_c3_s05
    hide screen y2_event_cg
    hide screen y2_stage
    call vn_end_chapter(Y2_TITLES[2]) from y2_end_c3
    return

label y2_chapter4(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y2-C4") from y2_begin_c4
    if start_at <= 0:
        call y2_c4_s01 from y2_run_y2_c4_s01
    if start_at <= 1:
        call y2_c4_s02 from y2_run_y2_c4_s02
    if start_at <= 2:
        call y2_c4_s04 from y2_run_y2_c4_s04
    if start_at <= 3:
        call y2_c4_s05 from y2_run_y2_c4_s05
    hide screen y2_event_cg
    hide screen y2_stage
    call vn_end_chapter(Y2_TITLES[3]) from y2_end_c4
    return

label y2_chapter5(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y2-C5") from y2_begin_c5
    if start_at <= 0:
        call y2_c5_s01 from y2_run_y2_c5_s01
    if start_at <= 1:
        call y2_c5_s02 from y2_run_y2_c5_s02
    if start_at <= 2:
        call y2_c5_s03 from y2_run_y2_c5_s03
    if start_at <= 3:
        call y2_c5_s04 from y2_run_y2_c5_s04
    hide screen y2_event_cg
    hide screen y2_stage
    call vn_end_chapter(Y2_TITLES[4]) from y2_end_c5
    return

label y2_chapter6(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y2-C6") from y2_begin_c6
    if start_at <= 0:
        call y2_c6_s01 from y2_run_y2_c6_s01
    if start_at <= 1:
        call y2_c6_s02 from y2_run_y2_c6_s02
    if start_at <= 2:
        call y2_c6_s03 from y2_run_y2_c6_s03
    if start_at <= 3:
        call y2_c6_s04 from y2_run_y2_c6_s04
    if start_at <= 4:
        call y2_c6_s05 from y2_run_y2_c6_s05
    if start_at <= 5:
        call y2_c6_s06 from y2_run_y2_c6_s06
    hide screen y2_event_cg
    hide screen y2_stage
    call vn_end_chapter(Y2_TITLES[5]) from y2_end_c6
    return

label y2_start:
    $ y2_begin()
    $ y2_review_chapter = 1
    $ y2_review_offset = 0
    jump y2_continue

label y2_continue:
    hide screen y1_stage
    hide screen y1_event_cg
    if y2_review_chapter <= 1:
        call y2_chapter1(y2_review_offset if y2_review_chapter == 1 else 0) from y2_continue_c1
    if y2_review_chapter <= 2:
        call y2_chapter2(y2_review_offset if y2_review_chapter == 2 else 0) from y2_continue_c2
    if y2_review_chapter <= 3:
        call y2_chapter3(y2_review_offset if y2_review_chapter == 3 else 0) from y2_continue_c3
    if y2_review_chapter <= 4:
        call y2_chapter4(y2_review_offset if y2_review_chapter == 4 else 0) from y2_continue_c4
    if y2_review_chapter <= 5:
        call y2_chapter5(y2_review_offset if y2_review_chapter == 5 else 0) from y2_continue_c5
    if y2_review_chapter <= 6:
        call y2_chapter6(y2_review_offset if y2_review_chapter == 6 else 0) from y2_continue_c6
    stop music fadeout 1.0
    $ m21_annual(2)
    call screen y2_ending
    if _return == "year3":
        jump y3_start
    return

label review_y2_c1_s01:
    $ y2_prepare_review("Y2-C1-S01", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c1_s02:
    $ y2_prepare_review("Y2-C1-S02", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c1_s03:
    $ y2_prepare_review("Y2-C1-S03", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c1_s04:
    $ y2_prepare_review("Y2-C1-S04", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c1_s05:
    $ y2_prepare_review("Y2-C1-S05", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c2_s01:
    $ y2_prepare_review("Y2-C2-S01", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c2_s02:
    $ y2_prepare_review("Y2-C2-S02", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c2_s03:
    $ y2_prepare_review("Y2-C2-S03", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c2_s04:
    $ y2_prepare_review("Y2-C2-S04", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c2_s06:
    $ y2_prepare_review("Y2-C2-S06", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c2_s05:
    $ y2_prepare_review("Y2-C2-S05", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c3_s01:
    $ y2_prepare_review("Y2-C3-S01", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c3_s02:
    $ y2_prepare_review("Y2-C3-S02", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c3_s03:
    $ y2_prepare_review("Y2-C3-S03", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c3_s04:
    $ y2_prepare_review("Y2-C3-S04", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c3_s05:
    $ y2_prepare_review("Y2-C3-S05", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c4_s01:
    $ y2_prepare_review("Y2-C4-S01", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c4_s02:
    $ y2_prepare_review("Y2-C4-S02", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c4_s03:
    # An old review link now starts at the next surviving scene.
    $ y2_prepare_review("Y2-C4-S04", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c4_s04:
    $ y2_prepare_review("Y2-C4-S04", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c4_s05:
    $ y2_prepare_review("Y2-C4-S05", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c5_s01:
    $ y2_prepare_review("Y2-C5-S01", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c5_s02:
    $ y2_prepare_review("Y2-C5-S02", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c5_s03:
    $ y2_prepare_review("Y2-C5-S03", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c5_s04:
    $ y2_prepare_review("Y2-C5-S04", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c6_s01:
    $ y2_prepare_review("Y2-C6-S01", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c6_s02:
    $ y2_prepare_review("Y2-C6-S02", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c6_s03:
    $ y2_prepare_review("Y2-C6-S03", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c6_s04:
    $ y2_prepare_review("Y2-C6-S04", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c6_s05:
    $ y2_prepare_review("Y2-C6-S05", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue

label review_y2_c6_s06:
    $ y2_prepare_review("Y2-C6-S06", y2_preview_diary, y2_preview_cooperation)
    jump y2_continue
