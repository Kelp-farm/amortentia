label y6_chapter1(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y6-C1")
    if start_at <= 0 and y6_scene_available("Y6-C1-S01"):
        call y6_c1_s01
    if start_at <= 1 and y6_scene_available("Y6-C1-S02"):
        call y6_c1_s02
    if start_at <= 2 and y6_scene_available("Y6-C1-S03"):
        call y6_c1_s03
    if start_at <= 3 and y6_scene_available("Y6-C1-S04"):
        call y6_c1_s04
    if start_at <= 4 and y6_scene_available("Y6-C1-S05"):
        call y6_c1_s05
    if start_at <= 10 and y6_scene_available("Y6-C1-S11"):
        call y6_c1_s11
    if start_at <= 11 and y6_scene_available("Y6-C1-S12"):
        call y6_c1_s12
    if start_at <= 12 and y6_scene_available("Y6-C1-S13"):
        call y6_c1_s13
    if start_at <= 13 and y6_scene_available("Y6-C1-S14"):
        call y6_c1_s14
    if start_at <= 14 and y6_scene_available("Y6-C1-S15"):
        call y6_c1_s15
    hide screen y6_event_cg
    hide screen y6_stage
    call vn_end_chapter(Y6_TITLES[0])
    return

label y6_chapter2(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y6-C2")
    if start_at <= 0 and y6_scene_available("Y6-C2-S01"):
        call y6_c2_s01
    if start_at <= 1 and y6_scene_available("Y6-C2-S02"):
        call y6_c2_s02
    if start_at <= 2 and y6_scene_available("Y6-C2-S03"):
        call y6_c2_s03
    if start_at <= 3 and y6_scene_available("Y6-C2-S04"):
        call y6_c2_s04
    if start_at <= 4 and y6_scene_available("Y6-C2-S05"):
        call y6_c2_s05
    if start_at <= 5 and y6_scene_available("Y6-C2-S06"):
        call y6_c2_s06
    if start_at <= 10 and y6_scene_available("Y6-C2-S11"):
        call y6_c2_s11
    if start_at <= 11 and y6_scene_available("Y6-C2-S12"):
        call y6_c2_s12
    if start_at <= 12 and y6_scene_available("Y6-C2-S13"):
        call y6_c2_s13
    if start_at <= 13 and y6_scene_available("Y6-C2-S14"):
        call y6_c2_s14
    if start_at <= 14 and y6_scene_available("Y6-C2-S15"):
        call y6_c2_s15
    if start_at <= 15 and y6_scene_available("Y6-C2-S16"):
        call y6_c2_s16
    hide screen y6_event_cg
    hide screen y6_stage
    call vn_end_chapter(Y6_TITLES[1])
    return

label y6_chapter3(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y6-C3")
    if start_at <= 0 and y6_scene_available("Y6-C3-S01"):
        call y6_c3_s01
    if start_at <= 1 and y6_scene_available("Y6-C3-S02"):
        call y6_c3_s02
    if start_at <= 2 and y6_scene_available("Y6-C3-S03"):
        call y6_c3_s03
    if start_at <= 3 and y6_scene_available("Y6-C3-S04"):
        call y6_c3_s04
    if start_at <= 4 and y6_scene_available("Y6-C3-S05"):
        call y6_c3_s05
    if start_at <= 10 and y6_scene_available("Y6-C3-S11"):
        call y6_c3_s11
    if start_at <= 11 and y6_scene_available("Y6-C3-S12"):
        call y6_c3_s12
    if start_at <= 12 and y6_scene_available("Y6-C3-S13"):
        call y6_c3_s13
    if start_at <= 13 and y6_scene_available("Y6-C3-S14"):
        call y6_c3_s14
    if start_at <= 14 and y6_scene_available("Y6-C3-S15"):
        call y6_c3_s15
    if start_at <= 15 and y6_scene_available("Y6-C3-S16"):
        call y6_c3_s16
    hide screen y6_event_cg
    hide screen y6_stage
    call vn_end_chapter(Y6_TITLES[2])
    return

label y6_chapter4(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y6-C4")
    if start_at <= 0 and y6_scene_available("Y6-C4-S01"):
        call y6_c4_s01
    if start_at <= 1 and y6_scene_available("Y6-C4-S02"):
        call y6_c4_s02
    if start_at <= 2 and y6_scene_available("Y6-C4-S03"):
        call y6_c4_s03
    if start_at <= 3 and y6_scene_available("Y6-C4-S04"):
        call y6_c4_s04
    if start_at <= 4 and y6_scene_available("Y6-C4-S05"):
        call y6_c4_s05
    if start_at <= 10 and y6_scene_available("Y6-C4-S11"):
        call y6_c4_s11
    if start_at <= 11 and y6_scene_available("Y6-C4-S12"):
        call y6_c4_s12
    if start_at <= 12 and y6_scene_available("Y6-C4-S13"):
        call y6_c4_s13
    if start_at <= 13 and y6_scene_available("Y6-C4-S14"):
        call y6_c4_s14
    if start_at <= 14 and y6_scene_available("Y6-C4-S15"):
        call y6_c4_s15
    if start_at <= 15 and y6_scene_available("Y6-C4-S16"):
        call y6_c4_s16
    if start_at <= 16 and y6_scene_available("Y6-C4-S17"):
        call y6_c4_s17
    hide screen y6_event_cg
    hide screen y6_stage
    call vn_end_chapter(Y6_TITLES[3])
    return

label y6_chapter5(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y6-C5")
    if start_at <= 0 and y6_scene_available("Y6-C5-S01"):
        call y6_c5_s01
    if start_at <= 1 and y6_scene_available("Y6-C5-S02"):
        call y6_c5_s02
    if start_at <= 2 and y6_scene_available("Y6-C5-S03"):
        call y6_c5_s03
    if start_at <= 3 and y6_scene_available("Y6-C5-S04"):
        call y6_c5_s04
    if start_at <= 4 and y6_scene_available("Y6-C5-S05"):
        call y6_c5_s05
    if start_at <= 10 and y6_scene_available("Y6-C5-S11"):
        call y6_c5_s11
    if start_at <= 11 and y6_scene_available("Y6-C5-S12"):
        call y6_c5_s12
    if start_at <= 12 and y6_scene_available("Y6-C5-S13"):
        call y6_c5_s13
    if start_at <= 13 and y6_scene_available("Y6-C5-S14"):
        call y6_c5_s14
    if start_at <= 14 and y6_scene_available("Y6-C5-S15"):
        call y6_c5_s15
    if start_at <= 15 and y6_scene_available("Y6-C5-S16"):
        call y6_c5_s16
    hide screen y6_event_cg
    hide screen y6_stage
    call vn_end_chapter(Y6_TITLES[4])
    return

label y6_chapter6(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y6-C6")
    if start_at <= 0 and y6_scene_available("Y6-C6-S01"):
        call y6_c6_s01
    if start_at <= 1 and y6_scene_available("Y6-C6-S02"):
        call y6_c6_s02
    if start_at <= 2 and y6_scene_available("Y6-C6-S03"):
        call y6_c6_s03
    if start_at <= 3 and y6_scene_available("Y6-C6-S04"):
        call y6_c6_s04
    if start_at <= 4 and y6_scene_available("Y6-C6-S05"):
        call y6_c6_s05
    if start_at <= 10 and y6_scene_available("Y6-C6-S11"):
        call y6_c6_s11
    if start_at <= 11 and y6_scene_available("Y6-C6-S12"):
        call y6_c6_s12
    if start_at <= 12 and y6_scene_available("Y6-C6-S13"):
        call y6_c6_s13
    if start_at <= 13 and y6_scene_available("Y6-C6-S14"):
        call y6_c6_s14
    if start_at <= 14 and y6_scene_available("Y6-C6-S15"):
        call y6_c6_s15
    if start_at <= 15 and y6_scene_available("Y6-C6-S16"):
        call y6_c6_s16
    hide screen y6_event_cg
    hide screen y6_stage
    call vn_end_chapter(Y6_TITLES[5])
    return

label y6_chapter7(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y6-C7")
    if start_at <= 0 and y6_scene_available("Y6-C7-S01"):
        call y6_c7_s01
    if start_at <= 1 and y6_scene_available("Y6-C7-S02"):
        call y6_c7_s02
    if start_at <= 2 and y6_scene_available("Y6-C7-S03"):
        call y6_c7_s03
    if start_at <= 3 and y6_scene_available("Y6-C7-S04"):
        call y6_c7_s04
    if start_at <= 10 and y6_scene_available("Y6-C7-S11"):
        call y6_c7_s11
    if start_at <= 11 and y6_scene_available("Y6-C7-S12"):
        call y6_c7_s12
    if start_at <= 12 and y6_scene_available("Y6-C7-S13"):
        call y6_c7_s13
    if start_at <= 13 and y6_scene_available("Y6-C7-S14"):
        call y6_c7_s14
    if start_at <= 14 and y6_scene_available("Y6-C7-S15"):
        call y6_c7_s15
    hide screen y6_event_cg
    hide screen y6_stage
    call vn_end_chapter(Y6_TITLES[6])
    return

label y6_chapter8(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y6-C8")
    if start_at <= 0 and y6_scene_available("Y6-C8-S01"):
        call y6_c8_s01
    if start_at <= 1 and y6_scene_available("Y6-C8-S02"):
        call y6_c8_s02
    if start_at <= 2 and y6_scene_available("Y6-C8-S03"):
        call y6_c8_s03
    if start_at <= 3 and y6_scene_available("Y6-C8-S04"):
        call y6_c8_s04
    if start_at <= 4 and y6_scene_available("Y6-C8-S05"):
        call y6_c8_s05
    if start_at <= 10 and y6_scene_available("Y6-C8-S11"):
        call y6_c8_s11
    if start_at <= 11 and y6_scene_available("Y6-C8-S12"):
        call y6_c8_s12
    if start_at <= 12 and y6_scene_available("Y6-C8-S13"):
        call y6_c8_s13
    if start_at <= 13 and y6_scene_available("Y6-C8-S14"):
        call y6_c8_s14
    if start_at <= 14 and y6_scene_available("Y6-C8-S15"):
        call y6_c8_s15
    hide screen y6_event_cg
    hide screen y6_stage
    call vn_end_chapter(Y6_TITLES[7])
    return

label y6_start:
    if m6_route_incompatible(vn):
        call screen m6_commitment_changed
        return
    $ y6_begin()
    $ y6_review_chapter, y6_review_offset = 1, 0
    jump y6_continue

label y6_continue:
    if y6_review_chapter <= 1:
        call y6_chapter1(y6_review_offset if y6_review_chapter == 1 else 0)
    if y6_review_chapter <= 2:
        call y6_chapter2(y6_review_offset if y6_review_chapter == 2 else 0)
    if y6_review_chapter <= 3:
        call y6_chapter3(y6_review_offset if y6_review_chapter == 3 else 0)
    if y6_review_chapter <= 4:
        call y6_chapter4(y6_review_offset if y6_review_chapter == 4 else 0)
    if y6_review_chapter <= 5:
        call y6_chapter5(y6_review_offset if y6_review_chapter == 5 else 0)
    if y6_review_chapter <= 6:
        call y6_chapter6(y6_review_offset if y6_review_chapter == 6 else 0)
    if y6_review_chapter <= 7:
        call y6_chapter7(y6_review_offset if y6_review_chapter == 7 else 0)
    if y6_review_chapter <= 8:
        call y6_chapter8(y6_review_offset if y6_review_chapter == 8 else 0)
    $ m21_annual(6)
    call screen y6_ending
    return
