label y4_chapter1(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y4-C1") from y4_begin_c1
    if start_at <= 0 and y4_scene_available("Y4-C1-S01"):
        call y4_c1_s01 from y4_run_y4_c1_s01
    if start_at <= 1 and y4_scene_available("Y4-C1-S06"):
        call y4_c1_s06 from y4_run_y4_c1_s06
    if start_at <= 2 and y4_scene_available("Y4-C1-S02"):
        call y4_c1_s02 from y4_run_y4_c1_s02
    if start_at <= 3 and y4_scene_available("Y4-C1-S03"):
        call y4_c1_s03 from y4_run_y4_c1_s03
    if start_at <= 4 and y4_scene_available("Y4-C1-S04"):
        call y4_c1_s04 from y4_run_y4_c1_s04
    if start_at <= 5 and y4_scene_available("Y4-C1-S07"):
        call y4_c1_s07 from y4_run_y4_c1_s07
    if start_at <= 6 and y4_scene_available("Y4-C1-S05"):
        call y4_c1_s05 from y4_run_y4_c1_s05
    hide screen y4_event_cg
    hide screen y4_stage
    call vn_end_chapter(Y4_TITLES[0]) from y4_end_c1
    return

label y4_chapter2(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y4-C2") from y4_begin_c2
    if start_at <= 0 and y4_scene_available("Y4-C2-S01"):
        call y4_c2_s01 from y4_run_y4_c2_s01
    if start_at <= 1 and y4_scene_available("Y4-C2-S02"):
        call y4_c2_s02 from y4_run_y4_c2_s02
    if start_at <= 2 and y4_scene_available("Y4-C2-S03"):
        call y4_c2_s03 from y4_run_y4_c2_s03
    if start_at <= 3 and y4_scene_available("Y4-C2-S08"):
        call y4_c2_s08 from y4_run_y4_c2_s08
    if start_at <= 4 and y4_scene_available("Y4-C2-S04"):
        call y4_c2_s04 from y4_run_y4_c2_s04
    if start_at <= 5 and y4_scene_available("Y4-C2-S05"):
        call y4_c2_s05 from y4_run_y4_c2_s05
    if start_at <= 6 and y4_scene_available("Y4-C2-S06"):
        call y4_c2_s06 from y4_run_y4_c2_s06
    if start_at <= 7 and y4_scene_available("Y4-C2-S07"):
        call y4_c2_s07 from y4_run_y4_c2_s07
    hide screen y4_event_cg
    hide screen y4_stage
    call vn_end_chapter(Y4_TITLES[1]) from y4_end_c2
    return

label y4_chapter3(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y4-C3") from y4_begin_c3
    if start_at <= 0 and y4_scene_available("Y4-C3-S01"):
        call y4_c3_s01 from y4_run_y4_c3_s01
    if start_at <= 1 and y4_scene_available("Y4-C3-S02"):
        call y4_c3_s02 from y4_run_y4_c3_s02
    if start_at <= 2 and y4_scene_available("Y4-C3-S03"):
        call y4_c3_s03 from y4_run_y4_c3_s03
    if start_at <= 3 and y4_scene_available("Y4-C3-S04"):
        call y4_c3_s04 from y4_run_y4_c3_s04
    if start_at <= 4 and y4_scene_available("Y4-C3-S05"):
        call y4_c3_s05 from y4_run_y4_c3_s05
    if start_at <= 5 and y4_scene_available("Y4-C3-S06"):
        call y4_c3_s06 from y4_run_y4_c3_s06
    if start_at <= 6 and y4_scene_available("Y4-C3-S07"):
        call y4_c3_s07 from y4_run_y4_c3_s07
    if start_at <= 7 and y4_scene_available("Y4-C3-S08"):
        call y4_c3_s08 from y4_run_y4_c3_s08
    if start_at <= 8 and y4_scene_available("Y4-C3-S09"):
        call y4_c3_s09 from y4_run_y4_c3_s09
    if start_at <= 9 and y4_scene_available("Y4-C3-S10"):
        call y4_c3_s10 from y4_run_y4_c3_s10
    if start_at <= 10 and y4_scene_available("Y4-C3-S11"):
        call y4_c3_s11 from y4_run_y4_c3_s11
    if start_at <= 11 and y4_scene_available("Y4-C3-S12"):
        call y4_c3_s12 from y4_run_y4_c3_s12
    hide screen y4_event_cg
    hide screen y4_stage
    call vn_end_chapter(Y4_TITLES[2]) from y4_end_c3
    return

label y4_chapter4(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y4-C4") from y4_begin_c4
    if start_at <= 0 and y4_scene_available("Y4-C4-S01"):
        call y4_c4_s01 from y4_run_y4_c4_s01
    if start_at <= 1 and y4_scene_available("Y4-C4-S02"):
        call y4_c4_s02 from y4_run_y4_c4_s02
    if start_at <= 2 and y4_scene_available("Y4-C4-S03"):
        call y4_c4_s03 from y4_run_y4_c4_s03
    if start_at <= 3 and y4_scene_available("Y4-C4-S04"):
        call y4_c4_s04 from y4_run_y4_c4_s04
    if start_at <= 4 and y4_scene_available("Y4-C4-S05"):
        call y4_c4_s05 from y4_run_y4_c4_s05
    if start_at <= 5 and y4_scene_available("Y4-C4-S06"):
        call y4_c4_s06 from y4_run_y4_c4_s06
    if start_at <= 6 and y4_scene_available("Y4-C4-S07"):
        call y4_c4_s07 from y4_run_y4_c4_s07
    hide screen y4_event_cg
    hide screen y4_stage
    call vn_end_chapter(Y4_TITLES[3]) from y4_end_c4
    return

label y4_chapter5(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y4-C5") from y4_begin_c5
    if start_at <= 0 and y4_scene_available("Y4-C5-S01"):
        call y4_c5_s01 from y4_run_y4_c5_s01
    if start_at <= 1 and y4_scene_available("Y4-C5-S06"):
        call y4_c5_s06 from y4_run_y4_c5_s06
    if start_at <= 2 and y4_scene_available("Y4-C5-S07"):
        call y4_c5_s07 from y4_run_y4_c5_s07
    if start_at <= 3 and y4_scene_available("Y4-C5-S02"):
        call y4_c5_s02 from y4_run_y4_c5_s02
    if start_at <= 4 and y4_scene_available("Y4-C5-S03"):
        call y4_c5_s03 from y4_run_y4_c5_s03
    if start_at <= 5 and y4_scene_available("Y4-C5-S04"):
        call y4_c5_s04 from y4_run_y4_c5_s04
    if start_at <= 6 and y4_scene_available("Y4-C5-S05"):
        call y4_c5_s05 from y4_run_y4_c5_s05
    hide screen y4_event_cg
    hide screen y4_stage
    call vn_end_chapter(Y4_TITLES[4]) from y4_end_c5
    return

label y4_chapter6(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y4-C6") from y4_begin_c6
    if start_at <= 0 and y4_scene_available("Y4-C6-S01"):
        call y4_c6_s01 from y4_run_y4_c6_s01
    if start_at <= 1 and y4_scene_available("Y4-C6-S02"):
        call y4_c6_s02 from y4_run_y4_c6_s02
    if start_at <= 2 and y4_scene_available("Y4-C6-S03"):
        call y4_c6_s03 from y4_run_y4_c6_s03
    if start_at <= 3 and y4_scene_available("Y4-C6-S04"):
        call y4_c6_s04 from y4_run_y4_c6_s04
    hide screen y4_event_cg
    hide screen y4_stage
    call vn_end_chapter(Y4_TITLES[5]) from y4_end_c6
    return

label y4_chapter7(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y4-C7") from y4_begin_c7
    if start_at <= 0 and y4_scene_available("Y4-C7-S01"):
        call y4_c7_s01 from y4_run_y4_c7_s01
    if start_at <= 1 and y4_scene_available("Y4-C7-S02"):
        call y4_c7_s02 from y4_run_y4_c7_s02
    if start_at <= 2 and y4_scene_available("Y4-C7-S03"):
        call y4_c7_s03 from y4_run_y4_c7_s03
    if start_at <= 3 and y4_scene_available("Y4-C7-S04"):
        call y4_c7_s04 from y4_run_y4_c7_s04
    if start_at <= 4 and y4_scene_available("Y4-C7-S05"):
        call y4_c7_s05 from y4_run_y4_c7_s05
    hide screen y4_event_cg
    hide screen y4_stage
    call vn_end_chapter(Y4_TITLES[6]) from y4_end_c7
    return

label y4_chapter8(start_at=0):
    if vn["current_chapter"] is None:
        call vn_chapter("Y4-C8") from y4_begin_c8
    if start_at <= 0 and y4_scene_available("Y4-C8-S01"):
        call y4_c8_s01 from y4_run_y4_c8_s01
    if start_at <= 1 and y4_scene_available("Y4-C8-S02"):
        call y4_c8_s02 from y4_run_y4_c8_s02
    if start_at <= 2 and y4_scene_available("Y4-C8-S03"):
        call y4_c8_s03 from y4_run_y4_c8_s03
    if start_at <= 3 and y4_scene_available("Y4-C8-S04"):
        call y4_c8_s04 from y4_run_y4_c8_s04
    if start_at <= 4 and y4_scene_available("Y4-C8-S10"):
        call y4_c8_s10 from y4_run_y4_c8_s10
    if start_at <= 5 and y4_scene_available("Y4-C8-S05"):
        call y4_c8_s05 from y4_run_y4_c8_s05
    if start_at <= 6 and y4_scene_available("Y4-C8-S06"):
        call y4_c8_s06 from y4_run_y4_c8_s06
    if start_at <= 7 and y4_scene_available("Y4-C8-S07"):
        call y4_c8_s07 from y4_run_y4_c8_s07
    if start_at <= 8 and y4_scene_available("Y4-C8-S11"):
        call y4_c8_s11 from y4_run_y4_c8_s11
    if start_at <= 9 and y4_scene_available("Y4-C8-S08"):
        call y4_c8_s08 from y4_run_y4_c8_s08
    if start_at <= 10 and y4_scene_available("Y4-C8-S09"):
        call y4_c8_s09 from y4_run_y4_c8_s09
    hide screen y4_event_cg
    hide screen y4_stage
    call vn_end_chapter(Y4_TITLES[7]) from y4_end_c8
    return

label y4_start:
    $ y4_begin()
    $ y4_review_chapter, y4_review_offset = 1, 0
    jump y4_continue

label y4_continue:
    hide screen y1_stage
    hide screen y2_stage
    hide screen y3_stage
    hide screen y3_event_cg
    if y4_review_chapter <= 1:
        call y4_chapter1(y4_review_offset if y4_review_chapter == 1 else 0) from y4_continue_c1
    if y4_review_chapter <= 2:
        call y4_chapter2(y4_review_offset if y4_review_chapter == 2 else 0) from y4_continue_c2
    if y4_review_chapter <= 3:
        call y4_chapter3(y4_review_offset if y4_review_chapter == 3 else 0) from y4_continue_c3
    if y4_review_chapter <= 4:
        call y4_chapter4(y4_review_offset if y4_review_chapter == 4 else 0) from y4_continue_c4
    if y4_review_chapter <= 5:
        call y4_chapter5(y4_review_offset if y4_review_chapter == 5 else 0) from y4_continue_c5
    if y4_review_chapter <= 6:
        call y4_chapter6(y4_review_offset if y4_review_chapter == 6 else 0) from y4_continue_c6
    if y4_review_chapter <= 7:
        call y4_chapter7(y4_review_offset if y4_review_chapter == 7 else 0) from y4_continue_c7
    if y4_review_chapter <= 8:
        call y4_chapter8(y4_review_offset if y4_review_chapter == 8 else 0) from y4_continue_c8
    $ m21_annual(4)
    call screen y4_ending
    if _return == "year5":
        jump y5_start
    return

label review_y4_c1_s01:
    $ y4_prepare_review("Y4-C1-S01",y4_review_preset_for("Y4-C1-S01",y4_preview_preset))
    jump y4_continue

label review_y4_c1_s02:
    $ y4_prepare_review("Y4-C1-S02",y4_review_preset_for("Y4-C1-S02",y4_preview_preset))
    jump y4_continue

label review_y4_c1_s03:
    $ y4_prepare_review("Y4-C1-S03",y4_review_preset_for("Y4-C1-S03",y4_preview_preset))
    jump y4_continue

label review_y4_c1_s04:
    $ y4_prepare_review("Y4-C1-S04",y4_review_preset_for("Y4-C1-S04",y4_preview_preset))
    jump y4_continue

label review_y4_c1_s05:
    $ y4_prepare_review("Y4-C1-S05",y4_review_preset_for("Y4-C1-S05",y4_preview_preset))
    jump y4_continue

label review_y4_c2_s01:
    $ y4_prepare_review("Y4-C2-S01",y4_review_preset_for("Y4-C2-S01",y4_preview_preset))
    jump y4_continue

label review_y4_c2_s02:
    $ y4_prepare_review("Y4-C2-S02",y4_review_preset_for("Y4-C2-S02",y4_preview_preset))
    jump y4_continue

label review_y4_c2_s03:
    $ y4_prepare_review("Y4-C2-S03",y4_review_preset_for("Y4-C2-S03",y4_preview_preset))
    jump y4_continue

label review_y4_c2_s04:
    $ y4_prepare_review("Y4-C2-S04",y4_review_preset_for("Y4-C2-S04",y4_preview_preset))
    jump y4_continue

label review_y4_c2_s05:
    $ y4_prepare_review("Y4-C2-S05",y4_review_preset_for("Y4-C2-S05",y4_preview_preset))
    jump y4_continue

label review_y4_c2_s06:
    $ y4_prepare_review("Y4-C2-S06",y4_review_preset_for("Y4-C2-S06",y4_preview_preset))
    jump y4_continue

label review_y4_c2_s07:
    $ y4_prepare_review("Y4-C2-S07",y4_review_preset_for("Y4-C2-S07",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s01:
    $ y4_prepare_review("Y4-C3-S01",y4_review_preset_for("Y4-C3-S01",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s02:
    $ y4_prepare_review("Y4-C3-S02",y4_review_preset_for("Y4-C3-S02",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s03:
    $ y4_prepare_review("Y4-C3-S03",y4_review_preset_for("Y4-C3-S03",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s04:
    $ y4_prepare_review("Y4-C3-S04",y4_review_preset_for("Y4-C3-S04",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s05:
    $ y4_prepare_review("Y4-C3-S05",y4_review_preset_for("Y4-C3-S05",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s06:
    $ y4_prepare_review("Y4-C3-S06",y4_review_preset_for("Y4-C3-S06",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s07:
    $ y4_prepare_review("Y4-C3-S07",y4_review_preset_for("Y4-C3-S07",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s08:
    $ y4_prepare_review("Y4-C3-S08",y4_review_preset_for("Y4-C3-S08",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s09:
    $ y4_prepare_review("Y4-C3-S09",y4_review_preset_for("Y4-C3-S09",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s10:
    $ y4_prepare_review("Y4-C3-S10",y4_review_preset_for("Y4-C3-S10",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s11:
    $ y4_prepare_review("Y4-C3-S11",y4_review_preset_for("Y4-C3-S11",y4_preview_preset))
    jump y4_continue

label review_y4_c3_s12:
    $ y4_prepare_review("Y4-C3-S12",y4_review_preset_for("Y4-C3-S12",y4_preview_preset))
    jump y4_continue

label review_y4_c4_s01:
    $ y4_prepare_review("Y4-C4-S01",y4_review_preset_for("Y4-C4-S01",y4_preview_preset))
    jump y4_continue

label review_y4_c4_s02:
    $ y4_prepare_review("Y4-C4-S02",y4_review_preset_for("Y4-C4-S02",y4_preview_preset))
    jump y4_continue

label review_y4_c4_s03:
    $ y4_prepare_review("Y4-C4-S03",y4_review_preset_for("Y4-C4-S03",y4_preview_preset))
    jump y4_continue

label review_y4_c4_s04:
    $ y4_prepare_review("Y4-C4-S04",y4_review_preset_for("Y4-C4-S04",y4_preview_preset))
    jump y4_continue

label review_y4_c4_s05:
    $ y4_prepare_review("Y4-C4-S05",y4_review_preset_for("Y4-C4-S05",y4_preview_preset))
    jump y4_continue

label review_y4_c4_s06:
    $ y4_prepare_review("Y4-C4-S06",y4_review_preset_for("Y4-C4-S06",y4_preview_preset))
    jump y4_continue

label review_y4_c4_s07:
    $ y4_prepare_review("Y4-C4-S07",y4_review_preset_for("Y4-C4-S07",y4_preview_preset))
    jump y4_continue

label review_y4_c5_s01:
    $ y4_prepare_review("Y4-C5-S01",y4_review_preset_for("Y4-C5-S01",y4_preview_preset))
    jump y4_continue

label review_y4_c5_s02:
    $ y4_prepare_review("Y4-C5-S02",y4_review_preset_for("Y4-C5-S02",y4_preview_preset))
    jump y4_continue

label review_y4_c5_s03:
    $ y4_prepare_review("Y4-C5-S03",y4_review_preset_for("Y4-C5-S03",y4_preview_preset))
    jump y4_continue

label review_y4_c5_s04:
    $ y4_prepare_review("Y4-C5-S04",y4_review_preset_for("Y4-C5-S04",y4_preview_preset))
    jump y4_continue

label review_y4_c5_s05:
    $ y4_prepare_review("Y4-C5-S05",y4_review_preset_for("Y4-C5-S05",y4_preview_preset))
    jump y4_continue

label review_y4_c6_s01:
    $ y4_prepare_review("Y4-C6-S01",y4_review_preset_for("Y4-C6-S01",y4_preview_preset))
    jump y4_continue

label review_y4_c6_s02:
    $ y4_prepare_review("Y4-C6-S02",y4_review_preset_for("Y4-C6-S02",y4_preview_preset))
    jump y4_continue

label review_y4_c6_s03:
    $ y4_prepare_review("Y4-C6-S03",y4_review_preset_for("Y4-C6-S03",y4_preview_preset))
    jump y4_continue

label review_y4_c6_s04:
    $ y4_prepare_review("Y4-C6-S04",y4_review_preset_for("Y4-C6-S04",y4_preview_preset))
    jump y4_continue

label review_y4_c7_s01:
    $ y4_prepare_review("Y4-C7-S01",y4_review_preset_for("Y4-C7-S01",y4_preview_preset))
    jump y4_continue

label review_y4_c7_s02:
    $ y4_prepare_review("Y4-C7-S02",y4_review_preset_for("Y4-C7-S02",y4_preview_preset))
    jump y4_continue

label review_y4_c7_s03:
    $ y4_prepare_review("Y4-C7-S03",y4_review_preset_for("Y4-C7-S03",y4_preview_preset))
    jump y4_continue

label review_y4_c7_s04:
    $ y4_prepare_review("Y4-C7-S04",y4_review_preset_for("Y4-C7-S04",y4_preview_preset))
    jump y4_continue

label review_y4_c7_s05:
    $ y4_prepare_review("Y4-C7-S05",y4_review_preset_for("Y4-C7-S05",y4_preview_preset))
    jump y4_continue

label review_y4_c8_s01:
    $ y4_prepare_review("Y4-C8-S01",y4_review_preset_for("Y4-C8-S01",y4_preview_preset))
    jump y4_continue

label review_y4_c8_s02:
    $ y4_prepare_review("Y4-C8-S02",y4_review_preset_for("Y4-C8-S02",y4_preview_preset))
    jump y4_continue

label review_y4_c8_s03:
    $ y4_prepare_review("Y4-C8-S03",y4_review_preset_for("Y4-C8-S03",y4_preview_preset))
    jump y4_continue

label review_y4_c8_s04:
    $ y4_prepare_review("Y4-C8-S04",y4_review_preset_for("Y4-C8-S04",y4_preview_preset))
    jump y4_continue

label review_y4_c8_s05:
    $ y4_prepare_review("Y4-C8-S05",y4_review_preset_for("Y4-C8-S05",y4_preview_preset))
    jump y4_continue

label review_y4_c8_s06:
    $ y4_prepare_review("Y4-C8-S06",y4_review_preset_for("Y4-C8-S06",y4_preview_preset))
    jump y4_continue

label review_y4_c8_s07:
    $ y4_prepare_review("Y4-C8-S07",y4_review_preset_for("Y4-C8-S07",y4_preview_preset))
    jump y4_continue

label review_y4_c8_s08:
    $ y4_prepare_review("Y4-C8-S08",y4_review_preset_for("Y4-C8-S08",y4_preview_preset))
    jump y4_continue

label review_y4_c8_s09:
    $ y4_prepare_review("Y4-C8-S09",y4_review_preset_for("Y4-C8-S09",y4_preview_preset))
    jump y4_continue

label review_y4_c1_s06:
    $ y4_prepare_review("Y4-C1-S06",y4_review_preset_for("Y4-C1-S06",y4_preview_preset))
    jump y4_continue

label review_y4_c1_s07:
    $ y4_prepare_review("Y4-C1-S07",y4_review_preset_for("Y4-C1-S07",y4_preview_preset))
    jump y4_continue

label review_y4_c5_s06:
    $ y4_prepare_review("Y4-C5-S06",y4_review_preset_for("Y4-C5-S06",y4_preview_preset))
    jump y4_continue

label review_y4_c5_s07:
    $ y4_prepare_review("Y4-C5-S07",y4_review_preset_for("Y4-C5-S07",y4_preview_preset))
    jump y4_continue

label review_y4_c2_s08:
    $ y4_prepare_review("Y4-C2-S08",y4_review_preset_for("Y4-C2-S08",y4_preview_preset))
    jump y4_continue
