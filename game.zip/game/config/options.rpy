init -100 python:
    gui.init(1280, 720)

define config.name = "Amortentia: A Hogwarts Love Story"
define config.version = "0.18.29"
define config.save_directory = "vn-foundation-m0-2026"
define config.window_title = "Amortentia: A Hogwarts Love Story"
define config.developer = False
define M33_QA_BUILD = False
# Switch to False for a release; both the debug UI and mutation API are gated.
define config.rollback_enabled = True
define config.history_length = 500
define config.check_conflicting_properties = True
define config.has_sound = True
define config.has_music = True
define config.has_voice = False
define config.preserve_volume_when_muted = True
define config.default_text_cps = 0
define config.default_afm_time = 15
define _game_menu_screen = "save"

# Web-only mitigation for the observed GL2 correct_pixel_perfect division by
# zero. Render text at the stable 1280x720 game resolution instead of aligning
# glyphs to a transient browser drawable size. Desktop keeps its default.
# See docs/M31_DELIVERY.md: the original trigger remains unconfirmed.
init python:
    if renpy.emscripten:
        config.drawable_resolution_text = False

init python:
    config.overlay_screens.append("vn_hud")
    build.name = "project_malfoid_y7"
    build.classify("game/fonts/SourceHanSans-LICENSE.txt", "all")
    build.classify("game/audio/AUDIO-CREDITS.txt", "all")
    build.classify("**.md", None)
    build.classify("**.py", None)
    build.classify("game/tests/**", None)
    build.classify("game/images/production/m2/*.png", None)
    # Unused Y3 design references stay in source, not the download.
    for _reference in ("harry_neutral", "hermione_neutral", "hermione_concerned"):
        build.classify("game/images/production/m3/" + _reference + ".png", None)
    build.classify("tests/**", None)
    build.classify("docs/**", None)
    build.classify("**.txt", None)

init python:
    build.classify("game/characters/y1_review_assets.*", None)
    build.classify("game/images/characters/**", None)
    for _old_art in ("harry_neutral", "carina_neutral", "carina_thoughtful", "hermione_neutral", "hermione_thoughtful", "ron_neutral", "first_encounter", "trio_friendship"):
        build.classify("game/images/production/" + _old_art + ".webp", None)
    build.classify("game/debug/**", None)
    build.classify("game/screens/y1_asset_review.*", None)

init python:
    for _replaced_m14r in ("carina_neutral", "carina_guarded", "carina_thoughtful", "carina_fitting", "first_encounter", "year_end", "malkin"):
        build.classify("game/images/production/m14r/" + _replaced_m14r + ".webp", None)
